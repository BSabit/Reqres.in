package kz.eub.smart.core.mybank.domain.model.transfer_self;

import java.util.List;

public record AccountsPaymentOut(
        BonusOut bonus,
        List<AccountSourceOut> cards
) {
}
