package kz.eub.smart.core.mybank.infrastructure.repository.grpc;

import kz.eub.smart.core.mybank.domain.model.credit.Credit;
import kz.eub.smart.core.mybank.domain.model.credit.CreditPayment;
import kz.eub.smart.core.mybank.domain.repository.CreditPaymentRepository;
import kz.eub.smart.core.mybank.infrastructure.mapper.CreditMapper;
import kz.eub.smart.core.mybank.infrastructure.mapper.CreditPaymentMapper;
import kz.eubank.grpc.EubAggregatorCoreMyBank;
import kz.eubank.grpc.MyBankInfoGrpc;
import lombok.RequiredArgsConstructor;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.springframework.stereotype.Repository;

import java.util.List;

@RequiredArgsConstructor
@Repository
public class CreditPaymentRepositoryImpl implements CreditPaymentRepository {

    @GrpcClient("dashboard")
    private MyBankInfoGrpc.MyBankInfoBlockingStub stub;
    private final CreditPaymentMapper mapper;

    @Override
    public List<String> getCarCreditNumbers(String iin) {
        return getLoansWithCarPledgeAwaitingWithdrawalRequest(iin).getLoanNumberList();
    }

    @Override
    public List<CreditPayment> getCreditPayments(List<String> creditNumbers) {
        return mapper.toDomain(getLoans(creditNumbers).getLoansList());
    }

    public EubAggregatorCoreMyBank.GetLoansWithCarPledgeAwaitingWithdrawalReply getLoansWithCarPledgeAwaitingWithdrawalRequest(String iin){
        EubAggregatorCoreMyBank.GetLoansWithCarPledgeAwaitingWithdrawalRequest request = EubAggregatorCoreMyBank.GetLoansWithCarPledgeAwaitingWithdrawalRequest
                .newBuilder()
                .setIin(iin)
                .build();
        return stub.getLoansWithCarPledgeAwaitingWithdrawal(request);
    }

    public EubAggregatorCoreMyBank.GetLoansReply getLoans(List<String> creditNumbers){
        EubAggregatorCoreMyBank.GetLoansRequest request = EubAggregatorCoreMyBank.GetLoansRequest
                .newBuilder()
                .addAllLoanNumber(creditNumbers)
                .build();
        return stub.getLoans(request);
    }
}
