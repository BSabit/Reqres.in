package kz.eub.smart.core.mybank.presentation.controller;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import kz.eub.smart.core.mybank.application.model.ErrorResponse;
import kz.eub.smart.core.mybank.core.component.UserDetails;
import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.core.exception.MyBankException;
import kz.eub.smart.core.mybank.domain.model.bank.Bank;
import kz.eub.smart.core.mybank.domain.use_case.GetBankUseCase;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static kz.eub.smart.core.mybank.core.constants.HeaderName.LANG_KEY;

@RequestMapping("/mybank")
@RestController
@AllArgsConstructor
@Tag(name = "AccountController", description = "API вывода страницы 'Мой банк'")
public class AccountController {

    private GetBankUseCase getBankUseCase;
    private UserDetails userDetails;

    @GetMapping
    @SecurityRequirement(name = "Bearer Authentication")
    @Operation(summary = "Мой банк", description = "Получение всех продуктов по пользователью")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK",
                    content = {@Content(mediaType = "application/json", schema = @Schema(implementation = Bank.class))}
            ),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}
            )
    })
    public ResponseEntity<?> getListOfAccount(@RequestHeader(value = LANG_KEY, defaultValue = "EN") LangKey lang) {
        try {
            return ResponseEntity.ok(getBankUseCase.invoke(userDetails.getUserId(), userDetails.getIin(), lang));
        }catch (MyBankException myBankException){
            return new ResponseEntity<>(new ErrorResponse(myBankException), HttpStatus.INTERNAL_SERVER_ERROR);
        }catch (Exception exception){
            return new ResponseEntity<>(new ErrorResponse(exception), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
