package kz.eub.smart.core.mybank.core.exception;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(enumAsRef = true)
public enum MyBankErrorCode {
    E_VD_400("error.validate"),                                         //ANNOTATION 400-499
    E_VD_401("error.validate.annotation_validate"),

    E_SM_500("error.system"),                                           //SYSTEM 500-599
    E_SM_501("error.system.object-to-json"),
    E_SM_502("error.system.json-to-object"),

    E_DB_600("error.db.object-not-found"),                              //DB 600-699
    E_DB_601("error.db.result-more-than-expect"),
    E_DB_602("error.db.exec.procedure"),
    E_DB_603("error.incorrect.field"),

    E_EX_700("error.external.response-error"),                          //EXTERNAL 700-799
    E_EX_701("error.external.system-not-available"),

    E_LG_800("error.logical"),                                          //LOGICAL 800-899
    E_LG_801("error.logical.invalid-data"),
    E_LG_802("error.logical.not-implemented");

    private final String message;

    private MyBankErrorCode(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
