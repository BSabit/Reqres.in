package kz.eub.smart.core.mybank.core.constants;

public enum AccountType {
    CURR,
    CARD,
    SAVE,
    BONS;

    public static boolean isCardAccount(String accountType) {
        return CARD.name().equals(accountType);
    }

    public static boolean isCurrOrSave(String accountType) {
        return SAVE.name().equals(accountType) || CURR.name().equals(accountType);
    }

}
