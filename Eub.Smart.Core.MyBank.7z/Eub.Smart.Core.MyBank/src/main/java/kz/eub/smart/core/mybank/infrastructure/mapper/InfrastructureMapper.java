package kz.eub.smart.core.mybank.infrastructure.mapper;

import kz.eub.smart.core.mybank.core.util.S3UrlUtil;
import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.infrastructure.entity.AccountCardEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING, uses = {S3UrlUtil.class})
public interface InfrastructureMapper {

    List<AccountCard> toDomain(List<AccountCardEntity> entities);

    @Mapping(target = "image", source = "accountCardEntity.imageUid", qualifiedByName = "buildImageUrl")
    AccountCard toDomain(AccountCardEntity accountCardEntity);


}
