package kz.eub.smart.core.mybank.domain.use_case;

import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.domain.model.credit.CreditInfo;

public interface GetCreditInfoUseCase {
    CreditInfo invoke(Long userId, String iin, LangKey langKey);
}
