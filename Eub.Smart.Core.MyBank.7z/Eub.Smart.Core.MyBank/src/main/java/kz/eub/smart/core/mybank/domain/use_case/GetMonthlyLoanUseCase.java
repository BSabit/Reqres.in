package kz.eub.smart.core.mybank.domain.use_case;

import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.domain.model.credit.Credit;
import kz.eub.smart.core.mybank.domain.model.credit.MonthlyLoan;

import java.util.List;
import java.util.Optional;

public interface GetMonthlyLoanUseCase {
    Optional<MonthlyLoan> invoke(List<Credit> credits, LangKey langKey);
}
