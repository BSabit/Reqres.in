package kz.eub.smart.core.mybank.domain.repository;

import kz.eub.smart.core.mybank.domain.model.bank.Bank;

public interface BankRepository {
    Bank getByUserId(Long userId);
}
