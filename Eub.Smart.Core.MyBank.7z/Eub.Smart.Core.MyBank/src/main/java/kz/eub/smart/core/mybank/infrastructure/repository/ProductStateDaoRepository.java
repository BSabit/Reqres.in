package kz.eub.smart.core.mybank.infrastructure.repository;

import kz.eub.smart.core.mybank.infrastructure.entity.ProductStateEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductStateDaoRepository extends JpaRepository<ProductStateEntity, Long> {

    @Query(nativeQuery = true, value = """
                     SELECT
                               ps.ProductState_ID          AS productStatusId,
                               ps.ProductStatusCode_IDREF  AS status,
                               CASE
                                 WHEN :lang = 'KK' THEN t.Term_KZ
                                 WHEN :lang = 'RU' THEN t.Term_RU
                                 ELSE                   t.Term_EN
                               END COLLATE DATABASE_DEFAULT AS title,
                               CASE
                                 WHEN :lang = 'KK' THEN t.Desc_KZ
                                 WHEN :lang = 'RU' THEN t.Desc_RU
                                 ELSE                   t.Desc_EN
                               END COLLATE DATABASE_DEFAULT AS [desc],
                               ps.Priority                  AS priority
                        FROM ProductState ps
                        LEFT JOIN Term t ON t.Term_ID = ps.Term_OUTREF
                        WHERE ps.ProductStatusCode_IDREF = 'insufficientMinimumBalance';
                    """)
    ProductStateEntity getReplenishDepositStatus(@Param("lang") String lang);

    @Query(nativeQuery = true, value = """
                     SELECT
                               ps.ProductState_ID          AS productStatusId,
                               ps.ProductStatusCode_IDREF  AS status,
                               CASE
                                 WHEN :lang = 'KK' THEN t.Term_KZ
                                 WHEN :lang = 'RU' THEN t.Term_RU
                                 ELSE                   t.Term_EN
                               END COLLATE DATABASE_DEFAULT AS title,
                               CASE
                                 WHEN :lang = 'KK' THEN t.Desc_KZ
                                 WHEN :lang = 'RU' THEN t.Desc_RU
                                 ELSE                   t.Desc_EN
                               END COLLATE DATABASE_DEFAULT AS [desc],
                               ps.Priority                  AS priority
                        FROM ProductState ps
                        LEFT JOIN Term t ON t.Term_ID = ps.Term_OUTREF
                        WHERE ps.ProductStatusCode_IDREF = 'bonusIsBlocked';
                    """)
    ProductStateEntity getBlockedBonusStatus(@Param("lang") String lang);

}
