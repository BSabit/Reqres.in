package kz.eub.smart.core.mybank.core.constants;

public interface BonusStatus {
    String UNKNOWN = "UNKNOWN";
    String ACTIVE = "ACTIVE";
    String CLOSED = "CLOSED";
    String SUSPENDED = "SUSPENDED";
    String LIMIT = "LIMIT";
}