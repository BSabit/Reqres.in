package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.domain.mapper.BonusAccountMapper;
import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.Application;
import kz.eub.smart.core.mybank.domain.model.bonus.Bonus;
import kz.eub.smart.core.mybank.domain.model.bonus.BonusBalanceInfo;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;
import kz.eub.smart.core.mybank.domain.repository.BonusBalanceRepository;
import kz.eub.smart.core.mybank.domain.repository.DetailsUrlRepository;
import kz.eub.smart.core.mybank.domain.repository.ProductStateRepository;
import kz.eub.smart.core.mybank.domain.use_case.GetBonusUseCase;
import kz.eub.smart.core.mybank.core.constants.AccountType;
import lombok.AllArgsConstructor;

import java.util.List;

import static kz.eub.smart.core.mybank.core.constants.BonusStatus.CLOSED;
import static kz.eub.smart.core.mybank.core.constants.BonusStatus.SUSPENDED;

@AllArgsConstructor
public class GetBonusUseCaseImpl implements GetBonusUseCase {

    private final BonusBalanceRepository bonusBalanceRepository;
    private final DetailsUrlRepository detailsUrlRepository;
    private final ProductStateRepository productStateRepository;


    @Override
    public Bonus invoke(List<AccountCard> accountCards, String iin, List<Application> applications, LangKey langKey) {
        if (hasApplicationForCard(applications) || hasCard(accountCards)) {

            var bonusAccount = accountCards
                    .stream()
                    .filter(accountCard -> AccountType.BONS.name().equals(accountCard.getAccountType()))
                    .findFirst();

            if (bonusAccount.isPresent()){
                var bonusBalance = bonusBalanceRepository.getBalance(iin);
                return BonusAccountMapper.getBonusAccount(bonusAccount.get(), bonusBalance, detailsUrlRepository.getBonusDetails(), getBonusStatus(bonusBalance, langKey));
            }
        }
        return null;
    }

    private boolean hasCard(List<AccountCard> accountCards) {
        return accountCards
                .stream()
                .anyMatch(accountCard ->  AccountType.CARD.name().equals(accountCard.getAccountType()) && accountCard.getCardId() != null && accountCard.isCardUserAccountUserSame());
    }

    private boolean hasApplicationForCard(List<Application> applications) {
        return applications
                .stream()
                .anyMatch(application -> AccountType.CARD.name().equals(application.getApplicationType()));
    }

    private ProductStatus getBonusStatus(BonusBalanceInfo bonusBalance, LangKey langKey){
        if (SUSPENDED.equals(bonusBalance.getStatus()) || CLOSED.equals(bonusBalance.getStatus())){
            return productStateRepository.getBlockedBonusStatus(langKey);
        }
        return null;
    }
}
