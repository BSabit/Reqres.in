package kz.eub.smart.core.mybank.domain.model.credit;

import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;
import lombok.Data;

@Data
public class CreditResponse {

    private Long id;
    private String image;
    private String title;
    private String link;
    private ProductStatus status;
    private Period period;
}
