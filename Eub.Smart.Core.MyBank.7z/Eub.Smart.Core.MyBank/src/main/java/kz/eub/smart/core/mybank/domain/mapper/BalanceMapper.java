package kz.eub.smart.core.mybank.domain.mapper;

import kz.eub.smart.core.mybank.domain.model.AccountBalance;
import kz.eub.smart.core.mybank.domain.model.Application;
import kz.eub.smart.core.mybank.domain.model.Balance;

import java.util.ArrayList;
import java.util.List;

public class BalanceMapper {

    public static Balance getCardBalance(AccountBalance accountBalance){
        return new Balance(accountBalance.getBalance(),accountBalance.getCurrency());
    }

    public static List<Balance> toCardBalance(Application application){
        List<Balance> balances = new ArrayList<>(1);
        Balance cardBalance = new Balance(application.getAmount(), application.getCurrency());
        balances.add(cardBalance);
        return balances;
    }

}
