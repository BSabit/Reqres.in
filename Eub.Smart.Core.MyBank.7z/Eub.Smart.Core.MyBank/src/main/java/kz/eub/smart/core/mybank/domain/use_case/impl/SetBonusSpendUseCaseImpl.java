package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.domain.repository.BonusSpendRepository;
import kz.eub.smart.core.mybank.domain.use_case.SetBonusSpendUseCase;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public class SetBonusSpendUseCaseImpl implements SetBonusSpendUseCase {

    private final BonusSpendRepository bonusSpendRepository;

    @Override
    public void invoke(String iin, boolean isSpending) {
        bonusSpendRepository.setSpend(iin, isSpending);
    }
}
