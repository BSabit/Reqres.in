package kz.eub.smart.core.mybank.domain.model.bank;

import kz.eub.smart.core.mybank.domain.model.OpenProduct;
import kz.eub.smart.core.mybank.domain.model.bonus.BannerBonus;
import kz.eub.smart.core.mybank.domain.model.bonus.Bonus;
import kz.eub.smart.core.mybank.domain.model.card.Card;
import kz.eub.smart.core.mybank.domain.model.credit.CreditResponse;
import kz.eub.smart.core.mybank.domain.model.credit.MonthlyLoan;
import kz.eub.smart.core.mybank.domain.model.current_account.Account;
import kz.eub.smart.core.mybank.domain.model.deposit.Deposit;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class Bank {

    private MonthlyLoan monthlyLoan;
    private MonthlyLoan monthlyLoanCard;
    private List<Card> installmentCards;
    private List<Card> cards;
    private Bonus bonus;
    private List<Deposit> deposits;
    private List<Account> accounts;
    private List<CreditResponse> credits;
    private List<OpenProduct> openProducts;
    private BannerBonus bannerBonus;

}
