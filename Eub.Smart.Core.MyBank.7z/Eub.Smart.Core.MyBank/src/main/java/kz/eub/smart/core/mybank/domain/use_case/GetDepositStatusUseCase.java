package kz.eub.smart.core.mybank.domain.use_case;

import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.domain.model.AccountBalance;
import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;

public interface GetDepositStatusUseCase {

    ProductStatus invoke(AccountCard accountCard, AccountBalance accountBalance, LangKey langKey);
}
