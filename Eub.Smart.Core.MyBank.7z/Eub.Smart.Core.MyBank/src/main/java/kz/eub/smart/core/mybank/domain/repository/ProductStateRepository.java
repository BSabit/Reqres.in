package kz.eub.smart.core.mybank.domain.repository;

import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;

public interface ProductStateRepository {

    ProductStatus getReplenishDepositStatus(LangKey langKey);

    ProductStatus getBlockedBonusStatus(LangKey langKey);
}
