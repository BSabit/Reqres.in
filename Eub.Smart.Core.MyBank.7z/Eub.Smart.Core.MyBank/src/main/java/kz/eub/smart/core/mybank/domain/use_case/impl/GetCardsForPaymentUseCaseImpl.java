package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.core.constants.AccountType;
import kz.eub.smart.core.mybank.core.constants.Currency;
import kz.eub.smart.core.mybank.core.exception.MyBankException;
import kz.eub.smart.core.mybank.core.util.S3UrlUtil;
import kz.eub.smart.core.mybank.domain.mapper.BalanceMapper;
import kz.eub.smart.core.mybank.domain.model.AccountBalance;
import kz.eub.smart.core.mybank.domain.model.Balance;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;
import kz.eub.smart.core.mybank.domain.model.transfer_self.AccountSourceOut;
import kz.eub.smart.core.mybank.domain.model.transfer_self.AccountSourceTargetIn;
import kz.eub.smart.core.mybank.domain.repository.CardBalanceRepository;
import kz.eub.smart.core.mybank.domain.use_case.GetCardsForPaymentUseCase;
import lombok.RequiredArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static kz.eub.smart.core.mybank.core.exception.MyBankErrorCode.E_EX_700;

@RequiredArgsConstructor
public class GetCardsForPaymentUseCaseImpl implements GetCardsForPaymentUseCase {

    private final CardBalanceRepository cardBalanceRepository;
    private final S3UrlUtil s3UrlUtil;

    @Override
    public List<AccountSourceOut> invoke(List<AccountSourceTargetIn> accounts) {

        var cardOutRefs = accounts.stream().map(AccountSourceTargetIn::getAccountOutRef).collect(Collectors.toSet());
        var cardBalances = cardBalanceRepository.getListBalances(cardOutRefs);

        return accounts
                .stream()
                .map(accountSourceTargetIn -> this.buildAccountSourceOut(accountSourceTargetIn, cardBalances))
                .toList();
    }

    private AccountSourceOut buildAccountSourceOut(AccountSourceTargetIn accountSourceTargetIn, List<AccountBalance> balances){
        var status = getProductStatus(accountSourceTargetIn);
        var balance = getBalance(accountSourceTargetIn, balances);
        var image = s3UrlUtil.buildImageUrl(accountSourceTargetIn.getImageUid());

        return AccountSourceOut.builder()
                .accountId(accountSourceTargetIn.getAccountId())
                .cardId(accountSourceTargetIn.getCardId())
                .title(accountSourceTargetIn.getProductTitle())
                .image(image)
                .number(accountSourceTargetIn.getCardMaskedNumber())
                .accountType(AccountType.valueOf(accountSourceTargetIn.getAccountType()))
                .status(status)
                .amount(balance)
                .build();
    }

    private Balance getBalance(AccountSourceTargetIn accountSourceTargetIn, List<AccountBalance> accountBalances) {
        return accountBalances
                .stream()
                .filter(accountBalance -> balanceBelongsAccount(accountBalance, accountSourceTargetIn)
                        && isKZT(accountBalance))
                .findFirst()
                .map(BalanceMapper::getCardBalance)
                .orElseThrow(() -> new MyBankException(E_EX_700, " GetCreditPayCardsUseCase no balance from bus card balance"));
    }

    private boolean balanceBelongsAccount(AccountBalance accountBalance, AccountSourceTargetIn accountSourceTargetIn) {
        return nonNull(accountSourceTargetIn.getAccountOutRef())
                && accountSourceTargetIn.getAccountOutRef().equals(accountBalance.getAccountOutref());
    }

    private boolean isKZT(AccountBalance accountBalance) {
        return Currency.KZT.equals(accountBalance.getCurrency().getCode());
    }

    private ProductStatus getProductStatus(AccountSourceTargetIn account) {
        if (isNull(account.getStatusType()))
            return null;

        return ProductStatus.builder()
                .type(account.getStatusType())
                .title(account.getStatusTitle())
                .build();
    }
}
