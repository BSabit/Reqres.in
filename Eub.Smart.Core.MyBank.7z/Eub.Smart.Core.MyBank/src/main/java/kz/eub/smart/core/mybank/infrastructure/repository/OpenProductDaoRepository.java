package kz.eub.smart.core.mybank.infrastructure.repository;

import kz.eub.smart.core.mybank.infrastructure.entity.OpenProductEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OpenProductDaoRepository extends JpaRepository<OpenProductEntity, Long> {

    @Query(nativeQuery = true, value = """
                    SELECT
                   	op.OpenProduct_ID                AS openProductId,
                   	op.Details_Url                   AS detailsLink,
                   	op.ProductType_IDREF             AS productType,
                   	CASE
                   		WHEN :lang = 'KK' THEN t.Term_KZ
                   		WHEN :lang = 'RU' THEN t.Term_RU
                   		ELSE                   t.Term_EN
                   	END  COLLATE DATABASE_DEFAULT    AS title,
                   	CASE
                   		WHEN :lang = 'KK' THEN t.Desc_KZ
                   		WHEN :lang = 'RU' THEN t.Desc_RU 
                   		ELSE                   t.Desc_EN
                   	END   COLLATE DATABASE_DEFAULT   AS description,
                   	md.FileUid                       AS imageUid
                    FROM OpenProduct op
                    LEFT JOIN Term t ON t.Term_ID = op.Term_OUTREF
                    LEFT JOIN MetaDocument md ON md.Target_ID = op.OpenProduct_ID AND md.Target_Table = 'OpenProduct' AND md.IsActive = 'true' AND md.LangKey = :lang
                    ORDER BY op.Priority ASC
                    """)
    List<OpenProductEntity> getOpenProducts(@Param("lang") String language);

}
