package kz.eub.smart.core.mybank.infrastructure.repository.impl;

import kz.eub.smart.core.mybank.domain.model.transfer_self.AccountSourceTargetIn;
import kz.eub.smart.core.mybank.domain.repository.PaymentCardsRepository;
import kz.eub.smart.core.mybank.infrastructure.repository.AccountSourceTargetDaoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@RequiredArgsConstructor
public class PaymentCardsRepositoryImpl implements PaymentCardsRepository {

    private final AccountSourceTargetDaoRepository accountSourceTargetRepository;

    @Override
    public List<AccountSourceTargetIn> getListOfAccounts(Long userId, String lang) {
        return accountSourceTargetRepository.getAccountsPayment(userId, lang);
    }
}
