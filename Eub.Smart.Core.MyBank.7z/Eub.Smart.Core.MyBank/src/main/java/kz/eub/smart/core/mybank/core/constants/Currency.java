package kz.eub.smart.core.mybank.core.constants;

public interface Currency {
    String KZT = "KZT";
    String USD = "USD";
    String EUR = "EUR";
    String RUB = "RUB";
    String GBP = "GBP";
    String CNY = "CNY";
    String AED = "AED";
    String TRY = "TRY";
    String CHF = "CHF";
    String MC1 = "MC1";
    String BNS = "BNS";
    String AUD = "AUD";
    String HKD = "HKD";
    String JPY = "JPY";
    String SGD = "SGD";
    String UZS = "UZS";
}