package kz.eub.smart.core.mybank.domain.use_case;

import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.credit.MonthlyLoan;

import java.util.List;

public interface GetCreditCardPaymentUseCase {
    MonthlyLoan invoke(List<AccountCard> accountCards, LangKey langKey);
}
