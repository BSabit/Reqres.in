package kz.eub.smart.core.mybank.core.constants;

public interface UserDetailsConstants {

    String PREFERRED_USERNAME = "phoneNumber";
    String USER_ID = "userId";
    String CLIENT_ID = "clientId";
    String IIN = "iin";
}
