package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.core.constants.AccountType;
import kz.eub.smart.core.mybank.core.exception.MyBankException;
import kz.eub.smart.core.mybank.core.util.S3UrlUtil;
import kz.eub.smart.core.mybank.domain.model.AccountBalance;
import kz.eub.smart.core.mybank.domain.model.Balance;
import kz.eub.smart.core.mybank.domain.model.Currency;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;
import kz.eub.smart.core.mybank.domain.model.transfer_self.AccountSourceTargetIn;
import kz.eub.smart.core.mybank.domain.model.transfer_self.AccountSourceTargetOut;
import kz.eub.smart.core.mybank.domain.repository.AccountSourceTargetRepository;
import kz.eub.smart.core.mybank.domain.repository.CardBalanceRepository;
import kz.eub.smart.core.mybank.domain.repository.DepositCurrentAccountBalanceRepository;
import kz.eub.smart.core.mybank.domain.use_case.GetAccountSourceTargetUseCase;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;


import static java.util.Objects.nonNull;
import static kz.eub.smart.core.mybank.core.constants.AccountType.CARD;
import static kz.eub.smart.core.mybank.core.constants.AccountType.isCurrOrSave;
import static kz.eub.smart.core.mybank.core.constants.ActionType.CRED;
import static kz.eub.smart.core.mybank.core.constants.ActionType.TSLF;
import static kz.eub.smart.core.mybank.core.exception.MyBankErrorCode.E_LG_800;
import static kz.eub.smart.core.mybank.core.util.StringUtil.last4;

@Service
@RequiredArgsConstructor
public class GetAccountSourceTargetUseCaseImpl implements GetAccountSourceTargetUseCase {

    private final AccountSourceTargetRepository accountSourceTargetRepository;
    private final CardBalanceRepository cardBalanceRepository;
    private final DepositCurrentAccountBalanceRepository depositCurrentAccountBalanceRepository;

    private final S3UrlUtil s3UrlUtil;

    @Override
    public List<AccountSourceTargetOut> invoke(Long userId) {


        var accountsSourceTargetIn = accountSourceTargetRepository.getAccounts(userId, List.of(TSLF, CRED));

        var accountsSaveOrCurr = getAccountsSaveOrCurr(accountsSourceTargetIn);
        var accountsWithoutCard = getAccountsWithoutCard(accountsSourceTargetIn);
        var accountsCard = getAccountsWithMainCard(accountsSourceTargetIn);

        return Stream.concat(accountsSaveOrCurr.stream(),
                        Stream.concat(accountsWithoutCard.stream(), accountsCard.stream()))
                .collect(Collectors.toList());
    }

    private List<AccountSourceTargetOut> getAccountsWithoutCard(List<AccountSourceTargetIn> accountsSourceTarget) {

        var accounts = accountsSourceTarget
                .stream()
                .filter(it -> CARD.name().equals(it.getAccountType()))
                .filter(AccountSourceTargetIn::hasNotCards)
                .toList();

        if(accounts.isEmpty()) return List.of();

        var accountOutRefs = accounts
                .stream()
                .map(AccountSourceTargetIn::getAccountOutRef)
                .collect(Collectors.toSet());

        var accountsBalance = cardBalanceRepository.getListBalances(accountOutRefs);

        return accounts
                .stream()
                .collect(Collectors.groupingBy(AccountSourceTargetIn::getAccountId, LinkedHashMap::new, Collectors.toList()))
                .values()
                .stream()
                .map(it -> mergeSourceTarget(it, accountsBalance))
                .toList();
    }

    private List<AccountSourceTargetOut> getAccountsSaveOrCurr(List<AccountSourceTargetIn> accountsSourceTarget) {

        var accounts = accountsSourceTarget
                .stream()
                .filter(it -> isCurrOrSave(it.getAccountType()))
                .toList();

        if(accounts.isEmpty()) return List.of();

        var accountOutRefs = accounts
                .stream()
                .map(AccountSourceTargetIn::getAccountOutRef)
                .collect(Collectors.toSet());

        var accountsBalance = depositCurrentAccountBalanceRepository.getListBalances(accountOutRefs);

        return accounts
                .stream()
                .collect(Collectors.groupingBy(AccountSourceTargetIn::getAccountId, LinkedHashMap::new, Collectors.toList()))
                .values()
                .stream()
                .map(it -> mergeSourceTarget(it, accountsBalance))
                .toList();
    }

    private List<AccountSourceTargetOut> getAccountsWithMainCard(List<AccountSourceTargetIn> accountsSourceTarget) {

        var cards = accountsSourceTarget
                .stream()
                .filter(AccountSourceTargetIn::hasCards)
                .filter(AccountSourceTargetIn::isNotMultiCurrency)
                .collect(Collectors.groupingBy(AccountSourceTargetIn::getConcatAccountIdAndActionId, LinkedHashMap::new, Collectors.toList()))
                .values()
                .stream()
                .map(it -> it.stream().max(Comparator.comparing(AccountSourceTargetIn::isBasic)
                        .thenComparing(AccountSourceTargetIn::additionalIsMy)
                        .thenComparing(AccountSourceTargetIn::getCardIdForSort)).orElseThrow())
                .toList();

        if(cards.isEmpty()) return List.of();

        var accountOutRefs = cards
                .stream()
                .map(AccountSourceTargetIn::getAccountOutRef)
                .collect(Collectors.toSet());

        var accountsBalance = cardBalanceRepository.getListBalances(accountOutRefs);

        return cards
                .stream()
                .collect(Collectors.groupingBy(AccountSourceTargetIn::getCardId, LinkedHashMap::new, Collectors.toList()))
                .values()
                .stream()
                .map(it -> mergeSourceTarget(it, accountsBalance))
                .toList();
    }

    private AccountSourceTargetOut mergeSourceTarget(List<AccountSourceTargetIn> accountsSourceTarget,
                                                     List<AccountBalance> accountsBalance) {
        var account = accountsSourceTarget
                .stream()
                .findAny()
                .orElseThrow(() -> new MyBankException(E_LG_800, "GetAccountSourceTargetUseCaseImpl mergeSourceTarget "));

        var accountBalance = accountsBalance
                .stream()
                .filter(it -> Objects.equals(it.getAccountOutref(), account.getAccountOutRef()))
                .findFirst()
                .orElseThrow(() -> new MyBankException(E_LG_800, "GetAccountSourceTargetUseCaseImpl mergeSourceTarget"));

        var status = ProductStatus.builder()
                .type(account.getStatusType())
                .title(account.getStatusTitle())
                .build();

        status = nonNull(status.getType()) ? status : null;

        return AccountSourceTargetOut.builder()
                .accountId(account.getAccountId())
                .cardId(account.getCardId())
                .title(account.getProductTitle())
                .image(s3UrlUtil.buildImageUrl(account.getImageUid()))
                .number(last4(account.getCardMaskedNumber()))
                .accountType(AccountType.valueOf(account.getAccountType()))
                .status(status)
                .amount(Balance.builder()
                        .value(accountBalance.getBalance())
                        .currency(Currency.builder()
                                .code(account.getCurrencyCode())
                                .symbol(account.getCurrencySymbol())
                                .build())
                        .build())
                .allowSource(accountsSourceTarget.stream().anyMatch(AccountSourceTargetIn::allowSource))
                .allowTarget(accountsSourceTarget.stream().anyMatch(AccountSourceTargetIn::allowTarget))
                .build();
    }
}

