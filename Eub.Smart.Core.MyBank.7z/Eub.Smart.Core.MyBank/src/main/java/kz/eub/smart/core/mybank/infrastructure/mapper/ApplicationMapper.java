package kz.eub.smart.core.mybank.infrastructure.mapper;

import kz.eub.smart.core.mybank.core.util.CurrencyUtil;
import kz.eub.smart.core.mybank.domain.model.Application;
import kz.eub.smart.core.mybank.infrastructure.entity.ApplicationEntity;
import kz.eub.smart.core.mybank.core.util.S3UrlUtil;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING, uses = {S3UrlUtil.class, CurrencyUtil.class})
public interface ApplicationMapper {

    List<Application> toDomain(List<ApplicationEntity> entities);

    @Mapping(target = "image", source = "entity.imageUid", qualifiedByName = "buildImageUrl")
    @Mapping(target = "currency", source = "currencyCode", qualifiedByName = "getCurrencyMap")
    Application toDomain(ApplicationEntity entity);

}
