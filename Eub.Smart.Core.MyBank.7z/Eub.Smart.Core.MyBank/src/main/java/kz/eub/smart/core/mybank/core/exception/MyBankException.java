package kz.eub.smart.core.mybank.core.exception;

import java.util.List;

public class MyBankException extends RuntimeException {

    public MyBankException(MyBankErrorCode myBankErrorCode, List<ErrorDto> errorDtos) {
        super(errorDtos.toString());
        this.myBankErrorCode = myBankErrorCode;
    }

    public MyBankException(MyBankErrorCode myBankErrorCode) {
        super(myBankErrorCode.getMessage());
        this.myBankErrorCode = myBankErrorCode;
    }

    public MyBankException(MyBankErrorCode myBankErrorCode, String additionalMessage) {
        super(myBankErrorCode.getMessage() + additionalMessage);
        this.myBankErrorCode = myBankErrorCode;
    }

    public MyBankException(MyBankErrorCode errorCode, Throwable throwable) {
        super(throwable);
        if (throwable.getCause() instanceof MyBankException se) {
            this.myBankErrorCode = se.getCode();
            this.errorMessage = se.getErrorMessage();
        } else {
            this.myBankErrorCode = errorCode;
        }
    }
    private final MyBankErrorCode myBankErrorCode;
    private String errorMessage;
    public String getErrorMessage() {
        return errorMessage;
    }


    public MyBankErrorCode getCode() {
        return myBankErrorCode;
    }
}
