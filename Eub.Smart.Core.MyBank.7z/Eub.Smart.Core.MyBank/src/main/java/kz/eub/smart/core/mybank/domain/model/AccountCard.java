package kz.eub.smart.core.mybank.domain.model;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

@Data
public class AccountCard {
    private Long accountId;
    private Long parentAccountId;
    private String accountNumber;
    private String currencyCode;
    private Long accountUserId;
    private Long accountOutref;
    private Long cardUserId;
    private String accountType;
    private Long cardId;
    private String cardMaskedNumber;
    private Boolean isBasic;
    private BigDecimal minBalance;
    private String image;
    private Boolean isInstallment;
    private String productTitle;
    private String subProductTitle;
    private String statusTitle;
    private String statusType;
    private Integer statusPriority;
    private Date dateOpened;

    public boolean isBasic(){
        return this.getIsBasic() != null && this.getIsBasic();
    }

    public boolean additionalIsMy(){
        return this.getAccountUserId().equals(this.getCardUserId());
    }

    public boolean isCardUserAccountUserSame(){
        return  accountUserId != null && accountUserId.equals(cardUserId);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AccountCard)) return false;
        AccountCard that = (AccountCard) o;
        return Objects.equals(getAccountId(), that.getAccountId());
    }

    public Long getCardIdForSort(){
        if (this.getCardId() == null)
            return 0L;
        return this.getCardId();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getAccountId());
    }
}
