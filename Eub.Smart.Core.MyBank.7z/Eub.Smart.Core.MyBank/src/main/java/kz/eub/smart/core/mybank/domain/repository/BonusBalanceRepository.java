package kz.eub.smart.core.mybank.domain.repository;

import kz.eub.smart.core.mybank.domain.model.AccountBalance;
import kz.eub.smart.core.mybank.domain.model.bonus.BonusBalanceInfo;

import java.util.List;
import java.util.Set;

public interface BonusBalanceRepository {
    BonusBalanceInfo getBalance(String iin);
}
