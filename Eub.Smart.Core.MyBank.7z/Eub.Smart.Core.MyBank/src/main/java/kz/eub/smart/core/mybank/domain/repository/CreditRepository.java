package kz.eub.smart.core.mybank.domain.repository;

import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.domain.model.credit.Credit;
import java.util.List;

public interface CreditRepository {

    List<Credit> getListOfCredits(Long userId, LangKey langKey);

    List<Credit> getListOfCarCredits(List<String> carCreditNumbers, LangKey langKey);

}
