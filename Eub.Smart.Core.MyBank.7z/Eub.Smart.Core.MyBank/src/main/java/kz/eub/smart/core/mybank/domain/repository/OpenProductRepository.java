package kz.eub.smart.core.mybank.domain.repository;

import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.domain.model.OpenProduct;

import java.util.List;

public interface OpenProductRepository {

    List<OpenProduct> getAll(LangKey langKey);

}
