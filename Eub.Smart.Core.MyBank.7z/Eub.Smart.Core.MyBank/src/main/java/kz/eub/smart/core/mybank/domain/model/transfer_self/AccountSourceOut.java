package kz.eub.smart.core.mybank.domain.model.transfer_self;

import kz.eub.smart.core.mybank.core.constants.AccountType;
import kz.eub.smart.core.mybank.domain.model.Balance;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AccountSourceOut {
    private Long accountId;
    private Long cardId;
    private String title;
    private String image;
    private String number;
    private AccountType accountType;
    private ProductStatus status;
    private Balance amount;
}
