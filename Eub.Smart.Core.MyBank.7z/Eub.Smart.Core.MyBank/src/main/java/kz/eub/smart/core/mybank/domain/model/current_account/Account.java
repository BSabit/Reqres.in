package kz.eub.smart.core.mybank.domain.model.current_account;

import kz.eub.smart.core.mybank.domain.model.Balance;
import lombok.Data;

@Data
public class Account {

    private Long id;
    private Balance amount;
    private String image;
    private String title;
    private ProductStatus status;
    private String link;
}
