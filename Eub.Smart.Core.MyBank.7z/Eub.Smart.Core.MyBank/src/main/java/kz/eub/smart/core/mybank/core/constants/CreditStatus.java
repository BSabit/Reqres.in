package kz.eub.smart.core.mybank.core.constants;

public interface CreditStatus {
    String PAR = "PAR";
    String TAR = "TAR";
    String EP = "EP";
}
