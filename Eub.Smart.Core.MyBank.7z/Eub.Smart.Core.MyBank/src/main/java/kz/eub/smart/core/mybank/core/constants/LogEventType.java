package kz.eub.smart.core.mybank.core.constants;

public interface LogEventType {

    String REST = "REST";
    String EXTERNAL_CALL_gRPC = "External_Call_Grpc";
    String GATEWAY = "gateway_protocol.Gateway";
}
