package kz.eub.smart.core.mybank.infrastructure.repository.impl;


import kz.eub.smart.core.mybank.core.util.LangUtil;
import kz.eub.smart.core.mybank.domain.model.transfer_self.AccountSourceTargetIn;
import kz.eub.smart.core.mybank.domain.repository.AccountSourceTargetRepository;
import kz.eub.smart.core.mybank.infrastructure.repository.AccountSourceTargetDaoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@RequiredArgsConstructor
public class AccountSourceTargetRepositoryImpl implements AccountSourceTargetRepository {

    private final AccountSourceTargetDaoRepository accountSourceTargetDaoRepository;

    @Override
    public List<AccountSourceTargetIn> getAccounts(Long userId, List<String> listOfAction) {
        return accountSourceTargetDaoRepository.getAccounts(userId, LangUtil.getCurrentLocaleString());
    }
}
