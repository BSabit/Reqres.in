package kz.eub.smart.core.mybank.domain.model.transfer_self;


import java.util.Date;

import static kz.eub.smart.core.mybank.core.constants.AccountType.isCardAccount;
import static kz.eub.smart.core.mybank.core.constants.ActionType.CRED;
import static kz.eub.smart.core.mybank.core.constants.ActionType.TSLF;

public interface AccountSourceTargetIn {
    String getAccountType();
    Long getAccountId();
    Long getParentAccountId();
    Long getAccountOutRef();
    Long getAccountUserId();
    Long getCardUserId();
    Long getCardId();
    String getCardMaskedNumber();
    Boolean getIsMultiCurrency();
    Boolean getIsInstallment();
    Boolean getIsBasic();
    Boolean getMinBalance();
    Date getDateOpened();
    String getAccountNumber();
    String getStatusTitle();
    String getStatusType();
    Integer getStatusPriority();
    String getCurrencySymbol();
    String getCurrencyCode();
    String getImageUid();
    String getProductTitle();
    String getSubProductTitle();
    String getActionId();

    default boolean isBasic(){
        return this.getIsBasic() != null && this.getIsBasic();
    }

    default boolean additionalIsMy(){
        return this.getAccountUserId().equals(this.getCardUserId());
    }

    default boolean hasNotCards() {
        return this.getCardId() == null;
    }

    default boolean hasCards() {
        return  this.getCardId() != null;
    }

    default boolean allowSource() {
        if(isCardAccount(getAccountType())) {
            return TSLF.equals(getActionId()) && (getIsBasic() || additionalIsMy());
        }
        else{
            return TSLF.equals(getActionId());
        }
    }

    default boolean allowTarget() {
        return CRED.equals(getActionId());
    }

    default boolean isNotMultiCurrency() {
        return !getIsMultiCurrency();
    }

    default Long getCardIdForSort(){
        if (this.getCardId() == null)
            return 0L;
        return this.getCardId();
    }

    default String getConcatAccountIdAndActionId() {
        return getAccountId() + " " + getActionId();
    }
}

