package kz.eub.smart.core.mybank.domain.repository;

import kz.eub.smart.core.mybank.domain.model.credit.CreditPayment;

import java.util.List;

public interface CreditPaymentRepository {

    List<String> getCarCreditNumbers(String iin);

    List<CreditPayment> getCreditPayments(List<String> creditNumbers);

}
