package kz.eub.smart.core.mybank.domain.repository;

public interface BonusSpendRepository {

    void setSpend(String iin, boolean isSpending);

}
