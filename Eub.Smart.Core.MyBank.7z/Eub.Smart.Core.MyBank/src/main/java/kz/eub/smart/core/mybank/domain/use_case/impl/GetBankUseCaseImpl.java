package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.bank.Bank;
import kz.eub.smart.core.mybank.domain.repository.*;
import kz.eub.smart.core.mybank.domain.use_case.*;
import kz.eub.smart.core.mybank.core.constants.AccountType;
import lombok.AllArgsConstructor;

import java.util.stream.Collectors;

@AllArgsConstructor
public class GetBankUseCaseImpl implements GetBankUseCase {

    private final GetAccountsUseCase getAccountsUseCase;
    private final GetDepositsUseCase getDepositsUseCase;
    private final GetCardsUseCase getCardsUseCase;
    private final GetBonusUseCase getBonusUseCase;
    private final GetCardApplicationsUseCase getCardApplicationsUseCase;
    private final GetDepositApplicationsUseCase getDepositApplicationsUseCase;
    private final GetCurrentAccountApplicationsUseCase getCurrentAccountApplicationsUseCase;
    private final GetOpenProductsUseCase getOpenProductsUseCase;
    private final GetBannerBonusUseCase getBannerBonusUseCase;
    private final GetCreditInfoUseCase getCreditInfoUseCase;
    private final GetCreditCardPaymentUseCase getCreditCardPaymentUseCase;

    private final AccountCardRepository accountCardRepository;
    private final CardBalanceRepository cardBalanceRepository;
    private final DepositCurrentAccountBalanceRepository depositCurrentAccountBalanceRepository;
    private final ApplicationRepository applicationRepository;
    private final OpenProductRepository openProductRepository;


    @Override
    public Bank invoke(Long userId, String iin, LangKey langKey) {

        var accountCards = accountCardRepository.getListOfAccountCard(userId, langKey);
        var depositAccountOutrefs = accountCards.stream().filter(acc -> acc.getAccountType().equals(AccountType.SAVE.name()) || acc.getAccountType().equals(AccountType.CURR.name())).map(AccountCard::getAccountOutref).collect(Collectors.toSet());
        var cardOutrefs = accountCards.stream().filter(acc -> acc.getAccountType().equals(AccountType.CARD.name())).map(AccountCard::getAccountOutref).collect(Collectors.toSet());
        var cardBalances = cardBalanceRepository.getListBalances(cardOutrefs);
        var depCurrBalances = depositCurrentAccountBalanceRepository.getListBalances(depositAccountOutrefs);

        var applications = applicationRepository.getApplications(userId, langKey);
        var allCards = getCardApplicationsUseCase.invoke(applications);
        var allDeposits = getDepositApplicationsUseCase.invoke(applications);
        var allAccounts = getCurrentAccountApplicationsUseCase.invoke(applications);

        var installmentCards = getCardsUseCase.invoke(accountCards, cardBalances ,true);
        var cards = getCardsUseCase.invoke(accountCards, cardBalances, false);
        var accounts = getAccountsUseCase.invoke(accountCards, depCurrBalances);
        var deposits = getDepositsUseCase.invoke(accountCards, depCurrBalances, langKey);
        allCards.addAll(cards);
        allAccounts.addAll(accounts);
        allDeposits.addAll(deposits);

        var openProducts = openProductRepository.getAll(langKey);
        var creditInfo = getCreditInfoUseCase.invoke(userId, iin, langKey);

        return Bank.builder()
                .monthlyLoan(creditInfo.getMonthlyLoan().orElse(null))
                .monthlyLoanCard(getCreditCardPaymentUseCase.invoke(accountCards, langKey))
                .accounts(allAccounts)
                .cards(allCards)
                .deposits(allDeposits)
                .bonus(getBonusUseCase.invoke(accountCards, iin, applications, langKey))
                .installmentCards(installmentCards)
                .credits(creditInfo.getCreditResponses())
                .openProducts(getOpenProductsUseCase.invoke(openProducts, accountCards, applications))
                .bannerBonus(getBannerBonusUseCase.invoke(openProducts, accountCards, applications))
                .build();

    }
}
