package kz.eub.smart.core.mybank.domain.model.credit;

import lombok.Data;

@Data
public class MonthlyLoanStatus {
    private String type;
    private String title;
}
