package kz.eub.smart.core.mybank.domain.mapper;

import kz.eub.smart.core.mybank.domain.model.Application;
import kz.eub.smart.core.mybank.domain.model.Balance;
import kz.eub.smart.core.mybank.domain.model.current_account.Account;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;

public class AccountApplicationMapper {

    public static Account toAccount(Application application, String detailsLink) {
        Account account = new Account();
        account.setId(application.getApplicationId());
        account.setTitle(application.getTitle());
        account.setAmount(new Balance(application.getAmount(), application.getCurrency()));
        account.setStatus(new ProductStatus(application.getStatusType(), application.getStatusTitle()));
        account.setImage(application.getImage());
        account.setLink(detailsLink);
        return account;
    }

}
