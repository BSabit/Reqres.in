package kz.eub.smart.core.mybank.infrastructure.repository.impl;

import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.domain.model.credit.Credit;
import kz.eub.smart.core.mybank.domain.repository.CreditRepository;
import kz.eub.smart.core.mybank.infrastructure.mapper.CreditMapper;
import kz.eub.smart.core.mybank.infrastructure.repository.CreditDaoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;

@RequiredArgsConstructor
@Repository
public class CreditsRepositoryImpl implements CreditRepository {

    private final CreditDaoRepository creditDaoRepository;
    private final CreditMapper creditMapper;

    @Override
    public List<Credit> getListOfCredits(Long userId, LangKey langKey) {
        return creditMapper.toDomain(creditDaoRepository.getCredits(userId, langKey.name()));
    }

    @Override
    public List<Credit> getListOfCarCredits(List<String> carCreditNumbers, LangKey langKey) {
        return creditMapper.toDomain(creditDaoRepository.getCarCredits(carCreditNumbers,langKey.name()));
    }
}
