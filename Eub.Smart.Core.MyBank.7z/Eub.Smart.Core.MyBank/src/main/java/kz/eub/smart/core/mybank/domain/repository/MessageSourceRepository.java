package kz.eub.smart.core.mybank.domain.repository;

import java.util.List;
import java.util.Locale;

public interface MessageSourceRepository {

    String getMessage(String bundleCode, List<Object> args, Locale locale);
    String getMessage(String bundleCode, Object args, Locale locale);
    String getMessage(String bundleCode, Locale locale);
}
