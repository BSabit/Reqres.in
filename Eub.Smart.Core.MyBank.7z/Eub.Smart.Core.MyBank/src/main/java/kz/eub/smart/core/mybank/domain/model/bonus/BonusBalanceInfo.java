package kz.eub.smart.core.mybank.domain.model.bonus;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class BonusBalanceInfo {
    private BigDecimal amount;
    private Boolean spendIsAllowed;
    private String status;
}
