package kz.eub.smart.core.mybank.core.constants;

public interface CreditPaymentStatus {
    String EXPIRED = "EXPIRED";
    String PAID = "PAID";
    String WAITING = "WAITING";
}
