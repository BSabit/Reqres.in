package kz.eub.smart.core.mybank.domain.repository;

import kz.eub.smart.core.mybank.domain.model.credit.CreditCardPayment;

public interface CreditCardPaymentRepository {
    CreditCardPayment getCreditCardPayment(String accountNumber);
}
