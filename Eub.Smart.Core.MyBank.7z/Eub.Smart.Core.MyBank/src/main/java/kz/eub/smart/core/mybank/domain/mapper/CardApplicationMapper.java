package kz.eub.smart.core.mybank.domain.mapper;

import kz.eub.smart.core.mybank.domain.model.Application;
import kz.eub.smart.core.mybank.domain.model.Balance;
import kz.eub.smart.core.mybank.domain.model.card.Card;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;

import java.util.List;

public class CardApplicationMapper {

    public static Card getCard(Application application, List<Balance> balances, String detailsLink) {
        Card card = new Card();
        card.setId(application.getApplicationId());
        card.setStatus(new ProductStatus(application.getStatusType(), application.getStatusTitle()));
        card.setAmounts(balances);
        card.setTitle(application.getTitle());
        card.setImage(application.getImage());
        card.setNumber("");
        card.setLink(detailsLink);
        return card;
    }

}
