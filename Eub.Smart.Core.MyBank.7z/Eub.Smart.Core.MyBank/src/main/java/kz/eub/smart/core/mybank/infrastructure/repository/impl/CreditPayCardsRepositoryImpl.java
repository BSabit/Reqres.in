package kz.eub.smart.core.mybank.infrastructure.repository.impl;

import kz.eub.smart.core.mybank.domain.model.transfer_self.AccountSourceTargetIn;
import kz.eub.smart.core.mybank.domain.repository.CreditPayCardsRepository;
import kz.eub.smart.core.mybank.infrastructure.repository.AccountSourceTargetDaoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@RequiredArgsConstructor
public class CreditPayCardsRepositoryImpl implements CreditPayCardsRepository {

    private final AccountSourceTargetDaoRepository accountSourceTargetDaoRepository;

    @Override
    public List<AccountSourceTargetIn> getListOfAccounts(Long userId, String lang) {
        return accountSourceTargetDaoRepository.getAccountsCreditPay(userId, lang);
    }
}
