package kz.eub.smart.core.mybank.presentation.controller;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import kz.eub.smart.core.mybank.application.model.ErrorResponse;
import kz.eub.smart.core.mybank.core.component.UserDetails;
import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.core.exception.MyBankException;
import kz.eub.smart.core.mybank.domain.model.transfer_self.AccountSourceOut;
import kz.eub.smart.core.mybank.domain.model.transfer_self.AccountSourceTargetOut;
import kz.eub.smart.core.mybank.domain.use_case.GetAccountListTransferLocalUseCase;
import kz.eub.smart.core.mybank.domain.use_case.GetAccountSourceTargetUseCase;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static kz.eub.smart.core.mybank.core.constants.HeaderName.CORRELATION_ID;
import static kz.eub.smart.core.mybank.core.constants.HeaderName.LANG_KEY;

@RequestMapping("/mybank")
@RestController
@AllArgsConstructor
@Tag(name = "TransferController", description = "API вывода аккаунтов для Transfer")
public class TransferController {

    private final GetAccountSourceTargetUseCase getAccountSourceTargetUseCase;
    private final GetAccountListTransferLocalUseCase getAccountListTransferLocalUseCase;
    private UserDetails userDetails;


    @SecurityRequirement(name = "Bearer Authentication")
    @Operation(description = "Получение списка карт и счетов")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Успешный запрос",
                    content = @Content(array = @ArraySchema(schema = @Schema(implementation = AccountSourceTargetOut.class)))),

            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}
            )
    })
    @GetMapping("/transfer-self")
    public ResponseEntity<?> getAccountList(@RequestHeader(CORRELATION_ID) String correlationId,
                                                                       @RequestHeader(value = LANG_KEY, defaultValue = "EN") LangKey lang) {
        try {
            var response = getAccountSourceTargetUseCase.invoke(userDetails.getUserId());
            return ResponseEntity.ok(response);
        } catch (MyBankException myBankException) {
            return new ResponseEntity<>(new ErrorResponse(myBankException), HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception exception) {
            return new ResponseEntity<>(new ErrorResponse(exception), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @SecurityRequirement(name = "Bearer Authentication")
    @Operation(description = "Получение списка карт и счетов")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Успешный запрос",
                    content = @Content(array = @ArraySchema(schema = @Schema(implementation = AccountSourceOut.class)))),

            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}
            )
    })
    @GetMapping("/transfer-local")
    public ResponseEntity<?> getAccountListLocal(@RequestHeader(CORRELATION_ID) String correlationId,
                                                                 @RequestHeader(value = LANG_KEY, defaultValue = "EN") LangKey lang) {
        try {
            var response = getAccountListTransferLocalUseCase.invoke(userDetails.getUserId());
            return ResponseEntity.ok(response);
        } catch (MyBankException myBankException) {
            return new ResponseEntity<>(new ErrorResponse(myBankException), HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception exception) {
            return new ResponseEntity<>(new ErrorResponse(exception), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
