package kz.eub.smart.core.mybank.domain.mapper;


import kz.eub.smart.core.mybank.domain.model.AccountBalance;
import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.Balance;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;
import kz.eub.smart.core.mybank.domain.model.deposit.Deposit;

public class DepositMapper {

    public static Deposit getDeposit(AccountCard accountCard, AccountBalance accountBalance, ProductStatus productStatus, String detailsLink) {
        Deposit deposit = new Deposit();
        deposit.setTitle(accountCard.getProductTitle());
        deposit.setAmount(new Balance(accountBalance.getBalance(), accountBalance.getCurrency()));
        deposit.setId(accountCard.getAccountId());
        deposit.setImage(accountCard.getImage());
        deposit.setStatus(productStatus);
        deposit.setLink(detailsLink);
        return deposit;
    }
}
