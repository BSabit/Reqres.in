package kz.eub.smart.core.mybank.domain.use_case;

import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.Application;
import kz.eub.smart.core.mybank.domain.model.OpenProduct;

import java.util.List;

public interface GetOpenProductsUseCase {

    List<OpenProduct> invoke(List<OpenProduct> openProducts, List<AccountCard> accountCards, List<Application> applications);

}
