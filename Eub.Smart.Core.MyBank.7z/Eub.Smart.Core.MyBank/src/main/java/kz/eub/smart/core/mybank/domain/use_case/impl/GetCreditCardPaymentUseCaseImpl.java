package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.core.constants.CreditPaymentStatus;
import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.core.util.LangUtil;
import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.credit.CreditCardPayment;
import kz.eub.smart.core.mybank.domain.model.credit.MonthlyLoan;
import kz.eub.smart.core.mybank.domain.repository.CreditCardPaymentRepository;
import kz.eub.smart.core.mybank.domain.repository.DetailsUrlRepository;
import kz.eub.smart.core.mybank.domain.repository.MessageSourceRepository;
import kz.eub.smart.core.mybank.domain.use_case.GetCreditCardPaymentUseCase;
import lombok.RequiredArgsConstructor;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

import static kz.eub.smart.core.mybank.domain.constant.BundleCode.*;


@RequiredArgsConstructor
public class GetCreditCardPaymentUseCaseImpl implements GetCreditCardPaymentUseCase {

    private final CreditCardPaymentRepository creditCardPaymentRepository;
    private final DetailsUrlRepository detailsUrlRepository;
    private final MessageSourceRepository messageSourceRepository;
    private static final String KZT_SYMBOL = "₸";

    @Override
    public MonthlyLoan invoke(List<AccountCard> accountCards, LangKey langKey) {
        var creditCard = accountCards
                .stream()
                .sorted(Comparator.comparing(AccountCard::getDateOpened, Comparator.reverseOrder()))
                .filter(accountCard -> accountCard.getIsInstallment() != null && accountCard.getIsInstallment())
                .findFirst();

        if (creditCard.isPresent()){
            var creditCardPayment = creditCardPaymentRepository.getCreditCardPayment(creditCard.get().getAccountNumber());
            if (isNotPaid(creditCardPayment)){
                return MonthlyLoan.builder()
                        .title(getFormattedAmount(creditCardPayment))
                        .status(creditCardPayment.getStatus())
                        .description(getDescription(creditCardPayment, creditCard.get(), langKey))
                        .link(detailsUrlRepository.getCreditCardPay(creditCard.get().getCardId()))
                        .build();
            }
        }
        return null;
    }

    private boolean isNotPaid(CreditCardPayment creditCardPayment) {
        return !CreditPaymentStatus.PAID.equals(creditCardPayment.getStatus());
    }

    private String getFormattedAmount(CreditCardPayment creditCardPayment) {
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.getDefault());
        symbols.setGroupingSeparator(' ');
        DecimalFormat df = new DecimalFormat("#,##0.############", symbols);
        return df.format(creditCardPayment.getAmount()) + " " + KZT_SYMBOL;
    }

    private String getDescription(CreditCardPayment creditCardPayment, AccountCard accountCard, LangKey langKey) {
        if (isExpired(creditCardPayment)){
            return messageSourceRepository.getMessage(MONTHLY_LOAN_EXPIRED, LangUtil.get(langKey));
        }
        return messageSourceRepository.getMessage(MONTHLY_LOAN_PAY_CARD, Arrays.asList(accountCard.getProductTitle(), getFormattedDate(creditCardPayment)), LangUtil.get(langKey));
    }

    private boolean isExpired(CreditCardPayment creditCardPayment) {
        return CreditPaymentStatus.EXPIRED.equals(creditCardPayment.getStatus());
    }

    private String getFormattedDate(CreditCardPayment creditCardPayment) {
        SimpleDateFormat formatter = new SimpleDateFormat("MM.dd");
        return formatter.format(creditCardPayment.getDueDate());
    }

}
