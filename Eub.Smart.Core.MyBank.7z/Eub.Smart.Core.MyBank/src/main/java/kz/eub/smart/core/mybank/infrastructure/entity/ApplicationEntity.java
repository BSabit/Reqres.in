package kz.eub.smart.core.mybank.infrastructure.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Getter
@Setter
public class ApplicationEntity {

    @Id
    private Long applicationId;
    private String applicationType;
    private String statusTitle;
    private String statusType;
    private String imageUid;
    private String title;
    private String currencyCode;
    private BigDecimal amount;
    private Date dateCreated;

}
