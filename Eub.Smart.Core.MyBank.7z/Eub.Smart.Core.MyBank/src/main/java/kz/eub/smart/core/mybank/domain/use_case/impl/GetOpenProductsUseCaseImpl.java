package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.core.constants.AccountType;
import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.Application;
import kz.eub.smart.core.mybank.domain.model.OpenProduct;
import kz.eub.smart.core.mybank.domain.use_case.GetOpenProductsUseCase;
import lombok.AllArgsConstructor;

import java.util.List;

@AllArgsConstructor
public class GetOpenProductsUseCaseImpl implements GetOpenProductsUseCase {

    @Override
    public List<OpenProduct> invoke(List<OpenProduct> openProducts, List<AccountCard> accountCards, List<Application> applications) {
        return openProducts
                .stream()
                .filter(openProduct -> !AccountType.BONS.name().equals(openProduct.getProductType()) && !hasAccountCard(openProduct.getProductType(), accountCards) && !hasApplication(openProduct.getProductType(), applications))
                .toList();

    }

    private boolean hasAccountCard(String productType, List<AccountCard> accountCards) {
        return accountCards
                .stream()
                .anyMatch(accountCard -> accountCard.getAccountType().equals(productType)
                        && hasCard(accountCard));
    }

    private boolean hasCard(AccountCard accountCard) {
        return !AccountType.CARD.name().equals(accountCard.getAccountType()) || accountCard.getCardId() != null;
    }

    private boolean hasApplication(String productType,List<Application> applications) {
        return applications
                .stream()
                .anyMatch(application -> productType.equals(application.getApplicationType()));
    }
}
