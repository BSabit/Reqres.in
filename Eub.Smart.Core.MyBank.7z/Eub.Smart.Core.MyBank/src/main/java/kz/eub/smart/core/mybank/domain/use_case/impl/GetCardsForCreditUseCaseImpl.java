package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.core.util.LangUtil;
import kz.eub.smart.core.mybank.domain.model.transfer_self.AccountSourceOut;
import kz.eub.smart.core.mybank.domain.repository.CreditPayCardsRepository;
import kz.eub.smart.core.mybank.domain.use_case.GetCardsForCreditUseCase;
import kz.eub.smart.core.mybank.domain.use_case.GetCardsForPaymentUseCase;
import lombok.RequiredArgsConstructor;

import java.util.List;

@RequiredArgsConstructor
public class GetCardsForCreditUseCaseImpl implements GetCardsForCreditUseCase {

    private final CreditPayCardsRepository creditPayCardsRepository;
    private final GetCardsForPaymentUseCase getCardsForPaymentUseCase;

    @Override
    public List<AccountSourceOut> invoke(Long userId) {
        return getCardsForPaymentUseCase.invoke(creditPayCardsRepository.getListOfAccounts(userId, LangUtil.getCurrentLocaleString()));
    }
}
