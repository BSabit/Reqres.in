package kz.eub.smart.core.mybank.domain.model.credit;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class CreditCardPayment {
    private BigDecimal amount;
    private String status;
    private Date dueDate;
}
