package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;
import kz.eub.smart.core.mybank.domain.use_case.GetProductStatusUseCase;


public class GetProductStatusUseCaseImpl implements GetProductStatusUseCase {

    @Override
    public ProductStatus invoke(AccountCard accountCards) {

        if (accountCards.getStatusTitle() != null){
            return new ProductStatus(accountCards.getStatusType(), accountCards.getStatusTitle());
        }
        return null;
    }
}
