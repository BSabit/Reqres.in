package kz.eub.smart.core.mybank.domain.use_case;

import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;

public interface GetProductStatusUseCase {

    ProductStatus invoke(AccountCard accountCards);
}
