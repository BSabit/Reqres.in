package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.domain.model.AccountBalance;
import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;
import kz.eub.smart.core.mybank.domain.repository.ProductStateRepository;
import kz.eub.smart.core.mybank.domain.use_case.GetDepositStatusUseCase;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class GetDepositStatusUseCaseImpl implements GetDepositStatusUseCase{

    private final ProductStateRepository productStateRepository;
    private final int INSUFFICIENT_MINIMUM_BALANCE_STATUS_PRIORITY = 9;

    @Override
    public ProductStatus invoke(AccountCard accountCard, AccountBalance accountBalance, LangKey langKey) {
        if (accountCard != null && accountCard.getStatusTitle() != null){
            if (isStatusPriority(accountCard) && isLessThanMinimumBalance(accountCard ,accountBalance)){
                return productStateRepository.getReplenishDepositStatus(langKey);
            }
            return new ProductStatus(accountCard.getStatusType(), accountCard.getStatusTitle());
        }
        return null;
    }

    private boolean isLessThanMinimumBalance(AccountCard accountCard, AccountBalance accountBalance) {
        return accountBalance.getBalance() != null && accountBalance.getBalance().compareTo(accountCard.getMinBalance()) < 0;
    }

    private boolean isStatusPriority(AccountCard accountCard) {
        return accountCard.getStatusPriority() > INSUFFICIENT_MINIMUM_BALANCE_STATUS_PRIORITY;
    }

}
