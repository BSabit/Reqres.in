package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.core.constants.AccountType;
import kz.eub.smart.core.mybank.core.exception.MyBankException;
import kz.eub.smart.core.mybank.domain.comparator.CardBalanceComparator;
import kz.eub.smart.core.mybank.domain.mapper.AdditionalCardMapper;
import kz.eub.smart.core.mybank.domain.mapper.BalanceMapper;
import kz.eub.smart.core.mybank.domain.mapper.CardMapper;
import kz.eub.smart.core.mybank.domain.model.AccountBalance;
import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.Balance;
import kz.eub.smart.core.mybank.domain.model.card.AdditionalCard;
import kz.eub.smart.core.mybank.domain.model.card.Card;
import kz.eub.smart.core.mybank.domain.repository.DetailsUrlRepository;
import kz.eub.smart.core.mybank.domain.use_case.GetCardsUseCase;
import kz.eub.smart.core.mybank.domain.use_case.GetProductStatusUseCase;
import lombok.AllArgsConstructor;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import static kz.eub.smart.core.mybank.core.exception.MyBankErrorCode.E_EX_700;

@AllArgsConstructor
public class GetCardsUseCaseImpl implements GetCardsUseCase {

    private final GetProductStatusUseCase getProductStatusUseCase;
    private final DetailsUrlRepository detailsUrlRepository;
    private final String CARD_ID_PARAMETER_NAME = "cardId";
    private final String ACCOUNT_ID_PARAMETER_NAME = "accountId";

    @Override
    public List<Card> invoke(List<AccountCard> accountCards, List<AccountBalance> accountBalances, boolean isInstallment) {
        var mainAccounts = getMainAccounts(accountCards, isInstallment);

        return mainAccounts
                .stream()
                .map(acc -> {
                    var mainCard = getMainCard(acc, accountCards);
                    var balances = getCardBalances(acc,accountBalances, accountCards);
                    var additionalCards = getAdditionalCards(acc, accountCards, mainCard);
                    mainCard.setAmounts(balances);
                    mainCard.setAdditionalCards(additionalCards);
                    return mainCard;
                })
                .collect(Collectors.toList());
    }

    private List<AccountCard> getMainAccounts(List<AccountCard> accountCards, boolean isInstallment) {
        return accountCards.stream()
                .filter(accountCard -> AccountType.CARD.name().equals(accountCard.getAccountType())
                        && accountCard.getParentAccountId() == null
                        && isInstallment == accountCard.getIsInstallment())
                .distinct()
                .sorted(Comparator.comparing(AccountCard::getDateOpened, Comparator.reverseOrder()))
                .toList();
    }

    private Card getMainCard(AccountCard mainAccount, List<AccountCard> accountCards){

        var mainCard = accountCards.stream()
                .filter(card -> cardBelongsAccount(card, mainAccount))
                .max(Comparator.comparing(AccountCard::isBasic)
                        .thenComparing(AccountCard::additionalIsMy)
                        .thenComparing(AccountCard::getCardIdForSort));

        return mainCard.map(accountCard -> accountCard.getCardId() != null
                ? CardMapper.getCard(accountCard, getProductStatusUseCase.invoke(accountCard),buildCardDetailsUrl(accountCard, detailsUrlRepository.getMainCardDetails()))
                : CardMapper.getCardAccount(mainAccount, getProductStatusUseCase.invoke(mainAccount),buildCardAccountDetailsUrl(accountCard, detailsUrlRepository.getCardAccountDetails()))
        ).orElse(new Card());
    }

    private List<AdditionalCard> getAdditionalCards(AccountCard mainAccount, List<AccountCard> accountCards, Card mainCard){
        return accountCards.stream()
                .filter(card -> this.isAdditionalCard(card,mainAccount, mainCard ))
                .map(accountCard -> {
                    var productStatus = getProductStatusUseCase.invoke(accountCard);
                    var detailsUrl = detailsUrlRepository.getAdditionalCardDetails();
                    return AdditionalCardMapper.getAdditionalCard(accountCard, productStatus, buildCardDetailsUrl(accountCard, detailsUrl));
                })
                .toList();
    }

    private boolean isAdditionalCard(AccountCard card, AccountCard mainAccount,Card mainCard) {
        return card.getAccountId().equals(mainAccount.getAccountId())
                && card.getCardId() != null
                && !card.getCardId().equals(mainCard.getId());

    }

    private List<Balance> getCardBalances(AccountCard mainAccount, List<AccountBalance> allAccountBalances, List<AccountCard> allAccounts){
        var balances = getSubAccounts(mainAccount, allAccounts)
                .stream()
                .flatMap(subAccount -> getBalances(subAccount, allAccountBalances).stream())
                .collect(Collectors.toList());

        if (balances.isEmpty()) {
            balances.addAll(getBalances(mainAccount, allAccountBalances));
        }

        return balances
                .stream()
                .map(BalanceMapper::getCardBalance)
                .sorted(new CardBalanceComparator())
                .sorted(Comparator.comparing(card -> card.getValue().compareTo(BigDecimal.ZERO), Comparator.reverseOrder()))
                .toList();
    }

    private List<AccountBalance> getBalances(AccountCard subAccount, List<AccountBalance> allAccountBalances) {
        var balances = allAccountBalances
                .stream()
                .filter(accountBalance -> subAccount.getAccountOutref() != null && subAccount.getAccountOutref().equals(accountBalance.getAccountOutref()))
                .toList();

        if (balances.isEmpty())
            throw new MyBankException(E_EX_700, " GetCardsUseCaseImpl getBalance does not have balance from Bus");

        return balances;
    }

    private List<AccountCard> getSubAccounts(AccountCard mainAccount, List<AccountCard> allAccounts) {
        return allAccounts.stream().filter(accountCard -> mainAccount.getAccountId().equals(accountCard.getParentAccountId())).toList();
    }

    private boolean isMainAccount(AccountCard card, AccountCard account) {
        return card.getAccountId().equals(account.getAccountId());
    }

    private boolean cardBelongsAccount(AccountCard card, AccountCard account) {
        return isMainAccount(card, account)
                || isChild(card, account)
                || isSameParent(card, account)
                || isParent(card, account);
    }

    private boolean isParent(AccountCard card, AccountCard account) {
        return card.getAccountId().equals(account.getParentAccountId());
    }

    private boolean isSameParent(AccountCard card, AccountCard account) {
        return card.getParentAccountId() != null && card.getParentAccountId().equals(account.getParentAccountId());
    }

    private boolean isChild(AccountCard card, AccountCard account) {
        return account.getAccountId().equals(card.getParentAccountId());
    }

    private String buildCardDetailsUrl(AccountCard accountCard, String detailsLink) {
        return detailsLink.replace(CARD_ID_PARAMETER_NAME, String.valueOf(accountCard.getCardId()));
    }

    private String buildCardAccountDetailsUrl(AccountCard accountCard, String detailsLink) {
        return detailsLink.replace(ACCOUNT_ID_PARAMETER_NAME, String.valueOf(accountCard.getAccountId()));
    }
}