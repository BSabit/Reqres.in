package kz.eub.smart.core.mybank.core.enums;

public enum LangKey {
    RU,
    KK,
    EN
}
