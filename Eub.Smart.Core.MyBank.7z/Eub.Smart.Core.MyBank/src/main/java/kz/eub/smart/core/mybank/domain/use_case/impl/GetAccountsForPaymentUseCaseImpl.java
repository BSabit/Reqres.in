package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.core.constants.AccountType;
import kz.eub.smart.core.mybank.core.constants.BonusStatus;
import kz.eub.smart.core.mybank.core.exception.MyBankException;
import kz.eub.smart.core.mybank.core.util.CurrencyUtil;
import kz.eub.smart.core.mybank.core.util.LangUtil;
import kz.eub.smart.core.mybank.core.util.S3UrlUtil;
import kz.eub.smart.core.mybank.domain.model.Balance;
import kz.eub.smart.core.mybank.domain.model.bonus.BonusBalanceInfo;
import kz.eub.smart.core.mybank.domain.model.transfer_self.AccountSourceTargetIn;
import kz.eub.smart.core.mybank.domain.model.transfer_self.AccountsPaymentOut;
import kz.eub.smart.core.mybank.domain.model.transfer_self.BonusOut;
import kz.eub.smart.core.mybank.domain.repository.BonusBalanceRepository;
import kz.eub.smart.core.mybank.domain.repository.PaymentCardsRepository;
import kz.eub.smart.core.mybank.domain.use_case.GetAccountsForPaymentUseCase;
import kz.eub.smart.core.mybank.domain.use_case.GetCardsForPaymentUseCase;
import lombok.RequiredArgsConstructor;

import java.util.List;

import static kz.eub.smart.core.mybank.core.exception.MyBankErrorCode.E_DB_600;

@RequiredArgsConstructor
public class GetAccountsForPaymentUseCaseImpl implements GetAccountsForPaymentUseCase {

    private final GetCardsForPaymentUseCase getCardsForPaymentUseCase;
    private final BonusBalanceRepository bonusBalanceRepository;
    private final PaymentCardsRepository paymentCardsRepository;
    private final CurrencyUtil currencyUtil;
    private final S3UrlUtil s3UrlUtil;

    @Override
    public AccountsPaymentOut invoke(Long userId, String iin) {
        var accounts = paymentCardsRepository.getListOfAccounts(userId, LangUtil.getCurrentLocaleString());

        var cards = getCardsForPaymentUseCase.invoke(accounts);
        var bonusOut = getBonusOut(iin, accounts);
        return new AccountsPaymentOut(bonusOut, cards);

    }

    private BonusOut getBonusOut(String iin, List<AccountSourceTargetIn> accounts) {
        var bonusBalance = bonusBalanceRepository.getBalance(iin);
        if (isActiveBonus(bonusBalance)){
            var bonusAccount = getBonusAccountSource(accounts);
            return bonusOutBuild(bonusAccount, bonusBalance);
        }
        return null;
    }

    private AccountSourceTargetIn getBonusAccountSource(List<AccountSourceTargetIn> accounts) {
        return accounts
                .stream()
                .filter(accountSourceTargetIn ->  AccountType.BONS.name().equals(accountSourceTargetIn.getAccountType()))
                .findFirst()
                .orElseThrow(() -> new MyBankException(E_DB_600, " GetAccountsForPaymentUseCaseImpl No bonus account from DB"));
    }


    private boolean isActiveBonus(BonusBalanceInfo bonus) {
        return BonusStatus.ACTIVE.equals(bonus.getStatus());
    }

    private BonusOut bonusOutBuild(AccountSourceTargetIn bonusAccount, BonusBalanceInfo bonusBalance){
        return BonusOut.builder()
                .amount(
                        Balance.builder()
                                .value(bonusBalance.getAmount())
                                .currency(currencyUtil.getCurrency(bonusAccount.getCurrencyCode()))
                                .build()
                )
                .image(s3UrlUtil.buildImageUrl(bonusAccount.getImageUid()))
                .title(bonusAccount.getProductTitle())
                .build();
    }
}
