package kz.eub.smart.core.mybank.core.constants;

import java.util.Arrays;
import java.util.List;

import static kz.eub.smart.core.mybank.core.constants.Currency.*;

public interface CurrencyPriority {
    List<String> currencies = Arrays.asList(KZT, USD, EUR, RUB, GBP, CNY, AED, TRY, CHF, MC1, AUD, HKD, JPY, SGD, UZS);
}
