package kz.eub.smart.core.mybank.domain.repository;

public interface DetailsUrlRepository {
    String getCardAccountDetails();
    String getMainCardDetails();
    String getAdditionalCardDetails();
    String getCardApplication();
    String getDepositDetails(Long id);
    String getDepositApplication();
    String getCurrentAccountDetails(Long id);
    String getCurrentAccountApplication();
    String getCreditDetails(Long creditId);
    String getPayCreditMP(Long creditId);
    String getPayCreditPAR(Long creditId);
    String getPayCreditTAR(Long creditId);
    String getCreditDetailsWebView(Long creditId);
    String getCreditPayList();
    String getBonusDetails();
    String getCreditCardPay(Long cardId);
}
