package kz.eub.smart.core.mybank.infrastructure.repository.impl;

import kz.eub.smart.core.mybank.domain.repository.DetailsUrlRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

@Repository
public class DetailsUrlRepositoryImpl implements DetailsUrlRepository {

    @Value("${app.details-urls.cardAccountDetails}")
    String cardAccountDetails;

    @Value("${app.details-urls.mainCardDetails}")
    String mainCardDetails;

    @Value("${app.details-urls.additionalCardDetails}")
    String additionalCardDetails;

    @Value("${app.details-urls.cardApplication}")
    String cardApplication;

    @Value("${app.details-urls.depositDetails}")
    String depositDetails;

    @Value("${app.details-urls.depositApplication}")
    String depositApplication;

    @Value("${app.details-urls.currentAccountDetails}")
    String currentAccountDetails;

    @Value("${app.details-urls.currentAccountApplication}")
    String currentAccountApplication;

    @Value("${app.details-urls.creditDetails}")
    String creditDetails;

    @Value("${app.details-urls.creditDetailsWebView}")
    String creditDetailsWebView;

    @Value("${app.details-urls.creditMpPay}")
    String creditMpPay;

    @Value("${app.details-urls.creditParPay}")
    String creditParPay;

    @Value("${app.details-urls.creditTarPay}")
    String creditTarPay;

    @Value("${app.details-urls.creditApplication}")
    String creditApplication;

    @Value("${app.details-urls.creditCardPay}")
    String installmentPay;

    @Value("${app.details-urls.creditPayList}")
    String creditPayList;

    @Value("${app.details-urls.bonusDetails}")
    String bonusDetails;

    @Override
    public String getCardAccountDetails() {
        return this.cardAccountDetails;
    }

    @Override
    public String getMainCardDetails() {
        return this.mainCardDetails;
    }

    @Override
    public String getAdditionalCardDetails() {
        return this.additionalCardDetails;
    }

    @Override
    public String getCardApplication() {
        return this.cardApplication;
    }

    @Override
    public String getDepositDetails(Long id) {
        return this.depositDetails + id;
    }

    @Override
    public String getDepositApplication() {
        return this.depositApplication;
    }

    @Override
    public String getCurrentAccountDetails(Long id) {
        return this.currentAccountDetails + id;
    }

    @Override
    public String getCurrentAccountApplication() {
        return this.currentAccountApplication;
    }

    @Override
    public String getCreditDetails(Long creditId) {
        return this.creditDetails + creditId;
    }

    @Override
    public String getPayCreditMP(Long creditId) {
        return this.creditMpPay + creditId;
    }

    @Override
    public String getPayCreditPAR(Long creditId) {
        return this.creditParPay + creditId;
    }

    @Override
    public String getPayCreditTAR(Long creditId) {
        return this.creditTarPay + creditId;
    }

    @Override
    public String getCreditDetailsWebView(Long creditId) {
        return this.creditDetailsWebView + creditId;
    }

    @Override
    public String getCreditPayList() {
        return this.creditPayList;
    }

    @Override
    public String getBonusDetails() {
        return this.bonusDetails;
    }

    @Override
    public String getCreditCardPay(Long cardId) {
        return this.installmentPay + cardId;
    }

}
