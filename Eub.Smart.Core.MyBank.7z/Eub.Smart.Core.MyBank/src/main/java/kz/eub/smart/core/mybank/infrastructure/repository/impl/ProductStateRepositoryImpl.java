package kz.eub.smart.core.mybank.infrastructure.repository.impl;

import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;
import kz.eub.smart.core.mybank.domain.repository.ProductStateRepository;
import kz.eub.smart.core.mybank.infrastructure.mapper.ProductStateMapper;
import kz.eub.smart.core.mybank.infrastructure.repository.ProductStateDaoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

@RequiredArgsConstructor
@Repository
public class ProductStateRepositoryImpl implements ProductStateRepository {

    private final ProductStateDaoRepository productStateDaoRepository;
    private final ProductStateMapper mapper;

    @Override
    public ProductStatus getReplenishDepositStatus(LangKey langKey) {
        return mapper.toDomain(productStateDaoRepository.getReplenishDepositStatus(langKey.name()));
    }

    @Override
    public ProductStatus getBlockedBonusStatus(LangKey langKey) {
        return mapper.toDomain(productStateDaoRepository.getBlockedBonusStatus(langKey.name()));
    }
}
