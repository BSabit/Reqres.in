package kz.eub.smart.core.mybank.domain.model.card;

import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;
import lombok.Data;

@Data
public class AdditionalCard {
    private Long id;
    private String number;
    private String name;
    private String image;
    private String title;
    private ProductStatus status;
    private String link;
}
