package kz.eub.smart.core.mybank.domain.repository;

import kz.eub.smart.core.mybank.domain.model.transfer_self.AccountSourceTargetIn;

import java.util.List;

public interface AccountSourceTargetRepository {
    List<AccountSourceTargetIn> getAccounts(Long userId, List<String> listOfAction);
}
