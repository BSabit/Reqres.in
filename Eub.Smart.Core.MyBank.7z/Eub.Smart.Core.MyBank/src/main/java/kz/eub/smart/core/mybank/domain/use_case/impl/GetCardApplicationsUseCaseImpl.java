package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.domain.mapper.CardApplicationMapper;
import kz.eub.smart.core.mybank.domain.mapper.BalanceMapper;
import kz.eub.smart.core.mybank.domain.model.Application;
import kz.eub.smart.core.mybank.domain.model.card.Card;
import kz.eub.smart.core.mybank.core.constants.AccountType;
import kz.eub.smart.core.mybank.domain.repository.DetailsUrlRepository;
import kz.eub.smart.core.mybank.domain.use_case.GetCardApplicationsUseCase;
import lombok.AllArgsConstructor;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@AllArgsConstructor
public class GetCardApplicationsUseCaseImpl implements GetCardApplicationsUseCase {

    private final DetailsUrlRepository detailsUrlRepository;

    @Override
    public List<Card> invoke(List<Application> applications) {
        return applications.stream()
                .filter(application -> AccountType.CARD.name().equals(application.getApplicationType()))
                .sorted(Comparator.comparing(Application::getDateCreated, Comparator.reverseOrder()))
                .map(application ->  CardApplicationMapper.getCard(application, BalanceMapper.toCardBalance(application), detailsUrlRepository.getCardApplication()))
                .collect(Collectors.toList());
    }

}
