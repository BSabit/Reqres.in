package kz.eub.smart.core.mybank.infrastructure.repository.impl;

import kz.eub.smart.core.mybank.domain.repository.MessageSourceRepository;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Locale;

@Component
public class MessageSourceRepositoryImpl implements MessageSourceRepository {

    private final MessageSource messageSource;

    public MessageSourceRepositoryImpl(MessageSource messageSource) {
        this.messageSource = messageSource;
    }

    @Override
    public String getMessage(String bundleCode, List<Object> args, Locale locale) {
        return messageSource.getMessage(bundleCode, args.toArray(), locale);
    }

    @Override
    public String getMessage(String bundleCode, Object arg, Locale locale) {
        Object[] args = new Object[1];
        args[0] = arg;
        return messageSource.getMessage(bundleCode, args, locale);
    }

    @Override
    public String getMessage(String bundleCode, Locale locale) {
        return getMessage(bundleCode, Collections.emptyList(), locale);
    }
}
