package kz.eub.smart.core.mybank.infrastructure.repository;

import kz.eub.smart.core.mybank.domain.model.transfer_self.AccountSourceTargetIn;
import kz.eub.smart.core.mybank.infrastructure.entity.AccountCardEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AccountSourceTargetDaoRepository extends JpaRepository<AccountCardEntity, Long> {

    @Query(value = "EXEC dbo.microservice_GetAccountsForTSLF :lang, :userId", nativeQuery = true)
    List<AccountSourceTargetIn> getAccounts(Long userId, String lang);

    @Query(value = "EXEC dbo.microservice_GetAccountsForINPS :lang, :userId", nativeQuery = true)
    List<AccountSourceTargetIn> getAccountsTransferLocal(Long userId, String lang);

    @Query(value = "EXEC dbo.microservice_GetCardAccountsForCreditPay :lang, :userId", nativeQuery = true)
    List<AccountSourceTargetIn> getAccountsCreditPay(Long userId, String lang);

    @Query(value = "EXEC dbo.microservice_GetCardAccountsForPayments :lang, :userId", nativeQuery = true)
    List<AccountSourceTargetIn> getAccountsPayment(Long userId, String lang);
}
