package kz.eub.smart.core.mybank.infrastructure.mapper.uses;

import com.google.protobuf.Timestamp;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class TimestampToDateUses {

    public Date timestampToDate(Timestamp ts) {
        if (ts.getSeconds() < 0) {
            return null;
        }
        long milliseconds = (ts.getSeconds() * 1000) + (ts.getNanos() / 1000000);
        return new Date(milliseconds);
    }
}
