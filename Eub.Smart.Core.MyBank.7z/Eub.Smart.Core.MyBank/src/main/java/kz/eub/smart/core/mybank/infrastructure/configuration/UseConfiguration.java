package kz.eub.smart.core.mybank.infrastructure.configuration;

import kz.eub.smart.core.mybank.core.util.CurrencyUtil;
import kz.eub.smart.core.mybank.core.util.S3UrlUtil;
import kz.eub.smart.core.mybank.domain.repository.*;
import kz.eub.smart.core.mybank.domain.use_case.*;
import kz.eub.smart.core.mybank.domain.use_case.impl.*;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class UseConfiguration {

    @Bean
    public GetAccountsUseCase getAccountUseCase(DetailsUrlRepository detailsUrlRepository, GetProductStatusUseCase getProductStatusUseCase){
        return new GetAccountUseCaseImpl(detailsUrlRepository, getProductStatusUseCase);
    }

    @Bean
    public GetDepositsUseCase getDepositsUseCase(DetailsUrlRepository detailsUrlRepository,GetDepositStatusUseCase getDepositStatusUseCase){
        return new GetDepositsUseCaseImpl(detailsUrlRepository,getDepositStatusUseCase);
    }

    @Bean
    public GetCardsUseCase getCardsUseCase(GetProductStatusUseCase getProductStatusUseCase, DetailsUrlRepository detailsUrlRepository){
        return new GetCardsUseCaseImpl(getProductStatusUseCase, detailsUrlRepository);
    }

    @Bean
    public GetProductStatusUseCase getCardStatusUseCase(){
        return new GetProductStatusUseCaseImpl();
    }

    @Bean
    public GetBonusUseCase getBonusUseCase(BonusBalanceRepository bonusBalanceRepository, DetailsUrlRepository detailsUrlRepository, ProductStateRepository productStateRepository){
        return new GetBonusUseCaseImpl(bonusBalanceRepository, detailsUrlRepository, productStateRepository);
    }

    @Bean
    public GetCardApplicationsUseCase getCardApplicationsUseCase(DetailsUrlRepository detailsUrlRepository){
        return new GetCardApplicationsUseCaseImpl(detailsUrlRepository);
    }

    @Bean
    public GetDepositApplicationsUseCase getDepositApplicationsUseCase(DetailsUrlRepository detailsUrlRepository){
        return new GetDepositApplicationsUseCaseImpl(detailsUrlRepository);
    }

    @Bean
    public GetCurrentAccountApplicationsUseCase getCurrentAccountApplicationsUseCase(DetailsUrlRepository detailsUrlRepository){
        return new GetCurrentAccountApplicationsUseCaseImpl(detailsUrlRepository);
    }

    @Bean
    public GetBankUseCase getBankUseCase(GetAccountsUseCase getAccountsUseCase, GetCardsUseCase getCardsUseCase,
                                         AccountCardRepository accountCardRepository, CardBalanceRepository cardBalanceRepository,
                                         DepositCurrentAccountBalanceRepository depositCurrentAccountBalanceRepository,
                                         GetDepositsUseCase getDepositsUseCase,GetBonusUseCase getBonusUseCase,
                                         ApplicationRepository applicationRepository, GetCardApplicationsUseCase getCardApplicationsUseCase,
                                         GetDepositApplicationsUseCase getDepositApplicationsUseCase, GetCurrentAccountApplicationsUseCase getCurrentAccountApplicationsUseCase,
                                         GetOpenProductsUseCase getOpenProductsUseCase, GetBannerBonusUseCase getBannerBonusUseCase,GetCreditCardPaymentUseCase getCreditCardPaymentUseCase,
                                         OpenProductRepository openProductRepository,GetCreditInfoUseCase getCreditInfoUseCase){
        return new GetBankUseCaseImpl(getAccountsUseCase, getDepositsUseCase, getCardsUseCase, getBonusUseCase, getCardApplicationsUseCase, getDepositApplicationsUseCase, getCurrentAccountApplicationsUseCase, getOpenProductsUseCase, getBannerBonusUseCase, getCreditInfoUseCase, getCreditCardPaymentUseCase, accountCardRepository, cardBalanceRepository, depositCurrentAccountBalanceRepository, applicationRepository, openProductRepository);
    }

    @Bean
    public SetBonusSpendUseCase getSetBonusSpendUseCase(BonusSpendRepository bonusSpendRepository){
        return new SetBonusSpendUseCaseImpl(bonusSpendRepository);
    }

    @Bean
    public GetDepositStatusUseCase getDepositStatusUseCase(ProductStateRepository productStateRepository){
        return new GetDepositStatusUseCaseImpl(productStateRepository);
    }

    @Bean
    public GetProductStatusUseCase getProductStatusUseCase(){
        return new GetProductStatusUseCaseImpl();
    }

    @Bean
    public GetOpenProductsUseCase getOpenProductsUseCase(){
        return new GetOpenProductsUseCaseImpl();
    }

    @Bean
    public GetBannerBonusUseCase getBannerBonusUseCase(){
        return new GetBannerBonusUseCaseImpl();
    }

    @Bean
    public GetCreditInfoUseCase getCreditInfoUseCase(CreditRepository creditRepository, DetailsUrlRepository detailsUrlRepository,
                                                     CreditPaymentRepository creditPaymentRepository, GetMonthlyLoanUseCase getMonthlyLoanUseCase){
        return new GetCreditInfoUseCaseImpl(creditRepository, detailsUrlRepository, creditPaymentRepository, getMonthlyLoanUseCase);
    }

    @Bean
    public GetMonthlyLoanUseCase getMonthlyLoanUseCase(CreditPaymentRepository creditPaymentRepository, DetailsUrlRepository detailsUrlRepository, MessageSourceRepository messageSourceRepository){
        return new GetMonthlyLoanUseCaseImpl(creditPaymentRepository, detailsUrlRepository, messageSourceRepository);
    }

    @Bean
    public GetCreditCardPaymentUseCase getCreditCardPaymentUseCase(CreditCardPaymentRepository creditCardPaymentRepository, DetailsUrlRepository detailsUrlRepository, MessageSourceRepository messageSourceRepository){
        return new GetCreditCardPaymentUseCaseImpl(creditCardPaymentRepository, detailsUrlRepository, messageSourceRepository);
    }

    @Bean
    public GetAccountSourceTargetUseCase getAccountSourceTargetUseCase(AccountSourceTargetRepository accountSourceTargetRepository, CardBalanceRepository cardBalanceRepository, DepositCurrentAccountBalanceRepository depositCurrentAccountBalanceRepository, S3UrlUtil s3UrlUtil){
        return new GetAccountSourceTargetUseCaseImpl(accountSourceTargetRepository, cardBalanceRepository, depositCurrentAccountBalanceRepository, s3UrlUtil);
    }

    @Bean
    public GetCardsForPaymentUseCase getCreditPayCardsUseCase(CardBalanceRepository cardBalanceRepository, S3UrlUtil s3UrlUtil){
        return new GetCardsForPaymentUseCaseImpl(cardBalanceRepository, s3UrlUtil);
    }

    @Bean
    public GetAccountsForPaymentUseCase getAccountsForPaymentUseCase(GetCardsForPaymentUseCase getCardsForPaymentUseCase, BonusBalanceRepository bonusBalanceRepository,
                                                                     PaymentCardsRepository paymentCardsRepository, CurrencyUtil currencyUtil, S3UrlUtil s3UrlUtil){
        return new GetAccountsForPaymentUseCaseImpl(getCardsForPaymentUseCase, bonusBalanceRepository, paymentCardsRepository, currencyUtil, s3UrlUtil);
    }

    @Bean
    public GetCardsForCreditUseCase getCardsForCreditUseCase(CreditPayCardsRepository creditPayCardsRepository, GetCardsForPaymentUseCase getCardsForPaymentUseCase){
        return new GetCardsForCreditUseCaseImpl(creditPayCardsRepository, getCardsForPaymentUseCase);
    }
}
