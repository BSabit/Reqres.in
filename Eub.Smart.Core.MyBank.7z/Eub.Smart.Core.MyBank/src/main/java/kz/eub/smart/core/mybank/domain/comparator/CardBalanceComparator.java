package kz.eub.smart.core.mybank.domain.comparator;

import kz.eub.smart.core.mybank.core.constants.CurrencyPriority;
import kz.eub.smart.core.mybank.domain.model.Balance;
import lombok.AllArgsConstructor;

import java.util.Comparator;

@AllArgsConstructor
public class CardBalanceComparator implements Comparator<Balance> {

    @Override
    public int compare(Balance o1, Balance o2) {
        var currencies = CurrencyPriority.currencies;
        int index1 = currencies.indexOf(o1.getCurrency().getCode());
        int index2 = currencies.indexOf(o2.getCurrency().getCode());

        return Integer.compare(index1, index2);
    }
}