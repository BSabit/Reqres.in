package kz.eub.smart.core.mybank.core.util;

import kz.eub.smart.core.mybank.domain.model.Currency;
import org.mapstruct.Named;
import org.springframework.stereotype.Component;


import static kz.eub.smart.core.mybank.core.constants.Currency.*;

@Component
public class CurrencyUtil {

    @Named("getCurrencyMap")
    public  Currency getCurrency(String code){
        return switch (code) {
            case KZT -> new Currency(code, "₸");
            case USD -> new Currency(code, "$");
            case EUR -> new Currency(code, "€");
            case RUB -> new Currency(code, "₽");
            case GBP -> new Currency(code, "£");
            case CNY -> new Currency(code, "¥");
            case AED -> new Currency(code, "د. إ");
            case TRY -> new Currency(code, "₺");
            case CHF -> new Currency(code, "₣");
            case BNS -> new Currency(code, "Б");
            default -> new Currency(code, "");
        };
    }


}
