package kz.eub.smart.core.mybank.core.constants;

public interface ActionType {
    String TSLF = "TSLF";
    String CRED = "CRED";
    String INPS = "INPS";
}