package kz.eub.smart.core.mybank.domain.model.transfer_self;

import kz.eub.smart.core.mybank.domain.model.Balance;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BonusOut {
    private String title;
    private String image;
    private Balance amount;
}
