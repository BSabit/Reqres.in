package kz.eub.smart.core.mybank.domain.repository;

import kz.eub.smart.core.mybank.domain.model.transfer_self.AccountSourceTargetIn;

import java.util.List;

public interface PaymentCardsRepository {

    List<AccountSourceTargetIn> getListOfAccounts(Long userId, String lang);
}
