package kz.eub.smart.core.mybank.domain.mapper;

import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.card.AdditionalCard;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;

public class AdditionalCardMapper {

    public static AdditionalCard getAdditionalCard(AccountCard accountCard, ProductStatus productStatus,String detailsLink){
        AdditionalCard additionalCard = new AdditionalCard();
        additionalCard.setName(accountCard.getSubProductTitle());
        additionalCard.setId(accountCard.getCardId());
        additionalCard.setTitle(accountCard.getProductTitle());
        additionalCard.setImage(accountCard.getImage());
        additionalCard.setNumber(accountCard.getCardMaskedNumber());
        additionalCard.setStatus(productStatus);
        additionalCard.setLink(detailsLink);
        return additionalCard;
    }
}
