package kz.eub.smart.core.mybank.infrastructure.mapper;

import kz.eub.smart.core.mybank.core.util.S3UrlUtil;
import kz.eub.smart.core.mybank.domain.model.OpenProduct;
import kz.eub.smart.core.mybank.infrastructure.entity.OpenProductEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING, uses = S3UrlUtil.class)
public interface OpenProductMapper {

    List<OpenProduct> toDomain(List<OpenProductEntity> entities);

    @Mapping(target = "image", source = "entity.imageUid", qualifiedByName = "buildImageUrl")
    @Mapping(target = "link", source = "detailsLink")
    OpenProduct toDomain(OpenProductEntity entity);

}
