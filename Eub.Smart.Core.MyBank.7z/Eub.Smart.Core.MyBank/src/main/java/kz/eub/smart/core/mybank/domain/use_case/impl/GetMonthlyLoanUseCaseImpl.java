package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.core.constants.CreditPaymentStatus;
import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.core.exception.MyBankException;
import kz.eub.smart.core.mybank.core.util.CollectionUtil;
import kz.eub.smart.core.mybank.core.util.LangUtil;
import kz.eub.smart.core.mybank.domain.model.credit.Credit;
import kz.eub.smart.core.mybank.domain.model.credit.CreditPayment;
import kz.eub.smart.core.mybank.domain.model.credit.MonthlyLoan;
import kz.eub.smart.core.mybank.domain.repository.CreditPaymentRepository;
import kz.eub.smart.core.mybank.domain.repository.DetailsUrlRepository;
import kz.eub.smart.core.mybank.domain.repository.MessageSourceRepository;
import kz.eub.smart.core.mybank.domain.use_case.GetMonthlyLoanUseCase;
import lombok.RequiredArgsConstructor;
import static kz.eub.smart.core.mybank.core.constants.CreditStatus.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.time.Month;
import java.time.format.TextStyle;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import static kz.eub.smart.core.mybank.core.constants.CreditStatus.TAR;
import static kz.eub.smart.core.mybank.core.exception.MyBankErrorCode.E_EX_700;
import static kz.eub.smart.core.mybank.domain.constant.BundleCode.*;

@RequiredArgsConstructor
public class GetMonthlyLoanUseCaseImpl implements GetMonthlyLoanUseCase {

    private final CreditPaymentRepository creditPaymentRepository;
    private final DetailsUrlRepository detailsUrlRepository;
    private final MessageSourceRepository messageSourceRepository;
    private static final String KZT_SYMBOL = "₸";

    @Override
    public Optional<MonthlyLoan> invoke(List<Credit> credits, LangKey langKey) {
        if (CollectionUtil.isEmpty(credits))
            return Optional.empty();

        var creditNumbers = credits.stream().map(Credit::getCreditNumber).toList();
        var creditPayments = creditPaymentRepository.getCreditPayments(creditNumbers);

        if (creditPayments.size() != credits.size()){
            throw new MyBankException(E_EX_700, " The number of payments does not match the number of credits");
        }

        return Optional.of(
                MonthlyLoan.builder()
                .title(getTitle(creditPayments, langKey))
                .description(getDescription(creditPayments, langKey))
                .status(getStatus(creditPayments))
                .link(getLink(creditPayments, credits))
                .build()
        );
    }

    private String getLink(List<CreditPayment> creditPayments, List<Credit> credits) {
        if (creditPayments.size() > 1){
            return detailsUrlRepository.getCreditPayList();
        }
        return switch (creditPayments.get(0).getProductStatus()) {
            case EP -> detailsUrlRepository.getPayCreditMP(getCreditIdByNumber(creditPayments.get(0).getCreditNumber(), credits));
            case TAR -> detailsUrlRepository.getPayCreditTAR(getCreditIdByNumber(creditPayments.get(0).getCreditNumber(), credits));
            default -> detailsUrlRepository.getPayCreditPAR(getCreditIdByNumber(creditPayments.get(0).getCreditNumber(), credits));
        };
    }

    private Long getCreditIdByNumber(String creditNumber, List<Credit> credits) {
        return credits
                .stream()
                .filter(credit -> creditNumber.equals(credit.getCreditNumber()))
                .findFirst()
                .orElseThrow(() -> new MyBankException(E_EX_700, "The credit number from the Bus does not match the credit number from the database"))
                .getId();
    }

    private String getStatus(List<CreditPayment> creditPayments) {
        if (hasExpired(creditPayments))
            return CreditPaymentStatus.EXPIRED;

        if (isPaidAllCredit(creditPayments))
            return CreditPaymentStatus.PAID;

        return CreditPaymentStatus.WAITING;
    }

    private String getDescription(List<CreditPayment> creditPayments, LangKey langKey) {
        if (hasExpired(creditPayments)){
            return messageSourceRepository.getMessage(MONTHLY_LOAN_EXPIRED, LangUtil.get(langKey));
        }
        if (creditPayments.size() > 1){
            return messageSourceRepository.getMessage(MONTHLY_LOAN_PAY_ALL, getLocaledMonthName(langKey), LangUtil.get(langKey));
        }
        return messageSourceRepository.getMessage(MONTHLY_LOAN_PAY, getFormattedDate(creditPayments.get(0)), LangUtil.get(langKey));
    }

    private String getFormattedDate(CreditPayment creditPayment) {
        SimpleDateFormat formatter = new SimpleDateFormat("MM.dd");
        return formatter.format(creditPayment.getDate());
    }

    private String getLocaledMonthName(LangKey langKey) {
        Month jan = Month.of(Calendar.getInstance().get(Calendar.MONTH) + 1);
        Locale loc = Locale.forLanguageTag(langKey.name());
        return jan.getDisplayName(TextStyle.FULL, loc);
    }

    private String getTitle(List<CreditPayment> creditPayments, LangKey langKey) {
        if (hasExpired(creditPayments)){
            return formattedAmount(creditPayments);
        }

        if (isPaidAllCredit(creditPayments)){
            return messageSourceRepository.getMessage(MONTHLY_LOAN_PAID, LangUtil.get(langKey));
        }
        return formattedAmount(creditPayments);
    }

    private String formattedAmount(List<CreditPayment> creditPayments) {
        BigDecimal sum = creditPayments
                .stream()
                .filter(this::isNotPaid)
                .map(CreditPayment::getSum)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.getDefault());
        symbols.setGroupingSeparator(' ');
        DecimalFormat df = new DecimalFormat("#,##0.############", symbols);
        return df.format(sum) + " " + KZT_SYMBOL;
    }

    private boolean isNotPaid(CreditPayment creditPayment) {
        Calendar payForDate = Calendar.getInstance();
        payForDate.setTime(creditPayment.getDate());
        int payForMonth = payForDate.get(Calendar.MONTH) + 1;
        int currentMonth = Calendar.getInstance().get(Calendar.MONTH) + 1;
        return currentMonth >= payForMonth;
    }

    private boolean hasExpired(List<CreditPayment> creditPayments) {
        return creditPayments
                .stream()
                .anyMatch(creditPayment -> CreditPaymentStatus.EXPIRED.equals(creditPayment.getPaymentStatus()));
    }

    private boolean isPaidAllCredit(List<CreditPayment> creditPayments) {
        return creditPayments
                .stream()
                .allMatch(creditPayment -> CreditPaymentStatus.PAID.equals(creditPayment.getPaymentStatus()));
    }
}
