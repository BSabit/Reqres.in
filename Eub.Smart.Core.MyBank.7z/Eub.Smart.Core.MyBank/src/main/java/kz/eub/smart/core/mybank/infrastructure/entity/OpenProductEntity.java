package kz.eub.smart.core.mybank.infrastructure.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Getter
@Setter
public class OpenProductEntity {

    @Id
    private Long openProductId;
    private String title;
    private String description;
    private String detailsLink;
    private String imageUid;
    private String productType;
}
