package kz.eub.smart.core.mybank.domain.use_case;

import kz.eub.smart.core.mybank.domain.model.AccountBalance;
import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.card.Card;

import java.util.List;

public interface GetCardsUseCase {
    List<Card> invoke(List<AccountCard> accountCards, List<AccountBalance> accountBalances, boolean isInstallment);
}
