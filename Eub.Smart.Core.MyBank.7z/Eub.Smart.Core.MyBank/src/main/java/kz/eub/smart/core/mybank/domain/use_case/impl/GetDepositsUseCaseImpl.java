package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.core.exception.MyBankException;
import kz.eub.smart.core.mybank.domain.model.AccountBalance;
import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.deposit.Deposit;
import kz.eub.smart.core.mybank.domain.repository.DetailsUrlRepository;
import kz.eub.smart.core.mybank.domain.use_case.GetDepositStatusUseCase;
import kz.eub.smart.core.mybank.domain.use_case.GetDepositsUseCase;
import kz.eub.smart.core.mybank.core.constants.AccountType;
import kz.eub.smart.core.mybank.domain.mapper.DepositMapper;
import lombok.AllArgsConstructor;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import static kz.eub.smart.core.mybank.core.exception.MyBankErrorCode.E_EX_700;

@AllArgsConstructor
public class GetDepositsUseCaseImpl implements GetDepositsUseCase {

    private final DetailsUrlRepository detailsUrlRepository;
    private final GetDepositStatusUseCase getDepositStatusUseCase;

    @Override
    public List<Deposit> invoke(List<AccountCard> accountCards, List<AccountBalance> accountBalances, LangKey langKey) {
        return accountCards
                .stream()
                .filter(this::isDepositAccount)
                .distinct()
                .sorted(Comparator.comparing(AccountCard::getDateOpened, Comparator.reverseOrder()))
                .map(accountCard -> DepositMapper.getDeposit(
                        accountCard,
                        getBalance(accountCard, accountBalances),
                        getDepositStatusUseCase.invoke(accountCard,getBalance(accountCard, accountBalances), langKey),
                        detailsUrlRepository.getDepositDetails(accountCard.getAccountId()))
                )
                .collect(Collectors.toList());

    }

    private AccountBalance getBalance(AccountCard accountCard, List<AccountBalance> accountBalances){
        return accountBalances
                .stream()
                .filter(balance -> balance.getAccountOutref().equals(accountCard.getAccountOutref()))
                .findFirst()
                .orElseThrow(() -> new MyBankException(E_EX_700, "GetDepositsUseCaseImpl getBalance"));
    }

    private boolean isDepositAccount(AccountCard accountCard){
        return AccountType.SAVE.name().equals(accountCard.getAccountType());
    }

 }
