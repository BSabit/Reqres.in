package kz.eub.smart.core.mybank.infrastructure.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Getter
@Setter
public class AccountCardEntity {

    @Id
    private String accountCardId;
    private Long accountId;
    private Long parentAccountId;
    private String accountNumber;
    private String currencyCode;
    private Long accountUserId;
    private Long accountOutref;
    private Long cardUserId;
    private String accountType;
    private boolean isMultiCurrency;
    private Long cardId;
    private String cardMaskedNumber;
    private Boolean isBasic;
    private BigDecimal minBalance;
    private String imageUid;
    private Boolean isInstallment;
    private String productTitle;
    private String subProductTitle;
    private String statusTitle;
    private String statusType;
    private Integer statusPriority;
    private Date dateOpened;
}
