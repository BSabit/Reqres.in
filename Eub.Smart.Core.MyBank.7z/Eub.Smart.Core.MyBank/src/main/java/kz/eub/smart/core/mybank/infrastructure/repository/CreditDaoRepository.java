package kz.eub.smart.core.mybank.infrastructure.repository;

import kz.eub.smart.core.mybank.infrastructure.entity.CreditEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CreditDaoRepository extends JpaRepository<CreditEntity,Long> {

    @Query(nativeQuery = true, value = """
                SELECT
                    c.Credit_ID                AS id,
                    md.FileUid                 AS fileUid,
                    CASE
                        WHEN :lang = 'KK' THEN t.Term_KZ
                        WHEN :lang = 'RU' THEN t.Term_RU
                        ELSE t.Term_EN
                    END                        AS title,
                    NULL                       AS paidPeriod,
                    NULL                       AS fullPeriod,    
                    CASE
                        WHEN :lang = 'KK' THEN tps.Term_KZ
                        WHEN :lang = 'RU' THEN tps.Term_RU
                        ELSE tps.Term_EN
                    END                        AS statusTitle,
                    ps.ProductStatusCode_IDREF AS statusCode,
                    c.Number                   AS creditNumber 
                FROM
                    Credit c
                    INNER JOIN CreditType ct ON c.CreditType_IDREF = ct.CreditType_ID
                    LEFT JOIN Term t ON t.Term_ID = ct.Term_OUTREF
                    LEFT JOIN MetaDocument md ON md.Target_ID = ct.Target_ID
                                              AND md.Target_Table = 'CreditType'
                                              AND md.IsActive = 1
                    LEFT JOIN ProductState ps ON ps.ProductStatusCode_IDREF = 'removeCarCollateral'
                    LEFT JOIN Term tps ON ps.Term_OUTREF = tps.Term_ID
                WHERE
                    c.Number IN (:carCreditNumbers);
""")
    List<CreditEntity> getCarCredits(List<String> carCreditNumbers,String lang);

    @Query(nativeQuery = true, value = """
                SELECT
                    c.Credit_ID                AS id,
                    md.FileUid                 AS fileUid,
                    CASE
                        WHEN 'KK' = :lang THEN t.Term_KZ
                        WHEN 'RU' = :lang THEN t.Term_RU
                        ELSE t.Term_EN
                    END                        AS title,
                    c.PaidPeriod               AS paidPeriod,
                    c.Term                     AS fullPeriod,
                    CASE
                        WHEN 'KK' = :lang THEN tps.Term_KZ
                        WHEN 'RU' = :lang THEN tps.Term_RU
                        ELSE tps.Term_EN
                    END                        AS statusTitle,
                    ps.ProductStatusCode_IDREF AS statusCode,
                    c.Number                   AS creditNumber  
                FROM
                    Credit c
                    INNER JOIN map_User_Credit muc ON muc.Credit_IDREF = c.Credit_ID
                    LEFT JOIN CreditType ct ON ct.CreditType_ID = c.CreditType_IDREF
                    LEFT JOIN Term t ON t.Term_ID = ct.Term_OUTREF
                    LEFT JOIN MetaDocument md ON md.Target_ID = ct.Target_ID
                        AND md.Target_Table = 'CreditType'
                        AND md.IsActive = 1
                    LEFT JOIN ProductState ps ON  ps.ProductStatusCode_IDREF IN (
                            CASE
                                WHEN c.SecondDate <= DATEADD(DAY, 30, GETDATE())
                                     AND c.SecondDate >= GETDATE() AND c.IsGrace = 1
                                    THEN 'graceDeadline'
                            END
                        )
                    LEFT JOIN Term tps ON ps.Term_OUTREF = tps.Term_ID
                WHERE
                    muc.User_IDREF = :userId
                    AND c.CreditStatus_IDREF = 'ACTV'
                    AND c.Number NOT IN (
                        SELECT ra.LoanNumber
                        FROM RepaymentApplication ra
                        INNER JOIN Application a ON ra.Application_IDREF = a.Application_ID
                        WHERE a.ApplicationType_IDREF = 'AFER'
                    )
                ORDER BY
                    c.DateOpened DESC;
""")
    List<CreditEntity> getCredits(Long userId, String lang);

}
