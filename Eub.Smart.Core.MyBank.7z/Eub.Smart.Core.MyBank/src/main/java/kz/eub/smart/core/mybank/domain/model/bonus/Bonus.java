package kz.eub.smart.core.mybank.domain.model.bonus;

import kz.eub.smart.core.mybank.domain.model.Balance;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;
import lombok.Data;

@Data
public class Bonus {

    private String image;
    private Balance amount;
    private Boolean enabled;
    private ProductStatus status;
    private String link;

}
