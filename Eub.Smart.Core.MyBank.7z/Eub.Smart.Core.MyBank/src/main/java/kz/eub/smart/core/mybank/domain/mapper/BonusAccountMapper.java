package kz.eub.smart.core.mybank.domain.mapper;


import kz.eub.smart.core.mybank.core.util.CurrencyUtil;
import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.Balance;
import kz.eub.smart.core.mybank.domain.model.bonus.Bonus;
import kz.eub.smart.core.mybank.domain.model.bonus.BonusBalanceInfo;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;

public class BonusAccountMapper {

    public static Bonus getBonusAccount(AccountCard accountCard, BonusBalanceInfo bonusBalanceInfo, String detailsLink, ProductStatus productStatus) {
        Bonus bonus = new Bonus();
        bonus.setAmount(new Balance(bonusBalanceInfo.getAmount(), new CurrencyUtil().getCurrency(accountCard.getCurrencyCode())));
        bonus.setEnabled(bonusBalanceInfo.getSpendIsAllowed());
        bonus.setImage(accountCard.getImage());
        bonus.setStatus(productStatus);
        bonus.setLink(detailsLink);
        return bonus;
    }
}
