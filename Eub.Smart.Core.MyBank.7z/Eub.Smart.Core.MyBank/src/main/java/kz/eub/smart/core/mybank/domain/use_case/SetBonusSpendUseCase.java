package kz.eub.smart.core.mybank.domain.use_case;


public interface SetBonusSpendUseCase {
    void invoke(String iin, boolean isSpending);
}
