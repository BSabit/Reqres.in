package kz.eub.smart.core.mybank.infrastructure.mapper;

import kz.eub.smart.core.mybank.core.util.CurrencyUtil;
import kz.eub.smart.core.mybank.domain.model.AccountBalance;
import kz.eub.smart.core.mybank.infrastructure.mapper.uses.CustomTypeDecimalValueToBigDecimal;
import kz.eubank.grpc.EubAggregatorCoreMyBank;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING,uses = { CustomTypeDecimalValueToBigDecimal.class, CurrencyUtil.class})
public interface AccountBalanceMapper {

    List<AccountBalance> toDomain(List<EubAggregatorCoreMyBank.CurrentAccountBalance> balances);

    @Mapping(target = "accountOutref", source = "accountId")
    @Mapping(target = "balance", source = "availableBalance")
    @Mapping(target = "currency", source = "currency", qualifiedByName = "getCurrencyMap")
    AccountBalance toDomain(EubAggregatorCoreMyBank.CurrentAccountBalance balance);

    List<AccountBalance> toDomainFromCardBalance(List<EubAggregatorCoreMyBank.CardAccountBalance> balances);

    @Mapping(target = "accountOutref", source = "accountId")
    @Mapping(target = "balance", source = "availableBalance")
    @Mapping(target = "currency", source = "currency", qualifiedByName = "getCurrencyMap")
    AccountBalance toDomain(EubAggregatorCoreMyBank.CardAccountBalance balance);

}