package kz.eub.smart.core.mybank.domain.use_case;

import kz.eub.smart.core.mybank.domain.model.transfer_self.AccountsPaymentOut;

public interface GetAccountsForPaymentUseCase {
    AccountsPaymentOut invoke(Long userId, String iin);
}
