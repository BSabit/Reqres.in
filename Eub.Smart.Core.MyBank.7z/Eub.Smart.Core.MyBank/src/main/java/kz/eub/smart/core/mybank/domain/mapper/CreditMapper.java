package kz.eub.smart.core.mybank.domain.mapper;

import kz.eub.smart.core.mybank.domain.model.credit.Credit;
import kz.eub.smart.core.mybank.domain.model.credit.CreditResponse;
import kz.eub.smart.core.mybank.domain.model.credit.Period;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;

public class CreditMapper {

    public static CreditResponse getCreditResponse(Credit credit, String detailsLink){
        CreditResponse creditResponse = new CreditResponse();
        creditResponse.setId(credit.getId());
        creditResponse.setImage(credit.getImage());
        creditResponse.setTitle(credit.getTitle());
        creditResponse.setLink(detailsLink);
        creditResponse.setStatus(new ProductStatus(credit.getStatusCode(), credit.getStatusTitle()));
        creditResponse.setPeriod(new Period(credit.getPaidPeriod(), credit.getFullPeriod()));
        return creditResponse;
    }
}
