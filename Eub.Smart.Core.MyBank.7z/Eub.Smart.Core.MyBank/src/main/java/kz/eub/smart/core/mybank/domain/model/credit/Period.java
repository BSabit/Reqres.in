package kz.eub.smart.core.mybank.domain.model.credit;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Period {
    private Long paid;
    private Long full;
}
