package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.core.util.CollectionUtil;
import kz.eub.smart.core.mybank.domain.mapper.CreditMapper;
import kz.eub.smart.core.mybank.domain.model.credit.Credit;
import kz.eub.smart.core.mybank.domain.model.credit.CreditInfo;
import kz.eub.smart.core.mybank.domain.model.credit.CreditResponse;
import kz.eub.smart.core.mybank.domain.repository.CreditPaymentRepository;
import kz.eub.smart.core.mybank.domain.repository.CreditRepository;
import kz.eub.smart.core.mybank.domain.repository.DetailsUrlRepository;
import kz.eub.smart.core.mybank.domain.use_case.GetCreditInfoUseCase;
import kz.eub.smart.core.mybank.domain.use_case.GetMonthlyLoanUseCase;
import lombok.RequiredArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

@RequiredArgsConstructor
public class GetCreditInfoUseCaseImpl implements GetCreditInfoUseCase {

    private final CreditRepository creditRepository;
    private final DetailsUrlRepository detailsUrlRepository;
    private final CreditPaymentRepository creditPaymentRepository;
    private final GetMonthlyLoanUseCase getMonthlyLoanUseCase;
    private String CREDIT_REMOVE_CAR_COLLATERAL_STATUS = "removeCarCollateral";

    @Override
    public CreditInfo invoke(Long userId, String iin, LangKey langKey) {
        var credits = creditRepository.getListOfCredits(userId, langKey);
        var monthlyLoan = getMonthlyLoanUseCase.invoke(credits, langKey);

        var carCreditNumbers = creditPaymentRepository.getCarCreditNumbers(iin);
        if (CollectionUtil.isNotEmpty(carCreditNumbers)){
            credits.addAll(creditRepository.getListOfCarCredits(carCreditNumbers, langKey));
        }

        return new CreditInfo(monthlyLoan, addLinkAndMap(credits));
    }

    private List<CreditResponse> addLinkAndMap(List<Credit> credits) {
        return credits.stream()
                .map(credit -> CreditMapper.getCreditResponse(credit, getLink(credit)))
                .collect(Collectors.toList());

    }

    private String getLink(Credit credit){
        if (CREDIT_REMOVE_CAR_COLLATERAL_STATUS.equals(credit.getStatusCode())){
            return detailsUrlRepository.getCreditDetailsWebView(credit.getId());
        }
        return detailsUrlRepository.getCreditDetails(credit.getId());
    }
}
