package kz.eub.smart.core.mybank.domain.model.credit;


import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MonthlyLoan {
    private String title;
    private String description;
    private String status;
    private String link;
}
