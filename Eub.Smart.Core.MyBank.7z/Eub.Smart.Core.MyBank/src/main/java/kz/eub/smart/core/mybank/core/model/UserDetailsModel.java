package kz.eub.smart.core.mybank.core.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import kz.eub.smart.core.mybank.core.exception.MyBankException;
import lombok.Data;

import java.util.Date;

import static kz.eub.smart.core.mybank.core.exception.MyBankErrorCode.E_SM_502;
import static kz.eub.smart.core.mybank.core.util.JsonUtil.toObject;


@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserDetailsModel {
    @JsonProperty("user_id")
    private Long userId;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.S")
    @JsonProperty("birth_date")
    private Date birthDate;
    @JsonProperty("name")
    private String name;
    @JsonProperty("preferred_username")
    private String preferredUsername;
    @JsonProperty("middle_name")
    private String middleName;
    @JsonProperty("given_name")
    private String givenName;
    @JsonProperty("family_name")
    private String familyName;
    @JsonProperty("client_id")
    private Long clientId;
    @JsonProperty("iin")
    private String iin;
    @JsonProperty("person_id")
    private Long personId;

    public static UserDetailsModel build(String payload) {
        return toObject(payload, UserDetailsModel.class)
                .orElseThrow(() -> new MyBankException(E_SM_502, ": UserDetails"));
    }
}
