package kz.eub.smart.core.mybank.infrastructure.mapper;

import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;
import kz.eub.smart.core.mybank.infrastructure.entity.ProductStateEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING)
public interface ProductStateMapper {

    @Mapping(target = "type", source = "status")
    ProductStatus toDomain(ProductStateEntity productStateEntity);

}
