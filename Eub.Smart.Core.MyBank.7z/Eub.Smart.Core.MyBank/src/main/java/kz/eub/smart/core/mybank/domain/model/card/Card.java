package kz.eub.smart.core.mybank.domain.model.card;

import kz.eub.smart.core.mybank.domain.model.Balance;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;
import lombok.Data;
import java.util.List;

@Data
public class Card {
    private Long id;
    private String number;
    private String image;
    private String title;
    private ProductStatus status;
    private List<AdditionalCard> additionalCards;
    private List<Balance> amounts;
    private String link;
}
