package kz.eub.smart.core.mybank.infrastructure.mapper;

import kz.eub.smart.core.mybank.domain.model.credit.CreditPayment;
import kz.eub.smart.core.mybank.infrastructure.mapper.uses.CustomTypeDecimalValueToBigDecimal;
import kz.eub.smart.core.mybank.infrastructure.mapper.uses.TimestampToDateUses;
import kz.eubank.grpc.EubAggregatorCoreMyBank;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING, uses = {CustomTypeDecimalValueToBigDecimal.class, TimestampToDateUses.class})
public interface CreditPaymentMapper {

    List<CreditPayment> toDomain(List<EubAggregatorCoreMyBank.LoanInformation> credits);

    @Mapping(target = "creditNumber", source = "loanNumber")
    CreditPayment toDomain(EubAggregatorCoreMyBank.LoanInformation credit);
}
