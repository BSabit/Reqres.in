package kz.eub.smart.core.mybank.domain.model.current_account;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProductStatus {
    private String type;
    private String title;
}
