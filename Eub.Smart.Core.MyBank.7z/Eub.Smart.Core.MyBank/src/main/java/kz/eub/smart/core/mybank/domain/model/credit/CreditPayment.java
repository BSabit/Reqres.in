package kz.eub.smart.core.mybank.domain.model.credit;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class CreditPayment {
    private String creditNumber;
    private BigDecimal sum;
    private String paymentStatus;
    private Date date;
    private String productStatus;
}
