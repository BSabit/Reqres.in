package kz.eub.smart.core.mybank.domain.constant;

public interface BundleCode {

    String MONTHLY_LOAN_PAID = "payment.paid";
    String MONTHLY_LOAN_EXPIRED = "payment.expired";
    String MONTHLY_LOAN_PAY = "payment.for_pay";
    String MONTHLY_LOAN_PAY_ALL = "payment.for_pay_all";
    String MONTHLY_LOAN_PAY_CARD = "payment.for_pay_card";

}