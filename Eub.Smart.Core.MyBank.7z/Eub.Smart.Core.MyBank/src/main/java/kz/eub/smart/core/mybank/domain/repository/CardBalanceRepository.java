package kz.eub.smart.core.mybank.domain.repository;

import kz.eub.smart.core.mybank.domain.model.AccountBalance;

import java.util.List;
import java.util.Set;

public interface CardBalanceRepository {
    List<AccountBalance> getListBalances(Set<Long> accountOutrefs);
}
