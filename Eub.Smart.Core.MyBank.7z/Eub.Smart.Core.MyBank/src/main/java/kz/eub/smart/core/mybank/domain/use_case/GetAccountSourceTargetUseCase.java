package kz.eub.smart.core.mybank.domain.use_case;


import kz.eub.smart.core.mybank.domain.model.transfer_self.AccountSourceTargetOut;

import java.util.List;

public interface GetAccountSourceTargetUseCase {
    List<AccountSourceTargetOut> invoke(Long userId);
}
