package kz.eub.smart.core.mybank.application.filter.logger;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.*;

@Component
public class RequestResponseLogger {

    private final Logger log = LogManager.getLogger(getClass());
    private final static String AUTHORIZATION = "authorization";

    public void log(ContentCachingRequestWrapper request, ContentCachingResponseWrapper response) throws IOException {

        log.info("Event-Type=REST, Request:[method={}, path={}, headers={}, params={}, body={}], Response:[status={}, body={}]",
                request.getMethod(),
                request.getRequestURI(),
                getHeaders(request),
                getParameters(request),
                new String(request.getContentAsByteArray(), request.getCharacterEncoding()),
                response.getStatus(),
                new String(response.getContentAsByteArray(), response.getCharacterEncoding())
        );
    }

    private Map<String, String> getHeaders(HttpServletRequest request) {
        Map<String, String> headers = new HashMap<>();
        Collection<String> headerMap = Collections.list(request.getHeaderNames());
        for (String str : headerMap) {
            if (!AUTHORIZATION.equals(str)) {
                headers.put(str, request.getHeader(str));
            }
        }
        return headers;
    }

    private Map<String, String> getParameters(HttpServletRequest request) {
        Map<String, String> parameters = new HashMap<>();
        Enumeration<String> params = request.getParameterNames();
        while (params.hasMoreElements()) {
            String paramName = params.nextElement();
            String paramValue = request.getParameter(paramName);
            parameters.put(paramName, paramValue);
        }
        return parameters;
    }
}