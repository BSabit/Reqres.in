package kz.eub.smart.core.mybank.domain.model;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
public class Application {

    private Long applicationId;
    private String applicationType;
    private String statusTitle;
    private String statusType;
    private String image;
    private String title;
    private Currency currency;
    private BigDecimal amount;
    private Date dateCreated;
}
