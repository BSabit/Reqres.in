package kz.eub.smart.core.mybank.infrastructure.mapper;

import kz.eub.smart.core.mybank.domain.model.credit.CreditCardPayment;
import kz.eub.smart.core.mybank.infrastructure.mapper.uses.CustomTypeDecimalValueToBigDecimal;
import kz.eub.smart.core.mybank.infrastructure.mapper.uses.TimestampToDateUses;
import kz.eubank.grpc.EubAggregatorCoreMyBank;
import org.mapstruct.Mapper;


import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING, uses = {CustomTypeDecimalValueToBigDecimal.class, TimestampToDateUses.class})
public interface CreditCardPaymentMapper {
    CreditCardPayment toDomain(EubAggregatorCoreMyBank.GetCreditCardCurrentPaymentInformationReply payment);
}
