package kz.eub.smart.core.mybank.domain.use_case;

import kz.eub.smart.core.mybank.domain.model.transfer_self.AccountSourceOut;
import kz.eub.smart.core.mybank.domain.model.transfer_self.AccountSourceTargetIn;

import java.util.List;

public interface GetCardsForPaymentUseCase {
    List<AccountSourceOut> invoke(List<AccountSourceTargetIn> accounts);
}
