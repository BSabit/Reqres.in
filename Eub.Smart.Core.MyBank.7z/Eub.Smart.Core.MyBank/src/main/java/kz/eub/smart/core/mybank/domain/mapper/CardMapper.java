package kz.eub.smart.core.mybank.domain.mapper;

import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.card.Card;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;

public class CardMapper {

    public static Card getCard(AccountCard mainCard, ProductStatus productStatus, String detailsLink) {
        Card card = new Card();
        card.setImage(mainCard.getImage());
        card.setNumber(mainCard.getCardMaskedNumber());
        card.setTitle(mainCard.getProductTitle());
        card.setStatus(productStatus);
        card.setId(mainCard.getCardId());
        card.setLink(detailsLink);
        return card;
    }

    public static Card getCardAccount(AccountCard mainCard, ProductStatus productStatus, String cardAccountDetails) {
        Card card = new Card();
        card.setId(mainCard.getAccountId());
        card.setImage(mainCard.getImage());
        card.setNumber("");
        card.setTitle(mainCard.getProductTitle());
        card.setStatus(productStatus);
        card.setLink(cardAccountDetails);
        return card;
    }
}
