package kz.eub.smart.core.mybank.domain.model.credit;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;
import java.util.Optional;

@Data
@AllArgsConstructor
public class CreditInfo {
    private Optional<MonthlyLoan> monthlyLoan;
    private List<CreditResponse> creditResponses;
}
