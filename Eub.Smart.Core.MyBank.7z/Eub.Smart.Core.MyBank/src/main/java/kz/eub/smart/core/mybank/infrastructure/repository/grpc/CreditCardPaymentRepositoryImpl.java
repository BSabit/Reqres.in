package kz.eub.smart.core.mybank.infrastructure.repository.grpc;

import kz.eub.smart.core.mybank.domain.model.credit.CreditCardPayment;
import kz.eub.smart.core.mybank.domain.repository.CreditCardPaymentRepository;
import kz.eub.smart.core.mybank.infrastructure.mapper.CreditCardPaymentMapper;
import kz.eubank.grpc.EubAggregatorCoreMyBank;
import kz.eubank.grpc.MyBankInfoGrpc;
import lombok.RequiredArgsConstructor;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.springframework.stereotype.Repository;

@Repository
@RequiredArgsConstructor
public class CreditCardPaymentRepositoryImpl implements CreditCardPaymentRepository {

    @GrpcClient("dashboard")
    private MyBankInfoGrpc.MyBankInfoBlockingStub stub;

    private final CreditCardPaymentMapper mapper;

    @Override
    public CreditCardPayment getCreditCardPayment(String accountNumber) {
        return mapper.toDomain(getCreditPayment(accountNumber));
    }

    private EubAggregatorCoreMyBank.GetCreditCardCurrentPaymentInformationReply getCreditPayment(String accountNumber){
        EubAggregatorCoreMyBank.GetCreditCardCurrentPaymentInformationRequest request = EubAggregatorCoreMyBank.GetCreditCardCurrentPaymentInformationRequest.newBuilder()
                .setIban(accountNumber)
                .build();
        return stub.getCreditCardCurrentPaymentInformation(request);
    }

}
