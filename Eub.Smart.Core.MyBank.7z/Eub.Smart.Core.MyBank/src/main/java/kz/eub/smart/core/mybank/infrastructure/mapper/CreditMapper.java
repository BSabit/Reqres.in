package kz.eub.smart.core.mybank.infrastructure.mapper;

import kz.eub.smart.core.mybank.core.util.S3UrlUtil;
import kz.eub.smart.core.mybank.domain.model.credit.Credit;
import kz.eub.smart.core.mybank.infrastructure.entity.CreditEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING, uses = S3UrlUtil.class)
public interface CreditMapper {

    List<Credit> toDomain(List<CreditEntity> creditEntities);

    @Mapping(target = "image", source = "creditEntity.fileUid", qualifiedByName = "buildImageUrl")
    Credit toDomain(CreditEntity creditEntity);

}
