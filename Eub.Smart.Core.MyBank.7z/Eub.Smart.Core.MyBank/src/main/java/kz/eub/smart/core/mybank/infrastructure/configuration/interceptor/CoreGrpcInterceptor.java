package kz.eub.smart.core.mybank.infrastructure.configuration.interceptor;

import io.grpc.*;
import kz.eub.smart.core.mybank.core.util.StringUtil;
import net.devh.boot.grpc.client.interceptor.GrpcGlobalClientInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.context.annotation.Primary;

import static java.util.Objects.nonNull;
import static kz.eub.smart.core.mybank.core.constants.HeaderName.CORRELATION_ID;
import static kz.eub.smart.core.mybank.core.constants.LogEventType.EXTERNAL_CALL_gRPC;
import static kz.eub.smart.core.mybank.core.constants.LogEventType.GATEWAY;

@GrpcGlobalClientInterceptor
@Primary
public class CoreGrpcInterceptor implements ClientInterceptor {

    private final Logger log = LoggerFactory.getLogger(getClass());

    @Override
    public <ReqT, RespT> ClientCall<ReqT, RespT> interceptCall(final MethodDescriptor<ReqT, RespT> method, final CallOptions callOptions, final Channel next) {

        long startTime = System.currentTimeMillis();

        return new ForwardingClientCall.SimpleForwardingClientCall<>(next.newCall(method, callOptions)) {

            @Override
            public void sendMessage(ReqT message) {
                if (nonNull(MDC.get(CORRELATION_ID)) && !GATEWAY.equals(method.getServiceName())) {
                    log.info("Event-Type={}, gRPC Request:[serviceName={}, method={}, message={}]",
                            EXTERNAL_CALL_gRPC,
                            method.getServiceName(),
                            method.getBareMethodName(),
                            StringUtil.removeAllLineBreakers(message));
                }
                super.sendMessage(message);
            }

            @Override
            public void start(Listener<RespT> responseListener, Metadata headers) {
                Metadata.Key<String> key = Metadata.Key.of(CORRELATION_ID, Metadata.ASCII_STRING_MARSHALLER);
                if (nonNull(MDC.get(CORRELATION_ID))) headers.put(key, MDC.get(CORRELATION_ID));
                super.start(new ForwardingClientCallListener.SimpleForwardingClientCallListener<>(responseListener) {
                    @Override
                    public void onMessage(RespT message) {
                        if (nonNull(MDC.get(CORRELATION_ID)) && !GATEWAY.equals(method.getServiceName())) {
                            log.info("Event-Type={}, gRPC Response:[serviceName={}, method={}, message={}]",
                                    EXTERNAL_CALL_gRPC,
                                    method.getServiceName(),
                                    method.getBareMethodName(),
                                    StringUtil.removeAllLineBreakers(message));
                        }
                        super.onMessage(message);
                    }

                    @Override
                    public void onClose(Status status, Metadata trailers) {
                        if (nonNull(MDC.get(CORRELATION_ID)) && !GATEWAY.equals(method.getServiceName())) {
                            long duration = System.currentTimeMillis() - startTime;
                            StringBuilder statusInfo = new StringBuilder();
                            statusInfo.append("Status{")
                                    .append("code=").append(status.getCode())
                                    .append(", description=").append(StringUtil.removeAllLineBreakers(status.getDescription() != null ? status.getDescription() : ""))
                                    .append(", cause=").append(status.getCause())
                                    .append(", duration=").append(duration).append(" ms");
                            log.info("Event-Type={}, gRPC Response:[serviceName={}, method={}, status={}]",
                                    EXTERNAL_CALL_gRPC,
                                    method.getServiceName(),
                                    method.getBareMethodName(),
                                    statusInfo);
                        }
                        super.onClose(status, trailers);
                    }
                }, headers);
            }
        };
    }
}
