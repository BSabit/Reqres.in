package kz.eub.smart.core.mybank.domain.model.credit;

import lombok.Data;

@Data
public class Credit {

    private Long id;
    private String image;
    private String title;
    private Long paidPeriod;
    private Long fullPeriod;
    private String statusTitle;
    private String statusCode;
    private String creditNumber;
}
