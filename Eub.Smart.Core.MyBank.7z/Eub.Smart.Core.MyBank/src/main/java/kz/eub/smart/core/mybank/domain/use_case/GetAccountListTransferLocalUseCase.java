package kz.eub.smart.core.mybank.domain.use_case;


import kz.eub.smart.core.mybank.domain.model.transfer_self.AccountSourceOut;

import java.util.List;

public interface GetAccountListTransferLocalUseCase {
    List<AccountSourceOut> invoke(Long userId);
}
