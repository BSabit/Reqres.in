package kz.eub.smart.core.mybank.infrastructure.repository.grpc;

import kz.eub.smart.core.mybank.core.util.CollectionUtil;
import kz.eub.smart.core.mybank.domain.model.AccountBalance;
import kz.eub.smart.core.mybank.infrastructure.mapper.AccountBalanceMapper;
import kz.eub.smart.core.mybank.domain.repository.CardBalanceRepository;
import kz.eubank.grpc.MyBankInfoGrpc;
import kz.eubank.grpc.*;
import lombok.RequiredArgsConstructor;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.springframework.stereotype.Service;

import java.util.*;

@RequiredArgsConstructor
@Service
public class CardBalanceRepositoryImpl implements CardBalanceRepository {

    @GrpcClient("dashboard")
    private MyBankInfoGrpc.MyBankInfoBlockingStub stub;

    private final AccountBalanceMapper mapper;

    @Override
    public List<AccountBalance> getListBalances(Set<Long> accountOutrefs) {
        if (CollectionUtil.isNotEmpty(accountOutrefs)) {
            return mapper.toDomainFromCardBalance(getBalances(accountOutrefs).getBalancesList());
        }
        return Collections.emptyList();
    }

    public EubAggregatorCoreMyBank.CardAccountBalanceReply getBalances(Set<Long> accountOutrefs){
        EubAggregatorCoreMyBank.GetCardAccountBalanceRequest request = EubAggregatorCoreMyBank.GetCardAccountBalanceRequest
                .newBuilder()
                .addAllAccountIds(accountOutrefs)
                .build();
        return stub.getCardAccountBalance(request);
    }
}
