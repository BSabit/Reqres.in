package kz.eub.smart.core.mybank.domain.mapper;

import kz.eub.smart.core.mybank.domain.model.AccountBalance;
import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.Balance;
import kz.eub.smart.core.mybank.domain.model.current_account.Account;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;

public class AccountMapper {

    public static Account getAccount(AccountCard accountCard, AccountBalance accountBalance, ProductStatus productStatus, String detailsLink) {
        Account account = new Account();
        account.setId(accountCard.getAccountId());
        account.setTitle(accountCard.getProductTitle());
        account.setAmount(new Balance(accountBalance.getBalance(), accountBalance.getCurrency()));
        account.setImage(accountCard.getImage());
        account.setStatus(productStatus);
        account.setLink(detailsLink);
        return account;
    }
}
