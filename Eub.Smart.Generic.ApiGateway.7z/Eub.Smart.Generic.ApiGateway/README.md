### Описание проекта
ApiGateway - gateway для новых сервисов smartbank:
- проверка входящих запросов на авторизацию
- gateway

### Информация по K8s деплою (DevOps):
- project_name: **smart-generic-apigateway**
- namespace: **smart-generic**
- image: **nexus-dev.eub.kz:8085/repository/smart-generic/smart-generic-apigateway**
- dev-endpoints: **smart-generic-apigateway.devk8s.eub.kz**
- prod-endpoints: **smart-generic-apigateway.eub.kz**
- internal-port: **8081**
- limits: **cpu: 500m, memory: 500Mi**
- requests: **cpu: 200m, memory: 200Mi**
- labels: **[app: "smart-generic-apigateway", domain: "generic"]**
- autoscale **on** replicas min 1, max 3 (cpu, memory threshold 80%)

### Инструкция для начала работы:
- Восстановление пакетов и компиляция: `gradle build`
- Адрес тестовой среды проекта:
    - service name: smart-generic-apigateway.smart-generic:8080
    - node port:
    - dns:

- Инструкция для запуска исходного кода: `java -Dspring.profiles.active=docker -Djava.awt.headless=true -jar /app/app.jar`
- Dashboard K8s:
  <br/> https://dashboard.devk8s.eub.kz/#/service/smart-generic/smart-generic-apigateway?namespace=smart-generic
- ELK:
  <br/> http://172.25.43.147/s/smartbank/app/discover
  <br> !!!NOTE: Необходимо выбрать smart-generic.smart-generic-apigateway
- Docker Image Repo: https://nexus-dev.eub.kz/#browse/browse:docker-registry:v2%2Frepository%2Fsmart-generic%2Fsmart-generic-apigateway
- Nexus:
  <br> https://nexus-dev.eub.kz
  <br> !!!NOTE: Все необходимые библиотеки скачивать с Nexus-а

### Инструкция для тестирования:
- Алгоритм тестирования адаптера в программе Postman и / или прочих:
- Виды тестов, которые можно произвести над проектом:

### Статус сборки:
Сборка в пилотном тестировании

### Установка дополнительного ПО
https://www.jetbrains.com/idea/download/ (Community)

### Связи и обращения
- postgres:
    - dev: 172.25.43.119:5432
    - prod: -
- keycloak:
    - dev: https://keycloak-smart.devk8s.eub.kz/
    - prod: https://keycloak-smart.eub.kz/

![Logic schema](/logic-schema/api-gateway.png)
