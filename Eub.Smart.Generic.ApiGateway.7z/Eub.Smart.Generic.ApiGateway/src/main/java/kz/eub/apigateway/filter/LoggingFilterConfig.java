package kz.eub.apigateway.filter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;

@Configuration
public class LoggingFilterConfig {

    private static final Logger logger = LoggerFactory.getLogger(LoggingFilterConfig.class);
    @Bean
    public WebFilter logFilter() {
        return (ServerWebExchange exchange, WebFilterChain chain) -> {
            long startTime = System.currentTimeMillis();
            String uri = exchange.getRequest().getURI().getPath();
            return chain.filter(exchange).doOnTerminate(() -> {
                if (!uri.startsWith("/actuator/prometheus")) {
                    long duration = System.currentTimeMillis() - startTime;
                    StringBuilder requestInfoBuilder = new StringBuilder();
                    requestInfoBuilder.append("CorrelationId: ")
                            .append(exchange.getRequest().getHeaders().getFirst("X-Correlation-Id"))
                            .append(", IP: ")
                            .append(exchange.getRequest().getHeaders().getFirst("X-Forwarded-For"))
                            .append(", Method: ")
                            .append(exchange.getRequest().getMethod())
                            .append(", URI: ")
                            .append(exchange.getRequest().getURI());

                    StringBuilder responseInfoBuilder = new StringBuilder();
                    responseInfoBuilder.append("Status: ")
                            .append(exchange.getResponse().getStatusCode())
                            .append(", Duration: ")
                            .append(duration)
                            .append(" ms");

                    String requestInfo = requestInfoBuilder.toString();
                    String responseInfo = responseInfoBuilder.toString();

                    logger.info("{} | {}", requestInfo, responseInfo);
                }
            });
        };
    }
}

