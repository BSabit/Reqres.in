package kz.eub.apigateway.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.security.web.server.authentication.HttpStatusServerEntryPoint;
import org.springframework.web.cors.CorsConfiguration;

import java.util.List;

@Configuration
public class SecurityConfiguration {

    @Bean
    public SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http) throws Exception {
        http
            .csrf().disable()
            .cors().configurationSource(exchange -> {
                CorsConfiguration config = new CorsConfiguration();
                config.setAllowedOriginPatterns(List.of("*"));
                config.setAllowedHeaders(List.of("*"));
                config.setAllowedMethods(List.of("*"));
                config.setAllowCredentials(true);
                return config;
            })
            .and()
            .authorizeExchange()
            .pathMatchers("/registration/**").permitAll()
            .pathMatchers("/auth/**").permitAll()
            .pathMatchers("/digitalid/open-api/**").permitAll()
            .pathMatchers("/reference/**").permitAll()
            .pathMatchers("/actuator/**").permitAll()
            .pathMatchers("/forex/front/**").permitAll()
            .pathMatchers("/forex/v1/webhook/**").permitAll()
            .pathMatchers("/visa-b2b/**").permitAll()
            .pathMatchers("/s3/api/download/**").permitAll()
            .pathMatchers("/cms/main").permitAll()
            .pathMatchers("/unauthorized/**").permitAll()
            .anyExchange().authenticated()
            .and()
            .oauth2ResourceServer()
            .opaqueToken()
            .and()
            .authenticationEntryPoint(new HttpStatusServerEntryPoint(HttpStatus.UNAUTHORIZED));

        return http.build();
    }

}
