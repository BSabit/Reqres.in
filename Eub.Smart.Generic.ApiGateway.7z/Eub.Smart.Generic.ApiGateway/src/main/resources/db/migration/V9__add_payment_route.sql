INSERT INTO route(id_name, uri, p_path)
VALUES ('payment', 'http://smart-payment.smart-payment.svc.cluster.local:8080', '/payment/**');