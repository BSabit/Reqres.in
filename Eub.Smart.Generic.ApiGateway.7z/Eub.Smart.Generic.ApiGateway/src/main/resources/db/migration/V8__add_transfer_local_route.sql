INSERT INTO route(id_name, uri, p_path)
VALUES ('transfer-local', 'http://smart-cardproduct-transfer-self.smart-cardproduct.svc.cluster.local:8080', '/transfer-local/**');