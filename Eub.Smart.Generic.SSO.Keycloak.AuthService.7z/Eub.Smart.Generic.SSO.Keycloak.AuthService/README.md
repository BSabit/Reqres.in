### Описание проекта
AuthService - сервис для авторизации через Keycloak:
- Авторизации по логину
- Получение refresh token
- logout
- Проверка актуальности токена
- Блокировка и разблокировка пользователя

### Информация по K8s деплою (DevOps):
- project_name: **smart-generic-sso-keycloak-authservice**
- namespace: **smart-generic**
- image: **nexus-dev.eub.kz:8085/repository/smart-generic/smart-generic-sso-keycloak-authservice**
- dev-endpoints: **-**
- prod-endpoints: **-**
- internal-port: **8080**
- limits: **cpu: 500m, memory: 500Mi**
- requests: **cpu: 200m, memory: 200Mi**
- labels: **[app: "smart-generic-sso-keycloak-authservice", domain: "generic"]**
- autoscale **on** replicas min 1, max 3 (cpu, memory threshold 80%)

### Инструкция для начала работы:
- Восстановление пакетов и компиляция: `gradle build`
- Адрес тестовой среды проекта: 
    - service name: smart-generic-sso-keycloak-authservice.smart-generic:8080
    - node port: 
    - dns: 
- Адрес gRpcUI/Swagger: 
  <br/> https://smart-generic-swaggercentral.devk8s.eub.kz/swagger-ui/index.html?urls.primaryName=keycloak
- Инструкция для запуска исходного кода: `java -Dspring.profiles.active=docker -Djava.awt.headless=true -jar /app/app.jar`
- Dashboard K8s: 
  <br/> https://dashboard.devk8s.eub.kz/#/service/smart-generic/smart-generic-sso-keycloak-authservice?namespace=smart-generic
- ELK: 
  <br/> http://172.25.43.147/s/smartbank/app/discover
  <br> !!!NOTE: Необходимо выбрать smart-generic.smart-generic-sso-keycloak-authservice
- Docker Image Repo: https://nexus-dev.eub.kz/#browse/browse:docker-registry:v2%2Frepository%2Fsmart-generic%2Fsmart-generic-sso-keycloak-authservice
- Nexus: 
  <br> https://nexus-dev.eub.kz 
  <br> !!!NOTE: Все необходимые библиотеки скачивать с Nexus-а

### Инструкция для тестирования:
- Алгоритм тестирования адаптера в программе Postman и / или прочих:
- Виды тестов, которые можно произвести над проектом:

### Статус сборки: 
Сборка в пилотном тестировании

### Установка дополнительного ПО
https://www.jetbrains.com/idea/download/ (Community)

### Связи и обращения
- api-gateway:
    - dev: smart-generic-apigateway.devk8s.eub.kz
    - prod: smart-generic-apigateway.eub.kz
- mssql:
    - dev: 172.25.43.31:1433
    - prod: kzwsqlsmart.eub.kz:1433
- keycloak:
    - dev: https://keycloak-smart.devk8s.eub.kz/
    - prod: https://keycloak-smart.eub.kz/

![Logic schema](/logic-schema/auth-service.png)
