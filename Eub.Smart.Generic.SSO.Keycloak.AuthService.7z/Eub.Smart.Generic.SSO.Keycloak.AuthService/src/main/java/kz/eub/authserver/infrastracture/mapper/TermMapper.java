package kz.eub.authserver.infrastracture.mapper;

import kz.eub.authserver.domain.model.Term;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface TermMapper {
    Term toTerm(kz.eub.authserver.infrastracture.entity.Term term);
}
