package kz.eub.authserver.application.controller;

import kz.eub.authserver.domain.use_case.ClearUserCacheUseCase;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/users/")
@RequiredArgsConstructor
public class UserController {
    public final ClearUserCacheUseCase clearUserCacheUseCase;

    @DeleteMapping("{login}")
    public ResponseEntity<?> clearUserCache(@PathVariable String login) {
        clearUserCacheUseCase.invoke(login);

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

}
