package kz.eub.authserver.domain.repository;

public interface AdminRepository {
    void deleteUserByUsername(String phoneNumber);
}
