package kz.eub.authserver.infrastracture.entity;

import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "NewPasscode")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class NewPasscodeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Passcode_ID")
    private Long id;

    @Column(name = "User_IDREF")
    private Long userId;

    @Column(name = "PasscodeStatus_IDREF")
    private String status;

    @Column(name = "Hash")
    private String hash;

    @Column(name = "DeviceID")
    private String deviceId;

    @Column(name = "DateCreated")
    private Date dateCreated;

    @Column(name = "InvalidUses")
    private int invalidUses;
}