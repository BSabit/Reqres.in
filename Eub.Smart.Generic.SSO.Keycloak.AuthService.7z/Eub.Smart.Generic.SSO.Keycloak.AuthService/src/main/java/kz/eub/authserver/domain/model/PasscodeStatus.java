package kz.eub.authserver.domain.model;

public enum PasscodeStatus {
    ACTV,
    BUPR,
    BLAE
}
