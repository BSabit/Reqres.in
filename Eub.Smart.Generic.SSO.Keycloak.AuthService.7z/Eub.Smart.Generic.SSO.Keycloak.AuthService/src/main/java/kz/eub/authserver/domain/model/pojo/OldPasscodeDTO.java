package kz.eub.authserver.domain.model.pojo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import java.util.Date;

@Builder
@Setter
@Getter
public class OldPasscodeDTO {

    private int id;
    private int userId;
    private String status;
    private String hash;
    private String salt;
    private String deviceId;
    private Date dateCreated;
    private int invalidUses;
    private Date lastInvalidUse;
}
