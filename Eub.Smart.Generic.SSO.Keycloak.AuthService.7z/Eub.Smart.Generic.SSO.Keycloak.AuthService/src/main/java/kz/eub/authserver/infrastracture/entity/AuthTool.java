package kz.eub.authserver.infrastracture.entity;

import kz.eub.authserver.domain.model.AuthToolStatus;

import javax.persistence.*;

@Entity
@Table(name = "AuthTool")
public class AuthTool {

    @Id
    @Column(name = "AuthTool_ID")
    private Long id;

    @Enumerated(value = EnumType.STRING)
    @Column(name = "AuthToolStatus_IDREF")
    private AuthToolStatus status;
}
