package kz.eub.authserver.application.view;

import kz.eub.authserver.domain.model.User;

public record LoginRequestMessage(String deviceId, String phoneNumber, String passcode) {

    public User toUser(){
        return new User(this.deviceId, this.phoneNumber, this.passcode);
    }
}
