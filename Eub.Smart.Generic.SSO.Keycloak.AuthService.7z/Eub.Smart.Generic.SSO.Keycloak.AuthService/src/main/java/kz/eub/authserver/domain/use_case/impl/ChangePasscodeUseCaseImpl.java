package kz.eub.authserver.domain.use_case.impl;

import kz.eub.authserver.application.filter.AuthToken;
import kz.eub.authserver.domain.exception.SelfException;
import kz.eub.authserver.domain.model.pojo.NewPasscodeDTO;
import kz.eub.authserver.domain.repository.NewPasscodeRepository;
import kz.eub.authserver.domain.use_case.ChangePasscodeUseCase;
import kz.eub.authserver.domain.use_case.HashUseCase;
import lombok.RequiredArgsConstructor;
import org.jboss.logging.MDC;
import static kz.eub.authserver.core.constant.UserDetails.USER_ID;
import static kz.eub.authserver.core.util.DateUtil.currentDate;
import static kz.eub.authserver.domain.exception.SelfErrorCode.E_DB_600;
import static kz.eub.authserver.domain.model.PasscodeStatus.BUPR;

@RequiredArgsConstructor
public class ChangePasscodeUseCaseImpl implements ChangePasscodeUseCase {

    private final NewPasscodeRepository newPasscodeRepository;
    private final HashUseCase hashUseCase;
    private final AuthToken authToken;

    @Override
    public void invoke(String authorization, String pin) {
        var userId = getUserId(authorization);
        var deviceId = newPasscodeRepository.getDeviceIdByUserId(userId).orElseThrow(() -> new SelfException(E_DB_600, ": Not found by userId"));
        var hashPasscode = hashUseCase.getHash(pin);
        this.changePasscodeStatusByUserId(BUPR.toString(), String.valueOf(userId));
        NewPasscodeDTO passcode = NewPasscodeDTO.builder()
                .hash(hashPasscode)
                .deviceId(deviceId)
                .userId(userId)
                .status("ACTV")
                .dateCreated(currentDate())
                .build();
        newPasscodeRepository.save(passcode);
    }

    private long getUserId(String authorization) {
        MDC.put("Authorization", authorization);
        authToken.addToMDC();
        String userIdStr = (String) MDC.get(USER_ID);
        MDC.clear();
        return Long.parseLong(userIdStr);
    }

    @Override
    public void changePasscodeStatusByUserId(String status, String userID) {
        newPasscodeRepository.changeStatusByUserId(status, userID);
    }
}
