package kz.eub.authserver.infrastracture.repository.db.jpa;

import kz.eub.authserver.domain.model.UserStatus;
import kz.eub.authserver.infrastracture.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface UserJpaRepository extends JpaRepository<User, Long> {
    @Query("""
            SELECT u
            FROM MobilePhone m
            INNER JOIN AuthSMS a ON a.mobilePhoneId = m.id
            INNER JOIN UserAuthTool mua ON mua.authToolId = a.authToolId
            INNER JOIN AuthTool at ON at.id = mua.authToolId
            INNER JOIN User u ON u.id = mua.userId
            INNER JOIN NewPasscode p ON u.id = p.userId
            WHERE m.mobilePhone = ?1 AND p.status = 'ACTV' AND m.status = 'ACTV' AND at.status = 'ACTV'""")
    Optional<User> getUserByPhoneNumber(String phoneNumber);
}
