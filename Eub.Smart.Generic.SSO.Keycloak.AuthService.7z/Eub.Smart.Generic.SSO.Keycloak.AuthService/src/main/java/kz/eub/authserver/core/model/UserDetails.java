package kz.eub.authserver.core.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import kz.eub.authserver.domain.exception.SelfException;

import static kz.eub.authserver.core.util.JsonUtil.toObject;
import static kz.eub.authserver.domain.exception.SelfErrorCode.E_SM_502;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserDetails {

    @JsonProperty("user_id")
    private Long userId;
    @JsonProperty("birth_date")
    private String birthDate;
    @JsonProperty("name")
    private String name;
    @JsonProperty("preferred_username")
    private String preferredUsername;
    @JsonProperty("middle_name")
    private String middleName;
    @JsonProperty("given_name")
    private String givenName;
    @JsonProperty("family_name")
    private String familyName;
    @JsonProperty("client_id")
    private Long clientId;
    @JsonProperty("iin")
    private String iin;
    @JsonProperty("person_id")
    private Long personId;

    public UserDetails() {
    }

    public UserDetails(Long userId,
                       String birthDate,
                       String name,
                       String preferredUsername,
                       String middleName,
                       String givenName,
                       String familyName,
                       Long clientId,
                       String iin,
                       Long personId) {
        this.userId = userId;
        this.birthDate = birthDate;
        this.name = name;
        this.preferredUsername = preferredUsername;
        this.middleName = middleName;
        this.givenName = givenName;
        this.familyName = familyName;
        this.clientId = clientId;
        this.iin = iin;
        this.personId = personId;
    }

    public Long getUserId() {
        return userId;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public String getName() {
        return name;
    }

    public String getPreferredUsername() {
        return preferredUsername;
    }

    public String getMiddleName() {
        return middleName;
    }

    public String getGivenName() {
        return givenName;
    }

    public String getFamilyName() {
        return familyName;
    }

    public Long getClientId() {
        return clientId;
    }

    public String getIin() {
        return iin;
    }

    public Long getPersonId() {
        return personId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPreferredUsername(String preferredUsername) {
        this.preferredUsername = preferredUsername;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public void setIin(String iin) {
        this.iin = iin;
    }

    public void setPersonId(Long personId) {
        this.personId = personId;
    }

    public static UserDetails build(String payload) {
        return toObject(payload, UserDetails.class)
                .orElseThrow(() -> new SelfException(E_SM_502, ": UserDetails"));
    }

    @Override
    public String toString() {
        return "UserDetails{" +
                "userId=" + userId +
                ", birthDate=" + birthDate +
                ", name=" + name +
                ", preferredUsername=" + preferredUsername +
                ", middleName=" + middleName +
                ", givenName=" + givenName +
                ", familyName=" + familyName +
                ", clientId=" + clientId +
                ", iin=" + iin +
                ", personId=" + personId +
                '}';
    }
}
