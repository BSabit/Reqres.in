package kz.eub.authserver.domain.use_case;

import kz.eub.authserver.domain.model.LoginResponse;
import kz.eub.authserver.domain.model.User;

public interface Login {
    LoginResponse invoke(User user, int hiddenInvalidUses, int maxInvalidUses, String language);
}
