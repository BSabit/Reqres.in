package kz.eub.authserver.application.controller_advice;

import kz.eub.authserver.domain.model.LoginResponse;
import kz.eub.authserver.domain.repository.TermRepository;
import kz.eub.authserver.domain.exception.*;
import kz.eub.authserver.domain.exception.UnAuthorizeException;
import kz.eubank.core.config.ApplicationContext;
import lombok.RequiredArgsConstructor;
import lombok.val;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import static kz.eub.authserver.domain.model.Steps.*;

@ControllerAdvice
@RequiredArgsConstructor
public class ResponseEntityExceptionHandler {

    private final ApplicationContext context;
    private final TermRepository termDao;

    @ExceptionHandler(value = {AccountBlockedDefineRouteException.class})
    public ResponseEntity<LoginResponse> handleBlockedEx(AccountBlockedDefineRouteException ex) {
        val user = context.getCurrentUser();
        val lang = context.getLanguage();
        val termErr = termDao.getOneByCode("define_route_error_msg")
                .orElseThrow(() -> new NotFoundException("Term not found!"));
        val termDesc = termDao.getOneByCode("define_route_error_desc")
                .orElseThrow(() -> new NotFoundException("Term not found!"));
        val termBtn = termDao.getOneByCode("define_route_button_text")
                .orElseThrow(() -> new NotFoundException("Term not found!"));
        val errMsg = switch (lang) {
            case "en" -> termErr.descEN();
            case "ru" -> termErr.descRU();
            default -> termErr.descKZ();
        };
        val descErr = switch (lang) {
            case "en" -> termDesc.descEN();
            case "ru" -> termDesc.descRU();
            default -> termDesc.descKZ();
        };
        val btmText = switch (lang) {
            case "en" -> termBtn.descEN();
            case "ru" -> termBtn.descRU();
            default -> termBtn.descKZ();
        };
        val response = LoginResponse.builder()
                .errorMessage(errMsg)
                .errorDescription(descErr)
                .buttonText(btmText)
                .techErrorDescription(ex.getMessage())
                .nextStep(DefineRoute)
                .build();
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(value = {AccountBlockedCallBankException.class})
    public ResponseEntity<LoginResponse> handleException(AccountBlockedCallBankException ex) {
        val lang = context.getLanguage();
        val termErr = termDao.getOneByCode("call_bank_error_msg")
                .orElseThrow(() -> new NotFoundException("Term not found!"));
        val termDesc = termDao.getOneByCode("call_bank_error_desc")
                .orElseThrow(() -> new NotFoundException("Term not found!"));
        val termBtn = termDao.getOneByCode("call_bank_button_text")
                .orElseThrow(() -> new NotFoundException("Term not found!"));
        val errMsg = switch (lang) {
            case "en" -> termErr.descEN();
            case "ru" -> termErr.descRU();
            default -> termErr.descKZ();
        };
        val desc = switch (lang) {
            case "en" -> termDesc.descEN();
            case "ru" -> termDesc.descRU();
            default -> termDesc.descKZ();
        };
        val btmText = switch (lang) {
            case "en" -> termBtn.descEN();
            case "ru" -> termBtn.descRU();
            default -> termBtn.descKZ();
        };
        val response = LoginResponse.builder()
                .errorMessage(errMsg)
                .errorDescription(desc)
                .buttonText(btmText)
                .techErrorDescription(ex.getMessage())
                .nextStep(DefineRoute)
                .build();
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(value = {UnAuthorizeException.class})
    public ResponseEntity<LoginResponse> handleException(UnAuthorizeException ex) {

        val response = LoginResponse.builder()
                .errorDescription(ex.getMessage())
                .errorMessage(ex.getMessage())
                .nextStep(PasscodeError)
                .build();
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(value = {VerificationRequiredException.class})
    public ResponseEntity<LoginResponse> handleException(VerificationRequiredException ex) {
        val response = LoginResponse.builder()
                .nextStep(VerificationRequired)
                .techErrorDescription(ex.getMessage())
                .build();
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(value = {BadHistoryException.class})
    public ResponseEntity<LoginResponse> handleException(BadHistoryException ex) {
        val response = LoginResponse.builder()
                .techErrorDescription(ex.getMessage())
                .build();
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(value = {NotFoundException.class})
    public ResponseEntity<LoginResponse> handleException(NotFoundException ex) {
        val response = LoginResponse.builder()
                .techErrorDescription(ex.getMessage())
                .build();
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }
    
    @ExceptionHandler(value = {UserNotFoundException.class})
    public ResponseEntity<LoginResponse> handleException(UserNotFoundException ex) {
        val response = LoginResponse.builder()
                .techErrorDescription(ex.getMessage())
                .build();
        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(value = {AppException.class})
    public ResponseEntity<LoginResponse> handleException(AppException ex) {
        val response = LoginResponse.builder()
                .techErrorDescription(ex.getMessage())
                .build();
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
