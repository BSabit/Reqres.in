package kz.eub.authserver.domain.use_case;

public interface ClearUserCacheUseCase {

    void invoke(String login);
}
