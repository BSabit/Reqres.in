package kz.eub.authserver.infrastracture.repository.db.jpa;


import kz.eub.authserver.infrastracture.entity.OldPasscodeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import javax.transaction.Transactional;
import java.util.Optional;

@Repository
public interface OldPasscodeJpaRepository extends JpaRepository<OldPasscodeEntity, Integer> {

    @Query(value = """
                    SELECT Count(*) FROM Passcode
                    WHERE DeviceID = :deviceId
                    AND PasscodeStatus_IDREF = 'ACTV'
                    AND User_IDREF = :userId
    """, nativeQuery = true)
    int getPasscodeIsExistCountAmount(String deviceId, long userId);

    @Transactional
    @Modifying
    @Query(nativeQuery = true,
            value = """
                    UPDATE Passcode 
                    SET PasscodeStatus_IDREF = :status 
                    WHERE USER_IDREF = :userID 
                    AND PasscodeStatus_IDREF = 'ACTV'
            """)
    void changeStatusByUserId(String status, String userID);

    @Query(nativeQuery = true,
            value = """
                     select * from Passcode 
                     WHERE User_IDREF = :userId 
                     AND PasscodeStatus_IDREF = 'ACTV'
           """)
    Optional<OldPasscodeEntity> getDeviceIdByUserId(long userId);
}
