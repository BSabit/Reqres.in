package kz.eub.authserver.core.constant;

public interface Channel {

    String UFO = "UFO";
}
