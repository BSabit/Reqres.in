package kz.eub.authserver.domain.use_case.impl;

import kz.eub.authserver.domain.exception.AppException;
import kz.eub.authserver.domain.model.LoginResponse;
import kz.eub.authserver.domain.repository.AuthorizationRepository;
import kz.eub.authserver.domain.use_case.RefreshToken;

public class RefreshTokenImpl implements RefreshToken {

    private final AuthorizationRepository authorizationRepository;

    public RefreshTokenImpl(AuthorizationRepository authorizationRepository) {
        this.authorizationRepository = authorizationRepository;
    }

    @Override
    public LoginResponse invoke(String refreshToken) {

        try {
            final var response = authorizationRepository.getAuthByRefreshToken(refreshToken);

            return LoginResponse.builder()
                    .token(response.token())
                    .refreshToken(response.refreshToken())
                    .build();
        } catch (RuntimeException e) {
            throw new AppException(e.getMessage());
        }
    }
}
