package kz.eub.authserver.domain.use_case;

import kz.eub.authserver.domain.model.LoginResponse;

public interface RefreshToken {
    LoginResponse invoke(String tokenRefresh);
}
