package kz.eub.authserver.domain.model;

public enum AuthToolStatus {
    ACTV
}
