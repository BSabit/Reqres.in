package kz.eub.authserver.domain.use_case;

public interface Logout {
    void invoke();
}
