package kz.eub.authserver.domain.exception;

import org.springframework.http.HttpStatus;

public class AccountBlockedCallBankException extends AppException {
    public AccountBlockedCallBankException(String message) {
        super(message);
    }

    @Override
    public HttpStatus getStatus() {
        return HttpStatus.LOCKED;
    }
}
