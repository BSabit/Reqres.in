package kz.eub.authserver.core.util;

import java.util.Calendar;
import java.util.Date;

public class DateUtil {
    public static Date currentDate() {
        return new Date();
    }

    public static Date addMinutesToCurrentDate(long minutes) {
        var date = Calendar.getInstance();
        var timeInSecs = date.getTimeInMillis();
        return new Date(timeInSecs + (minutes * 60 * 1000));
    }

    public static Date addYearsToCurrentDate(long years) {
        var date = Calendar.getInstance();
        var timeInSecs = date.getTimeInMillis();
        return new Date(timeInSecs + (years * 365 * 24 * 60 * 60 * 1000));
    }
}
