package kz.eub.authserver.infrastracture.repository.db.jpa;

import kz.eub.authserver.infrastracture.entity.NewPasscodeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface NewPasscodeJpaRepository2 extends JpaRepository<NewPasscodeEntity, Long> {
    @Query(nativeQuery = true,
            value = """
                     select * from NewPasscode WHERE User_IDREF = :userId AND PasscodeStatus_IDREF = 'ACTV'
           """)
    Optional<NewPasscodeEntity> getDeviceIdByUserId(long userId);
}
