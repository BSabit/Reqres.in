package kz.eub.authserver.domain.use_case.impl;

import kz.eub.authserver.domain.repository.AuthorizationRepository;
import kz.eub.authserver.domain.use_case.Logout;

public class LogoutImpl implements Logout {

    private final AuthorizationRepository authorizationRepository;

    public LogoutImpl(AuthorizationRepository authorizationRepository) {
        this.authorizationRepository = authorizationRepository;
    }

    @Override
    public void invoke() {
        authorizationRepository.logout();
    }
}
