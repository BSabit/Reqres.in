package kz.eub.authserver.domain.use_case.impl;

import kz.eub.authserver.domain.repository.AdminRepository;
import kz.eub.authserver.domain.use_case.ClearUserCacheUseCase;

public class ClearUserCacheUseCaseImpl implements ClearUserCacheUseCase {

    private final AdminRepository repository;

    public ClearUserCacheUseCaseImpl(AdminRepository repository) {
        this.repository = repository;
    }

    @Override
    public void invoke(String login) {
        repository.deleteUserByUsername(login);
    }
}