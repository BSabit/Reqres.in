package kz.eub.authserver.domain.util;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.UUID;

public class CommonUtil {

    public static String randomNumber(int size) {
        var multiplier = Long.parseLong(StringUtils.rightPad("9", size, '0'));
        var summand = Long.parseLong(StringUtils.rightPad("1", size, '0'));
        return String.valueOf((long) Math.floor(Math.random() * multiplier) + summand);
    }

    public static String sha64(String str) {
        if (str == null) {
            return "";
        }
        byte[] sha = DigestUtils.sha1(str);
        return Base64.encodeBase64String(sha);
    }

    public static String salt() {
        return UUID.randomUUID().toString().toUpperCase();
    }
}
