package kz.eub.authserver.core.util;

import java.util.Collection;

public class CollectionUtil {

    public static boolean isEmpty(Object[] arr){
        return arr == null || arr.length == 0;
    }

    public static <T> boolean isEmpty(Collection<T> col){
        return col == null || col.isEmpty();
    }

    public static <T> boolean isNotEmpty(Collection<T> col){
        return !isEmpty(col);
    }

    public static <T> boolean isOneResult(Collection<T> col) {
        return col.size() == 1;
    }
}
