package kz.eub.authserver.infrastracture.repository.keycloak;

import kz.eub.authserver.domain.exception.AppException;
import kz.eub.authserver.domain.exception.UserNotFoundException;
import kz.eub.authserver.domain.repository.AdminRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.authorization.client.AuthzClient;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import javax.ws.rs.core.Response;
import java.util.List;

import static kz.eub.authserver.core.util.CollectionUtil.isEmpty;

@Slf4j
@RequiredArgsConstructor
@Repository
public class AdminRepositoryImpl implements AdminRepository {

    private final Keycloak keycloak;
    private final AuthzClient authzClient;

    @Override
    public void deleteUserByUsername(String phoneNumber) {
        List<UserRepresentation> searchUser = keycloak.realm(authzClient.getConfiguration().getRealm()).users().search(phoneNumber);
        if (isEmpty(searchUser)) {
            log.info("While search user: {}, return not result", phoneNumber);
            throw new UserNotFoundException("User not found: " + phoneNumber);
        }

        if (searchUser.size() != 1) {
            log.error("An error occurred while search user: {}, return more than one result", phoneNumber);
            throw new AppException("Return more than one result: " + phoneNumber);
        }

        String userId = searchUser.get(0).getId();
        Response deleteResponse;
        try {
            deleteResponse = keycloak.realm(authzClient.getConfiguration().getRealm()).users().delete(userId);
        } catch (Exception e) {
            log.error("An error occurred while delete the user: {}", phoneNumber);
            throw new AppException("Keycloak service unavailable");
        }

        HttpStatus status = HttpStatus.valueOf(deleteResponse.getStatus());
        if ((status.is2xxSuccessful()) || (status ==  HttpStatus.BAD_REQUEST)) {   //todo need rework Keycloak, does not respond correctly(400 bad request) but removes user
            log.info("User: {} deleted successfully", phoneNumber);
        } else {
            log.error("An error occurred while delete the user: {}", phoneNumber);
            throw new AppException("Keycloak service response error");
        }
    }
}