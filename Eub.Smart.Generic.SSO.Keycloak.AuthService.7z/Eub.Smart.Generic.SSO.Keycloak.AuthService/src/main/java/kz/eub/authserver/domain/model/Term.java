package kz.eub.authserver.domain.model;

public record Term(
        String descKZ,
        String descRU,
        String descEN,
        String code
) {

    public static Term.TermBuilder builder() {
        return new TermBuilder();
    }

    public static class TermBuilder {
        private String descKZ;
        private String descRU;
        private String descEN;
        private String code;

        public TermBuilder descKZ(String descKZ) {
            this.descKZ = descKZ;
            return this;
        }

        public TermBuilder descRU(String descRU) {
            this.descRU = descRU;
            return this;
        }

        public TermBuilder descEN(String descEN) {
            this.descEN = descEN;
            return this;
        }

        public TermBuilder code(String code) {
            this.code = code;
            return this;
        }

        public Term build() {
            return new Term(
                    this.descKZ,
                    this.descRU,
                    this.descEN,
                    this.code
            );
        }
    }
}
