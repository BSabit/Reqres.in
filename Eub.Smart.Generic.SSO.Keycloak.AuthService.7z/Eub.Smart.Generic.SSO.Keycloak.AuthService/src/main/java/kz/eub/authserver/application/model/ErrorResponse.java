package kz.eub.authserver.application.model;

import io.swagger.v3.oas.annotations.media.Schema;
import kz.eub.authserver.domain.exception.SelfErrorCode;
import kz.eub.authserver.domain.exception.SelfException;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ErrorResponse{
    @Schema(description = "тех код ошибки", implementation = SelfErrorCode.class)
    private SelfErrorCode techErrorCode;

    @Schema(description = "тех сообщение ошибки")
    private String techErrorMessage;

    @Schema(description = "сообщение ошибки")
    private String errorMessage;

    @Schema(description = "детали ошибки")
    private String errorDetails;

    public ErrorResponse(SelfException e) {
        this.setTechErrorCode(e.getCode());
        this.setTechErrorMessage(e.getMessage());
        this.setErrorMessage(null);
        this.setErrorDetails(null);
    }
    public ErrorResponse(Exception e) {
        this.setTechErrorCode(null);
        this.setTechErrorMessage(e.getMessage());
        this.setErrorMessage(null);
        this.setErrorDetails(null);
    }

    public String json() {
        return "{" +
                ", \"techErrorCode\":" + techErrorCode +
                ", \"techErrorMessage\":\"" + techErrorMessage + "\"" +
                ", \"errorMessage\":\"" + errorMessage + "\"" +
                ", \"errorDetails\":\"" + errorDetails + "\"" +
                "}";
    }

    @Override
    public String toString() {
        return "BiometricResponse{" +
                ", techErrorCode=" + techErrorCode +
                ", techErrorMessage=" + techErrorMessage +
                ", errorMessage=" + errorMessage +
                ", errorDetails=" + errorDetails +
                "}";
    }
}
