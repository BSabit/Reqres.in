package kz.eub.authserver.domain.repository;

import kz.eub.authserver.domain.model.pojo.NewPasscodeDTO;

import java.util.Optional;

public interface NewPasscodeRepository {
    Optional<String> getDeviceIdByPhoneNumber(String phoneNumber);
    Optional<Integer> getInvalidUses(String phoneNumber);
    void incrementInvalidUses(String phoneNumber);
    void resetInvalidUsesCounter(String phoneNumber);
    void changeStatus(String status, String deviceId);
    void changeStatusByUserId(String status, String userID);
    void save(NewPasscodeDTO newPasscode);
    Optional<String> getDeviceIdByUserId(long userId);
}
