package kz.eub.authserver.infrastracture.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Term")
public class Term {
    @Id
    @Column(name = "Term_ID")
    private Long id;

    @Column(name = "Desc_KZ")
    private String descKZ;

    @Column(name = "Desc_EN")
    private String descEN;

    @Column(name = "Desc_RU")
    private String descRU;

    @Column(name = "Code")
    private String code;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescKZ() {
        return descKZ;
    }

    public void setDescKZ(String descKZ) {
        this.descKZ = descKZ;
    }

    public String getDescEN() {
        return descEN;
    }

    public void setDescEN(String descEN) {
        this.descEN = descEN;
    }

    public String getDescRU() {
        return descRU;
    }

    public void setDescRU(String descRU) {
        this.descRU = descRU;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
