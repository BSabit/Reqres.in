package kz.eub.authserver.domain.use_case;

public interface HashUseCase {
    String getHash(String password);
    boolean validatePasscode(String originalPassword, String storedPassword);
}
