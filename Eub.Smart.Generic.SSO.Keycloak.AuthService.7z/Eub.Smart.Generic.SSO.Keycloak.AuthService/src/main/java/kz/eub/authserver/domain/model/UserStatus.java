package kz.eub.authserver.domain.model;

public enum UserStatus {
    ACTV,
    APWR,
    BLAE,
    BLSF,
    BBUP,
    BBUS,
    BBBN,
    UDUR
}
