package kz.eub.authserver.core.constant;

public interface Headers {
    String AUTHORIZATION = "Authorization";
    String X_FORWARDED_FOR = "X-Forwarded-For";
    String CHANNEL = "Channel";
}
