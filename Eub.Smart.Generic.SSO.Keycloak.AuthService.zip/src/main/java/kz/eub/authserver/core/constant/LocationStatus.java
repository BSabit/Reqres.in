package kz.eub.authserver.core.constant;

public interface LocationStatus {

    String ACCESS = "Access";
    String DENIED = "Permission Denied";
    String UNKN = "Unknown";
}
