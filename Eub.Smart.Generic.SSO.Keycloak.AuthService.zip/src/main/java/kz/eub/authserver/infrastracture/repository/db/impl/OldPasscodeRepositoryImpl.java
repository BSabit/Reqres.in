package kz.eub.authserver.infrastracture.repository.db.impl;

import kz.eub.authserver.domain.model.pojo.OldPasscodeDTO;
import kz.eub.authserver.domain.repository.OldPasscodeRepository;
import kz.eub.authserver.infrastracture.entity.OldPasscodeEntity;
import kz.eub.authserver.infrastracture.mapper.BaseMapper;
import kz.eub.authserver.infrastracture.repository.db.jpa.OldPasscodeJpaRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Slf4j
@Primary
@Repository
@RequiredArgsConstructor
public class OldPasscodeRepositoryImpl implements OldPasscodeRepository {
    private final OldPasscodeJpaRepository oldPasscodeJpaRepository;
    @Override
    public int getPasscodeIsExistCountAmount(String deviceId, long userId) {
        return oldPasscodeJpaRepository.getPasscodeIsExistCountAmount(deviceId, userId);
    }

    @Override
    public void changeStatusByUserId(String status, String userID) {
        oldPasscodeJpaRepository.changeStatusByUserId(status, userID);
    }

    @Override
    public void save(OldPasscodeDTO passcodeDTO) {
        var entity = BaseMapper.INSTANCE.toEntity(passcodeDTO);
        oldPasscodeJpaRepository.save(entity);
    }

    @Override
    public Optional<String> getDeviceIdByUserId(long userId) {
        return oldPasscodeJpaRepository.getDeviceIdByUserId(userId)
                .map(OldPasscodeEntity::getDeviceId);
    }
}
