package kz.eub.authserver.infrastracture.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "Passcode")
@Getter
@Setter
public class OldPasscodeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Passcode_ID")
    private int id;
    @Column(name = "User_IDREF")
    private int userId;
    @Column(name = "PasscodeStatus_IDREF")
    private String status;
    @Column(name = "Hash")
    private String hash;
    @Column(name = "Salt")
    private String salt;
    @Column(name = "DeviceID")
    private String deviceId;
    @Column(name = "DateCreated")
    private Date dateCreated;
    @Column(name = "InvalidUses")
    private int invalidUses;
    @Column(name = "LastInvalidUse")
    private Date lastInvalidUse;
}
