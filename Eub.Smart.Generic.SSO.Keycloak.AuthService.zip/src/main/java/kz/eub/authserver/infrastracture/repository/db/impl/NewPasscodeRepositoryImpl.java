package kz.eub.authserver.infrastracture.repository.db.impl;

import kz.eub.authserver.domain.exception.AccountBlockedDefineRouteException;
import kz.eub.authserver.domain.exception.NotFoundException;
import kz.eub.authserver.domain.model.AuthToolStatus;
import kz.eub.authserver.domain.model.PasscodeStatus;
import kz.eub.authserver.domain.model.UserStatus;
import kz.eub.authserver.domain.model.pojo.NewPasscodeDTO;
import kz.eub.authserver.domain.repository.NewPasscodeRepository;
import kz.eub.authserver.infrastracture.entity.NewPasscode;
import kz.eub.authserver.infrastracture.entity.NewPasscodeEntity;
import kz.eub.authserver.infrastracture.mapper.BaseMapper;
import kz.eub.authserver.infrastracture.repository.db.jpa.NewPasscodeJpaRepository;
import kz.eub.authserver.infrastracture.repository.db.jpa.NewPasscodeJpaRepository2;
import kz.eub.authserver.infrastracture.repository.db.jpa.UserJpaRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Slf4j
@Primary
@Repository
@RequiredArgsConstructor
public class NewPasscodeRepositoryImpl implements NewPasscodeRepository {

    private final NewPasscodeJpaRepository newPasscodeJpaRepository;
    private final NewPasscodeJpaRepository2 newPasscodeJpaRepository2;
    private final UserJpaRepository userJpaRepository;

    @Value("${app.invalid-uses}")
    private int maxInvalidUses;
    public Optional<String> getDeviceIdByPhoneNumber(String phoneNumber) {
        return newPasscodeJpaRepository.getByPhoneNumber(phoneNumber, PasscodeStatus.ACTV, AuthToolStatus.ACTV)
                .map(NewPasscode::getDeviceId);
    }

    public Optional<Integer> getInvalidUses(String phoneNumber) {
        return newPasscodeJpaRepository.getByPhoneNumber(phoneNumber, PasscodeStatus.ACTV, AuthToolStatus.ACTV)
                .map(NewPasscode::getInvalidUses);
    }

    public void incrementInvalidUses(String phoneNumber) {

        val passcode = newPasscodeJpaRepository.getByPhoneNumber(phoneNumber, PasscodeStatus.ACTV, AuthToolStatus.ACTV)
                .orElseThrow(() -> new NotFoundException("Passcode not found!"));

        val invalidUses = passcode.getInvalidUses();

        if (invalidUses >= maxInvalidUses - 1) {
            updatePasscodeStatus(phoneNumber);
            throw new AccountBlockedDefineRouteException("Too many attempts");
        }

        val newInvalidUses = passcode.getInvalidUses() + 1;
        saveInvalidUses(passcode, newInvalidUses);
    }

    public void resetInvalidUsesCounter(String phoneNumber) {
        val passcode = newPasscodeJpaRepository.getByPhoneNumber(phoneNumber, PasscodeStatus.ACTV, AuthToolStatus.ACTV)
                .orElseThrow(() -> new NotFoundException("Passcode not found!"));

        saveInvalidUses(passcode, 0);
    }

    @Override
    public void changeStatus(String status, String deviceId) {
        newPasscodeJpaRepository.changeStatus(status, deviceId);
    }

    @Override
    public void changeStatusByUserId(String status, String userID) {
        newPasscodeJpaRepository.changeStatusByUserId(status, userID);
    }
    @Override
    public void save(NewPasscodeDTO newPasscode) {
        var entity = BaseMapper.INSTANCE.toEntity(newPasscode);
        newPasscodeJpaRepository2.save(entity);
    }

    @Override
    public Optional<String> getDeviceIdByUserId(long userId) {
        return newPasscodeJpaRepository2.getDeviceIdByUserId(userId)
                .map(NewPasscodeEntity::getDeviceId);
    }

    private void saveInvalidUses(NewPasscode passcode, Integer invalidUses) {
        passcode.setInvalidUses(invalidUses);
        newPasscodeJpaRepository.save(passcode);
    }

    @Transactional(propagation = Propagation.REQUIRED)
    private void updatePasscodeStatus(String phoneNumber) {

        val passcode = newPasscodeJpaRepository.getByPhoneNumber(phoneNumber, PasscodeStatus.ACTV, AuthToolStatus.ACTV)
                .orElseThrow(() -> new NotFoundException("Passcode not found!"));

        val user = userJpaRepository.getUserByPhoneNumber(phoneNumber)
                .orElseThrow(() -> new NotFoundException("User not found!"));

        passcode.setStatus(PasscodeStatus.BLAE);
        newPasscodeJpaRepository.save(passcode);

        user.setStatus(UserStatus.BLAE);
        userJpaRepository.save(user);
    }
}
