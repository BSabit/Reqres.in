package kz.eub.authserver.infrastracture.config;

import kz.eub.authserver.AuthServerApplication;
import kz.eub.authserver.application.filter.AuthToken;
import kz.eub.authserver.domain.repository.*;
import kz.eub.authserver.domain.use_case.*;
import kz.eub.authserver.domain.use_case.impl.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackageClasses = AuthServerApplication.class)
public class BeanConfiguration {

    @Bean
    Login createLogin(AuthorizationRepository authorizationRepository,
                      UserRepository userRepository,
                      NewPasscodeRepository newPasscodeRepository,
                      TermRepository termRepository,
                      OldPasscodeRepository oldPasscodeRepository) {
        return new LoginImpl(authorizationRepository, userRepository, newPasscodeRepository, termRepository, oldPasscodeRepository);
    }

    @Bean
    Logout createLogout(AuthorizationRepository authorizationRepository) {
        return new LogoutImpl(authorizationRepository);
    }

    @Bean
    RefreshToken createRefreshToken(AuthorizationRepository authorizationRepository) {
        return new RefreshTokenImpl(authorizationRepository);
    }

    @Bean
    ClearUserCacheUseCase clearUserCacheUseCase(AdminRepository repository) {
        return new ClearUserCacheUseCaseImpl(repository);
    }

    @Bean
    HashUseCase hashUseCase() {
        return new HashUseCaseImpl();
    }

    @Bean
    ChangePasscodeUseCase changePasscodeUseCase(NewPasscodeRepository repository, HashUseCase hashUseCase, AuthToken authToken) {
        return new ChangePasscodeUseCaseImpl(repository, hashUseCase, authToken);
    }

    @Bean
    ChangeOldPasscodeUseCase changeOldPasscodeUseCase(OldPasscodeRepository repository, AuthToken authToken) {
        return new ChangeOldPasscodeUseCaseImpl(repository, authToken);
    }
}
