package kz.eub.authserver.infrastracture.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AuthSMS")
public class AuthSMS {
    @Id
    @Column(name = "AuthSMS_ID")
    private Long id;
    @Column(name = "AuthTool_IDREF")
    private Long authToolId;
    @Column(name = "MobilePhone_IDREF")
    private Long mobilePhoneId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAuthToolId() {
        return authToolId;
    }

    public void setAuthToolId(Long authToolId) {
        this.authToolId = authToolId;
    }

    public Long getMobilePhoneId() {
        return mobilePhoneId;
    }

    public void setMobilePhoneId(Long mobilePhoneId) {
        this.mobilePhoneId = mobilePhoneId;
    }
}
