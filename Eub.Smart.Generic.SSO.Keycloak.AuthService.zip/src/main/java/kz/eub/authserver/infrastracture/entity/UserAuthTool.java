package kz.eub.authserver.infrastracture.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "map_User_AuthTool")
public class UserAuthTool {
    @Id
    @Column(name = "User_IDREF")
    private Long userId;
    @Column(name = "AuthTool_IDREF")
    private Long authToolId;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getAuthToolId() {
        return authToolId;
    }

    public void setAuthToolId(Long authToolId) {
        this.authToolId = authToolId;
    }
}
