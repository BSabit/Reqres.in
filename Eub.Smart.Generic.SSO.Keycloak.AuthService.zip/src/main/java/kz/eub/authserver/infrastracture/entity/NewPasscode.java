package kz.eub.authserver.infrastracture.entity;

import kz.eub.authserver.domain.model.PasscodeStatus;

import javax.persistence.*;

@Entity
@Table(name = "NewPasscode")
public class NewPasscode {
    @Id
    @Column(name = "Passcode_ID")
    private Long id;

    @Column(name = "User_IDREF")
    private Long userId;

    @Enumerated(value = EnumType.STRING)
    @Column(name = "PasscodeStatus_IDREF")
    private PasscodeStatus status;

    @Column(name = "DeviceID")
    private String deviceId;

    @Column(name = "InvalidUses")
    private Integer invalidUses;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public PasscodeStatus getStatus() {
        return status;
    }

    public void setStatus(PasscodeStatus status) {
        this.status = status;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public Integer getInvalidUses() {
        return invalidUses;
    }

    public void setInvalidUses(Integer invalidUses) {
        this.invalidUses = invalidUses;
    }
}
