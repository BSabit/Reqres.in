package kz.eub.authserver.infrastracture.repository.db.impl;

import kz.eub.authserver.domain.model.Term;
import kz.eub.authserver.domain.repository.TermRepository;
import kz.eub.authserver.infrastracture.mapper.TermMapper;
import kz.eub.authserver.infrastracture.repository.db.jpa.TermJpaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
@RequiredArgsConstructor
public class TermRepositoryImpl implements TermRepository {

    private final TermJpaRepository termJpaRepository;
    private final TermMapper termMapper;

    public Optional<Term> getOneByCode(String code) {
        return termJpaRepository.findByCode(code)
                .stream().findFirst()
                .map(termMapper::toTerm);
    }
}
