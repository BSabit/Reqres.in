package kz.eub.authserver.infrastracture.mapper;

import kz.eub.authserver.domain.model.pojo.NewPasscodeDTO;
import kz.eub.authserver.domain.model.pojo.OldPasscodeDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface BaseMapper {

    BaseMapper INSTANCE = Mappers.getMapper(BaseMapper.class);

    NewPasscodeDTO toDomain(kz.eub.authserver.infrastracture.entity.NewPasscodeEntity entity);
    OldPasscodeDTO toDomain(kz.eub.authserver.infrastracture.entity.OldPasscodeEntity entity);

    kz.eub.authserver.infrastracture.entity.NewPasscodeEntity toEntity(NewPasscodeDTO newPasscodeDTO);
    kz.eub.authserver.infrastracture.entity.OldPasscodeEntity toEntity(OldPasscodeDTO oldPasscodeDTO);
}
