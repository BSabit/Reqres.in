package kz.eub.authserver.infrastracture.entity;

import kz.eub.authserver.domain.model.UserStatus;

import javax.persistence.*;

@Entity
@Table(name = "[dbo].[User]")
public class User {
    @Id
    @Column(name = "User_ID")
    private Long id;
    @Enumerated(value = EnumType.STRING)
    @Column(name = "UserStatus_IDREF")
    private UserStatus status;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public UserStatus getStatus() {
        return status;
    }

    public void setStatus(UserStatus status) {
        this.status = status;
    }
}
