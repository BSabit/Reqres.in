package kz.eub.authserver.infrastracture.repository.db.impl;

import kz.eub.authserver.domain.model.UserStatus;
import kz.eub.authserver.domain.repository.UserRepository;
import kz.eub.authserver.infrastracture.entity.User;
import kz.eub.authserver.infrastracture.repository.db.jpa.UserJpaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
@RequiredArgsConstructor
public class UserRepositoryImpl implements UserRepository {

    private final UserJpaRepository userJpaRepository;

    public Optional<UserStatus> getUserStatus(String phoneNumber) {
        return userJpaRepository.getUserByPhoneNumber(phoneNumber)
                .map(User::getStatus);
    }

    @Override
    public long getUserId(String phoneNumber) {
        return userJpaRepository.getUserByPhoneNumber(phoneNumber)
                .map(User::getId).orElse(0L);
    }
}
