package kz.eub.authserver.infrastracture.repository.db.jpa;

import kz.eub.authserver.infrastracture.entity.Term;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface TermJpaRepository extends JpaRepository<Term, Long> {

    @Query("SELECT t FROM Term t WHERE t.code = ?1")
    List<Term> findByCode(String code);
}
