package kz.eub.authserver.infrastracture.repository.keycloak;

import kz.eub.authserver.domain.exception.NotFoundException;
import kz.eub.authserver.domain.model.AuthResponse;
import kz.eub.authserver.domain.model.User;
import kz.eub.authserver.domain.repository.AuthorizationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.keycloak.KeycloakSecurityContext;
import org.keycloak.adapters.OidcKeycloakAccount;
import org.keycloak.adapters.springboot.KeycloakSpringBootProperties;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.authorization.client.AuthzClient;
import org.keycloak.authorization.client.util.Http;
import org.keycloak.representations.AccessToken;
import org.keycloak.representations.AccessTokenResponse;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Slf4j
@Component
@RequiredArgsConstructor
public class AuthorizationRepositoryImpl implements AuthorizationRepository {

    private final AuthzClient authzClient;
    private final Keycloak keycloak;
    private final KeycloakSpringBootProperties keycloakProperties;

    @Override
    public AuthResponse getAuth(User user) {
        val response = authzClient
                .authorization(user.phoneNumber(), user.passcode())
                .authorize();
        return new AuthResponse(response.getToken(), response.getRefreshToken());
    }

    @Override
    public AuthResponse getAuthByRefreshToken(String refreshToken) {
        val url = String.format("%s/realms/%s/protocol/openid-connect/token",
                authzClient.getConfiguration().getAuthServerUrl(),
                authzClient.getConfiguration().getRealm());
        val clientId = authzClient.getConfiguration().getResource();
        val secret = authzClient.getConfiguration().getCredentials().get("secret").toString();
        val http = new Http(authzClient.getConfiguration(), (params, headers) -> {});
        val response = http.<AccessTokenResponse>post(url)
                .authentication()
                .client()
                .form()
                .param("grant_type", "refresh_token")
                .param("refresh_token", refreshToken)
                .param("client_id", clientId)
                .param("client_secret", secret)
                .response()
                .json(AccessTokenResponse.class)
                .execute();
        return new AuthResponse(response.getToken(), response.getRefreshToken());
    }

    @Override
    public void logout() {
        log.info("logout user");
        val token = getToken();
        val state = token
                .map(AccessToken::getSessionState)
                .orElseThrow(() -> new NotFoundException("Session not found!"));

        keycloak.realm(keycloakProperties.getRealm()).deleteSession(state);
    }

    private Optional<AccessToken> getToken() {
        val context = SecurityContextHolder.getContext().getAuthentication();
        return Optional.ofNullable(context)
                .filter(KeycloakAuthenticationToken.class::isInstance)
                .map(KeycloakAuthenticationToken.class::cast)
                .map(KeycloakAuthenticationToken::getAccount)
                .map(OidcKeycloakAccount::getKeycloakSecurityContext)
                .map(KeycloakSecurityContext::getToken);
    }
}
