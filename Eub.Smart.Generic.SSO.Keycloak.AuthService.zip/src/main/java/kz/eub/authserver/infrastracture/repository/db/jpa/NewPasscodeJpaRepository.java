package kz.eub.authserver.infrastracture.repository.db.jpa;

import kz.eub.authserver.domain.model.AuthToolStatus;
import kz.eub.authserver.domain.model.PasscodeStatus;
import kz.eub.authserver.infrastracture.entity.NewPasscode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import javax.transaction.Transactional;
import java.util.Optional;

public interface NewPasscodeJpaRepository extends JpaRepository<NewPasscode, Long> {

    @Query("""
            SELECT p
            FROM MobilePhone m
            INNER JOIN AuthSMS a ON a.mobilePhoneId = m.id
            INNER JOIN UserAuthTool mua ON mua.authToolId = a.authToolId
            INNER JOIN AuthTool at ON at.id = mua.authToolId
            INNER JOIN User u ON u.id = mua.userId
            INNER JOIN NewPasscode p ON u.id = p.userId
            WHERE m.mobilePhone = ?1 AND p.status = ?2 AND at.status = ?3""")
    Optional<NewPasscode> getByPhoneNumber(String phoneNumber, PasscodeStatus passcodeStatus, AuthToolStatus authToolStatus);

    @Transactional
    @Modifying
    @Query(nativeQuery = true,
            value = """
                    UPDATE NewPassCode SET PasscodeStatus_IDREF = :status WHERE DeviceID = :deviceId AND PasscodeStatus_IDREF = 'ACTV'
            """)
    void changeStatus(String status, String deviceId);

    @Transactional
    @Modifying
    @Query(nativeQuery = true,
            value = """
                    UPDATE NewPassCode SET PasscodeStatus_IDREF = :status WHERE USER_IDREF = :userID AND PasscodeStatus_IDREF = 'ACTV'
            """)
    void changeStatusByUserId(String status, String userID);
}
