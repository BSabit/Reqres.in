package kz.eub.authserver.infrastracture.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
public class SmsTranslator {

    private static ResourceBundleMessageSource messageSource;

    public SmsTranslator(@Qualifier("sms_text") ResourceBundleMessageSource messageSource) {
        SmsTranslator.messageSource = messageSource;
    }

    public static String toSendSmsMessage() {
        var locale = LocaleContextHolder.getLocale();
        var code = "sms.success.passcode.change";
        var message = messageSource.getMessage(code, null, locale);
        return message.equals(code) ? null : message;
    }
}
