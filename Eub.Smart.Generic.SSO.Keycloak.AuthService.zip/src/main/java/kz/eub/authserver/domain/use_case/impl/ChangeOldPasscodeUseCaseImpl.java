package kz.eub.authserver.domain.use_case.impl;

import kz.eub.authserver.application.filter.AuthToken;
import kz.eub.authserver.domain.exception.SelfException;
import kz.eub.authserver.domain.model.pojo.OldPasscodeDTO;
import kz.eub.authserver.domain.repository.OldPasscodeRepository;
import kz.eub.authserver.domain.use_case.ChangeOldPasscodeUseCase;
import kz.eub.authserver.domain.util.CommonUtil;
import lombok.RequiredArgsConstructor;
import org.jboss.logging.MDC;

import static kz.eub.authserver.core.constant.UserDetails.USER_ID;
import static kz.eub.authserver.core.util.DateUtil.currentDate;
import static kz.eub.authserver.domain.exception.SelfErrorCode.E_DB_600;
import static kz.eub.authserver.domain.model.PasscodeStatus.BUPR;

@RequiredArgsConstructor
public class ChangeOldPasscodeUseCaseImpl implements ChangeOldPasscodeUseCase {

    private final OldPasscodeRepository oldPasscodeRepository;
    private final AuthToken authToken;

    @Override
    public void invoke(String authorization, String pin) {
        var userId = getUserId(authorization);
        var deviceId = oldPasscodeRepository.getDeviceIdByUserId(userId).orElseThrow(() -> new SelfException(E_DB_600, ": Not found by userId"));
        String salt = CommonUtil.salt();
        String hash = CommonUtil.sha64(salt + pin);
        this.changePasscodeStatusByUserId(BUPR.toString(), String.valueOf(userId));
        OldPasscodeDTO passcode = OldPasscodeDTO.builder()
                .hash(hash)
                .deviceId(deviceId)
                .userId(userId)
                .salt(salt)
                .status("ACTV")
                .dateCreated(currentDate())
                .build();
        oldPasscodeRepository.save(passcode);
    }

    private Integer getUserId(String authorization) {
        MDC.put("Authorization", authorization);
        authToken.addToMDC();
        String userIdStr = (String) MDC.get(USER_ID);
        MDC.clear();
        return Integer.parseInt(userIdStr);
    }

    @Override
    public void changePasscodeStatusByUserId(String status, String userID) {
        oldPasscodeRepository.changeStatusByUserId(status, userID);
    }
}
