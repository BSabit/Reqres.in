package kz.eub.authserver.domain.exception;

public class NoValidHash extends RuntimeException{
    public NoValidHash(String message) {
        super(message);
    }

    public NoValidHash(String message, Throwable cause) {
        super(message, cause);
    }
}
