package kz.eub.authserver.domain.exception;

import org.springframework.http.HttpStatus;

public class UnAuthorizeException extends AppException {

    public UnAuthorizeException(String message) {
        super(message);
    }

    @Override
    public HttpStatus getStatus() {
        return HttpStatus.UNAUTHORIZED;
    }
}
