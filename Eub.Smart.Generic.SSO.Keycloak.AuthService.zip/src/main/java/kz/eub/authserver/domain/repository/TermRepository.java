package kz.eub.authserver.domain.repository;

import kz.eub.authserver.domain.model.Term;

import java.util.Optional;

public interface TermRepository {
    Optional<Term> getOneByCode(String code);
}
