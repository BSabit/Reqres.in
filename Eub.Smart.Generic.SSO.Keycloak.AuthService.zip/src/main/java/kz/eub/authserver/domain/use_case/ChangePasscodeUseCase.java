package kz.eub.authserver.domain.use_case;

public interface ChangePasscodeUseCase {

    void invoke(String authorization, String newPasscode);

    void changePasscodeStatusByUserId(String status, String userID);
}
