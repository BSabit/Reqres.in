package kz.eub.authserver.domain.exception;

import java.util.List;

public class SelfException extends RuntimeException {
    private final SelfErrorCode selfErrorCode;

    public SelfException(SelfErrorCode selfErrorCode, List<ErrorDto> errorDtos) {
        super(errorDtos.toString());
        this.selfErrorCode = selfErrorCode;
    }

    public SelfException(SelfErrorCode selfErrorCode) {
        super(selfErrorCode.getMessage());
        this.selfErrorCode = selfErrorCode;
    }

    public SelfException(SelfErrorCode selfErrorCode, String message) {
        super(selfErrorCode.getMessage() + " " + message);
        this.selfErrorCode = selfErrorCode;
    }

    public SelfErrorCode getCode() {
        return selfErrorCode;
    }
}
