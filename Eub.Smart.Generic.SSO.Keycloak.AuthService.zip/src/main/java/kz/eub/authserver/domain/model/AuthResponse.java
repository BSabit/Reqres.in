package kz.eub.authserver.domain.model;

public record AuthResponse(String token, String refreshToken) {}
