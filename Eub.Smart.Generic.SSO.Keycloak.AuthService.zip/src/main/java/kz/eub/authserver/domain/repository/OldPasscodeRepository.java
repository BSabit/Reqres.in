package kz.eub.authserver.domain.repository;

import kz.eub.authserver.domain.model.pojo.OldPasscodeDTO;

import java.util.Optional;

public interface OldPasscodeRepository {
    int getPasscodeIsExistCountAmount(String deviceId, long userId);
    void changeStatusByUserId(String status, String userID);
    void save(OldPasscodeDTO Passcode);
    Optional<String> getDeviceIdByUserId(long userId);
}
