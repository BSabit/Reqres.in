package kz.eub.authserver.domain.model;

public enum Steps {
    PasscodeError,
    DefineRoute,
    CallBank,
    VerificationRequired
}
