package kz.eub.authserver.domain.model;

public record LoginResponse(
        String token,
        String refreshToken,
        String errorMessage,
        String errorDescription,
        String techErrorDescription,
        String buttonText,
        Steps nextStep) {

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String token;
        private String refreshToken;
        private String errorMessage;
        private String errorDescription;
        private String techErrorDescription;
        private String buttonText;
        private Steps nextStep;

        public Builder token(String token) {
            this.token = token;
            return this;
        }

        public Builder refreshToken(String refreshToken) {
            this.refreshToken = refreshToken;
            return this;
        }

        public Builder errorMessage(String errorMessage) {
            this.errorMessage = errorMessage;
            return this;
        }

        public Builder errorDescription(String errorDescription) {
            this.errorDescription = errorDescription;
            return this;
        }

        public Builder techErrorDescription(String techErrorDescription) {
            this.techErrorDescription = techErrorDescription;
            return this;
        }

        public Builder buttonText(String buttonText) {
            this.buttonText = buttonText;
            return this;
        }

        public Builder nextStep(Steps steps) {
            this.nextStep = steps;
            return this;
        }

        public LoginResponse build() {
            return new LoginResponse(
                    this.token,
                    this.refreshToken,
                    this.errorMessage,
                    this.errorDescription,
                    this.techErrorDescription,
                    this.buttonText,
                    this.nextStep
            );
        }
    }
}
