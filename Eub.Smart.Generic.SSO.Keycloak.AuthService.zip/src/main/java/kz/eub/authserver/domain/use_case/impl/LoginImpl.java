package kz.eub.authserver.domain.use_case.impl;

import kz.eub.authserver.domain.exception.*;
import kz.eub.authserver.domain.model.LoginResponse;
import kz.eub.authserver.domain.model.User;
import kz.eub.authserver.domain.repository.*;
import kz.eub.authserver.domain.use_case.Login;

import java.util.Objects;

import static kz.eub.authserver.domain.model.UserStatus.*;

public class LoginImpl implements Login {

    private static final String PASSCODE_ERROR_SHORT = "passcode_err_short";
    private static final String PASSCODE_ERROR = "passcode_error";
    private final AuthorizationRepository authorizationRepository;
    private final UserRepository userRepository;
    private final NewPasscodeRepository newPasscodeRepository;
    private final TermRepository termRepository;
    private final OldPasscodeRepository oldPasscodeRepository;
    private static final int NO_RECORDS = 0;

    public LoginImpl(AuthorizationRepository authorizationRepository, UserRepository userRepository, NewPasscodeRepository newPasscodeRepository, TermRepository termRepository, OldPasscodeRepository oldPasscodeRepository) {
        this.authorizationRepository = authorizationRepository;
        this.userRepository = userRepository;
        this.newPasscodeRepository = newPasscodeRepository;
        this.termRepository = termRepository;
        this.oldPasscodeRepository = oldPasscodeRepository;
    }

    @Override
    public LoginResponse invoke(User user, int hiddenInvalidUses, int maxInvalidUses, String language) {
        validateDeviceId(user.deviceId(), user.phoneNumber());
        validateUserStatus(user.phoneNumber());
        validateIsExistPasscode(user.deviceId(), user.phoneNumber());

        try {
            final var response = authorizationRepository.getAuth(user);
            newPasscodeRepository.resetInvalidUsesCounter(user.phoneNumber());
            return LoginResponse.builder()
                    .token(response.token())
                    .refreshToken(response.refreshToken())
                    .build();
        } catch (Exception e) {
            final var invalidUses = newPasscodeRepository.getInvalidUses(user.phoneNumber())
                    .orElseThrow(() -> new NotFoundException("Passcode not found!"));

            final var count = invalidUses + 1;
            
            String formattedText;

            if (count < hiddenInvalidUses) {
                final var term = termRepository.getOneByCode(PASSCODE_ERROR_SHORT)
                        .orElseThrow(() -> new NotFoundException("Term not found!"));
                formattedText = switch (language) {
                    case "en" -> term.descEN();
                    case "ru" -> term.descRU();
                    default -> term.descKZ();
                };
            } else {
                final var term = termRepository.getOneByCode(PASSCODE_ERROR)
                        .orElseThrow(() -> new NotFoundException("Term not found!"));
                final var desc = switch (language) {
                    case "en" -> term.descEN();
                    case "ru" -> term.descRU();
                    default -> term.descKZ();
                };
                final var remainUses = maxInvalidUses - count;
                formattedText = String.format(desc, remainUses);
            }
            newPasscodeRepository.incrementInvalidUses(user.phoneNumber());
            throw new UnAuthorizeException(formattedText);
        }
    }

    private void validateDeviceId(String deviceId, String phoneNumber) {
        final var savedDeviceId = newPasscodeRepository.getDeviceIdByPhoneNumber(phoneNumber)
                .orElseThrow(() -> new AccountBlockedDefineRouteException("Active device id not found!"));
        if (!Objects.equals(deviceId, savedDeviceId)) {
            throw new AccountBlockedDefineRouteException("Device id are not matched!");
        }
    }

    private void validateUserStatus(String phoneNumber) {
        final var status = userRepository.getUserStatus(phoneNumber)
                .orElseThrow(() -> new NotFoundException("User not found!"));
        if (BLAE.equals(status) || BLSF.equals(status)) {
            throw new AccountBlockedDefineRouteException("Account id blocked!");
        } else if (BBUP.equals(status) || BBUS.equals(status)) {
            throw new AccountBlockedCallBankException("Account is blocked!");
        } else if (UDUR.equals(status)) {
            throw new VerificationRequiredException("Account is blocked!");
        }
    }
    private void validateIsExistPasscode(String deviceId, String phoneNumber) {
        long userId = userRepository.getUserId(phoneNumber);

        int passcodeRecordsCount = oldPasscodeRepository.getPasscodeIsExistCountAmount(deviceId, userId);
        if (passcodeRecordsCount == NO_RECORDS) {
            throw new AccountBlockedDefineRouteException("Active passcode id not found!");
        }
    }
}
