package kz.eub.authserver.domain.exception;

import org.springframework.http.HttpStatus;

public class VerificationRequiredException extends AppException {
    public VerificationRequiredException(String message) {
        super(message);
    }

    @Override
    public HttpStatus getStatus() {
        return HttpStatus.LOCKED;
    }
}
