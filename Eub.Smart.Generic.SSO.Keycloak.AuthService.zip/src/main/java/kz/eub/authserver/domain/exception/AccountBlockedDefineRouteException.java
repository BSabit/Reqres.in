package kz.eub.authserver.domain.exception;

import org.springframework.http.HttpStatus;

public class AccountBlockedDefineRouteException extends AppException {
    public AccountBlockedDefineRouteException(String message) {
        super(message);
    }

    @Override
    public HttpStatus getStatus() {
        return HttpStatus.LOCKED;
    }
}
