package kz.eub.authserver.domain.repository;

import kz.eub.authserver.domain.model.UserStatus;

import java.util.Optional;

public interface UserRepository {
    Optional<UserStatus> getUserStatus(String phoneNumber);
    long getUserId(String phoneNumber);
}
