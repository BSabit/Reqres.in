package kz.eub.authserver.domain.model;

public record User (String deviceId, String phoneNumber, String passcode){}
