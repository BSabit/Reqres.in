package kz.eub.authserver.domain.exception;

import org.springframework.http.HttpStatus;

public class BadHistoryException extends AppException {

    public BadHistoryException(String message) {
        super(message);
    }

    @Override
    public HttpStatus getStatus() {
        return HttpStatus.CONFLICT;
    }
}
