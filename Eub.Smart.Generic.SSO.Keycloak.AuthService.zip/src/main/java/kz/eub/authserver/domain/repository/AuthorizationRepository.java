package kz.eub.authserver.domain.repository;

import kz.eub.authserver.domain.model.AuthResponse;
import kz.eub.authserver.domain.model.User;

public interface AuthorizationRepository {
    AuthResponse getAuth(User user);
    AuthResponse getAuthByRefreshToken(String refreshToken);
    void logout();
}
