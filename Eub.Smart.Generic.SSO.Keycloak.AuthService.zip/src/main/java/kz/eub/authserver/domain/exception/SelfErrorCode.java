package kz.eub.authserver.domain.exception;

public enum SelfErrorCode {

    E_SM_500("error.system"),                                           //SYSTEM 500-599
    E_SM_501("error.system.object-to-json"),
    E_SM_502("error.system.json-to-object"),

    E_DB_600("error.db.object-not-found"),                              //DB 600-699

    E_BS_901("error.business.limit-exceeded");                          //BUSINESS 900-999

    private final String message;
    private Error error;
    public enum Error {
        recoveryProduct,
        recoveryBiometry
    }

    SelfErrorCode(Error error, String message) {
        this.message = message;
        this.error = error;
    }

    SelfErrorCode(String message) {
        this.message = message;
    }
    public boolean isInGroupError(Error error) {
        return this.error == error;
    }
    public Error getError() {
        return error;
    }

    public String getMessage() {
        return message;
    }
}
