package kz.eub.authserver.domain.exception;

import org.springframework.http.HttpStatus;

public class AppException extends RuntimeException {

    public AppException(String message) {
        super(message);
    }

    public HttpStatus getStatus() {
        return HttpStatus.INTERNAL_SERVER_ERROR;
    }
}
