package kz.eub.authserver.application.model;

public record RequestPasscode(String newPasscode){
}
