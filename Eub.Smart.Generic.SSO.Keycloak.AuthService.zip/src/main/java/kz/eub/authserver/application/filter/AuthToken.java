package kz.eub.authserver.application.filter;

import kz.eub.authserver.core.model.UserDetails;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import java.util.Base64;
import static kz.eub.authserver.core.constant.UserDetails.*;


@Component
public class AuthToken{

    public void addToMDC() {
        String payload = getDecodedPayload();
        UserDetails userDetails = UserDetails.build(payload);
        MDC.put(USER_ID, userDetails.getUserId().toString());
    }

    public String getToken() {
        String authorization = (String) org.jboss.logging.MDC.get("Authorization");
        return authorization.replace("Bearer", "")
                .trim();
    }

    public String getPayload() {
        return getToken().split("\\.")[1];
    }

    public String getDecodedPayload() {
        String token = getPayload();
        return new String (Base64.getUrlDecoder().decode(token));
    }
}