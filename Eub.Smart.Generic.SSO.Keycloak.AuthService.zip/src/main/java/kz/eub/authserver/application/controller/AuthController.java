package kz.eub.authserver.application.controller;

import kz.eub.authserver.application.view.*;
import kz.eub.authserver.domain.model.LoginResponse;
import kz.eub.authserver.domain.use_case.Login;
import kz.eub.authserver.domain.use_case.Logout;
import kz.eub.authserver.domain.use_case.RefreshToken;
import kz.eubank.core.config.ApplicationContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping(path = "/auth")
@RequiredArgsConstructor
public class AuthController {

    private final Login login;
    private final Logout logout;
    private final RefreshToken refreshToken;
    private final ApplicationContext context;
    @Value("${app.hidden-invalid-uses}")
    private int hiddenInvalidUses;
    @Value("${app.invalid-uses}")
    private int maxInvalidUses;

    @GetMapping({"/check-token"})
    public ResponseEntity<Void> checkToken() {
        return ResponseEntity.ok().build();
    }

    @PostMapping({"/login"})
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequestMessage loginRequestMessage) {
        val language = context.getLanguage();
        val response = login.invoke(loginRequestMessage.toUser(), hiddenInvalidUses, maxInvalidUses, language);
        return ResponseEntity.status(HttpStatus.OK)
                .body(response);
    }

    @DeleteMapping({"/logout"})
    public ResponseEntity<Void> logout() {
        logout.invoke();
        return ResponseEntity.ok().build();
    }

    @GetMapping({"/tokenRefresh"})
    public ResponseEntity<LoginResponse> tokenRefresh(@RequestParam(name = "token") String refreshTokenReq) {
        val response = refreshToken.invoke(refreshTokenReq);
        return ResponseEntity.status(HttpStatus.OK)
                .body(response);
    }

}
