package kz.eub.authserver.application.controller;

import kz.eub.authserver.application.model.ErrorResponse;
import kz.eub.authserver.application.model.RequestPasscode;
import kz.eub.authserver.domain.exception.SelfException;
import kz.eub.authserver.domain.use_case.ChangeOldPasscodeUseCase;
import kz.eub.authserver.domain.use_case.ChangePasscodeUseCase;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static kz.eub.authserver.infrastracture.config.SmsTranslator.toSendSmsMessage;

@RestController
@RequestMapping( "/auth/passcode")
@RequiredArgsConstructor
public class PasscodeController {

    private final ChangePasscodeUseCase newPasscodeUseCase;
    private final ChangeOldPasscodeUseCase oldPasscodeUseCase;

    @PostMapping("/change")
    public ResponseEntity<?> change(@RequestBody RequestPasscode requestPasscode,
                                    @RequestHeader(value = "Authorization") String authorization) {
        try{
            newPasscodeUseCase.invoke(authorization, requestPasscode.newPasscode());
            oldPasscodeUseCase.invoke(authorization, requestPasscode.newPasscode());
            return new ResponseEntity<>(toSendSmsMessage(), HttpStatus.OK);
        } catch (SelfException selfException){
            return new ResponseEntity<>(new ErrorResponse(selfException), HttpStatus.INTERNAL_SERVER_ERROR);
        }catch (Exception exception){
            return new ResponseEntity<>(new ErrorResponse(exception), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}