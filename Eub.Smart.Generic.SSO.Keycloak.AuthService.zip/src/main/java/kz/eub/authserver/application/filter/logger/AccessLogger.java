package kz.eub.authserver.application.filter.logger;


import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;

import static com.google.common.net.HttpHeaders.X_FORWARDED_FOR;
import static io.micrometer.core.instrument.util.StringUtils.isNotEmpty;


@Component
public class AccessLogger {

    private final HttpServletRequest request;

    public AccessLogger(HttpServletRequest request) {
        this.request = request;
    }

    public String getClientIp() {
        String xForwardedFor = request.getHeader(X_FORWARDED_FOR);
        if (isNotEmpty(xForwardedFor)) {
            return xForwardedFor.split(",")[0].trim();
        } else {
            return request.getRemoteAddr();
        }
    }
}