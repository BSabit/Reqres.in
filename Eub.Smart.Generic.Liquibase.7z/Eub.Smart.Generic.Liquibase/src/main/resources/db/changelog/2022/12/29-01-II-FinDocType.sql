-- liquibase formatted sql

-- changeset omarbek:1673602728927-1

insert into FinDocType (FinDocType_ID, FinDocType_Title)
values ('LOAN', 'Оплата кредита');