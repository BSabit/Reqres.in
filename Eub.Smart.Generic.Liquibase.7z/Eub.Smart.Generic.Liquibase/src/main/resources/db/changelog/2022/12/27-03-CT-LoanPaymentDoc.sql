-- liquibase formatted sql

-- changeset omarbek:1672139469247-3

create table LoanPaymentDoc
(
    LoanPaymentDoc_ID bigint identity (1000000, 1)
        constraint PK_LoanPaymentDoc
        primary key,
    FinDoc_IDREF      bigint       not null
        constraint FK_LoanPaymentDoc_FinDoc
            references FinDoc,
    Contract          varchar(20)  not null,
    IIN               char(12)     not null,
    KNP_IDREF         char(3)      not null,
    PTFormat          varchar(255) null,
    IBAN              varchar(255) null,
    SourceSystem      varchar(255) not null,
    Currency          char(3)      not null
);