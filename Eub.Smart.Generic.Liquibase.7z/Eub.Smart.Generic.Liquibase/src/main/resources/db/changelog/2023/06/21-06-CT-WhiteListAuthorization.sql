-- liquibase formatted sql

-- changeset Abekmat:1687353579229-17

CREATE TABLE dbo.[WhiteListAuthorization]
(
	[WhiteListAuthorization_ID]			bigint IDENTITY (1, 1) NOT NULL,
	[MobilePhone]						nchar(11) NULL,
	[Hash]								nvarchar(56) NOT NULL,
	[Salt]								nvarchar(60) NULL,
	[User_IDREF]						int NULL,
	[isActiv]							bit NOT NULL default 0,
	[DateValid]							datetime NULL,
	CONSTRAINT [[WhiteListAuthorization_PK] PRIMARY KEY NONCLUSTERED ([WhiteListAuthorization_ID] ASC),
	CONSTRAINT [WhiteListAuthorization_User_FK] FOREIGN KEY ([User_IDREF]) REFERENCES [User] ([User_ID]),
);