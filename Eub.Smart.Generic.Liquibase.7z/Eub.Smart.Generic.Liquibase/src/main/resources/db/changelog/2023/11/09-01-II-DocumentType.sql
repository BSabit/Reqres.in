-- liquibase formatted sql

-- changeset zbek:1699517475899-1

INSERT INTO DocumentType
(DocumentType_ID, Description, CredilogicCode, IsSendCertCenter, IsSendWebArchive, Extension)
VALUES('BDA1', 'Договор банковского вклада Срочный', null, 0, 0, 'pdf');

INSERT INTO DocumentType
(DocumentType_ID, Description, CredilogicCode, IsSendCertCenter, IsSendWebArchive, Extension)
VALUES('BDA2', 'Договор банковского вклада  Turbo c правом пополнения', null, 0, 0, 'pdf');

INSERT INTO DocumentType
(DocumentType_ID, Description, CredilogicCode, IsSendCertCenter, IsSendWebArchive, Extension)
VALUES('BDA3', 'Договор банковского вклада  Turbo без права пополнения', null, 0, 0, 'pdf');

INSERT INTO DocumentType
(DocumentType_ID, Description, CredilogicCode, IsSendCertCenter, IsSendWebArchive, Extension)
VALUES('BAA1', 'Договор открытия Текущего счета', null, 0, 0, 'pdf');

INSERT INTO DocumentType
(DocumentType_ID, Description, CredilogicCode, IsSendCertCenter, IsSendWebArchive, Extension)
VALUES('BCA1', 'Заявление-оферта на выпуск карты', null, 0, 0, 'pdf');