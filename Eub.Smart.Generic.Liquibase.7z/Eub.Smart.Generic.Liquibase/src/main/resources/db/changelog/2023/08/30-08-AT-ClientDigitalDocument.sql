-- liquibase formatted sql

-- changeset zh_bexultan:1693391904727-1

ALTER TABLE ClientDigitalDocument ADD isVerified BIT NOT NULL DEFAULT 0;

ALTER TABLE ClientDigitalDocument ADD ClientDigitalDocumentType_IDREF NCHAR(4) NOT NULL;

ALTER TABLE ClientDigitalDocument ADD CONSTRAINT ClientDigitalDocument_ClientDigitalDocumentType_FK
FOREIGN KEY (ClientDigitalDocumentType_IDREF) REFERENCES ClientDigitalDocumentType(ClientDigitalDocumentType_ID);
