-- liquibase formatted sql

-- changeset Abekmat:1687353579229-5

CREATE TABLE dbo.[RecoveryProductAccountType]
(
	[RecoveryProductAccountType_ID]      	nchar(4) NOT NULL ,
	[RecoveryProductAccountType_Title] 	    varchar(255) NOT NULL ,
	CONSTRAINT [RecoveryProductAccountType_PK] PRIMARY KEY NONCLUSTERED ([RecoveryProductAccountType_ID] ASC)
);