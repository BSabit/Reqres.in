-- liquibase formatted sql

-- changeset zbek:1700217863540-3

UPDATE DigitalCardType
SET CurrencyCode = 'KZT' WHERE DigitalCardType_ID = 'AUMC';

UPDATE DigitalCardType
SET CurrencyCode = 'KZT' WHERE DigitalCardType_ID = 'MGPP';

UPDATE DigitalCardType
SET CurrencyCode = 'KZT' WHERE DigitalCardType_ID = 'MGSC';

UPDATE DigitalCardType
SET CurrencyCode = 'MC1' WHERE DigitalCardType_ID = 'MBPP';