-- liquibase formatted sql

-- changeset zh_bexultan:1701148929114-1

UPDATE ClientDigitalDocumentType
   SET ClientDigitalDocumentType_ID = 'PHTO',
       ClientDigitalDocumentType_Title = 'Фото клиента'
 WHERE ClientDigitalDocumentType_ID = 'BSLF';