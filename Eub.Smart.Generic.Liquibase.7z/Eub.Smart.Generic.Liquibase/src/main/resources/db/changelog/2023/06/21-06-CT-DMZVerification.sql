-- liquibase formatted sql

-- changeset Abekmat:1687353579229-11

CREATE TABLE dbo.[DMZVerification]
(
	[DMZVerification_ID]            bigint IDENTITY (1, 1) NOT NULL,
	[Number]                        nchar(36) NOT NULL,
	[RouteType_IDREF] 			    nchar(4) NOT NULL,
	[DateCreated]                   datetime NOT NULL default getDate(),
	[DateExpired]               	datetime NOT NULL,
	[MobilePhone]                   nchar(11) NOT NULL,
	[Iin]                        	nchar(12) NULL,
	[RouteStatus_IDREF] 			nchar(4) NOT NULL default 'NEWW',
	[DeviceId]       				varchar(100) NOT NULL,
	[VersionFront]   				varchar(100) NOT NULL,
	[FrontEnd_IDREF] 				char(4) NOT NULL,
	[OldPasscode_IDREF] 			int NULL,
	[Passcode_IDREF] 				int NULL,
	CONSTRAINT [DMZVerification_RouteType_FK] FOREIGN KEY ([RouteType_IDREF]) REFERENCES [RouteType]([RouteType_ID]),
	CONSTRAINT [DMZVerification_PK] PRIMARY KEY (DMZVerification_ID),
	CONSTRAINT [DMZVerification_RouteStatus_FK] FOREIGN KEY ([RouteStatus_IDREF]) REFERENCES [RouteStatus]([RouteStatus_ID]),
	CONSTRAINT [DMZVerification_FrontEnd_FK] FOREIGN KEY ([FrontEnd_IDREF]) REFERENCES [FrontEnd]([FrontEnd_ID]),
	CONSTRAINT DMZVerification_OldPasscode_FK FOREIGN KEY (OldPasscode_IDREF) REFERENCES Passcode(Passcode_ID),
	CONSTRAINT DMZVerification_Passcode_FK FOREIGN KEY (Passcode_IDREF) REFERENCES NewPasscode(Passcode_ID),
);