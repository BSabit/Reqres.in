-- liquibase formatted sql

-- changeset Abekmat:1687353579229-24

INSERT INTO dbo.[RouteStatus] ([RouteStatus_ID], [RouteStatus_Title])
VALUES
    ('NEWW','Сессия создана'),
    ('VSMS','Провалидирован СМС'),
    ('VSCS','Валидацию прошел'),
    ('PSET','Код доступа установлена');
