-- liquibase formatted sql

-- changeset Abekmat:1687353579229-2

CREATE TABLE dbo.[RouteStatus]
(
	[RouteStatus_ID]         		nchar(4) NOT NULL,
	[RouteStatus_Title] 		    varchar(255) NOT NULL,
	CONSTRAINT [RouteStatus_PK] PRIMARY KEY NONCLUSTERED ([RouteStatus_ID] ASC)
);