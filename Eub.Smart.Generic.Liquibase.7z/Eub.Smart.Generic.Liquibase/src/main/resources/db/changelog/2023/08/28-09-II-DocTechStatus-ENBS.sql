-- liquibase formatted sql

-- changeset SBatyrkh:1693207624209-1

INSERT INTO  DocTechStatus(DocTechStatus_ID, DocTechStatus_Title, Term_OUTREF, FinDocStatus_IDREF, IsFinal)
VALUES ('ENBS', 'Ошибка не связанная с DOMAIN - ной логикой', NULL, 'RJCT', 1);

