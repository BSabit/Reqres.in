-- liquibase formatted sql

-- changeset Abekmat:1687353579229-30

INSERT INTO dbo.[DMZVerificationAttemptsType] ([DMZVerificationAttemptsType_ID], [DMZVerificationAttemptsType_Title])
VALUES
    ('VIIN','Неуспешная проверка ИИН'),
    ('SSMS','Отправка СМС\ОТП'),
    ('VBIO','Неуспешная биометрия'),
    ('VBDY','Неуспешная проверка даты рождения'),
    ('VRPA','Неуспешная валидация по номеру продкута');