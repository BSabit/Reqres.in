-- liquibase formatted sql

-- changeset zh_bexultan:1692784183777-1

CREATE TABLE ClientDigitalDocument (
	ClientDigitalDocument_ID	BIGINT IDENTITY (1, 1) NOT NULL,
	File_OUTREF					NVARCHAR(255) NOT NULL,
	DateCreated					DATETIME NOT NULL DEFAULT GETDATE(),
	DateExpired					DATETIME,
	Iin							NCHAR(12) NOT NULL,
	CONSTRAINT pk_ClientDigitalDocument_ID PRIMARY KEY NONCLUSTERED (ClientDigitalDocument_ID ASC)
);