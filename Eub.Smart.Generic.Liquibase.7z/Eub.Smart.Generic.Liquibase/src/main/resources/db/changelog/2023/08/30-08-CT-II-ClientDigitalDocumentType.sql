-- liquibase formatted sql

-- changeset zh_bexultan:1693391885636-1

CREATE TABLE ClientDigitalDocumentType (
	ClientDigitalDocumentType_ID	NCHAR(4) NOT NULL,
	ClientDigitalDocumentType_Title VARCHAR(70) NOT NULL,
	CONSTRAINT pk_ClientDigitalDocumentType_ID PRIMARY KEY NONCLUSTERED (ClientDigitalDocumentType_ID ASC)
);

INSERT INTO ClientDigitalDocumentType(ClientDigitalDocumentType_ID, ClientDigitalDocumentType_Title)
VALUES ('IDCD', 'Цифровой удостоверяющий документ'),
	   ('BSLF', 'Лучший селфи-кадр(Best shot)');