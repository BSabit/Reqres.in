-- liquibase formatted sql

-- changeset Abekmat:1687353579229-32

INSERT INTO FrontEnd  (FrontEnd_ID,	FrontEnd_Title,	Channel_IDREF)
VALUES ('UNKN',	'Неизвестное устроиство', 'APPS');