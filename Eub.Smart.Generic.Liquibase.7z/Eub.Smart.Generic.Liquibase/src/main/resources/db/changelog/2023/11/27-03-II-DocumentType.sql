-- liquibase formatted sql

-- changeset daurenbekuly:1701084092399-2

Insert Into DocumentType(DocumentType_ID, Description, CredilogicCode, IsSendCertCenter, IsSendWebArchive, Extension)
values ('I92A', 'Иконка 54х36', null, 0, 0, 'png');