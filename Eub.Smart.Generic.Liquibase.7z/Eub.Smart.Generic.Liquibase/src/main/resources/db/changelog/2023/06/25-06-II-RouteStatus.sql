-- liquibase formatted sql

-- changeset YKaliyev:1687451942792-1

INSERT INTO dbo.[RouteStatus] ([RouteStatus_ID], [RouteStatus_Title])
VALUES
    ('FAIL', 'Валидацию не прошел');
