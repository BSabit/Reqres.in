-- liquibase formatted sql

-- changeset daurenbekuly:1697137279898-1

alter table ZeebeEventFinDoc
drop column BpmnProcessId, Version, ProcessInstanceId;
