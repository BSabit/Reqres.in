-- liquibase formatted sql

-- changeset Abekmat:1687353579229-6

CREATE TABLE dbo.[RecoveryProductStatus]
(
	[RecoveryProductStatus_ID]       	nchar(4) NOT NULL ,
	[RecoveryProductStatus_Title] 	    varchar(255) NOT NULL,
	[Term_OUTREF]                       int NULL,
	CONSTRAINT [RecoveryProductStatus_PK] PRIMARY KEY NONCLUSTERED ([RecoveryProductStatus_ID] ASC)
);