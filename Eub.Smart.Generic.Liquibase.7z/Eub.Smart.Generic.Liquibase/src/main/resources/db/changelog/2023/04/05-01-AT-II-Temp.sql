-- liquibase formatted sql

-- changeset daulet:1680679915564-1

ALTER TABLE Term ADD Code VARCHAR(50) NULL;

INSERT INTO Term (Term_RU, Desc_RU, Term_KZ, Desc_KZ, Term_EN, Desc_EN, Code)
VALUES ('repayment', 'Для погашения кредита без процентов необходимо в течение %s месяцев оплатить основной долг %s т до %s.',
'repayment', 'Несиені пайызсыз өтеу үшін %s ай ішінде %s т негізгі қарызды %s жылға дейін төлеу қажет.',
'repayment', 'To repay a loan without any interest, it is necessary to pay the principal debt of %s tenge within %s months till %s year.',
'repayment');