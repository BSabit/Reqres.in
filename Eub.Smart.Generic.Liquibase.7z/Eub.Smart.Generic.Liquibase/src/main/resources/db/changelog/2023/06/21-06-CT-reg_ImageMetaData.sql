-- liquibase formatted sql

-- changeset Abekmat:1687353579229-21

CREATE TABLE reg_ImageMetaData(
	[Image_ID]                  bigint NOT NULL,
	[ImageName]                 varchar(50),
	[ImageSize]                 int,
	[ImageType]                 varchar(50),
	[ImagePath]                 varchar(250),
	[DateCreated]               datetime
	CONSTRAINT req_ImageMetaData_PK PRIMARY KEY (Image_ID)
);