-- liquibase formatted sql

-- changeset Abekmat:1687452159197-1

UPDATE dbo.Gbdfl_Region
SET Gbdfl_Code = '1907'
WHERE Region_IDREF = 1020