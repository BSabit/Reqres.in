-- liquibase formatted sql

-- changeset daulet:1685352473516-2

DROP TABLE IF EXISTS RepaymentApplication;