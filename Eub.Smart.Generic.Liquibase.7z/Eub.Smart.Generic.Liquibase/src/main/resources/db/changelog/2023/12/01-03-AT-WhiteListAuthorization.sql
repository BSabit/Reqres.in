-- liquibase formatted sql

-- changeset zh_bexultan:1701416892674-1

ALTER TABLE WhiteListAuthorization
ALTER COLUMN MobilePhone nvarchar(14);

ALTER TABLE WhiteListAuthorization
ADD CONSTRAINT CHK_WhiteListAuthorization_MinLength
CHECK (LEN(MobilePhone) >= 10);