-- liquibase formatted sql

-- changeset Abekmat:1687353579229-18

CREATE TABLE dbo.[Biometrics]
(
	[Biometrics_ID]						bigint IDENTITY (1, 1) NOT NULL,
	[DateCreated]						datetime NOT NULL default getDate(),
	[BiometricsType_IDREF]				nchar(4) NOT NULL,
	[BiometricsStatus_IDREF]			nchar(4) NOT NULL,
	[FolderId]							nchar(36) NOT NULL,
	[DMZVerification_IDREF]				bigint NOT NULL,
	[Data]								nvarchar(MAX) NULL,
	[Biometry_AnalyseID] 				varchar(36) NULL,
	[Quality_AnalyseID] 				varchar(36) NULL,
	CONSTRAINT [Biometrics_PK] PRIMARY KEY NONCLUSTERED ([Biometrics_ID] ASC),
	CONSTRAINT [Biometrics_DMZVerification_FK] FOREIGN KEY ([DMZVerification_IDREF]) REFERENCES [DMZVerification]([DMZVerification_ID]),
	CONSTRAINT [Biometrics_BiometricsStatus_FK] FOREIGN KEY ([BiometricsStatus_IDREF]) REFERENCES [BiometricsStatus]([BiometricsStatus_ID]),
	CONSTRAINT [Biometrics_BiometricsType_FK] FOREIGN KEY ([BiometricsType_IDREF]) REFERENCES [BiometricsType]([BiometricsType_ID])
);
