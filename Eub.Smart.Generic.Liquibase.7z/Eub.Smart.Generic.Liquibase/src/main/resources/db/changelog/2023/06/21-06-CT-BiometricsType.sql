-- liquibase formatted sql

-- changeset Abekmat:1687353579229-4

CREATE TABLE dbo.[BiometricsType]
(
	[BiometricsType_ID] 			nchar(4) NOT NULL,
	[BiometricsType_Title] 			nvarchar(255) NOT NULL,
	CONSTRAINT [BiometricsType_PK] PRIMARY KEY NONCLUSTERED ([BiometricsType_ID] ASC)
);