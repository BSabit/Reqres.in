-- liquibase formatted sql

-- changeset daurenbekuly:1701084092276-1

alter table FinDocType
    add Target_ID bigint IDENTITY(1,1)