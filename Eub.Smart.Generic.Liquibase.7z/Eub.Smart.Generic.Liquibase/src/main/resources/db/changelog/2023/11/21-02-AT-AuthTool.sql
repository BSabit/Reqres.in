-- liquibase formatted sql

-- changeset zbek:1700549583244-2

ALTER TABLE AuthTool
    ADD RevocationDate datetime2;