-- liquibase formatted sql

-- changeset daulet:1685352531176-3

CREATE TABLE RepaymentApplication (
	RepaymentApplication_ID bigint identity (1000000, 1),
	Application_IDREF int NOT NULL,
	LoanNumber nvarchar(255) NOT NULL,
	Account_IDREF int NOT NULL,
	TotalAmount money NOT NULL,
	SourceSystem varchar(255) NOT NULL,
	CreatedDate datetime NOT NULL,
	CONSTRAINT pk_RepaymentApplication_ID PRIMARY KEY (RepaymentApplication_ID),
	CONSTRAINT fk_Account_RP_IDREF FOREIGN KEY (Account_IDREF) REFERENCES Account(Account_ID) ON DELETE CASCADE,
	CONSTRAINT fk_Application_IDREF FOREIGN KEY (Application_IDREF) REFERENCES Application(Application_ID) ON DELETE CASCADE
);

