-- liquibase formatted sql

-- changeset Abekmat:1687408925155-1

ALTER TABLE DMZVerification DROP COLUMN [Number]
ALTER TABLE DMZVerification ADD SessionId nchar(36);
