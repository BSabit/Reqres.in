-- liquibase formatted sql

-- changeset Abekmat:1687353579229-19

CREATE TABLE dbo.[MobileOperator]
(
	[MobileOperator_ID]    		nchar(3) NOT NULL,
	[MobileOperator_Title] 		varchar(255) NOT NULL,
	CONSTRAINT [MobileOperator_PK] PRIMARY KEY NONCLUSTERED ([MobileOperator_ID] ASC)
); 