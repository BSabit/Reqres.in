-- liquibase formatted sql

-- changeset omarbek:1673602728927-1

create table FeatureFlag
(
    Code      varchar(255)  not null
        constraint PK_FeatureFlag
            primary key,
    FeatureOn bit default 0 not null
);

insert into FeatureFlag values ('DASHBOARD_CARD_ACCOUNTS', 0);