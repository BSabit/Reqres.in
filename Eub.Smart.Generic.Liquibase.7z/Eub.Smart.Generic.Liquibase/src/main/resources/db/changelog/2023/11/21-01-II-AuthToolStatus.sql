-- liquibase formatted sql

-- changeset zbek:1700547214222-1

INSERT INTO AuthToolStatus
(AuthToolStatus_ID, AuthToolStatus_Title, Term_OUTREF, IsValid)
VALUES('REVD', 'Отозван', null, 0);