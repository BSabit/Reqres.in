-- liquibase formatted sql

-- changeset zbek:1700217786023-2

ALTER TABLE DigitalCardType
    ADD CurrencyCode CHAR(3);