-- liquibase formatted sql

-- changeset Abekmat:1687353579229-14

CREATE TABLE dbo.[RegistrationInfo]
(
	[RegistrationInfo_ID]               bigint IDENTITY (1, 1) NOT NULL,
	[User_IDREF]                        int NULL,
	[DateCreated]                       datetime NOT NULL default getDate(),
	[Data]                              varchar(MAX) NULL,
	[DMZVerification_IDREF]             bigint NOT NULL,
	[RegistrationInfoStatus_IDREF]	    nchar(4) NOT NULL,
	CONSTRAINT [RegistrationInfo_PK] PRIMARY KEY ([RegistrationInfo_ID] ASC),
	CONSTRAINT [RegistrationInfo_DMZVerification_FK] FOREIGN KEY ([DMZVerification_IDREF]) REFERENCES [DMZVerification]([DMZVerification_ID]),
	CONSTRAINT [RegistrationInfo_User_FK] FOREIGN KEY ([User_IDREF]) REFERENCES [User]([User_ID]),
	CONSTRAINT [RegistrationInfo_RegistrationInfoStatus_FK] FOREIGN KEY ([RegistrationInfoStatus_IDREF]) REFERENCES [RegistrationInfoStatus]([RegistrationInfoStatus_ID])
);