-- liquibase formatted sql

-- changeset zh_bexultan:1691052129486-1

ALTER TABLE WhiteListAuthorization ADD NewHash VARCHAR(255) NOT NULL;