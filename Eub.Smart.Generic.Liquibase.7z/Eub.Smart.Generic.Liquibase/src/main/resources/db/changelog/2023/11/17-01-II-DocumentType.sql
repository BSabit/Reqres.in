-- liquibase formatted sql

-- changeset zbek:1700198065984-1

INSERT INTO DocumentType
(DocumentType_ID, Description, CredilogicCode, IsSendCertCenter, IsSendWebArchive, Extension)
VALUES('OTZV', 'Заявление на отзыв регистрационных свидетельств от физического лица', null, 0, 0, 'pdf');