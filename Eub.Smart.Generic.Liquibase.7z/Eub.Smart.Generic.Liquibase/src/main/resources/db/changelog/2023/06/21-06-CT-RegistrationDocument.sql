-- liquibase formatted sql

-- changeset Abekmat:1687353579229-15

CREATE TABLE dbo.[RegistrationDocument]
(
	[RegistrationDocument_ID]               bigint IDENTITY (1, 1) NOT NULL,
	[RegistationInfo_IDREF] 			    bigint NOT NULL,
	[FileStorage_OUTREF]        			bigint NOT NULL,
	[DateCreated]            				datetime NOT NULL default getDate(),
	CONSTRAINT [RegistrationDocument_PK] PRIMARY KEY ([RegistrationDocument_ID] ASC),
	CONSTRAINT [RegistrationDocument_RegistationInfo_FK] FOREIGN KEY ([RegistationInfo_IDREF]) REFERENCES [RegistrationInfo]([RegistrationInfo_ID])
);