-- liquibase formatted sql

-- changeset sabit:1695880807313-2

create table ZeebeEventFinDoc
(
    ZeebeEventFinDoc_ID bigint identity not null
        constraint PK_ZeebeEventFinDoc
        primary key,
    FinDoc_IDREF        bigint       not null
        unique
        constraint FK_FinDoc_RP_IDREF
            references FinDoc
            on delete cascade,
    BpmnProcessId       varchar(255) not null,
    Version             int          not null,
    ProcessInstanceId   bigint       not null,
    CreatedDate         datetime     not null
)


