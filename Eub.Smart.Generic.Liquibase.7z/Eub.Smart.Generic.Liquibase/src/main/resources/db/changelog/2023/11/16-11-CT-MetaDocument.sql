-- liquibase formatted sql

-- changeset zh_bexultan:1700125339598-1

CREATE TABLE dbo.MetaDocument (
	MetaDocument_ID				BIGINT IDENTITY (1, 1) NOT NULL,
	Target_Table				VARCHAR(250) NOT NULL,
	Target_ID					BIGINT NOT NULL,
	DocumentType_IDREF			CHAR(4) NOT NULL,
	IsActive					BIT NOT NULL DEFAULT 0,
	LangKey						CHAR(2),
	DateCreated					DATETIME NOT NULL,
	FileUid						VARCHAR(100) NOT NULL,
	CONSTRAINT MetaDocument_DocumentType_FK FOREIGN KEY (DocumentType_IDREF) REFERENCES DocumentType(DocumentType_ID)
);