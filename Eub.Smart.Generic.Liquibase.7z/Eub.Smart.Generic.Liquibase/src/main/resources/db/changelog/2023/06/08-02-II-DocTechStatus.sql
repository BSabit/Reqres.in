-- liquibase formatted sql

-- changeset alibi:1686220138971-1

INSERT INTO DocTechStatus (DocTechStatus_ID,
                           DocTechStatus_Title,
                           Term_OUTREF,
                           FinDocStatus_IDREF,
                           IsFinal,
                           DoProcess,
                           IsVisibleToUser)
VALUES ('NEWN', 'Новый', null, 'PROC', 0, 0, 0);
