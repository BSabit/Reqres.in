-- liquibase formatted sql

-- changeset Abekmat:1687353579229-7

CREATE TABLE dbo.[OtpStatus]
(
	[OtpStatus_ID]           		nchar(4) NOT NULL,
	[OtpStatus_Title] 				varchar(255) NOT NULL,
	CONSTRAINT [OtpStatus_PK] PRIMARY KEY NONCLUSTERED ([OtpStatus_ID] ASC)
);