-- liquibase formatted sql

-- changeset zh_bexultan:1701416871159-1

ALTER TABLE DMZVerification
ALTER COLUMN MobilePhone nvarchar(14);

ALTER TABLE DMZVerification
ADD CONSTRAINT CHK_DMZVerification_MinLength
CHECK (LEN(MobilePhone) >= 10);