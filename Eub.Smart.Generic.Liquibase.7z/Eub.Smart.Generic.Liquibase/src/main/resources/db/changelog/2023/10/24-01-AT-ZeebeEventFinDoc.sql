-- liquibase formatted sql

-- changeset daurenbekuly:1698121750916-1

alter table ZeebeEventFinDoc
    add CollectorID varchar(255) NULL,
        Rrn varchar(255) NULL,
        Brrn varchar(255) NULL,
        ErrorMessage varchar(max) NULL;
