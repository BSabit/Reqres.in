-- liquibase formatted sql

-- changeset zh_bexultan:1701416886506-1

ALTER TABLE DMZVerificationAttempts
ALTER COLUMN MobilePhone nvarchar(14);

ALTER TABLE DMZVerificationAttempts
ADD CONSTRAINT CHK_DMZVerificationAttempts_MinLength
CHECK (LEN(MobilePhone) >= 10);