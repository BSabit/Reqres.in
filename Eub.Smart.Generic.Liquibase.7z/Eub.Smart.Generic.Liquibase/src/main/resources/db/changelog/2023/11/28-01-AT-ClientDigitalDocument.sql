-- liquibase formatted sql

-- changeset zh_bexultan:1701148891331-1

ALTER TABLE ClientDigitalDocument DROP COLUMN File_OUTREF;