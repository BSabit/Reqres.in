-- liquibase formatted sql

-- changeset Abekmat:1687353579229-12

CREATE TABLE dbo.[DMZVerificationOtp]
(
	[DMZVerificationOtp_ID]             	bigint IDENTITY (1, 1) NOT NULL,
	[DateCreated]                        	datetime NOT NULL default getDate(),
	[OtpStatus_IDREF]                   	nchar(4) NOT NULL default 'SEND',
	[DateExpired]                          	datetime NOT NULL,
	[CodeHash]                           	varchar(254) NOT NULL,
	[DMZVerification_IDREF] 			    bigint NOT NULL,
	[CountValidation]                    	int NOT NULL default 0,
	CONSTRAINT [DMZVerificationOtp_PK] PRIMARY KEY NONCLUSTERED ([DMZVerificationOtp_ID] ASC),
	CONSTRAINT [DMZVerificationOtp_DMZVerification_FK] FOREIGN KEY ([DMZVerification_IDREF]) REFERENCES [DMZVerification]([DMZVerification_ID]),
	CONSTRAINT [DMZVerificationOtp_OtpStatus_FK] FOREIGN KEY ([OtpStatus_IDREF]) REFERENCES [OtpStatus]([OtpStatus_ID])
);