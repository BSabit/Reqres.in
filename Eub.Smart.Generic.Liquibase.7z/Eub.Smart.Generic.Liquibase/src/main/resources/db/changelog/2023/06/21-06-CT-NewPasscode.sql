-- liquibase formatted sql

-- changeset Abekmat:1687353579229-10

CREATE TABLE dbo.NewPasscode (
    [Passcode_ID]               int IDENTITY(1,1) NOT NULL,
    [User_IDREF]                int NOT NULL,
    [PasscodeStatus_IDREF]      char(4) NOT NULL,
    [Hash]                      varchar(255) NOT NULL,
    [DeviceID]                  varchar(254) NOT NULL,
    [DateCreated]               datetime DEFAULT getdate() NULL,
    [InvalidUses]               int DEFAULT 0 NULL,
    [LastInvalidUse]            datetime NULL,
    CONSTRAINT PK_NewPasscode PRIMARY KEY (Passcode_ID),
    CONSTRAINT FK_NewPasscode_PasscodeStatus FOREIGN KEY (PasscodeStatus_IDREF) REFERENCES PasscodeStatus(PasscodeStatus_ID),
    CONSTRAINT FK_NewPasscode_User FOREIGN KEY (User_IDREF) REFERENCES [User](User_ID)
);