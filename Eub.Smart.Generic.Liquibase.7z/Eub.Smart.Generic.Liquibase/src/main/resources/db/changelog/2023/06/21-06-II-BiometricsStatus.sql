-- liquibase formatted sql

-- changeset Abekmat:1687353579229-25

INSERT INTO [dbo].[BiometricsStatus] (BiometricsStatus_ID, BiometricsStatus_Title)
VALUES
    ('AZST', 'Анализ запушен'),
    ('VIIN', 'Ожидает проверки ИИН'),
    ('VODD', 'Ожидает кода ОТП от Цифровых документов'),
    ('BINM', 'Биометрия не совпала'),
    ('RDDE', 'Не удалось получить ЦД из EGOV'),
    ('VDDF', 'Верификация по Цифровым документам не прошла'),
    ('CDDN', 'ЦОИД не работает, цифровых доков нет'),
    ('SCBO', 'Биомтерия прошла успешно');
