-- liquibase formatted sql

-- changeset Abekmat:1687353579229-29

INSERT INTO dbo.[OtpStatus] ([OtpStatus_ID],[OtpStatus_Title])
VALUES
    ('SEND',	'Отправлено'),
    ('FAIL',	'ОТП не совпадает'),
    ('SCCS',	'Провалидировано');