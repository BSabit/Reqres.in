-- liquibase formatted sql

-- changeset Abekmat:1687353579229-20

CREATE TABLE reg_Image(
	[Image_ID] 				    bigint IDENTITY (1, 1),
	[ImageData] 			    varbinary(MAX),
	CONSTRAINT req_Image_PK PRIMARY KEY (Image_ID)
);