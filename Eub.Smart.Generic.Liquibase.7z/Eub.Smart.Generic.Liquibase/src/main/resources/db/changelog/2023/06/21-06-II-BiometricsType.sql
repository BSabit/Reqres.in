-- liquibase formatted sql

-- changeset Abekmat:1687353579229-26

INSERT INTO dbo.[BiometricsType] ([BiometricsType_ID],[BiometricsType_Title])
VALUES
    ('ARCH', 'Хранилище данных'),
    ('KISC', 'ЦОИД'),
    ('DGTL', 'Цифровые документы');
