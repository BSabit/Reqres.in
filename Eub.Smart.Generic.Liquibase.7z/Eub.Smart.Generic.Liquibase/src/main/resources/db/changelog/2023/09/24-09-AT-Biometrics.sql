-- liquibase formatted sql

-- changeset zh_bexultan:1695537044663-1

ALTER TABLE Biometrics ADD Similarity_Percent DECIMAL(10, 4);