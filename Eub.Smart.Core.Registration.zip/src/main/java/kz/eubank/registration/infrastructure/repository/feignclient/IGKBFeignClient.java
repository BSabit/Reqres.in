package kz.eubank.registration.infrastructure.repository.feignclient;

import feign.Headers;
import kz.eubank.registration.infrastructure.config.FeignSupportConfiguration;
import kz.eubank.registration.infrastructure.model.dto.scb.SCBPersonalData;
import kz.eubank.registration.infrastructure.repository.feignclient.fallback.GKBFeignFallback;
import kz.eubank.registration.infrastructure.repository.feignclient.model.DocumentResponseDto;
import kz.eubank.registration.infrastructure.repository.feignclient.model.OtpResponseDto;
import kz.eubank.registration.infrastructure.repository.feignclient.model.ProfileResponseDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Optional;

@FeignClient(value = "gkb",
        url = "${gkb.url}/api/${gkb.version}",
        configuration = FeignSupportConfiguration.class,
        fallbackFactory = GKBFeignFallback.class)
public interface IGKBFeignClient {

    @GetMapping("/IdentityCards/Profile")
    @Headers("Content-type:application/json2.json")
    Optional<ProfileResponseDto> getProfile(@RequestParam("iin") String iin,
                                            @RequestHeader("X-Correlation-Id") String correlationId);

    @GetMapping("/IdentityCards/AccessDocument")
    @Headers("Content-type:application/json2.json")
    Optional<OtpResponseDto> accessDocument(@RequestParam("iin") String iin,
                                            @RequestParam("documentType") String documentType,
                                            @RequestHeader("X-Correlation-Id") String correlationId);

    @GetMapping("/IdentityCards/GetIdentityCard")
    @Headers("Content-type:application/json2.json")
    Optional<DocumentResponseDto> getIdentityCard(@RequestParam("iin") String iin,
                                                  @RequestParam("code") String code,
                                                  @RequestHeader("X-Correlation-Id") String correlationId);

    @GetMapping("/Clients/GetClientDataByIin")
    @Headers("Content-type:application/json2.json")
    Optional<SCBPersonalData> getClientDataByIin(@RequestParam("iin") String iin,
                                                 @RequestHeader("X-Correlation-Id") String correlationId);
}
