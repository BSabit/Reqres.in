package kz.eubank.registration.infrastructure.model.entity.view;

import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Getter
@Entity
@NoArgsConstructor
public class AttemptsLimitView {

    @Id
    @Column(name = "Type")
    private String type;

    @Column(name = "Count")
    private int count;
}
