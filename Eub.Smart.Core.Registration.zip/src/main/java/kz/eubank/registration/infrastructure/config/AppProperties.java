package kz.eubank.registration.infrastructure.config;

import kz.eubank.registration.domain.model.enums.DMZVerificationAttemptsType;
import lombok.RequiredArgsConstructor;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class AppProperties {

    private final Environment environment;

    //Проверка общего лимита
    public int getVerificationLimitCount() {
        return Integer.parseInt(environment.getProperty("verification.limit.all", "10"));
    }

    //Проверка лимитов по отправке SMS(SSMS), проверке SMS(CSMS), ИИН(SIIN), биометрии(SBIO)
    public int getVerificationLimitCountByType(DMZVerificationAttemptsType type) {
        return Integer.parseInt(environment.getProperty("verification.limit.type." + type.name(), "5"));
    }

    //Количество порога предупреждения проверки отправке SMS(SSMS), проверке SMS(CSMS), ИИН(SIIN), биометрии(SBIO)
    public int getVerificationWarnThresholdCountByType(DMZVerificationAttemptsType type) {
        return Integer.parseInt(environment.getProperty("verification.warn-threshold.type." + type, "3"));
    }

    public String getForensicUrl() {
        return environment.getProperty("forensic.url");
    }

    public String getForensicEmail() {
        return environment.getProperty("forensic.email");
    }

    public int getAttemptsForRecovery() {
        return Integer.parseInt(environment.getProperty("recovery.limit.attempts", "5"));
    }

    public String getNotifyForRecovery() {
        return environment.getProperty("recovery.limit.notify");
    }

    public int getAttemptsForBiometry() {
        return Integer.parseInt(environment.getProperty("biometrics.limit.attempts", "5"));
    }

    public String getNotifyForBiometry() {
        return environment.getProperty("biometrics.limit.notify");
    }

    public String getForensicPassword() {
        return environment.getProperty("forensic.password");
    }

    public String getProxyServerHost() {
        return environment.getProperty("proxy.server.host");
    }

    public Integer getProxyServerPort() {
        return Integer.parseInt(environment.getProperty("proxy.server.port", "8080"));
    }

    public String getBiometricsAnalyseType(String type) {
        return environment.getProperty("biometrics.analyses.type." + type);
    }

    public Integer getSuitableAgeForVerificationIIN() {
        return Integer.parseInt(environment.getProperty("verification.iin.suitable-age", "18"));
    }

    public String getSmsHashCode(String frontEnd) {
        return environment.getProperty("send.sms.hashCode." + frontEnd);
    }

    public boolean isServiceHealthy(String serviceName) {
        return "1".equals(environment.getProperty("service.health." + serviceName));
    }

    public Integer getSessionExpirationMinutes() {
        return Integer.parseInt(environment.getProperty("session.expiration.minutes", "30"));
    }
}