package kz.eubank.registration.infrastructure.model.entity;

import lombok.*;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "FrontEnd")
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FrontEnd {

    @Id
    @Column(name = "FrontEnd_ID")
    private String id;

    @Column(name = "FrontEnd_Title")
    private String title;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "Channel_IDREF")
    private Channel chanel;

    @Column(name = "Term_OUTREF")
    private Long term;

    @Column(name = "PlatformCode")
    private int platformCode;
}
