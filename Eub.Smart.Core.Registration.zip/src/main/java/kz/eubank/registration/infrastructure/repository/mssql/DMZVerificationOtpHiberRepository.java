package kz.eubank.registration.infrastructure.repository.mssql;

import kz.eubank.registration.infrastructure.model.entity.DMZVerificationOtp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DMZVerificationOtpHiberRepository extends JpaRepository<DMZVerificationOtp, Long> {

    @Query(nativeQuery = true,
            value = """
                    select top(1) *
                      from DMZVerificationOtp d
                      join DMZVerification v on d.DMZVerification_IDREF = v.DMZVerification_ID
                     where GETDATE() between d.DateCreated and d.DateExpired
                       and v.SessionId = :sessionId
                     order by d.DateCreated desc
                    """)
    Optional<DMZVerificationOtp> getActualOtpBySessionId(String sessionId);
}
