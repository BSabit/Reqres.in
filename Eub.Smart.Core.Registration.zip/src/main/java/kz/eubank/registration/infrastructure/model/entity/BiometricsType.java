package kz.eubank.registration.infrastructure.model.entity;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@Entity
@Table(name = "BiometricsType")
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BiometricsType {

    @Id
    @Column(name = "BiometricsType_ID")
    private String id;

    @Column(name = "BiometricsType_Title")
    private String title;
}
