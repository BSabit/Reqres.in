package kz.eubank.registration.infrastructure.repository.mssql.procedure;

import lombok.*;

import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ResponseCreateUserProcedure {
    private String login;
    private String password;
    private String status;
    private int userId;
    private String error;
}
