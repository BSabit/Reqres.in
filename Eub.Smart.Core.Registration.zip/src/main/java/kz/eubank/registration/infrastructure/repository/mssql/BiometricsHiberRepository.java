package kz.eubank.registration.infrastructure.repository.mssql;

import kz.eubank.registration.infrastructure.model.entity.Biometrics;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.Optional;

@Repository
public interface BiometricsHiberRepository extends JpaRepository<Biometrics, Long> {
    @Query(nativeQuery = true,
            value = """
                         SELECT top 1 * FROM Biometrics b
                          WHERE b.FolderId = :folderId
                          ORDER BY b.DateCreated DESC
                    """)
    Optional<Biometrics> findByIdAndFolderId(String folderId);


    @Transactional
    @Modifying
    @Query(nativeQuery = true,
            value = """
                        UPDATE Biometrics SET [Data] = :responseAnalyze,
                               BiometricsStatus_IDREF = :status
                         WHERE Biometrics_ID = :biometricsID
                    """)
    void updateData(Object responseAnalyze, String status, long biometricsID);


    @Transactional
    @Modifying
    @Query(nativeQuery = true,
            value = """
                        UPDATE Biometrics SET BiometricsStatus_IDREF = :status
                         WHERE Biometrics_ID = :biometricsID
                    """)
    void updateStatus(String status, long biometricsID);

    @Transactional
    @Modifying
    @Query(nativeQuery = true,
            value = """
                        UPDATE Biometrics SET Similarity_Percent = :similarityPercent
                         WHERE FolderId = :folderId
                    """)
    void updateSimilarityPercentByFolderId(String folderId, double similarityPercent);
}
