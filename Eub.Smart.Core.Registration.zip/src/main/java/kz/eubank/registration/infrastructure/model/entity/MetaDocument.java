package kz.eubank.registration.infrastructure.model.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "MetaDocument")
@NoArgsConstructor
@AllArgsConstructor
public class MetaDocument {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MetaDocument_ID")
    private Long id;

    @Column(name = "Target_Table")
    private String targetTable;

    @Column(name = "Target_ID")
    private Long targetId;

    @Column(name = "DocumentType_IDREF")
    private String documentType;

    @Column(name = "IsActive")
    private Boolean isActive;

    @Column(name = "LangKey")
    private String langKey;

    @Column(name = "DateCreated")
    private Date dateCreated;

    @Column(name = "FileUid")
    private String fileUid;
}
