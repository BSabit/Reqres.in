package kz.eubank.registration.infrastructure.model.dto.scb.subclass;

import com.fasterxml.jackson.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ListOfDocument {
    @JsonProperty("type")
    private GenericField type;
    @JsonProperty("number")
    private String number;
    @JsonProperty("beginDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private Date beginDate;
    @JsonProperty("endDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private Date endDate;
    @JsonProperty("issueOrganization")
    private GenericField issueOrganization;
    @JsonProperty("status")
    private GenericField status;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("surname")
    private String surname;
    @JsonProperty("patronymic")
    private String patronymic;
    @JsonProperty("birthDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private Date birthDate;
}
