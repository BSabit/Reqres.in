package kz.eubank.registration.infrastructure.config.logger;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Component
public class CustomWebConfigurer implements WebMvcConfigurer {
    private final InterceptLog interceptLog;

    public CustomWebConfigurer(InterceptLog interceptLog) {
        this.interceptLog = interceptLog;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(interceptLog);
    }

}
