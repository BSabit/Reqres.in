package kz.eubank.registration.infrastructure.repository.mssql.impl;

import kz.eubank.registration.domain.model.pojo.MetaDocument;
import kz.eubank.registration.domain.repository.IMetaDocumentRepository;
import kz.eubank.registration.infrastructure.model.mapper.BaseMapper;
import kz.eubank.registration.infrastructure.repository.mssql.MetaDocumentHiberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Primary
@Component
@RequiredArgsConstructor
public class MetaDocumentRepository implements IMetaDocumentRepository {

    private final MetaDocumentHiberRepository metaDocumentHiberRepository;

    @Override
    public Optional<MetaDocument> findActiveByTargetTableAndTargetId(String targetTable, Long targetId) {
        return metaDocumentHiberRepository.findActiveByTargetTableAndTargetId(targetTable, targetId)
                .map(BaseMapper.INSTANCE::toDomain);
    }
}
