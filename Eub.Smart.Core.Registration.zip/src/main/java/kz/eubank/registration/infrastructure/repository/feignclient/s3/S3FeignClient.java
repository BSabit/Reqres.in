package kz.eubank.registration.infrastructure.repository.feignclient.s3;

import kz.eubank.registration.infrastructure.repository.feignclient.model.UploadDocumentResponseDto;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.E_BS_951;
import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.E_EX_701;

@Primary
@Service
@RequiredArgsConstructor
public class S3FeignClient {

    private final IS3FeignClient s3Client;

    public UploadDocumentResponseDto uploadFileOrThrowException(String mediaType, MultipartFile file,
                                                                String targetTable, Long targetId, String documentType) {
        try {
            return s3Client.uploadFile(mediaType,file, targetTable, targetId, documentType)
                    .orElseThrow(() -> new SelfException(E_EX_701));
        } catch (SelfException e) {
            throw new SelfException(E_EX_701);
        }
    }

    public byte[] downloadFileOrThrowException(String fileUid) {
        try {
            return s3Client.downloadFile(fileUid)
                    .orElseThrow(() -> new SelfException(E_EX_701));
        } catch (SelfException e) {
            throw new SelfException(E_BS_951);
        }
    }
}
