package kz.eubank.registration.infrastructure.repository.feignclient;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Service
public class IdentityProviderFeignClient {

    private final IIdentityProviderFeignClient identityProviderFeignClient;

    public void clearUserCache(String username, String correlationId) {
        identityProviderFeignClient.clearUserCache(username, correlationId);
    }
}
