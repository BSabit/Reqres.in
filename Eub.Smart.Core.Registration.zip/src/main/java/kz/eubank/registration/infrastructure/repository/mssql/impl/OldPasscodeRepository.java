package kz.eubank.registration.infrastructure.repository.mssql.impl;

import kz.eubank.registration.domain.model.pojo.Passcode;
import kz.eubank.registration.domain.repository.IOldPasscodeRepository;
import kz.eubank.registration.infrastructure.model.mapper.BaseMapper;
import kz.eubank.registration.infrastructure.repository.mssql.OldPasscodeHiberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Primary
@Component
@RequiredArgsConstructor
public class OldPasscodeRepository implements IOldPasscodeRepository {

    private final OldPasscodeHiberRepository oldPasscodeHiberRepository;

    @Override
    public Passcode saveAndGet(Passcode passcode) {
        var entity = BaseMapper.INSTANCE.toEntity(passcode);
        return BaseMapper.INSTANCE.toDomain(oldPasscodeHiberRepository.saveAndFlush(entity));
    }
    @Override
    public void save(Passcode passcode) {
        var entity = BaseMapper.INSTANCE.toEntity(passcode);
        oldPasscodeHiberRepository.save(entity);
    }
    @Override
    public void changeStatusByDeviceId(String status, String deviceId) {
        oldPasscodeHiberRepository.changeStatusByDeviceId(status, deviceId);
    }
    public void changeStatusByUserId(String status, String userID) {
        oldPasscodeHiberRepository.changeStatusByUserId(status, userID);
    }
}
