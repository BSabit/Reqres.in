package kz.eubank.registration.infrastructure.model.dto.scb.subclass;

import com.fasterxml.jackson.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class RegAddress {
    @JsonProperty("country")
    private GenericField country;
    @JsonProperty("district")
    private GenericField district;
    @JsonProperty("region")
    private GenericField region;
    @JsonProperty("street")
    private String street;
    @JsonProperty("building")
    private String building;
    @JsonProperty("flat")
    private String flat;
    @JsonProperty("beginDate")
    private String beginDate;
    @JsonProperty("status")
    private GenericField status;
    @JsonProperty("invalidity")
    private GenericField invalidity;
    @JsonProperty("arCode")
    private String arCode;
}
