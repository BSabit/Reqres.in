package kz.eubank.registration.infrastructure.model.entity;

import lombok.*;

import javax.persistence.*;

@Entity
@Table(name = "Gbdfl_Region")
@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GbdflRegion {

    @Id
    @Column(name = "Gbdfl_code")
    private String code;

    @Column(name = "Gbdfl_title")
    private String title;

    @Column(name = "Region_IDREF")
    private String region;
}
