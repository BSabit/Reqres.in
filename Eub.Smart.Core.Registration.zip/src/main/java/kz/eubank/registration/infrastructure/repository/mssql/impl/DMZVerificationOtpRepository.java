package kz.eubank.registration.infrastructure.repository.mssql.impl;

import kz.eubank.registration.domain.model.pojo.DMZVerificationOtp;
import kz.eubank.registration.domain.repository.IDMZVerificationOtpRepository;
import kz.eubank.registration.infrastructure.model.mapper.BaseMapper;
import kz.eubank.registration.infrastructure.repository.mssql.DMZVerificationOtpHiberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Primary
@Component
@RequiredArgsConstructor
public class DMZVerificationOtpRepository implements IDMZVerificationOtpRepository {

    private final DMZVerificationOtpHiberRepository dmzVerificationOtpHiberRepository;

    @Override
    public Optional<DMZVerificationOtp> getActualOtpBySessionId(String sessionId) {
        return dmzVerificationOtpHiberRepository.getActualOtpBySessionId(sessionId)
                .map(BaseMapper.INSTANCE::toDomain);
    }

    @Override
    public void save(DMZVerificationOtp dmzVerificationOtp) {
        var entity = BaseMapper.INSTANCE.toEntity(dmzVerificationOtp);
        dmzVerificationOtpHiberRepository.save(entity);
    }
}
