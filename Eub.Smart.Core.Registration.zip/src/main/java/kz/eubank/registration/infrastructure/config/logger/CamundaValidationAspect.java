package kz.eubank.registration.infrastructure.config.logger;

import kz.eubank.registration.application.camunda.execution.impl.BaseExecution;
import kz.eubank.registration.application.camunda.util.Element2StepUtil;
import kz.eubank.registration.domain.util.StringUtil;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.camunda.bpm.engine.task.Task;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.E_BS_962;
import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.E_BS_963;

@Aspect
@Component
@RequiredArgsConstructor
public class CamundaValidationAspect {
    private final BaseExecution baseExecution;
    private final Logger log = LogManager.getLogger(getClass());

    @Pointcut("within(@org.springframework.stereotype.Repository *)" +
            " || within(@org.springframework.stereotype.Service *)" +
            " || within(@org.springframework.stereotype.Component *)")
    public void springBeanPointcut() {
    }

    @Pointcut("execution(* kz.eubank.registration.application.camunda.execution.impl.SmsExecution.sms(..))" +
            " || execution(* kz.eubank.registration.application.camunda.execution.impl.BiometryExecution.statusAnalyze(..))" +
            " || execution(* kz.eubank.registration.application.camunda.execution.impl.BiometryExecution.uploadSelfie(..))" +
            " || execution(* kz.eubank.registration.application.camunda.execution.impl.ErrorTextExecution.getErrorText(..))" +
            " || execution(* kz.eubank.registration.application.camunda.execution.impl.DigitalDocumentExecution.identityCard(..))" +
            " || execution(* kz.eubank.registration.application.camunda.execution.impl.PasscodeExecution.createPasscode(..))" +
            " || execution(* kz.eubank.registration.application.camunda.execution.impl.VerificationExecution.verificationIIN(..))" +
            " || execution(* kz.eubank.registration.application.camunda.execution.impl.VerificationExecution.verificationProduct(..))")
    public void camundaExecution(){}

    @Before("camundaExecution()")
    public void validationExecute(JoinPoint point){
        MethodSignature methodSignature = (MethodSignature) point.getSignature();

        String checkMethod = methodSignature.getMethod().getName();

        Task userTask = baseExecution.getTaskBySessionId(MDC.get("Operation-Id"));
        if (userTask == null) {
            throw new SelfException(E_BS_963, "operation-id not found in camunda");
        }

        String stepId = Element2StepUtil.convert(userTask.getTaskDefinitionKey());
        String rightMethod = Element2StepUtil.methodMapStep.get(stepId);

        if (StringUtil.isEmpty(rightMethod) || !rightMethod.equals(checkMethod)) {
            throw new SelfException(E_BS_962, "wrong invoke step");
        }
    }
}
