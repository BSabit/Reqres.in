package kz.eubank.registration.infrastructure.model.entity;


import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "RecoveryProduct")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RecoveryProduct {
    @Id
    @Column(name = "RecoveryProduct_ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id;
    private Date dateCreated;
    private String productNumber;
    @OneToOne
    @JoinColumn(name = "RecoveryProductAccountType_IDREF", nullable = false)
    private RecoveryProductAccountType type;
    @OneToOne
    @JoinColumn(name = "RecoveryProductStatus_IDREF")
    private RecoveryProductStatus status;
    private String iin;
    @ManyToOne
    @JoinColumn(name = "DMZVerification_IDREF")
    private DMZVerification dmzVerification;
    @Column(name = "Customer_OUTREF")
    private String customer;
    @Column(name = "MobilePhone_OUTREF")
    private String mobilePhone;
    @Column(name = "BSystem_IDREF")
    private String bsystem;
}
