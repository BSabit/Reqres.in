package kz.eubank.registration.infrastructure.repository.mssql.impl;

import kz.eubank.registration.domain.model.pojo.DMZVerification;
import kz.eubank.registration.domain.repository.IDMZVerificationRepository;
import kz.eubank.registration.infrastructure.model.mapper.BaseMapper;
import kz.eubank.registration.infrastructure.repository.mssql.DMZVerificationHiberRepository;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Primary
@Component
@RequiredArgsConstructor
public class DMZVerificationRepository implements IDMZVerificationRepository {

    private final DMZVerificationHiberRepository dmzVerificationHiberRepository;

    @Override
    public int getVerificationLimitCountByMobilePhone(String mobilePhone) {
        return dmzVerificationHiberRepository.getVerificationLimitCountByMobilePhone(mobilePhone);
    }

    @Override
    public Optional<DMZVerification> getNotFinishedSessionByMobilePhoneAndDeviceId(String mobilePhone, String deviceId) {
        return dmzVerificationHiberRepository.getNotFinishedSessionByMobilePhoneAndDeviceId(mobilePhone, deviceId)
                .map(BaseMapper.INSTANCE::toDomain);
    }

    @Override
    public Optional<DMZVerification> findBySessionId(String sessionId) {
        return dmzVerificationHiberRepository.findBySessionId(sessionId)
                .map(BaseMapper.INSTANCE::toDomain);
    }

    @Override
    public void save(DMZVerification dmzVerification) {
        var entity = BaseMapper.INSTANCE.toEntity(dmzVerification);
        dmzVerificationHiberRepository.save(entity);
    }

    @Override
    public String findDeviceId(String sessionId) {
        return dmzVerificationHiberRepository.findDeviceId(sessionId);
    }

    @Override
    public long findUserIdByIin(String sessionId) {
        Optional<Long> userIdByIin = dmzVerificationHiberRepository.findUserIdByIin(sessionId);
        if (userIdByIin.isEmpty())
            throw new SelfException(SelfErrorCode.E_DB_600, "not found user sessionId: " + sessionId);
        return userIdByIin.get();

    }

    @Override
    public void updateIin(String sessionId, String iin) {
        dmzVerificationHiberRepository.updateIin(sessionId, iin);
    }

    @Override
    public void updatePasscode(String sessionId, long passcodeId) {
        dmzVerificationHiberRepository.updatePasscode(sessionId, passcodeId);
    }

    @Override
    public void updateOldPasscode(String sessionId, long oldPasscodeId) {
        dmzVerificationHiberRepository.updateOldPasscode(sessionId, oldPasscodeId);
    }

    @Override
    public void updateStatus(String status, long dmzverificationId) {
        dmzVerificationHiberRepository.updateStatus(status, dmzverificationId);
    }

    @Override
    public void updateStatusWithSessionId(String status, String sessionId) {
        dmzVerificationHiberRepository.updateStatusWithSessionId(status, sessionId);
    }
}
