package kz.eubank.registration.infrastructure.model.entity;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@Entity
@Table(name = "Channel")
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Channel {

    @Id
    @Column(name = "Channel_ID")
    private String id;

    @Column(name = "Channel_Title")
    private String title;

    @Column(name = "Term_OUTREF")
    private Long term;
}
