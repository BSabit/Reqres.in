package kz.eubank.registration.infrastructure.model.dto.scb;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class SCBResponse {
    private SCBPersonalData result;
    private String id;
    private String exception;
    private int status;
    private boolean isCanceled;
    private boolean isCompleted;
    private boolean isCompletedSuccessfully;
    private int creationOptions;
    private String asyncState;
    private boolean isFaulted;
}