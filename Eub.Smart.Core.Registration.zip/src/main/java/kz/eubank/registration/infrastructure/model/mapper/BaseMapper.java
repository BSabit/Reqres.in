package kz.eubank.registration.infrastructure.model.mapper;

import kz.eubank.registration.domain.model.pojo.*;
import kz.eubank.registration.domain.model.pojo.view.AttemptsLimitView;
import kz.eubank.registration.domain.model.pojo.view.UserDefineRouteView;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface BaseMapper {

    BaseMapper INSTANCE = Mappers.getMapper(BaseMapper.class);

    AttemptsLimitView toDomain(kz.eubank.registration.infrastructure.model.entity.view.AttemptsLimitView entity);

    UserDefineRouteView toDomain(kz.eubank.registration.infrastructure.model.entity.view.UserDefineRouteView entity);

    DMZVerification toDomain(kz.eubank.registration.infrastructure.model.entity.DMZVerification entity);

    DMZVerificationAttempts toDomain(kz.eubank.registration.infrastructure.model.entity.DMZVerificationAttempts entity);

    DMZVerificationOtp toDomain(kz.eubank.registration.infrastructure.model.entity.DMZVerificationOtp entity);

    OtpStatus toDomain(kz.eubank.registration.infrastructure.model.entity.OtpStatus entity);

    Passcode toDomain(kz.eubank.registration.infrastructure.model.entity.Passcode entity);

    PasscodeStatus toDomain(kz.eubank.registration.infrastructure.model.entity.PasscodeStatus entity);

    RouteStatus toDomain(kz.eubank.registration.infrastructure.model.entity.RouteStatus entity);

    RouteType toDomain(kz.eubank.registration.infrastructure.model.entity.RouteType entity);

    WhiteListAuthorization toDomain(kz.eubank.registration.infrastructure.model.entity.WhiteListAuthorization entity);

    Biometrics toDomain(kz.eubank.registration.infrastructure.model.entity.Biometrics entity);

    NewPasscode toDomain(kz.eubank.registration.infrastructure.model.entity.NewPasscode entity);

    RecoveryProductAccountType toDomain(kz.eubank.registration.infrastructure.model.entity.RecoveryProductAccountType entity);

    RecoveryProduct toDomain(kz.eubank.registration.infrastructure.model.entity.RecoveryProduct entity);

    RecoveryProductStatus toDomain(kz.eubank.registration.infrastructure.model.entity.RecoveryProductStatus entity);

    GbdflRegion toDomain(kz.eubank.registration.infrastructure.model.entity.GbdflRegion entity);

    User toDomain(kz.eubank.registration.infrastructure.model.entity.User entity);

    Device toDomain(kz.eubank.registration.infrastructure.model.entity.Device entity);

    Channel toDomain(kz.eubank.registration.infrastructure.model.entity.Channel entity);

    FrontEnd toDomain(kz.eubank.registration.infrastructure.model.entity.FrontEnd entity);

    Password toDomain(kz.eubank.registration.infrastructure.model.entity.Password entity);

    @Mapping(source = "verified", target = "isVerified")
    ClientDigitalDocument toDomain(kz.eubank.registration.infrastructure.model.entity.ClientDigitalDocument entity);

    ClientDigitalDocumentType toDomain(kz.eubank.registration.infrastructure.model.entity.ClientDigitalDocumentType entity);

    MetaDocument toDomain(kz.eubank.registration.infrastructure.model.entity.MetaDocument entity);

    kz.eubank.registration.infrastructure.model.entity.view.AttemptsLimitView toEntity(AttemptsLimitView domain);

    kz.eubank.registration.infrastructure.model.entity.view.UserDefineRouteView toEntity(UserDefineRouteView domain);

    kz.eubank.registration.infrastructure.model.entity.DMZVerification toEntity(DMZVerification domain);

    kz.eubank.registration.infrastructure.model.entity.DMZVerificationAttempts toEntity(DMZVerificationAttempts domain);

    kz.eubank.registration.infrastructure.model.entity.DMZVerificationOtp toEntity(DMZVerificationOtp domain);

    kz.eubank.registration.infrastructure.model.entity.OtpStatus toEntity(OtpStatus domain);

    kz.eubank.registration.infrastructure.model.entity.Passcode toEntity(Passcode domain);

    kz.eubank.registration.infrastructure.model.entity.NewPasscode toEntity(NewPasscode newPasscode);

    kz.eubank.registration.infrastructure.model.entity.PasscodeStatus toEntity(PasscodeStatus domain);

    kz.eubank.registration.infrastructure.model.entity.RouteStatus toEntity(RouteStatus domain);

    kz.eubank.registration.infrastructure.model.entity.RouteType toEntity(RouteType domain);

    kz.eubank.registration.infrastructure.model.entity.WhiteListAuthorization toEntity(WhiteListAuthorization domain);

    kz.eubank.registration.infrastructure.model.entity.Biometrics toEntity(Biometrics domain);

    kz.eubank.registration.infrastructure.model.entity.RecoveryProductAccountType toEntity(RecoveryProductAccountType domain);

    kz.eubank.registration.infrastructure.model.entity.RecoveryProduct toEntity(RecoveryProduct domain);

    kz.eubank.registration.infrastructure.model.entity.RecoveryProductStatus toEntity(RecoveryProductStatus domain);

    kz.eubank.registration.infrastructure.model.entity.GbdflRegion toEntity(GbdflRegion domain);

    kz.eubank.registration.infrastructure.model.entity.User toEntity(User domain);

    kz.eubank.registration.infrastructure.model.entity.Device toEntity(Device domain);

    kz.eubank.registration.infrastructure.model.entity.Channel toEntity(Channel domain);

    kz.eubank.registration.infrastructure.model.entity.FrontEnd toEntity(FrontEnd domain);

    kz.eubank.registration.infrastructure.model.entity.Password toEntity(Password domain);

    @Mapping(source = "verified", target = "isVerified")
    kz.eubank.registration.infrastructure.model.entity.ClientDigitalDocument toEntity(ClientDigitalDocument domain);

    kz.eubank.registration.infrastructure.model.entity.ClientDigitalDocumentType toEntity(ClientDigitalDocumentType domain);

    kz.eubank.registration.infrastructure.model.entity.MetaDocument toEntity(MetaDocument domain);
}
