package kz.eubank.registration.infrastructure.repository.mssql;

import kz.eubank.registration.infrastructure.model.entity.Device;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface DeviceHiberRepository extends JpaRepository<Device, Long> {
    @Query(nativeQuery = true,
            value = """
                         SELECT Count(*) FROM Device
                         WHERE Device_ID = :deviceId
                         AND User_IDREF = :userId
                    """)
    int checkDevice(String deviceId, Long userId);

    @Modifying
    @Query(nativeQuery = true,
             value = """
                          UPDATE Device
                          SET LoginDateTime = GETDATE(),
                              IsActualDevice = 1
                          WHERE User_IDREF = :userId
                          AND   Device_ID = :deviceId
                     """)
    void makeDeviceValid(Long userId, String deviceId);

    @Modifying
    @Query(nativeQuery = true,
            value = """
                          UPDATE Device
                          SET IsActualDevice = 0
                          WHERE User_IDREF = :userId
                          AND   Device_ID <> :deviceId
                     """)
    void logoutOtherDevices(Long userId, String deviceId);
}
