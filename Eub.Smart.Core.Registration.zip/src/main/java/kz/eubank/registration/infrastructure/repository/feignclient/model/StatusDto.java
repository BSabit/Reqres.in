package kz.eubank.registration.infrastructure.repository.feignclient.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public record StatusDto(@JsonProperty("Code") String code,
                        @JsonProperty("Message") String message) {
}
