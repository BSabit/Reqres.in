package kz.eubank.registration.infrastructure.repository.mssql;

import kz.eubank.registration.infrastructure.model.entity.Fingerprint;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;

@Repository
public interface FingerprintHiberRepository extends JpaRepository<Fingerprint, Long> {

    @Transactional
    @Modifying
    @Query(nativeQuery = true,
            value = """
                    UPDATE Fingerprint
                    SET FingerprintStatus_IDREF = 'BUPR'
                    WHERE User_IDREF = :userId  AND FingerprintStatus_IDREF = 'ACTV'
                    """)
    void updateBUPRStatus(long userId);
}
