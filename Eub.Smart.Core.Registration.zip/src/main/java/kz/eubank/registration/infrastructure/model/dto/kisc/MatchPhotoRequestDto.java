package kz.eubank.registration.infrastructure.model.dto.kisc;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class MatchPhotoRequestDto extends BaseRequestKisc{

    private String image;
    private String iin;
    private String vendor;
    private String idempotencyKey;

    public MatchPhotoRequestDto(String image, String iin, String vendor, String system, String idempotencyKey) {
        super(system);
        this.image = image;
        this.iin = iin;
        this.vendor = vendor;
        this.idempotencyKey = idempotencyKey;
    }

    public MatchPhotoRequestDto(String image, String iin, String vendor, String idempotencyKey) {
        this.image = image;
        this.iin = iin;
        this.vendor = vendor;
        this.idempotencyKey = idempotencyKey;
    }
}