package kz.eubank.registration.infrastructure.repository.mssql.impl;

import kz.eubank.registration.domain.repository.IFingerprintRepository;
import kz.eubank.registration.infrastructure.repository.mssql.FingerprintHiberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Primary
@Component
@RequiredArgsConstructor
public class FingerprintRepository implements IFingerprintRepository {

    private final FingerprintHiberRepository repository;

    @Override
    public void updateBUPRStatus(long userId) {
        repository.updateBUPRStatus(userId);
    }
}
