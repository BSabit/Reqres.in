package kz.eubank.registration.infrastructure.model.entity;

import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "Device")
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Device {


    @Column(name = "Device_ID")
    private String deviceId;

    @Column(name = "User_IDREF")
    private Long userId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "FrontEnd_IDREF")
    private FrontEnd frontEnd;

    @Column(name = "LoginDateTime")
    private Date loginDate;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private Long idPrimary;

    @Column(name = "IsActualDevice")
    private boolean isActualDevice;

    @Column(name = "isConfirmed")
    private Boolean isConfirmed;

    @Column(name = "CreateDate")
    private Date createDate;

    @Column(name = "Name")
    private String deviceName;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "MessageSender_IDREF")
    private MessageSender messageSenderIDREF;
}

