package kz.eubank.registration.infrastructure.model.entity;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@Entity
@Table(name = "RecoveryProductAccountType")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RecoveryProductAccountType {
    @Id
    @Column(name = "RecoveryProductAccountType_ID")
    private String id;
    @Column(name = "RecoveryProductAccountType_Title")
    private String title;
}
