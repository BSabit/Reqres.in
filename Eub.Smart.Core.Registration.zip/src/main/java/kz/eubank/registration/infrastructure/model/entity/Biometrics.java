package kz.eubank.registration.infrastructure.model.entity;

import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "Biometrics")
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Biometrics {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Biometrics_ID")
    private Long id;

    @Column(name = "DateCreated")
    private Date dateCreated;

    @OneToOne
    @JoinColumn(name = "BiometricsType_IDREF")
    private BiometricsType type;

    @OneToOne
    @JoinColumn(name = "BiometricsStatus_IDREF")
    private BiometricsStatus status;

    @Column(name = "FolderId")
    private String folderId;

    @ManyToOne
    @JoinColumn(name = "DMZVerification_IDREF")
    private DMZVerification dmzVerification;

    @Column(name = "Data")
    private String data;

    @Column(name = "Biometry_AnalyseID")
    private String biometryAnalyseId;

    @Column(name = "Quality_AnalyseID")
    private String qualityAnalyseId;

    @Column(name = "Similarity_Percent")
    private Double similarityPercent;
}
