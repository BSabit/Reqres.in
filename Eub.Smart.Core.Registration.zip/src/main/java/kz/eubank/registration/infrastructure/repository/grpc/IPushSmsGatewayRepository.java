package kz.eubank.registration.infrastructure.repository.grpc;

import kz.eubank.registration.infrastructure.model.dto.GrpcSendSmsResponse;

public interface IPushSmsGatewayRepository {

    GrpcSendSmsResponse sendSms(String phoneNumber, String message, String correlationId);
}
