package kz.eubank.registration.infrastructure.repository.mssql;

import kz.eubank.registration.infrastructure.model.entity.WhiteListAuthorization;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface WhiteListAuthorizationHiberRepository extends JpaRepository<WhiteListAuthorization, String> {

    Optional<WhiteListAuthorization> findByMobilePhone(String mobilePhone);
}
