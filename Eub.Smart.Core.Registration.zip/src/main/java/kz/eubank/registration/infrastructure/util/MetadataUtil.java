package kz.eubank.registration.infrastructure.util;

import io.grpc.ClientInterceptor;
import io.grpc.Metadata;
import io.grpc.stub.MetadataUtils;
import org.slf4j.MDC;

import java.util.Objects;

import static kz.eubank.registration.domain.constant.HeaderName.X_CORRELATION_ID;

public class MetadataUtil {

    public static ClientInterceptor newCorrelationIdInterceptor(String correlationId) {
        if (Objects.isNull(correlationId)) {
            correlationId = "";
        }
        Metadata headers = new Metadata();
        Metadata.Key<String> key = Metadata.Key.of(X_CORRELATION_ID, Metadata.ASCII_STRING_MARSHALLER);
        headers.put(key, correlationId);
        MDC.put(X_CORRELATION_ID, correlationId);
        return MetadataUtils.newAttachHeadersInterceptor(headers);
    }
}
