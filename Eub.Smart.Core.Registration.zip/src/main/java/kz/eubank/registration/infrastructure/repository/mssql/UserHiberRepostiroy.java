package kz.eubank.registration.infrastructure.repository.mssql;

import kz.eubank.registration.infrastructure.model.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.Optional;

@Repository
public interface UserHiberRepostiroy extends JpaRepository<User, Integer> {
    @Modifying
    @Transactional
    @Query(nativeQuery = true,
            value = """
                    UPDATE "USER" SET Region_IDREF = :regionId WHERE User_ID = :userId
            """)
    void updateUserRegion(int userId, int regionId);

    @Modifying
    @Transactional
    @Query(nativeQuery = true,
            value = """
                    UPDATE "User" SET UserStatus_IDREF = :status WHERE User_ID = :userId
            """)
    void updateUserStatus(String status, long userId);

    @Query(nativeQuery = true,
            value = """
                    SELECT top 1 [User].* FROM DMZVerification
                    JOIN Person ON Person.IIN = DMZVerification.Iin
                    JOIN [User] ON [User].Person_IDREF = Person.Person_ID
                    WHERE DMZVerification.Iin = :iin
            """)
    Optional<User> findUserWithIin(String iin);
}
