package kz.eubank.registration.infrastructure.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
public class SmsTranslator {

    private static ResourceBundleMessageSource messageSource;

    public SmsTranslator(@Qualifier("sms_text") ResourceBundleMessageSource messageSource) {
        SmsTranslator.messageSource = messageSource;
    }

    public static String toSendSmsMessageWithCode(String generatedCode, String route, String frontEnd, String hashCode) {
        var code = "send.sms." + route + "." + frontEnd;
        var message = getMessage(code);
        var messageWithCode = String.format(message, generatedCode);
        if (Objects.nonNull(hashCode)) {
            messageWithCode = messageWithCode + " " + hashCode;
        }
        return messageWithCode;
    }

    public static String getMessage(String code) {
        var locale = LocaleContextHolder.getLocale();
        return messageSource.getMessage(code, null, locale);
    }

}
