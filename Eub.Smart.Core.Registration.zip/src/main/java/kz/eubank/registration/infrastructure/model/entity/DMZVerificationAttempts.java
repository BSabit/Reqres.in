package kz.eubank.registration.infrastructure.model.entity;

import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "DMZVerificationAttempts")
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DMZVerificationAttempts {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DMZVerificationAttempts_ID")
    private Long id;

    @Column(name = "MobilePhone")
    private String mobilePhone;

    @Column(name = "DMZVerificationAttemptsType_IDREF")
    private String type;

    @ManyToOne
    @JoinColumn(name = "DMZVerification_IDREF")
    private DMZVerification dmzVerification;

    @Column(name = "DateCreated")
    private Date createdDate;

    @Column(name = "PasscodeSet")
    private boolean passcodeSet;
}
