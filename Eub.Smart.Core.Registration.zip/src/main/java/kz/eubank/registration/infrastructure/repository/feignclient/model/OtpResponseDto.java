package kz.eubank.registration.infrastructure.repository.feignclient.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

public record OtpResponseDto(@JsonProperty("MessageId") String messageId,
                             @JsonProperty("CorrelationId") String correlationId,
                             @JsonProperty("ResponseDate") Date responseDate,
                             @JsonProperty("Status") StatusDto status,
                             @JsonProperty("SessionId") String sessionId) {
}
