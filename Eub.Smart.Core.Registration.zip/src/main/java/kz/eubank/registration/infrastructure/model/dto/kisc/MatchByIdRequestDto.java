package kz.eubank.registration.infrastructure.model.dto.kisc;

import lombok.*;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class MatchByIdRequestDto extends BaseRequestKisc {
    private String idempotencyKey;
    public MatchByIdRequestDto(String idempotencyKey, String system) {
        super(system);
        this.idempotencyKey = idempotencyKey;
    }
}
