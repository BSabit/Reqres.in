package kz.eubank.registration.infrastructure.model.entity;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@Entity
@Table(name = "BiometricsStatus")
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BiometricsStatus {

    @Id
    @Column(name = "BiometricsStatus_ID")
    private String id;

    @Column(name = "BiometricsStatus_Title")
    private String title;

    @Column(name = "Term_OUTREF")
    private String term;
}
