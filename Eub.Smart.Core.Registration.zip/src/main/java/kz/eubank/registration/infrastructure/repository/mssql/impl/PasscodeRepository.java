package kz.eubank.registration.infrastructure.repository.mssql.impl;

import kz.eubank.registration.domain.model.pojo.NewPasscode;
import kz.eubank.registration.domain.repository.IPasscodeRepository;
import kz.eubank.registration.infrastructure.model.mapper.BaseMapper;
import kz.eubank.registration.infrastructure.repository.mssql.PasscodeHiberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Primary
@Component
@RequiredArgsConstructor
public class PasscodeRepository implements IPasscodeRepository {
   private final PasscodeHiberRepository passcodeHiberRepository;

    @Override
    public NewPasscode saveAndGet(NewPasscode newPasscode) {
        var entity = BaseMapper.INSTANCE.toEntity(newPasscode);
        return BaseMapper.INSTANCE.toDomain(passcodeHiberRepository.saveAndFlush(entity));
    }
    public void save(NewPasscode newPasscode) {
        var entity = BaseMapper.INSTANCE.toEntity(newPasscode);
        passcodeHiberRepository.save(entity);
    }
    @Override
    public void changeStatus(String status, String deviceId) {
        passcodeHiberRepository.changeStatus(status, deviceId);
    }
    @Override
    public void changeStatusByUserId(String status, String userID) {
        passcodeHiberRepository.changeStatusByUserId(status, userID);
    }

    @Override
    public String findHash(String sessionId) {
        return passcodeHiberRepository.findHash(sessionId);
    }
}
