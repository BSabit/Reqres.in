package kz.eubank.registration.infrastructure.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Component;

import static java.util.Objects.isNull;

@Component
public class ErrorTranslator {

    private static ResourceBundleMessageSource messageSource;

    public ErrorTranslator(@Qualifier("error_text") ResourceBundleMessageSource messageSource) {
        ErrorTranslator.messageSource = messageSource;
    }

    public static String toErrorMessageWithArg(String error, Integer number) {
        var message = toErrorMessage(error);
        if (isNull(number)) {
            return message;
        }
        return String.format(message, number);
    }

    public static String toErrorMessageWithArgAndNotify(String error, Integer number, String notify) {
        var message = toErrorMessage(error);
        if (isNull(number)) {
            return message;
        }
        return message + " " + String.format(notify, number);
    }

    public static String toErrorMessage(String error) {
        var code = "error.message." + error;
        return getMessageOrElseNull(code);
    }

    public static String toErrorDetails(String error) {
        var code = "error.details." + error;
        return getMessageOrElseNull(code);
    }

    public static String toErrorButtonText(String error) {
        var code = "error.button-text." + error;
        return getMessageOrElseNull(code);
    }

    private static String getMessageOrElseNull(String code) {
        var locale = LocaleContextHolder.getLocale();
        var message = messageSource.getMessage(code, null, locale);
        return message.equals(code) ? null : message;
    }

}
