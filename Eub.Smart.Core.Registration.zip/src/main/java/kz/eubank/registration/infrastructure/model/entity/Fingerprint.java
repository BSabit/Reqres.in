package kz.eubank.registration.infrastructure.model.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;


@Entity
@Table
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Fingerprint {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Fingerprint_ID")
    private long id;

    @Column(name = "User_IDREF")
    private int userId;

    @Column(name = "FingerprintStatus_IDREF")
    private String status;

    @Column(name = "PublicKey")
    private byte[] publicKey;

    @Column(name = "DeviceID")
    private String deviceId;

    @Column(name = "DateCreated")
    private Date dateCreated;

    @Column(name = "InvalidUses")
    private int invalidUses;

    @Column(name = "LastInvalidUse")
    private Date lastInvalidUse;
}
