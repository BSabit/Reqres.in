package kz.eubank.registration.infrastructure.repository.mssql.impl;

import kz.eubank.registration.domain.repository.IMobileOperatorRepository;
import kz.eubank.registration.infrastructure.model.entity.MobileOperator;
import kz.eubank.registration.infrastructure.repository.mssql.MobileOperatorHiberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.Set;
import java.util.stream.Collectors;

@Primary
@Component
@RequiredArgsConstructor
public class MobileOperatorRepository implements IMobileOperatorRepository {

    private final MobileOperatorHiberRepository mobileOperatorHiberRepository;

    @Override
    public Set<String> getAllMobileOperators() {
        var mobileOperators = mobileOperatorHiberRepository.findAll();
        return mobileOperators.stream().map(MobileOperator::getId).collect(Collectors.toSet());
    }
}
