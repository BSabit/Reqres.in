package kz.eubank.registration.infrastructure.repository.feignclient.model;

public record UploadDocumentResponseDto(String fileUid) {
}
