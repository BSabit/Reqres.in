package kz.eubank.registration.infrastructure.repository.mssql.procedure;

import org.springframework.stereotype.Component;

import java.sql.*;


@Component
public class AccountCreateProcedure {
    private ConnectionDB connectionDB;

    public AccountCreateProcedure(ConnectionDB connectionDB) {
        this.connectionDB = connectionDB;
    }

    private static final String runStoredProcedure = "{ call \"util_Registration_User_Create_SMBK_3_0\"(?,?,?,?,?,?,?,?,?,?," +
            "?,?,?,?,?,?,?,?,?,?," +
            "?,?,?,?,?,?,?,?,?,?) }";

    public ResponseCreateUserProcedure execute(RequestCreateUserProcedure request) throws SQLException {
        ResponseCreateUserProcedure response;
        try (Connection conn = DriverManager.getConnection(connectionDB.getUrl(), connectionDB.getUser(), connectionDB.getPassword());
             CallableStatement callableStatement = conn.prepareCall(runStoredProcedure)) {

            this.setMappingRequest(callableStatement, request);
            callableStatement.executeUpdate();
            response = this.getMappingResponse(callableStatement);
        }
        return response;
    }

    private void setMappingRequest(CallableStatement callableStatement, RequestCreateUserProcedure request) throws SQLException {
        callableStatement.setString(1, request.getFirstName());
        callableStatement.setString(2, request.getLastName());
        callableStatement.setString(3, request.getFatherName());
        callableStatement.setString(4, request.getGender().toString());
        callableStatement.setDate(5, new java.sql.Date(request.getBirthDate().getTime()));
        callableStatement.setBoolean(6, request.isIsResident());
        callableStatement.setString(7, request.getIin());
        callableStatement.setString(8, request.getMobilePhone());
        callableStatement.setString(9, request.getBirthPlace());
        callableStatement.setString(10, request.getAddressCity());
        callableStatement.setString(11, request.getAddressPlace());
        callableStatement.setString(12, request.getAddressHouseNo());
        callableStatement.setString(13, request.getAddressAptNo());
        callableStatement.setString(14, request.getAddressTitle());
        callableStatement.setBoolean(15, request.isIsCitizenship());
        callableStatement.setString(16, request.getPaperTitle());
        callableStatement.setString(17, request.getPaperType());
        callableStatement.setDate(18, new java.sql.Date(request.getPaperIssueDate().getTime()));
        callableStatement.setDate(19, new java.sql.Date(request.getPaperValidityDate().getTime()));
        callableStatement.setString(20, request.getPaperIssuer());
        callableStatement.setString(21, request.getPaperNumber());
        callableStatement.setString(22, request.getPaperStatus());
        callableStatement.setString(23, request.getPaperBSystem());
        callableStatement.setString(24, request.getRegisteredBy());
        callableStatement.setString(25, request.getRegChannelId());

        callableStatement.registerOutParameter(26, Types.VARCHAR);
        callableStatement.registerOutParameter(27, Types.VARCHAR);
        callableStatement.registerOutParameter(28, Types.VARCHAR);
        callableStatement.registerOutParameter(29, Types.INTEGER);
        callableStatement.registerOutParameter(30, Types.VARCHAR);
    }

    private ResponseCreateUserProcedure getMappingResponse(CallableStatement callableStatement) throws SQLException {
        ResponseCreateUserProcedure response = new ResponseCreateUserProcedure();
        response.setLogin(callableStatement.getString(26));
        response.setPassword(callableStatement.getString(27));
        response.setStatus(callableStatement.getString(28));
        response.setUserId(callableStatement.getInt(29));
        response.setError(callableStatement.getString(30));

        return response;
    }
}
