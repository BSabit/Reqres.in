package kz.eubank.registration.infrastructure.repository.grpc.impl;


import SmartRegistration.V1.EubAggregatorCoreSmartRegistration;
import SmartRegistration.V1.SmartRegistrationGrpc;
import io.grpc.StatusRuntimeException;
import kz.eubank.registration.infrastructure.repository.grpc.IVerifyClientRepository;
import kz.eubank.registration.infrastructure.util.MetadataUtil;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.E_EX_701;

@Component
@RequiredArgsConstructor
public class VerifyClientRepository implements IVerifyClientRepository {

    private final Logger log = LogManager.getLogger(getClass());

    @GrpcClient("registrationVerify")
    private SmartRegistrationGrpc.SmartRegistrationBlockingStub stub;

    public EubAggregatorCoreSmartRegistration.VerifyClientReply sendRequestVerifyClient(EubAggregatorCoreSmartRegistration.RecoveryProductAccountType recoveryProductAccountType,
                                                                                        String accountNumber,
                                                                                        String iin,
                                                                                        String mobilePhone,
                                                                                        String correlationId) {
        try {
            log.info("start sendRequestVerifyClient via grpc: recoveryProductAccountType: {}, " +
                             "accountNumber: {}, iin: {}, mobilePhone: {}, sessionId: {}",
                             recoveryProductAccountType, accountNumber, iin, mobilePhone, correlationId);
            return stub
                    .withInterceptors(MetadataUtil.newCorrelationIdInterceptor(correlationId))
                    .verifyClient(EubAggregatorCoreSmartRegistration.VerifyClientRequest
                            .newBuilder()
                            .setAccountNumber(accountNumber)
                            .setIin(iin)
                            .setPhoneNumber(mobilePhone)
                            .setRecoveryProductAccountType(recoveryProductAccountType)
                            .build());
        } catch (StatusRuntimeException e) {
            log.error("Error sendSms StatusRuntimeException: {}", e.getMessage());
            throw new SelfException(E_EX_701, " VerifyClient method not available");
        }
    }
}
