package kz.eubank.registration.infrastructure.repository.mssql.impl;

import kz.eubank.registration.domain.model.pojo.ClientDigitalDocument;
import kz.eubank.registration.domain.repository.IClientDigitalDocumentRepository;
import kz.eubank.registration.infrastructure.model.mapper.BaseMapper;
import kz.eubank.registration.infrastructure.repository.mssql.ClientDigitalDocumentHiberRepository;
import kz.eubank.registration.infrastructure.repository.mssql.MetaDocumentHiberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Optional;

@Primary
@Component
@RequiredArgsConstructor
public class ClientDigitalDocumentRepository implements IClientDigitalDocumentRepository {

    private final ClientDigitalDocumentHiberRepository clientDigitalDocumentHiberRepository;
    private final MetaDocumentHiberRepository metaDocumentHiberRepository;


    @Override
    public ClientDigitalDocument save(ClientDigitalDocument clientDigitalDocument) {
        var entity = BaseMapper.INSTANCE.toEntity(clientDigitalDocument);
        var saved = clientDigitalDocumentHiberRepository.save(entity);
        return BaseMapper.INSTANCE.toDomain(saved);
    }

    @Override
    public Optional<ClientDigitalDocument> findActualByIin(String iin) {
        return clientDigitalDocumentHiberRepository.findActualByIinAndType(iin).map(BaseMapper.INSTANCE::toDomain);
    }

    @Override
    public void verifyByFileUid(String fileUid) {
        var metaDoc = metaDocumentHiberRepository.findByFileUid(fileUid);
        metaDoc.ifPresent(doc -> clientDigitalDocumentHiberRepository.setVerifiedById(doc.getTargetId()));
    }

    @Override
    public void updateDateExpiredByIin(Date expiredDate, String iin) {
        clientDigitalDocumentHiberRepository.updateDateExpiredByIin(expiredDate, iin);
    }
}
