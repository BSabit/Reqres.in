package kz.eubank.registration.infrastructure.model.entity;

import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "ClientDigitalDocument")
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ClientDigitalDocument {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ClientDigitalDocument_ID")
    private Long id;

    @Column(name = "DateCreated")
    private Date dateCreated;

    @Column(name = "DateExpired")
    private Date dateExpired;

    @Column(name = "Iin")
    private String iin;

    @Column(name = "isVerified")
    private boolean isVerified;

    @OneToOne
    @JoinColumn(name = "ClientDigitalDocumentType_IDREF")
    private ClientDigitalDocumentType clientDigitalDocumentType;
}
