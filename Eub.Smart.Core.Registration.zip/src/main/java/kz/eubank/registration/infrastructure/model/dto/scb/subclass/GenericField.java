package kz.eubank.registration.infrastructure.model.dto.scb.subclass;

import com.fasterxml.jackson.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class GenericField {
    @JsonProperty("code")
    private String code;
    @JsonProperty("nameRu")
    private String nameRu;
    @JsonProperty("nameKz")
    private String nameKz;
    @JsonProperty("changeDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private Date changeDate;
}
