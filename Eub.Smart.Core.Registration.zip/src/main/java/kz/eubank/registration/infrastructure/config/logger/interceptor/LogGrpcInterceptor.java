package kz.eubank.registration.infrastructure.config.logger.interceptor;

import io.grpc.*;
import net.devh.boot.grpc.client.interceptor.GrpcGlobalClientInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.rmi.MarshalledObject;

import static io.grpc.Metadata.ASCII_STRING_MARSHALLER;
import static io.grpc.Metadata.BINARY_BYTE_MARSHALLER;
import static io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING;
import static kz.eubank.registration.domain.constant.HeaderName.X_CORRELATION_ID;
import static org.yaml.snakeyaml.tokens.Token.ID.Key;

@GrpcGlobalClientInterceptor
public class LogGrpcInterceptor implements ClientInterceptor {

    private final String ACTIVATE_JOBS = "gateway_protocol.Gateway/ActivateJobs";
    private final Logger log = LoggerFactory.getLogger(getClass());

    @Override
    public <ReqT, RespT> ClientCall<ReqT, RespT> interceptCall(
            final MethodDescriptor<ReqT, RespT> method,
            final CallOptions callOptions,
            final Channel next) {

        return new ForwardingClientCall.SimpleForwardingClientCall<>(
                next.newCall(method, callOptions)) {

            @Override
            public void sendMessage(ReqT message) {
                String fullMethodName = method.getFullMethodName();
                MethodDescriptor.MethodType type = method.getType();
                if (!ACTIVATE_JOBS.equals(fullMethodName) && !SERVER_STREAMING.equals(type)) {
                    log.info("GrpcClientLogInterceptor request: X-Correlation-Id: {}, method: {}, message: {}", MDC.get(X_CORRELATION_ID), method, message);
                }
                super.sendMessage(message);
            }

            @Override
            public void start(Listener<RespT> responseListener, Metadata headers) {

                super.start(
                        new ForwardingClientCallListener.SimpleForwardingClientCallListener<>(responseListener) {
                            @Override
                            public void onMessage(RespT message) {
                                log.info("GrpcClientLogInterceptor response: X-Correlation-Id: {}, message: {}", message,
                                        headers.getAll(Metadata.Key.of("x-corelation-id", ASCII_STRING_MARSHALLER)));
                                super.onMessage(message);
                            }
                        }, headers);
            }
        };
    }
}
