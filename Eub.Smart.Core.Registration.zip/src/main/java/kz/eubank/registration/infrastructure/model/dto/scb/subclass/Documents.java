package kz.eubank.registration.infrastructure.model.dto.scb.subclass;

import com.fasterxml.jackson.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Documents {
    @JsonProperty("listOfDocuments")
    private List<ListOfDocument> listOfDocuments;
}
