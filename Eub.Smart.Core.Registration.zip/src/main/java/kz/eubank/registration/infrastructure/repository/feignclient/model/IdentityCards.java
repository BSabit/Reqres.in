package kz.eubank.registration.infrastructure.repository.feignclient.model;

public interface IdentityCards {
    String IDENTITY_CARD = "IdentityCard";
    String DRIVER_LICENSE = "DriverLicense";
    String BIRTH_CERTIFICATE = "BirthCertificate";
    String MARRIAGE_CERTIFICATE = "MarriageCertificate";
    String CHANGE_CERTIFICATE = "ChangeFioCertificate";
    String DIVORCE_CERTIFICATE = "DivorceCertificate";
    String TECH_PASSPORT = "TechPassport";
    String PCR_CERTIFICATE = "PcrCertificate";
    String STUDENT_CARD = "StudentCard";
    String DIPLOMA = "Diploma";
    String PENSION = "Pension";
    String ORALMAN = "Oralman";
    String SRTS = "SRTS";
    String SOCIAL_ID = "SocialId";
    String VACCINATION = "Vaccination";
    String DISABILITY_CERTIFICATE = "DisabilityCertificate";
    String LARGE_FAMILY_CERTIFICATE = "LargeFamilyCertificate";
    String ASP_CERTIFICATE = "AspCertificate";
}
