package kz.eubank.registration.infrastructure.model.entity;

import lombok.*;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "ClientDigitalDocumentType")
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ClientDigitalDocumentType {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ClientDigitalDocumentType_ID")
    private String id;

    @Column(name = "ClientDigitalDocumentType_Title")
    private String title;
}
