package kz.eubank.registration.infrastructure.repository.mssql;

import kz.eubank.registration.infrastructure.model.entity.RecoveryProduct;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RecoveryProductHiberRepository extends JpaRepository<RecoveryProduct, Long> {

}
