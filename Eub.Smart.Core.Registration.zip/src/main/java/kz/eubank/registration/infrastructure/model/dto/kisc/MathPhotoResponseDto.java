package kz.eubank.registration.infrastructure.model.dto.kisc;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.*;

import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class MathPhotoResponseDto {

    @JsonProperty("Code")
    private String code;
    @JsonProperty("Msg")
    private JsonNode msg;
    @JsonProperty("Id")
    private long id;
    @JsonProperty("Date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private Date  date;
    @JsonProperty("ClientIin")
    private String clientIin;
    @JsonProperty("Similarity")
    private String similarity;
    @JsonProperty("VendorName")
    private String vendorName;
}
