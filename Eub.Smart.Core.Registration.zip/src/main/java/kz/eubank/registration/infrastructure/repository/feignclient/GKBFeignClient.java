package kz.eubank.registration.infrastructure.repository.feignclient;

import feign.FeignException;
import kz.eubank.registration.infrastructure.model.dto.scb.SCBPersonalData;
import kz.eubank.registration.infrastructure.repository.feignclient.model.DocumentResponseDto;
import kz.eubank.registration.infrastructure.repository.feignclient.model.OtpResponseDto;
import kz.eubank.registration.infrastructure.repository.feignclient.model.ProfileResponseDto;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.util.Optional;

import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.*;

@Service
@RequiredArgsConstructor
@Log4j2
public class GKBFeignClient {

    private final IGKBFeignClient gkbClient;

    public ProfileResponseDto getProfileOrThrowException(String iin, String correlationId) {
        try {
            return gkbClient.getProfile(iin, correlationId)
                    .orElseThrow(() -> new SelfException(E_EX_701));
        } catch (SelfException e) {
            throw new SelfException(E_EX_701);
        }
    }

    public OtpResponseDto accessDocumentOrThrowException(String iin, String documentType, String correlationId) {
        try {
            return gkbClient.accessDocument(iin, documentType, correlationId)
                    .orElseThrow(() -> new SelfException(E_EX_701));
        } catch (SelfException e) {
            throw new SelfException(E_BS_951);
        }
    }

    public DocumentResponseDto getIdentityCardOrThrowException(String iin, String code, String correlationId) {
        try {
            return gkbClient.getIdentityCard(iin, code, correlationId)
                    .orElseThrow(() -> new SelfException(E_EX_701));
        } catch (SelfException e) {
            throw new SelfException(E_BS_952);
        }
    }

    public SCBPersonalData getClientDataByIinOrThrowException(String iin, String correlationId) {
        try {
            return gkbClient.getClientDataByIin(iin, correlationId)
                    .orElseThrow(() -> new SelfException(E_EX_701));
        } catch (SelfException e) {
            log.error("GKB service response code: {}, messages: {}", e.getCode(), e.getMessage());
            throw e;
        }
    }
}
