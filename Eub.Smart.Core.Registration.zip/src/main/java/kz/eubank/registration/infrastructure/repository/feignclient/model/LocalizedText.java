package kz.eubank.registration.infrastructure.repository.feignclient.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public record LocalizedText(@JsonProperty("Code") String code,
                            @JsonProperty("NameRu") String nameRu,
                            @JsonProperty("NameKk") String nameKk,
                            @JsonProperty("NameEn") String nameEn) {
}
