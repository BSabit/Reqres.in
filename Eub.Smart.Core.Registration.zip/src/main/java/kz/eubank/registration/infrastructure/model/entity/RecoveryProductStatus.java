package kz.eubank.registration.infrastructure.model.entity;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@Entity
@Table(name = "RecoveryProductStatus")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RecoveryProductStatus {
    @Id
    @Column(name = "RecoveryProductStatus_ID")
    private String id;
    @Column(name = "RecoveryProductStatus_Title")
    private String title;
    @Column(name = "Term_OUTREF")
    private String termId;
}
