package kz.eubank.registration.infrastructure.model.dto.kisc;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public abstract class BaseRequestKisc {
    private String system;
}
