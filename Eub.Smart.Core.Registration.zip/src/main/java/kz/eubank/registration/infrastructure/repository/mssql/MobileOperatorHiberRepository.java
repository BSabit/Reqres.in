package kz.eubank.registration.infrastructure.repository.mssql;

import kz.eubank.registration.infrastructure.model.entity.MobileOperator;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MobileOperatorHiberRepository extends JpaRepository<MobileOperator, String> {
}
