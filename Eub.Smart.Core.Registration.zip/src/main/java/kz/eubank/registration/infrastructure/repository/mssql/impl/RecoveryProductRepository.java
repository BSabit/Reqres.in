package kz.eubank.registration.infrastructure.repository.mssql.impl;

import kz.eubank.registration.domain.model.pojo.RecoveryProduct;
import kz.eubank.registration.domain.repository.IRecoveryProductRepository;
import kz.eubank.registration.infrastructure.model.mapper.BaseMapper;
import kz.eubank.registration.infrastructure.repository.mssql.RecoveryProductHiberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Primary
@Component
@RequiredArgsConstructor
public class RecoveryProductRepository implements IRecoveryProductRepository {
    private final RecoveryProductHiberRepository repository;
    @Override
    public void save(RecoveryProduct recoveryProduct) {
        var entity = BaseMapper.INSTANCE.toEntity(recoveryProduct);
        repository.save(entity);
    }
}
