package kz.eubank.registration.infrastructure.model.entity;

import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "Passcode")
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Passcode {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Passcode_ID")
    private Long id;

    @Column(name = "User_IDREF")
    private Long userId;

    @OneToOne
    @JoinColumn(name = "PasscodeStatus_IDREF")
    private PasscodeStatus status;

    @Column(name = "Hash")
    private String hash;

    @Column(name = "Salt")
    private String salt;

    @Column(name = "DeviceID")
    private String deviceId;

    @Column(name = "DateCreated")
    private Date dateCreated;

    @Column(name = "InvalidUses")
    private int invalidUses;
}
