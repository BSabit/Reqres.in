package kz.eubank.registration.infrastructure.repository.feignclient.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public record DocumentResponseDto(@JsonProperty("responseCode") String responseCode,
                                  @JsonProperty("responseMessage") String responseMessage,
                                  @JsonProperty("content") String content,
                                  @JsonProperty("documentType") LocalizedText documentType) {
}
