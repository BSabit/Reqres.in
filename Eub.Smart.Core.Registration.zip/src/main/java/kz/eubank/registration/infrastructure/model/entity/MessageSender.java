package kz.eubank.registration.infrastructure.model.entity;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@Entity
@Table(name = "MessageSender")
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MessageSender {

    @Id
    @Column(name = "MessageSender_ID")
    private String id;

    @Column(name = "MessageSender_Title")
    private String title;
}
