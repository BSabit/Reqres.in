package kz.eubank.registration.infrastructure.repository.mssql.impl;

import kz.eubank.registration.domain.model.pojo.Device;
import kz.eubank.registration.domain.repository.IDeviceRepository;
import kz.eubank.registration.infrastructure.model.mapper.BaseMapper;
import kz.eubank.registration.infrastructure.repository.mssql.DeviceHiberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Primary
@Component
@RequiredArgsConstructor
public class DeviceRepository implements IDeviceRepository {

    private final DeviceHiberRepository deviceHiberRepository;

    @Override
    public int checkDeviceIsExistAmount(String deviceId, Long userId) {
        return deviceHiberRepository.checkDevice(deviceId, userId);
    }

    @Override
    public void save(Device device) {
        var entity = BaseMapper.INSTANCE.toEntity(device);
        deviceHiberRepository.save(entity);
    }

    @Override
    public void makeDeviceValid(Long userId, String deviceId) {
        deviceHiberRepository.makeDeviceValid(userId, deviceId);
    }

    @Override
    public void logoutOtherDevices(Long userId, String deviceId) {
        deviceHiberRepository.logoutOtherDevices(userId, deviceId);
    }
}
