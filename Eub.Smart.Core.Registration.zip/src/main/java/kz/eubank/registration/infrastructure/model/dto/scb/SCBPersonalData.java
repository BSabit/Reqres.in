package kz.eubank.registration.infrastructure.model.dto.scb;

import com.fasterxml.jackson.annotation.*;
import kz.eubank.registration.infrastructure.model.dto.scb.subclass.BirthPlace;
import kz.eubank.registration.infrastructure.model.dto.scb.subclass.Documents;
import kz.eubank.registration.infrastructure.model.dto.scb.subclass.GenericField;
import kz.eubank.registration.infrastructure.model.dto.scb.subclass.RegAddress;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class SCBPersonalData {
    @JsonProperty("iin")
    private String iin;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("surname")
    private String surname;
    @JsonProperty("patronymic")
    private String patronymic;
    @JsonProperty("engFirstName")
    private String engFirstName;
    @JsonProperty("engSurname")
    private String engSurname;
    @JsonProperty("birthDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private Date birthDate;
    @JsonProperty("gender")
    private GenericField gender;
    @JsonProperty("nationality")
    private GenericField nationality;
    @JsonProperty("citizenship")
    private GenericField citizenship;
    @JsonProperty("lifeStatus")
    private GenericField lifeStatus;
    @JsonProperty("birthPlace")
    private BirthPlace birthPlace;
    @JsonProperty("regAddress")
    private RegAddress regAddress;
    @JsonProperty("documents")
    private Documents documents;
    @JsonProperty("created")
    private Date created;
}
