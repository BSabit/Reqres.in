package kz.eubank.registration.infrastructure.repository.mssql;

import kz.eubank.registration.infrastructure.model.entity.Password;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface PasswordHiberRepository extends JpaRepository<Password, Long> {

    @Modifying
    @Query(nativeQuery = true,
           value = """
                   UPDATE Password
                   SET IsValid = 0
                   WHERE User_IDREF = :userId
                   AND IsValid = 1
            """)
    void makePasswordInvalid(Long userId);
}
