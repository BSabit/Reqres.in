package kz.eubank.registration.infrastructure.config;

import feign.codec.ErrorDecoder;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.extern.log4j.Log4j2;
import org.springframework.context.annotation.Bean;

import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.*;

@Log4j2
public class FeignSupportConfiguration {

    private final ErrorDecoder errorDecoder = new ErrorDecoder.Default();

    @Bean
    public ErrorDecoder errorDecoder() {
        return (methodKey, response) -> switch (response.status()) {
            case 400 -> new SelfException(E_EX_700, response.reason());
            case 404, 504, 500 -> new SelfException(E_EX_701, response.reason());
            case 408 -> new SelfException(E_BS_931, response.reason());
            default -> errorDecoder.decode(methodKey, response);
        };
    }
}
