package kz.eubank.registration.infrastructure.repository.mssql;

import kz.eubank.registration.infrastructure.model.entity.DMZVerification;
import kz.eubank.registration.infrastructure.repository.mssql.procedure.RequestCreateUserProcedure;
import kz.eubank.registration.infrastructure.repository.mssql.procedure.ResponseCreateUserProcedure;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.Optional;

@Repository
public interface DMZVerificationHiberRepository extends JpaRepository<DMZVerification, Long> {

    @Query(nativeQuery = true,
            value = """
                    select count(*)
                    from DMZVerification v
                    where v.MobilePhone = :mobilePhone
                    and format(v.DateCreated, 'yyyy-MM-dd') = format(GETDATE(), 'yyyy-MM-dd')
                    """)
    int getVerificationLimitCountByMobilePhone(String mobilePhone);

    @Query(nativeQuery = true,
            value = """
                    select *
                      from DMZVerification v
                     where v.MobilePhone = :mobilePhone
                       and v.DeviceId = :deviceId
                       and v.RouteStatus_IDREF = 'VSCS'
                       and getdate() between v.DateCreated and v.DateExpired
                    """)
    Optional<DMZVerification> getNotFinishedSessionByMobilePhoneAndDeviceId(String mobilePhone, String deviceId);

    Optional<DMZVerification> findBySessionId(String sessionId);

    @Query(value = "SELECT v.deviceId FROM DMZVerification v WHERE v.sessionId = :sessionId")
    String findDeviceId(String sessionId);

    @Query(nativeQuery = true,
            value = """
                    SELECT [User].USER_ID FROM dbo.[DMZVerification]
                    JOIN dbo.[Person] ON Person.IIN =  dbo.[DMZVerification].Iin
                    JOIN dbo.[User] ON [User].Person_IDREF  = [Person].Person_ID
                    WHERE DMZVerification.SessionId = :sessionId
            """)
    Optional<Long> findUserIdByIin(String sessionId);
    @Transactional
    @Modifying
    @Query(nativeQuery = true,
            value = """
                    UPDATE DMZVerification SET DMZVerification.Iin = :iin WHERE DMZVerification.SessionId = :sessionId
                    """)
    void updateIin(String sessionId, String iin);
    @Transactional
    @Modifying
    @Query(nativeQuery = true,
            value = """
                    UPDATE DMZVerification SET DMZVerification.Passcode_IDREF = :passcodeId WHERE DMZVerification.SessionId = :sessionId
                    """)
    void updatePasscode(String sessionId, long passcodeId);
    @Transactional
    @Modifying
    @Query(nativeQuery = true,
            value = """
                    UPDATE DMZVerification SET DMZVerification.OldPasscode_IDREF = :oldPasscodeId WHERE DMZVerification.SessionId = :sessionId
                    """)
    void updateOldPasscode(String sessionId, long oldPasscodeId);
    @Transactional
    @Modifying
    @Query(nativeQuery = true,
            value = """
                    UPDATE DMZVerification SET DMZVerification.RouteStatus_IDREF = :status WHERE DMZVerification.DMZVerification_ID = :dmzverificationId
                    """)
    void updateStatus(String status, long dmzverificationId);
    @Transactional
    @Modifying
    @Query(nativeQuery = true,
            value = """
                    UPDATE DMZVerification SET DMZVerification.RouteStatus_IDREF = :status WHERE DMZVerification.SessionId = :sessionId
                    """)
    void updateStatusWithSessionId(String status, String sessionId);

    @Procedure(value = "util_Bio_Registration_Account_Create")
    ResponseCreateUserProcedure createUser(RequestCreateUserProcedure userProcedure);
}
