package kz.eubank.registration.infrastructure.repository.feignclient.s3;

import kz.eubank.registration.infrastructure.config.FeignSupportConfiguration;
import kz.eubank.registration.infrastructure.repository.feignclient.model.UploadDocumentResponseDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Optional;

import static org.springframework.http.MediaType.*;

@FeignClient(value = "minioS3",
        url = "${s3.url}/",
        configuration = FeignSupportConfiguration.class)
public interface IS3FeignClient {

    @PostMapping(value = "s3/api/upload/s3",
            consumes = MULTIPART_FORM_DATA_VALUE,
            produces = APPLICATION_JSON_VALUE)
    Optional<UploadDocumentResponseDto> uploadFile(@RequestHeader(name = "Media-Type") String mediaType,
                                                   @RequestPart(name = "file") MultipartFile file,
                                                   @PathVariable(name = "target-table") String targetTable,
                                                   @PathVariable(name = "target-id") Long targetId,
                                                   @PathVariable(name = "document-type") String documentType);

    @GetMapping(value = "s3/api/download/s3",
            produces = APPLICATION_OCTET_STREAM_VALUE)
    Optional<byte[]> downloadFile(@RequestParam("fileUid") String fileUid);
}
