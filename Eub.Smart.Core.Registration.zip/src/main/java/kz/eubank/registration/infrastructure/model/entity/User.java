package kz.eubank.registration.infrastructure.model.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "`User`")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "User_ID")
    private Long id;

    @Column(name = "Username")
    private String username;

    @Column(name = "Person_IDREF")
    private Integer person;

    @Column(name = "Locale_IDREF")
    private String locale;

    @Column(name = "UserStatus_IDREF")
    private String status;

    @Column(name = "UILayout_IDREF")
    private Long layout;

    @Column(name = "UITheme_IDREF")
    private Long theme;

    @Column(name = "LoginHourStart")
    private Integer loginHourStart;

    @Column(name = "LoginHourEnd")
    private Integer loginHourEnd;

    @Column(name = "FailedLogins")
    private Integer failedLogins;

    @Column(name = "CodeWord")
    private String codeWord;

    @Column(name = "PasswordAge")
    private Integer passwordAge;

    @Column(name = "SessionTimeout")
    private Integer sessionTimeout;

    @Column(name = "DateRegistered")
    private Date dateRegistered;

    @Column(name = "Branch_IDREF")
    private Integer branch;

    @Column(name = "RegisteredBy")
    private String registeredBy;

    @Column(name = "RegChannel_IDREF")
    private String regChannelId;

    @Column(name = "RegFinishDate")
    private Date regFinishDate;

    @Column(name = "DateCreated")
    private Date dateCreated;

    @Column(name = "UIUseSmallCards")
    private boolean useSmallCards;

    @Column(name = "Region_IDREF")
    private Integer region;

}
