package kz.eubank.registration.infrastructure.repository.mssql.impl;

import kz.eubank.registration.domain.model.pojo.Password;
import kz.eubank.registration.domain.repository.IPasswordRepository;
import kz.eubank.registration.infrastructure.model.mapper.BaseMapper;
import kz.eubank.registration.infrastructure.repository.mssql.PasswordHiberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
@Primary
@Component
@RequiredArgsConstructor
public class PasswordRepository implements IPasswordRepository {

    private final PasswordHiberRepository passwordHiberRepository;
    @Override
    public void save(Password password) {
        var entity = BaseMapper.INSTANCE.toEntity(password);
        passwordHiberRepository.save(entity);
    }

    @Override
    public void makePasswordInvalid(Long userId) {
        passwordHiberRepository.makePasswordInvalid(userId);
    }
}
