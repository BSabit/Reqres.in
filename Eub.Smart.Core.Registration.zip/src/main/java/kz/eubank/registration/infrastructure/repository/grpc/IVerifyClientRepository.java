package kz.eubank.registration.infrastructure.repository.grpc;

import SmartRegistration.V1.EubAggregatorCoreSmartRegistration;

public interface IVerifyClientRepository {
    public EubAggregatorCoreSmartRegistration.VerifyClientReply sendRequestVerifyClient(EubAggregatorCoreSmartRegistration.RecoveryProductAccountType recoveryProductAccountType,
                                                                                        String accountNumber,
                                                                                        String iin,
                                                                                        String mobilePhone,
                                                                                        String correlationId);
}
