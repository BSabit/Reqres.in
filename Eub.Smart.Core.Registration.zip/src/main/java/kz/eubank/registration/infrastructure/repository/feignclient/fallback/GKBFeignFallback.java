package kz.eubank.registration.infrastructure.repository.feignclient.fallback;

import kz.eubank.registration.infrastructure.model.dto.scb.SCBPersonalData;
import kz.eubank.registration.infrastructure.repository.feignclient.IGKBFeignClient;
import kz.eubank.registration.infrastructure.repository.feignclient.model.DocumentResponseDto;
import kz.eubank.registration.infrastructure.repository.feignclient.model.OtpResponseDto;
import kz.eubank.registration.infrastructure.repository.feignclient.model.ProfileResponseDto;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import org.springframework.cloud.openfeign.FallbackFactory;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class GKBFeignFallback implements FallbackFactory<IGKBFeignClient> {

    @Override
    public IGKBFeignClient create(Throwable cause) {
        return new IGKBFeignClient() {

            private void throwException(SelfException e) {
                switch (e.getCode()) {
                    case E_EX_701 -> throw new SelfException(SelfErrorCode.E_EX_701);
                    case E_EX_702 -> throw new SelfException(SelfErrorCode.E_EX_702);
                    default -> throw new SelfException(SelfErrorCode.E_EX_700);
                }
            }

            @Override
            public Optional<ProfileResponseDto> getProfile(String iin, String correlationId) {
                if (cause instanceof SelfException e) throwException(e);
                return Optional.empty();
            }

            @Override
            public Optional<OtpResponseDto> accessDocument(String iin, String documentType, String correlationId) {
                if (cause instanceof SelfException e) throwException(e);
                return Optional.empty();
            }

            @Override
            public Optional<DocumentResponseDto> getIdentityCard(String iin, String code, String correlationId) {
                if (cause instanceof SelfException e) throwException(e);
                return Optional.empty();
            }

            @Override
            public Optional<SCBPersonalData> getClientDataByIin(String iin, String correlationId) {
                if (cause instanceof SelfException e) throwException(e);
                return Optional.empty();
            }
        };
    }
}
