package kz.eubank.registration.infrastructure.model.entity.view;

import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Getter
@Entity
@NoArgsConstructor
public class UserDefineRouteView {

    @Id
    @Column(name = "MobilePhone")
    private String mobilePhone;

    @Column(name = "IIN")
    private String iin;

    @Column(name = "IsResident")
    private boolean isResident;

    @Column(name = "UserStatus_IDREF")
    private String userStatus;
}
