package kz.eubank.registration.infrastructure.model.entity;

import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "Password")
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Password {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Password_ID")
    private Long id;

    @Column(name = "Hash")
    private String hash;

    @Column(name = "User_IDREF")
    private Long userId;

    @Column(name = "DateCreated")
    private Date dateCreated;

    @Column(name = "IsValid")
    private int isValid;

    @Column(name = "IsTechnical")
    private int isTechnical;
}
