package kz.eubank.registration.infrastructure.repository.mssql.impl;

import kz.eubank.registration.domain.model.pojo.RecoveryProductStatus;
import kz.eubank.registration.domain.repository.IRecoveryProductStatusRepository;
import kz.eubank.registration.infrastructure.model.mapper.BaseMapper;
import kz.eubank.registration.infrastructure.repository.mssql.RecoveryProductStatusHiberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import java.util.Optional;

@Primary
@Component
@RequiredArgsConstructor
public class RecoveryProductStatusRepository implements IRecoveryProductStatusRepository {
    private final RecoveryProductStatusHiberRepository repository;
    @Override
    public RecoveryProductStatus findById(String id) {
        Optional<kz.eubank.registration.infrastructure.model.entity.RecoveryProductStatus> recoveryProductStatus = repository.findById(id);
        return recoveryProductStatus.map(BaseMapper.INSTANCE::toDomain).orElse(null);
    }
}
