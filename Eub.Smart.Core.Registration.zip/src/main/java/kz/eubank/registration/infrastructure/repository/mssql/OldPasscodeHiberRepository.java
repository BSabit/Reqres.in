package kz.eubank.registration.infrastructure.repository.mssql;

import kz.eubank.registration.infrastructure.model.entity.Passcode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;

@Repository
public interface OldPasscodeHiberRepository extends JpaRepository<Passcode, Long> {

    @Transactional
    @Modifying
    @Query(nativeQuery = true,
            value = """
                    UPDATE Passcode SET PasscodeStatus_IDREF = :status WHERE DeviceID = :deviceId AND PasscodeStatus_IDREF = 'ACTV'
            """)
    void changeStatusByDeviceId(String status, String deviceId);

    @Transactional
    @Modifying
    @Query(nativeQuery = true,
            value = """
                    UPDATE PassCode SET PasscodeStatus_IDREF = :status WHERE User_IDREF = :userID AND PasscodeStatus_IDREF = 'ACTV'
            """)
    void changeStatusByUserId(String status, String userID);
}
