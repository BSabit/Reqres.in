package kz.eubank.registration.infrastructure.model.entity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@Entity
@Table(name = "PasscodeStatus")
@RequiredArgsConstructor
public class PasscodeStatus {

    @Id
    @Column(name = "PasscodeStatus_ID")
    private String id;

    @Column(name = "PasscodeStatus_Title")
    private String title;

    @Column(name = "IsValid")
    private boolean isValid;

    @Column(name = "Term_OUTREF")
    private Long termId;
}
