package kz.eubank.registration.infrastructure.repository.feignclient;

import feign.Headers;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(value = "identityProvide",
        url = "${identityProvider.url}/")
public interface IIdentityProviderFeignClient {

    @DeleteMapping("/users/{username}")
    @Headers("Content-type:application/json")
    void clearUserCache(@PathVariable String username,
                        @RequestHeader("X-Correlation-Id") String correlationId);
}
