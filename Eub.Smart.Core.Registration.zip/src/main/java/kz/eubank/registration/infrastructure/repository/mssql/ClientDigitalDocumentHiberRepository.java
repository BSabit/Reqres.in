package kz.eubank.registration.infrastructure.repository.mssql;

import kz.eubank.registration.infrastructure.model.entity.ClientDigitalDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.Date;
import java.util.Optional;

public interface ClientDigitalDocumentHiberRepository extends JpaRepository<ClientDigitalDocument, Long> {

    @Query(nativeQuery = true,
            value = """
                    SELECT TOP(1) c.*
                    FROM ClientDigitalDocument c
                    WHERE c.IIN = :iin
                    AND c.IsVerified = 1
                    AND GETDATE() BETWEEN c.DateCreated AND c.DateExpired
                    ORDER BY c.DateCreated DESC
                    """)
    Optional<ClientDigitalDocument> findActualByIinAndType(String iin);

    @Modifying
    @Query(nativeQuery = true,
            value = """
                    UPDATE ClientDigitalDocument
                    SET isVerified = 1
                    WHERE ClientDigitalDocument_ID = :id
                    """
    )
    void setVerifiedById(Long id);

    @Modifying
    @Query(nativeQuery = true,
            value = """
                    UPDATE ClientDigitalDocument
                    SET DateExpired = :expiredDate
                    WHERE Iin = :iin AND isVerified = 1
                    """
    )
    void updateDateExpiredByIin(Date expiredDate, String iin);
}
