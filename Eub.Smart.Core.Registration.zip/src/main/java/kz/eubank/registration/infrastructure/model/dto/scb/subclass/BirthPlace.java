package kz.eubank.registration.infrastructure.model.dto.scb.subclass;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class BirthPlace {
    @JsonProperty("country")
    private GenericField country;
    @JsonProperty("district")
    private GenericField district;
    @JsonProperty("region")
    private GenericField region;
    @JsonProperty("city")
    private String city;
}



