package kz.eubank.registration.infrastructure.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver;

import java.util.Locale;

@Configuration
public class LocaleConfig {

    @Value("${resource_bundle.name.error}")
    private String errorName;

    @Value("${resource_bundle.name.sms}")
    private String smsName;

    @Value("${resource_bundle.defaultLocale}")
    private String defaultLocale;

    @Bean(name = "error_text")
    public ResourceBundleMessageSource errorMessageSource() {
        var messageSource = new ResourceBundleMessageSource();
        messageSource.setBasename(errorName);
        messageSource.setDefaultEncoding("UTF-8");
        messageSource.setUseCodeAsDefaultMessage(true);
        return messageSource;
    }

    @Bean(name = "sms_text")
    public ResourceBundleMessageSource smsMessageSource() {
        var messageSource = new ResourceBundleMessageSource();
        messageSource.setBasename(smsName);
        messageSource.setDefaultEncoding("UTF-8");
        messageSource.setUseCodeAsDefaultMessage(true);
        return messageSource;
    }

    @Bean
    public LocaleResolver localeResolver() {
        var localeResolver = new AcceptHeaderLocaleResolver();
        localeResolver.setDefaultLocale(new Locale(defaultLocale));
        return localeResolver;
    }
}
