package kz.eubank.registration.infrastructure.repository.mssql;

import kz.eubank.registration.infrastructure.model.entity.MetaDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface MetaDocumentHiberRepository extends JpaRepository<MetaDocument, Long> {

    @Query(nativeQuery = true,
            value = """
                    select *
                      from MetaDocument
                     where IsActive = 1
                       and Target_Table = :targetTable
                       and Target_ID = :targetId
                    """)
    Optional<MetaDocument> findActiveByTargetTableAndTargetId(String targetTable, Long targetId);

    @Query(nativeQuery = true,
            value = """
                    select *
                      from MetaDocument
                     where FileUid = :fileUid
                    """)
    Optional<MetaDocument> findByFileUid(String fileUid);
}
