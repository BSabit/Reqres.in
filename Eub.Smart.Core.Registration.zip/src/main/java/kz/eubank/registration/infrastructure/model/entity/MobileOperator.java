package kz.eubank.registration.infrastructure.model.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MobileOperator")
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MobileOperator {

    @Id
    @Column(name = "MobileOperator_ID")
    private String id;
    @Column(name = "MobileOperator_Title")
    private String title;
}
