package kz.eubank.registration.infrastructure.model.mapper;

import kz.eubank.registration.domain.model.enums.Gender;
import kz.eubank.registration.infrastructure.model.dto.scb.SCBPersonalData;
import kz.eubank.registration.infrastructure.repository.mssql.procedure.RequestCreateUserProcedure;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.util.Date;

import static kz.eubank.registration.domain.constant.SCB.*;

@Mapper(componentModel = "spring")
public interface SCBMapper {
    SCBMapper INSTANCE = Mappers.getMapper(SCBMapper.class);

    @Mapping(target = "firstName", source = "firstName")
    @Mapping(target = "lastName", source = "surname")
    @Mapping(target = "fatherName", source = "patronymic")
    @Mapping(target = "gender", source = ".", qualifiedByName = "getEnumGender")
    @Mapping(target = "birthDate", source = "birthDate")
    @Mapping(target = "isResident", source = ".", qualifiedByName = "getComparedCitizenship")
    @Mapping(target = "iin", source = "iin")
    @Mapping(target = "birthPlace", source = ".", qualifiedByName = "getFullBirthPlace")
    @Mapping(target = "addressCity", source = "regAddress.region.nameRu")
    @Mapping(target = "addressPlace", source = "regAddress.street")
    @Mapping(target = "addressHouseNo", source = "regAddress.building")
    @Mapping(target = "addressAptNo", source = "regAddress.flat")
    @Mapping(target = "addressTitle", source = ".", qualifiedByName = "getFullAddress")
    @Mapping(target = "isCitizenship", source = ".", qualifiedByName = "getComparedCitizenship")
    @Mapping(target = "paperTitle", source = ".", qualifiedByName = "getPaperTitle")
    @Mapping(target = "paperType", source = ".", qualifiedByName = "getPaperType")
    @Mapping(target = "paperIssueDate", source = ".", qualifiedByName = "getPaperIssueDate")
    @Mapping(target = "paperValidityDate", source = ".", qualifiedByName = "getPaperValidityDate")
    @Mapping(target = "paperIssuer", source = ".", qualifiedByName = "getPaperIssuer")
    @Mapping(target = "paperNumber", source = ".", qualifiedByName = "getPaperNumber")
    @Mapping(target = "paperStatus", source = ".", qualifiedByName = "getPaperStatus")
    @Mapping(target = "paperBSystem", constant = BSYSTEM_SMBK)
    @Mapping(target = "registeredBy", constant = REGISTERED_BY_SMBK)
    @Mapping(target = "regChannelId", constant = REG_CHANNEL_WEBB)
    RequestCreateUserProcedure toDto(SCBPersonalData data);

    @Named("getFullBirthPlace")
    default String getFullBirthPlace(SCBPersonalData data) {
        String country = data.getBirthPlace().getCountry().getNameRu();
        String region = data.getBirthPlace().getRegion().getNameRu();
        String district = data.getBirthPlace().getDistrict().getNameRu();
        String city = data.getBirthPlace().getCity();
        return (String.format("%s, %s, %s, %s", country, region, district, city));
    }

    @Named("getEnumGender")
    default Gender getEnumGender(SCBPersonalData data) {
        int code = Integer.parseInt(data.getGender().getCode());
        switch (code) {
            case 1 -> {
                return Gender.MALE;
            }
            case 2 -> {
                return Gender.FEML;
            }
            default -> {
                return Gender.UNKN;
            }
        }
    }

    @Named("getComparedCitizenship")
    default boolean getComparedCitizenship(SCBPersonalData data) {
        int codeCountry = Integer.parseInt(data.getCitizenship().getCode());
        return codeCountry == CODE_KAZAKHSTAN;
    }

    @Named("getFullAddress")
    default String getFullAddress(SCBPersonalData data) {
        String city = data.getRegAddress().getRegion().getNameRu();
        String street = data.getRegAddress().getStreet();
        String apartNumber = data.getRegAddress().getBuilding();
        String flat = data.getRegAddress().getFlat();
        return (String.format("%s, %s, %s, %s", city, street, apartNumber, flat));
    }

    @Named("getPaperTitle")
    default String getPaperTitle(SCBPersonalData data) {
        return data.getDocuments().getListOfDocuments().get(0).getType().getNameRu();
    }

    @Named("getPaperType")
    default String getPaperType(SCBPersonalData data) {
        String response;
        int typeCode = Integer.parseInt(data.getDocuments().getListOfDocuments().get(0).getType().getCode());
        switch (typeCode) {
            case 1 -> response = "PASS";
            case 2 -> response = "IDEN";
            default -> response = "UNKW";
        }
        return response;
    }
    @Named("getPaperIssueDate")
    default Date getPaperIssueDate(SCBPersonalData data) {
        return data.getDocuments().getListOfDocuments().get(0).getBeginDate();
    }
    @Named("getPaperValidityDate")
    default Date getPaperValidityDate(SCBPersonalData data) {
        return data.getDocuments().getListOfDocuments().get(0).getEndDate();
    }
    @Named("getPaperIssuer")
    default String getPaperIssuer(SCBPersonalData data) {
        return data.getDocuments().getListOfDocuments().get(0).getIssueOrganization().getNameRu();
    }
    @Named("getPaperNumber")
    default String getPaperNumber(SCBPersonalData data) {
        return data.getDocuments().getListOfDocuments().get(0).getNumber();
    }
    @Named("getPaperStatus")
    default String getPaperStatus(SCBPersonalData data) {
        int statusCode = Integer.parseInt(data.getDocuments().getListOfDocuments().get(0).getStatus().getCode());
        if (statusCode != 0) {
            throw new RuntimeException("Paper status is not correct");
        }
        return PAPER_STATUS_APPR;
    }
}
