package kz.eubank.registration.infrastructure.repository.mssql.impl;


import kz.eubank.registration.domain.model.pojo.User;
import kz.eubank.registration.domain.repository.IUserRepository;
import kz.eubank.registration.infrastructure.model.mapper.BaseMapper;
import kz.eubank.registration.infrastructure.repository.mssql.UserHiberRepostiroy;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Primary
@Component
@RequiredArgsConstructor
public class UserRepository implements IUserRepository {
    private final UserHiberRepostiroy repostiroy;

    @Override
    public void updateUserRegion(int userId, int regionId) {
        repostiroy.updateUserRegion(userId, regionId);
    }

    @Override
    public void updateUserStatus(String status, long userId) {
        repostiroy.updateUserStatus(status, userId);
    }
    @Override
    public Optional<User> findUserWithIin(String iin) {
        return repostiroy.findUserWithIin(iin).map(BaseMapper.INSTANCE::toDomain);
    }
}
