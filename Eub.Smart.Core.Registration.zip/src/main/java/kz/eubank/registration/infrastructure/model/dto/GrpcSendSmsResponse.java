package kz.eubank.registration.infrastructure.model.dto;

public record GrpcSendSmsResponse(String status,
                                  String message) {
}
