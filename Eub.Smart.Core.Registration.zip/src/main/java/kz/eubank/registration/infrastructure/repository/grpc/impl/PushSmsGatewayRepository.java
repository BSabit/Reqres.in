package kz.eubank.registration.infrastructure.repository.grpc.impl;

import io.grpc.StatusRuntimeException;
import kz.eubank.grpc.EubServiceGenericPushSmsGateway;
import kz.eubank.grpc.PushSmsGrpc;
import kz.eubank.registration.infrastructure.model.dto.GrpcSendSmsResponse;
import kz.eubank.registration.infrastructure.repository.grpc.IPushSmsGatewayRepository;
import kz.eubank.registration.infrastructure.util.MetadataUtil;
import lombok.RequiredArgsConstructor;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class PushSmsGatewayRepository implements IPushSmsGatewayRepository {

    private final Logger log = LogManager.getLogger(getClass());

    @GrpcClient("smsGateWay")
    private PushSmsGrpc.PushSmsBlockingStub stub;

    public GrpcSendSmsResponse sendSms(String phoneNumber, String message, String correlationId) {
        log.info("start sendSms via grpc: phoneNumber - {}", phoneNumber);
        try {
            var response = stub
                    .withInterceptors(MetadataUtil.newCorrelationIdInterceptor(correlationId))
                    .sendSms(EubServiceGenericPushSmsGateway.SendSmsRequest
                            .newBuilder()
                            .setPhones(phoneNumber)
                            .setMessage(message)
                            .setSenderName("Smartbank")
                            .build());
            log.info("sms sent: status - {}, message - {}", response.getStatus(), response.getMessage());
            return new GrpcSendSmsResponse(response.getStatus(), response.getMessage());
        } catch (StatusRuntimeException e) {
            log.error("Error sendSms StatusRuntimeException: {}", e.getMessage());
            return new GrpcSendSmsResponse("OK", "OK message");
            //throw new SelfException(SelfErrorCode.E_EX_703);
        }
    }
}
