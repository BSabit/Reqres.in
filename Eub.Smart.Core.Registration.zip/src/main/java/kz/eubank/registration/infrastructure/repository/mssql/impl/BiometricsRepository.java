package kz.eubank.registration.infrastructure.repository.mssql.impl;

import kz.eubank.registration.domain.model.pojo.Biometrics;
import kz.eubank.registration.domain.repository.IBiometricsRepository;
import kz.eubank.registration.infrastructure.model.mapper.BaseMapper;
import kz.eubank.registration.infrastructure.repository.mssql.BiometricsHiberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Primary
@Component
@RequiredArgsConstructor
public class BiometricsRepository implements IBiometricsRepository {

    private final BiometricsHiberRepository biometricsHiberRepository;

    @Override
    public void save(Biometrics biometrics) {
        var entity = BaseMapper.INSTANCE.toEntity(biometrics);
        biometricsHiberRepository.save(entity);
    }
    @Override
    public Optional<Biometrics> findByFolderId(String folderId) {
        return biometricsHiberRepository.findByIdAndFolderId(folderId).map(BaseMapper.INSTANCE::toDomain);
    }
    @Override
    public void updateData(Object analyseResponse, String status, long biometryId) {
        biometricsHiberRepository.updateData(analyseResponse, status, biometryId);
    }
    @Override
    public void updateStatus(String status, long biometryId) {
        biometricsHiberRepository.updateStatus(status, biometryId);
    }

    @Override
    public void updateSimilarityPercentByFolderId(String folderId, double similarityPercent) {
        biometricsHiberRepository.updateSimilarityPercentByFolderId(folderId, similarityPercent);
    }
}
