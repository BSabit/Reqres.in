package kz.eubank.registration.presentation.rest.model.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class APIResponse<T> {

    private T body;
    private String techErrorCode;
    private String techErrorMessage;

    public APIResponse<T> successResponse(T body) {
        this.body = body;
        return this;
    }

    public APIResponse<T> errorResponse(String techErrorCode, String techErrorMessage) {
        this.techErrorCode = techErrorCode;
        this.techErrorMessage = techErrorMessage;
        return this;
    }

    public String json() {
        return "{" +
                "\"body\":\"" + body + "\"" +
                ", \"techErrorCode\":" + techErrorCode +
                ", \"techErrorMessage\":" + techErrorMessage +
                "}";
    }
}
