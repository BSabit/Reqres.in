package kz.eubank.registration.presentation.rest.model.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class StatusAnalyseResponse extends BaseResponseBody {

    public StatusAnalyseResponse(String nextStep) {
        super(nextStep);
    }
}
