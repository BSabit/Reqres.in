package kz.eubank.registration.presentation.rest.model.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class RecoveryProductResponse extends BaseResponseBody {

    public RecoveryProductResponse(String nextStep) {
        super(nextStep);
    }
}
