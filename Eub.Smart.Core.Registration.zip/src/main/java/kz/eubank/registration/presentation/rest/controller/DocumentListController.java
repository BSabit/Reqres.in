package kz.eubank.registration.presentation.rest.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import kz.eubank.registration.presentation.rest.exception.ResponseBinding;
import kz.eubank.registration.presentation.rest.model.response.Document;
import kz.eubank.registration.presentation.rest.model.response.DocumentListResponse;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static kz.eubank.registration.domain.constant.PathUrl.registration;
import static org.springframework.http.HttpStatus.OK;

@ResponseBinding
@RestController
@RequestMapping(registration + "/documentList")
@RequiredArgsConstructor
@Tag(name = "Список документов", description = "DocumentListController")
public class DocumentListController {

    private final Logger log = LogManager.getLogger(getClass());

    @Operation(summary = "Получение документов", description = "getDocumentList")
    @GetMapping
    public ResponseEntity<?> getDocumentList(@RequestHeader("Operation-Id") String sessionId) {
        log.info("REST getDocumentList Operation-Id: {}", sessionId);
        var docList =
                List.of(new Document("docName", "docType", "base64", "formatBase64"),
                        new Document("docName2", "docType2", "base64", "formatBase64"));
        return new ResponseEntity<>(new DocumentListResponse(docList), OK);
    }
}
