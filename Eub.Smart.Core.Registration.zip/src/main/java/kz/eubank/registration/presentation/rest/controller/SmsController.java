package kz.eubank.registration.presentation.rest.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import kz.eubank.registration.application.camunda.execution.ISmsExecution;
import kz.eubank.registration.presentation.rest.exception.ResponseBinding;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static kz.eubank.registration.domain.constant.PathUrl.registration;
import static org.springframework.http.HttpStatus.OK;

@ResponseBinding
@RestController
@RequestMapping(registration + "/sms")
@RequiredArgsConstructor
@Tag(name = "СМС", description = "SmsController")
public class SmsController {

    private final Logger log = LogManager.getLogger(getClass());
    private final ISmsExecution execution;

    @Operation(summary = "Отправка и проверка СМС", description = "sms")
    @Parameters({
            @Parameter(name = "code", description = "code", required = true)
    })
    @PostMapping
    public ResponseEntity<?> sms(@RequestHeader("Operation-Id") String sessionId,
                                 @RequestParam(defaultValue = "") String code) {
        log.info("REST sms Operation-Id: {}", sessionId);
        var response = execution.sms(sessionId, code);
        return new ResponseEntity<>(response, OK);
    }
}
