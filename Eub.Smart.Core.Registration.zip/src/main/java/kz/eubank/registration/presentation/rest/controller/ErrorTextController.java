package kz.eubank.registration.presentation.rest.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import kz.eubank.registration.application.camunda.execution.IErrorTextExecution;
import kz.eubank.registration.presentation.rest.exception.ResponseBinding;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static kz.eubank.registration.domain.constant.PathUrl.registration;
import static org.springframework.http.HttpStatus.OK;

@ResponseBinding
@RestController
@RequestMapping(registration + "/errorText")
@RequiredArgsConstructor
@Tag(name = "Ошибки", description = "ErrorTextController")
public class ErrorTextController {

    private final Logger log = LogManager.getLogger(getClass());
    private final IErrorTextExecution execution;

    @Operation(summary = "Получение текста ошибки", description = "getErrorText")
    @GetMapping
    public ResponseEntity<?> getErrorText(@RequestHeader("Operation-Id") String sessionId) {
        log.info("REST getErrorText Operation-Id: {}", sessionId);
        var response = execution.getErrorText(sessionId);
        return new ResponseEntity<>(response, OK);
    }
}
