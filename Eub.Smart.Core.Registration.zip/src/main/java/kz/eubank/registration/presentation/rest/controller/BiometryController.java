package kz.eubank.registration.presentation.rest.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import kz.eubank.registration.application.camunda.execution.IBiometryExecution;
import kz.eubank.registration.presentation.rest.exception.ResponseBinding;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotNull;

import static kz.eubank.registration.domain.constant.PathUrl.registration;
import static org.springframework.http.HttpStatus.OK;

@ResponseBinding
@RestController
@RequestMapping(registration + "/biometry")
@Tag(name = "Биометрия", description = "BiometryController")
@RequiredArgsConstructor
public class BiometryController {

    private final Logger log = LogManager.getLogger(getClass());

    private final IBiometryExecution execution;

    @Operation(summary = "Загрузка фото лица", description = "uploadSelfie")
    @Parameters({
            @Parameter(name = "mediaList", description = "mediaList", required = true),
            @Parameter(name = "payload", description = "payload", required = true)
    })
    @PostMapping(value = "uploadSelfie", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    public ResponseEntity<?> uploadSelfie(@RequestHeader("Operation-Id") String sessionId,
                                          @RequestParam @NotNull MultiValueMap<String, MultipartFile> mediaList,
                                          @RequestParam String payload) {                                  
        log.info("REST uploadSelfie Operation-Id: {}", sessionId);
        log.info("Payload input: {}", payload);
        var response = execution.uploadSelfie(sessionId, payload, mediaList);
        return new ResponseEntity<>(response, OK);
    }

    @Operation(summary = "Статус анализа", description = "statusAnalyse")
    @GetMapping("statusAnalyse")
    public ResponseEntity<?> statusAnalyse(@RequestHeader("Operation-Id") String sessionId) {
        log.info("REST statusAnalyse Operation-Id: {}", sessionId);
        var response = execution.statusAnalyze(sessionId);
        return new ResponseEntity<>(response, OK);
    }
}