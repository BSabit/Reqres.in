package kz.eubank.registration.presentation.rest.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import kz.eubank.registration.application.camunda.execution.IRegistrationExecution;
import kz.eubank.registration.presentation.rest.exception.ResponseBinding;
import kz.eubank.registration.presentation.rest.model.request.DefineRouteRequest;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import static kz.eubank.registration.domain.constant.PathUrl.registration;
import static org.springframework.http.HttpStatus.OK;

@ResponseBinding
@RestController
@RequestMapping(registration + "/defineRoute")
@RequiredArgsConstructor
@Tag(name = "Определение роута", description = "DefineRouteController")
@Validated
public class DefineRouteController {

    private final Logger log = LogManager.getLogger(getClass());

    private final IRegistrationExecution execution;

    @Operation(summary = "Определение роута по номеру телефона", description = "defineRoute")
    @Parameters({
            @Parameter(name = "phoneNumber", description = "phoneNumber", required = true),
            @Parameter(name = "deviceId", description = "deviceId", required = true)
    })
    @GetMapping
    public ResponseEntity<?> defineRoute(@RequestHeader(value = "User-Agent",
            defaultValue = "Browser;OpenAPI;Swagger:3.0.1") String userAgent,
                                         @RequestHeader(value = "APP_VERSION",
                                                 defaultValue = "1.0.0") String appVersion,
                                         @RequestParam String deviceId,
                                         @RequestParam String phoneNumber) {
        log.info("PhoneNumber: {}, User-Agent: {}, APP_VERSION: {}", phoneNumber, userAgent, appVersion);
        var request = new DefineRouteRequest(phoneNumber, deviceId, userAgent, appVersion);
        var response = execution.defineRoute(request);
        return new ResponseEntity<>(response, OK);
    }
}
