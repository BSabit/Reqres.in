package kz.eubank.registration.presentation.rest.model.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class VerificationProductResponse extends BaseResponseBody {

    public VerificationProductResponse(String nextStep) {
        super(nextStep);
    }
}
