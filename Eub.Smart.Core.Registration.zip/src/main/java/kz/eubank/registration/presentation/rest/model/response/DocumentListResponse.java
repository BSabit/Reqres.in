package kz.eubank.registration.presentation.rest.model.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString(callSuper = true)
public class DocumentListResponse {

    private List<Document> documentList;

    public DocumentListResponse(List<Document> documentList) {
        this.documentList = documentList;
    }
}
