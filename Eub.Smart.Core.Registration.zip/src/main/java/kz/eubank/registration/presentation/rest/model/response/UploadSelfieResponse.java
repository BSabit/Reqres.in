package kz.eubank.registration.presentation.rest.model.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class UploadSelfieResponse extends BaseResponseBody {

    public UploadSelfieResponse(String nextStep) {
        super(nextStep);
    }
}
