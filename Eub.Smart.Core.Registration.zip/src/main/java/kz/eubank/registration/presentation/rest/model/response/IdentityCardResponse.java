package kz.eubank.registration.presentation.rest.model.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class IdentityCardResponse extends BaseResponseBody {

    public IdentityCardResponse(String nextStep) {
        super(nextStep);
    }
}
