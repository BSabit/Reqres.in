package kz.eubank.registration.presentation.rest.exception;

public enum SelfErrorCode {

    E_VD_400("error.validate.annotation_validate"),                     //ANNOTATION 400-499

    E_SM_500("error.system.json2.json-to-object"),                            //SYSTEM 500-599
    E_SM_501("error.system.object-to-json2.json"),

    E_DB_600("error.db.object-not-found"),                              //DB 600-699
    E_DB_601("error.db.result-more-than-expect"),
    E_DB_602("error.db.exec.procedure"),
    E_DB_603("error.incorrect.field"),

    E_EX_700("error.external.response-error"),                          //EXTERNAL 700-799
    E_EX_701("error.external.system-not-available"),
    E_EX_702("error.external.invalid-token"),
    E_EX_703("error.external.send-sms-not-available"),
    E_EX_704("error.external.kisc-response-not-success"),
    E_EX_705("error.external.kisc-system-not-available"),
    E_LG_800("error.logical.file-is-not-complete"),                     //LOGICAL 800-899
    E_LG_801("error.logical.data-is-not-correct"),

    E_BS_901("error.business.limit-exceeded"),                                     //BUSINESS 900-999
    E_BS_902("error.business.product-number-incorrect"),
    E_BS_903("error.business.sessionId-not-found"),
    E_BS_904("error.business.route-status-not-correct"),
    E_BS_905("error.business.route-type-not-correct"),
    E_BS_906("error.business.session-expired"),
    E_BS_907("error.business.iin-already-exists"),
    E_BS_908("error.business.age-is-not-suitable"),
    E_BS_909("error.business.incorrect-sms-code"),
    E_BS_910("error.business.incorrect-sms-code-with-attempts-left"),
    E_BS_911("error.business.sms-code-expired"),
    E_BS_912("error.business.iin-registered-under-different-phone-number"),
    E_BS_913("error.business.incorrect-iin"),
    E_BS_914("error.business.access-blocked"),
    E_BS_900("error.business.session-id-not-found"),
    E_BS_915("error.business.verification-product-failed"),
    E_BS_916("error.business.invalid-phone-number-format"),
    E_BS_917("error.business.invalid-mobile-operator"),
    E_BS_920("error.business.biometrics-analyzeId-not-found"),
    E_BS_921("error.business.biometrics-analyze-empty"),
    E_BS_922("error.business.biometrics-analyze-thumb-url-empty"),
    E_BS_923(Error.recoveryBiometry,"error.business.biometrics-attempts-failed"),
    E_BS_924(Error.recoveryBiometry,"error.business.biometrics-attempts-limited"),
    E_BS_930("error.business.kisc-error"),
    E_BS_931("error.business.kisc-no-one-person-find"),
    E_BS_940("error.business.forensic-service-error"),
    E_BS_941("error.business.forensic-analyse-failed"),
    E_BS_942("error.business.forensic-biometry-analyse-failed"),
    E_BS_951("error.business.gkb-client-not-exists"),
    E_BS_952("error.business.gkb-wrong-code-or-iin"),
    E_BS_953("error.business.gkb-attempts-exceeded"),
    E_BS_960("error.business.scb-receive-null"),
    E_BS_961("error.business.procedure-failed"),
    E_BS_962("error.business.wrong-step"),
    E_BS_963("error.business.operation-id-not-found-in-camunda"),
    E_BS_964("error.business.scb-exception"),
    E_BS_970("error.business.registration-service-not-available"),

    E_BS_1000(Error.recoveryProduct,"error.business.recovery-product-status.wphe"),
    E_BS_1001(Error.recoveryProduct,"error.business.recovery-product-status.cnew"),
    E_BS_1002(Error.recoveryProduct,"error.business.recovery-product-status.arst"),
    E_BS_1003(Error.recoveryProduct,"error.business.recovery-product-status.fcnf"),
    E_BS_1004(Error.recoveryProduct,"error.business.recovery-product-status.fall"),
    E_BS_1005(Error.recoveryProduct,"error.business.recovery-product-status.fcie"),
    E_BS_1006(Error.recoveryProduct,"error.business.recovery-product-status.rspe"),
    E_BS_1007(Error.recoveryProduct,"error.business.recovery-product-status.faow"),
    E_BS_1008(Error.recoveryProduct,"error.business.recovery-product-status.anar"),
    E_BS_1009(Error.recoveryProduct,"error.business.recovery-product-status.aner"),
    E_BS_1010(Error.recoveryProduct,"error.business.recovery-product-status.pner"),
    E_BS_1011(Error.recoveryProduct,"error.business.recovery-product-status.cner"),
    E_BS_1012(Error.recoveryProduct,"error.business.recovery-product-status.cnar"),
    E_BS_1013(Error.recoveryProduct,"error.business.recovery-product-status.fmpo"),
    E_BS_1014(Error.recoveryProduct,"error.business.recovery-product-status.w4na"),
    E_BS_1015(Error.recoveryProduct,"error.business.recovery-product-status.fphe"),
    E_BS_1016(Error.recoveryProduct,"error.business.recovery-product-status.fphn"),
    E_BS_1017(Error.recoveryProduct,"error.business.recovery-product-status.limited");

    private final String message;
    private Error error;
    public enum Error {
        recoveryProduct,
        recoveryBiometry
    }

    SelfErrorCode(Error error, String message) {
        this.message = message;
        this.error = error;
    }

    SelfErrorCode(String message) {
        this.message = message;
    }
    public boolean isInGroupError(Error error) {
        return this.error == error;
    }
    public Error getError() {
        return error;
    }

    public String getMessage() {
        return message;
    }
}
