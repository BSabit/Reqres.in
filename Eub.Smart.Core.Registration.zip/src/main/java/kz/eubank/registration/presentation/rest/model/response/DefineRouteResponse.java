package kz.eubank.registration.presentation.rest.model.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class DefineRouteResponse extends BaseResponseBody {

    private String sessionId;

    public DefineRouteResponse(String nextStep, String sessionId) {
        super(nextStep);
        this.sessionId = sessionId;
    }
}
