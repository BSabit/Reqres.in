package kz.eubank.registration.presentation.rest.model.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class PasscodeSetResponse extends BaseResponseBody {

    public PasscodeSetResponse(String nextStep) {
        super(nextStep);
    }
}
