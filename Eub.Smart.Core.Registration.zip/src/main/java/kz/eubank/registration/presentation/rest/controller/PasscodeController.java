package kz.eubank.registration.presentation.rest.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import kz.eubank.registration.application.camunda.execution.IPasscodeExecution;
import kz.eubank.registration.presentation.rest.exception.ResponseBinding;
import kz.eubank.registration.presentation.rest.model.response.PasscodeSetResponse;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static kz.eubank.registration.domain.constant.PathUrl.registration;


@ResponseBinding
@RestController
@RequestMapping(registration + "/passcode")
@Tag(name = "Код доступа", description = "PasscodeController")
@RequiredArgsConstructor
public class PasscodeController {

    private final Logger log = LogManager.getLogger(getClass());
    private final IPasscodeExecution execution;

    @Operation(summary = "Создание быстрого кода доступа", description = "passcodeSet")
    @Parameters({
            @Parameter(name = "passcode", description = "passcode", required = true)
    })
    @PostMapping("set")
    public ResponseEntity<?> passcodeSet(@RequestHeader("Operation-Id") String sessionId,
                                         @RequestParam String passcode) {
        log.info("REST passcodeSet Operation-Id: {}", sessionId);
        execution.createPasscode(sessionId, passcode);
        return new ResponseEntity<>(new PasscodeSetResponse("Login"), HttpStatus.OK);
    }
}
