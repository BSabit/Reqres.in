package kz.eubank.registration.presentation.rest.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import kz.eubank.registration.application.camunda.execution.IDigitalDocumentExecution;
import kz.eubank.registration.presentation.rest.exception.ResponseBinding;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static kz.eubank.registration.domain.constant.PathUrl.registration;
import static org.springframework.http.HttpStatus.OK;

@ResponseBinding
@RestController
@RequestMapping(registration + "/digitalDocument")
@RequiredArgsConstructor
@Tag(name = "Цифровые документы", description = "DigitalDocumentController")
public class DigitalDocumentController {

    private final Logger log = LogManager.getLogger(getClass());
    private final IDigitalDocumentExecution execution;

    @Operation(summary = "Отправка и проверка(+загрузка документа с ГКБ) ОТП", description = "identityCard")
    @Parameters({
            @Parameter(name = "otpCode", description = "otpCode", required = true)
    })
    @PostMapping("identityCard")
    public ResponseEntity<?> identityCard(@RequestHeader("Operation-Id") String sessionId,
                                          @RequestParam(defaultValue = "") String otpCode) {
        log.info("REST identityCard Operation-Id: {}", sessionId);
        var response = execution.identityCard(sessionId, otpCode);
        return new ResponseEntity<>(response, OK);
    }
}
