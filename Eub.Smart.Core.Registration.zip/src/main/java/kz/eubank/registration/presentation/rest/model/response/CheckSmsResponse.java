package kz.eubank.registration.presentation.rest.model.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CheckSmsResponse extends BaseResponseBody {

    public CheckSmsResponse(String nextStep) {
        super(nextStep);
    }
}
