package kz.eubank.registration.presentation.rest.model.request;

public record DefineRouteRequest(String phoneNumber,
                                 String deviceId,
                                 String userAgent,
                                 String versionFront) {
}
