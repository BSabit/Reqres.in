package kz.eubank.registration.presentation.rest.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import kz.eubank.registration.application.camunda.execution.IVerificationExecution;
import kz.eubank.registration.presentation.rest.exception.ResponseBinding;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import static kz.eubank.registration.domain.constant.PathUrl.registration;
import static org.springframework.http.HttpStatus.OK;

@ResponseBinding
@RestController
@RequestMapping(registration + "/verification")
@RequiredArgsConstructor
@Tag(name = "Верификация", description = "VerificationController")
@Validated
public class VerificationController {
    private final Logger log = LogManager.getLogger(getClass());
    private final IVerificationExecution execution;

    @Operation(summary = "Верификация ИИН", description = "verificationIIN")
    @Parameters({
            @Parameter(name = "iin", description = "iin", required = true)
    })
    @GetMapping("iin")
    public ResponseEntity<?> verificationIIN(@RequestHeader("Operation-Id") String sessionId,
                                             @RequestParam String iin) {
        log.info("REST verificationIIN Operation-Id: {}", sessionId);
        var response = execution.verificationIIN(sessionId, iin);
        return new ResponseEntity<>(response, OK);
    }

    @Operation(summary = "Верификация ИИН и продукта", description = "verificationProduct")
    @Parameters({
            @Parameter(name = "iin", description = "iin", required = true),
            @Parameter(name = "product", description = "product", required = true)
    })
    @GetMapping("product")
    public ResponseEntity<?> verificationProduct(@RequestParam String iin,
                                                 @RequestParam String product,
                                                 @RequestHeader("Operation-Id") String sessionId) {
        log.info("REST verificationProduct Operation-Id: {}", sessionId);
        var response = execution.verificationProduct(iin, product, sessionId);
        return new ResponseEntity<>(response, OK);
    }
}
