package kz.eubank.registration.application.camunda.delegate;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.service.IVerificationIINService;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class VerificationIINDelegate implements JavaDelegate {

    private final Logger log = LogManager.getLogger(getClass());
    private final IVerificationIINService verificationIINService;

    @Override
    public void execute(DelegateExecution execution) throws Exception {
        var model = (BaseModel) execution.getVariableTyped("model").getValue();
        log.info("VerificationIINDelegate input: {}", model);
        verificationIINService.verificationIIN(model);
        execution.setVariable("model", model);
        log.info("VerificationIINDelegate output: {}", model);

        if (model.getError() != null) {
            throw new BpmnError(model.getError().toString());
        }
    }
}
