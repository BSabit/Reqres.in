package kz.eubank.registration.application.camunda.execution;

import kz.eubank.registration.presentation.rest.model.response.ErrorTextResponse;

public interface IErrorTextExecution {

    ErrorTextResponse getErrorText(String sessionId);
}
