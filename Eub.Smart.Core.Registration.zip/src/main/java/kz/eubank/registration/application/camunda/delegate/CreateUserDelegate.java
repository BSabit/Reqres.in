package kz.eubank.registration.application.camunda.delegate;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.service.IAccountCreateService;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;

import java.sql.SQLException;

import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.*;

@Component
@RequiredArgsConstructor
public class CreateUserDelegate implements JavaDelegate {

    private final Logger log = LogManager.getLogger(getClass());
    private final IAccountCreateService accountCreateService;

    @Override
    public void execute(DelegateExecution execution) {
        var model = (BaseModel) execution.getVariableTyped("model").getValue();
        log.info("CreateUserDelegate input: {}", model);
        try {
            accountCreateService.createAccount(model);
        } catch (SelfException e) {
            log.error("ERROR createAccount Session-Id: {}, code: {}", model.getSessionId(), e.getCode());
            e.printStackTrace();
            model.setError(e.getCode());
            throw new BpmnError(e.toString());
        } catch (Exception e) {
            log.error("Exception error createAccount Session-Id: {}, code: {}", model.getSessionId(), e.getMessage());
            e.printStackTrace();
            model.setError(E_BS_1004);
            throw new BpmnError(e.getMessage());
        }
        execution.setVariable("model", model);
        log.info("CreateUserDelegate output: {}", model);
    }

}
