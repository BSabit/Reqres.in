package kz.eubank.registration.application.camunda.execution.impl;

import kz.eubank.registration.application.camunda.execution.IErrorTextExecution;
import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.infrastructure.config.AppProperties;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.model.response.ErrorTextResponse;
import org.camunda.bpm.engine.ProcessEngine;
import org.springframework.stereotype.Component;

import static java.util.Objects.nonNull;
import static kz.eubank.registration.domain.model.enums.DMZVerificationAttemptsType.CSMS;
import static kz.eubank.registration.infrastructure.config.ErrorTranslator.*;
import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.E_BS_910;

@Component
public class ErrorTextExecution extends BaseExecution implements IErrorTextExecution {

    private final AppProperties properties;

    public ErrorTextExecution(ProcessEngine engine, AppProperties properties) {
        super(engine);
        this.properties = properties;
    }

    @Override
    public ErrorTextResponse getErrorText(String sessionId) {
        var task = getTaskBySessionId(sessionId);
        var model = getBaseModelByExecutionId(task.getExecutionId());

        var error = model.getError().toString();
        var attemptsLeft = getAttemptsLeftNumberByError(model);

        completeTaskById(task.getId());

        task = getTaskBySessionId(sessionId);
        if (nonNull(task)) {
            model.setError(null);
            setBaseModelByExecutionId(task.getExecutionId(), model);
        }

        var nextStep = getNextStepBySessionId(sessionId, model.getError());

        return new ErrorTextResponse(nextStep, toErrorMessageWithArg(error, attemptsLeft), toErrorDetails(error), toErrorButtonText(error));
    }

    private Integer getAttemptsLeftNumberByError(BaseModel model) {
        Integer attemptsLeft = null;
        if (model.getError() == E_BS_910) {
            attemptsLeft = properties.getVerificationLimitCountByType(CSMS) - model.getCheckSmsAttempts();
        }
        if (model.getError().isInGroupError(SelfErrorCode.Error.recoveryProduct)) {
            attemptsLeft = properties.getAttemptsForRecovery() - model.getProductRecoveryAttempts();
        }
        if (model.getError().isInGroupError(SelfErrorCode.Error.recoveryBiometry)) {
            attemptsLeft = properties.getAttemptsForBiometry() - model.getBiometryAttempts();
        }
        return attemptsLeft;
    }

    private ErrorTextResponse getErrorResponse(String nextStep, String error, String notify, int attemptsLeft) {
        return new ErrorTextResponse(nextStep,
                toErrorMessageWithArgAndNotify(error, attemptsLeft, notify),
                toErrorDetails(error),
                toErrorButtonText(error));
    }
}

