package kz.eubank.registration.application.camunda.execution;

import kz.eubank.registration.presentation.rest.model.response.StatusAnalyseResponse;
import kz.eubank.registration.presentation.rest.model.response.UploadSelfieResponse;
import org.springframework.util.MultiValueMap;
import org.springframework.web.multipart.MultipartFile;

public interface IBiometryExecution {

    UploadSelfieResponse uploadSelfie(String sessionId,
                                      String payload,
                                      MultiValueMap<String, MultipartFile> mediaList);

    StatusAnalyseResponse statusAnalyze(String authorization);
}
