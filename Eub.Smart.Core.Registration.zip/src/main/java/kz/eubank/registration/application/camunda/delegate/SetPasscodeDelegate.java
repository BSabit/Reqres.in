package kz.eubank.registration.application.camunda.delegate;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.service.IFingerprintService;
import kz.eubank.registration.domain.service.IPasscodeService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;


@Component
public class SetPasscodeDelegate implements JavaDelegate {

    private final Logger log = LogManager.getLogger(getClass());
    @Qualifier("oldPasscode")
    private final IPasscodeService oldPasscodeService;
    @Qualifier("passcode")
    private final IPasscodeService passcodeService;
    private final IFingerprintService fingerprintService;

    public SetPasscodeDelegate(IPasscodeService oldPasscodeService, IPasscodeService passcodeService, IFingerprintService fingerprintService) {
        this.oldPasscodeService = oldPasscodeService;
        this.passcodeService = passcodeService;
        this.fingerprintService = fingerprintService;
    }

    @Override
    @Transactional
    public void execute(DelegateExecution execution) throws Exception {
        var model = (BaseModel) execution.getVariableTyped("model").getValue();
        log.info("SetPasscodeDelegate input: {}", model);
        oldPasscodeService.savePasscode(model.getSessionId(), model.getPasscode());
        passcodeService.savePasscode(model.getSessionId(), model.getPasscode());
        fingerprintService.updateBUPRStatus(model.getSessionId());
        log.info("SetPasscodeDelegate output: {}", model);
    }
}
