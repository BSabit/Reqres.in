package kz.eubank.registration.application.camunda.execution;

import kz.eubank.registration.presentation.rest.model.response.VerificationIINResponse;
import kz.eubank.registration.presentation.rest.model.response.VerificationProductResponse;

public interface IVerificationExecution {

    VerificationIINResponse verificationIIN(String sessionId, String iin);

    VerificationProductResponse verificationProduct(String sessionId, String iin, String productNumber);
}
