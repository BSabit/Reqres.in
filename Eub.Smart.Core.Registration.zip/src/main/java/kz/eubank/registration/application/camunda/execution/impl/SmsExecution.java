package kz.eubank.registration.application.camunda.execution.impl;

import kz.eubank.registration.application.camunda.execution.ISmsExecution;
import kz.eubank.registration.presentation.rest.model.response.SmsResponse;
import org.camunda.bpm.engine.ProcessEngine;
import org.springframework.stereotype.Component;

import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.E_BS_914;

@Component
public class SmsExecution extends BaseExecution implements ISmsExecution {

    public SmsExecution(ProcessEngine engine) {
        super(engine);
    }

    @Override
    public SmsResponse sms(String sessionId, String code) {
        var nextStep = "";
        if ("".equals(code)) {
            nextStep = sendSms(sessionId);
        } else {
            nextStep = checkSms(sessionId, code);
        }
        return new SmsResponse(nextStep);
    }

    private String sendSms(String sessionId) {
        var task = getTaskBySessionId(sessionId);
        var model = getBaseModelByExecutionId(task.getExecutionId());

        model.setClientSmsCode("");
        var sendSmsAttempts = model.getSendSmsAttempts() == null ? 0 : model.getSendSmsAttempts();
        model.setSendSmsAttempts(sendSmsAttempts + 1);
        setBaseModelByExecutionId(task.getExecutionId(), model);

        completeTaskById(task.getId());
        return getNextStepBySessionId(sessionId, model.getError());
    }

    private String checkSms(String sessionId, String code) {
        var task = getTaskBySessionId(sessionId);
        var model = getBaseModelByExecutionId(task.getExecutionId());

        model.setClientSmsCode(code);
        var checkSmsAttempts = model.getCheckSmsAttempts() == null ? 0 : model.getCheckSmsAttempts();
        model.setCheckSmsAttempts(checkSmsAttempts + 1);
        setBaseModelByExecutionId(task.getExecutionId(), model);

        completeTaskById(task.getId());

        return getNextStepBySessionId(sessionId, model.getError());
    }
}
