package kz.eubank.registration.application.camunda.delegate;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.service.IDeviceService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;


@Component
public class DeviceExistenceDelegate implements JavaDelegate {
    private final Logger log = LogManager.getLogger(getClass());
    private final IDeviceService deviceService;

    public DeviceExistenceDelegate(IDeviceService deviceService) {
        this.deviceService = deviceService;
    }


    @Override
    public void execute(DelegateExecution execution) throws Exception {
        var model = (BaseModel) execution.getVariableTyped("model").getValue();
        log.info("DeviceExistenceDelegate input: {} ", model);
        deviceService.checkAndAddDevice(model);
        log.info("DeviceExistenceDelegate output: {} ", model);
    }
}
