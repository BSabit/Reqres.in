package kz.eubank.registration.application.camunda.execution.impl;

import kz.eubank.registration.application.camunda.execution.IVerificationExecution;
import kz.eubank.registration.presentation.rest.model.response.VerificationIINResponse;
import kz.eubank.registration.presentation.rest.model.response.VerificationProductResponse;
import org.camunda.bpm.engine.ProcessEngine;
import org.springframework.stereotype.Component;

import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.E_BS_1017;

@Component
public class VerificationExecution extends BaseExecution implements IVerificationExecution {

    public VerificationExecution(ProcessEngine engine) {
        super(engine);
    }

    @Override
    public VerificationIINResponse verificationIIN(String sessionId, String iin) {
        var task = getTaskBySessionId(sessionId);
        var model = getBaseModelByExecutionId(task.getExecutionId());

        model.setClientIin(iin);
        setBaseModelByExecutionId(task.getExecutionId(), model);

        completeTaskById(task.getId());
        var nextStep = getNextStepBySessionId(sessionId, model.getError());
        return new VerificationIINResponse(nextStep);
    }

    @Override
    public VerificationProductResponse verificationProduct(String iin, String productNumber, String sessionId) {
        var task = getTaskBySessionId(sessionId);
        var model = getBaseModelByExecutionId(task.getExecutionId());

        model.setClientIin(iin);
        model.setProductNumber(productNumber);
        //setBaseModelByExecutionId(task.getExecutionId(), model);

        int productRecoveryAttempts = model.getProductRecoveryAttempts() == null ? 0 : model.getProductRecoveryAttempts();
        if (productRecoveryAttempts >= 5) {
            model.setError(E_BS_1017);
        }
        model.setProductRecoveryAttempts(productRecoveryAttempts + 1);
        setBaseModelByExecutionId(task.getExecutionId(), model);
        completeTaskById(task.getId());

        var nextStep = getNextStepBySessionId(sessionId, model.getError());
        return new VerificationProductResponse(nextStep);
    }
}
