package kz.eubank.registration.application.camunda.execution.impl;

import kz.eubank.registration.application.camunda.execution.IDigitalDocumentExecution;
import kz.eubank.registration.presentation.rest.model.response.IdentityCardResponse;
import org.camunda.bpm.engine.ProcessEngine;
import org.springframework.stereotype.Component;

@Component
public class DigitalDocumentExecution extends BaseExecution implements IDigitalDocumentExecution {

    public DigitalDocumentExecution(ProcessEngine engine) {
        super(engine);
    }

    @Override
    public IdentityCardResponse identityCard(String sessionId, String otpCode) {
        var task = getTaskBySessionId(sessionId);
        var model = getBaseModelByExecutionId(task.getExecutionId());

        model.setClientGKBSmsCode(otpCode);
        setBaseModelByExecutionId(task.getExecutionId(), model);

        completeTaskById(task.getId());
        var nextStep = getNextStepBySessionId(sessionId, model.getError());
        return new IdentityCardResponse(nextStep);
    }
}
