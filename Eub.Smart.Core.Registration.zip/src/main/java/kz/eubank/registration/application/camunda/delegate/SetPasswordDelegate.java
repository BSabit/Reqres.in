package kz.eubank.registration.application.camunda.delegate;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.service.IDeviceService;
import kz.eubank.registration.domain.service.IPasswordService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;
import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

@Component
public class SetPasswordDelegate implements JavaDelegate {

    private final Logger log = LogManager.getLogger(getClass());
    private final IDeviceService deviceService;
    private final IPasswordService passwordService;
    private final HttpServletRequest request;

    public SetPasswordDelegate(IDeviceService deviceService, IPasswordService passwordService, HttpServletRequest request) {
        this.deviceService = deviceService;
        this.passwordService = passwordService;
        this.request = request;
    }

    @Override
    @Transactional
    public void execute(DelegateExecution execution) throws Exception {
        var model = (BaseModel) execution.getVariableTyped("model").getValue();
        var userAgent = request.getHeader("User-Agent");
        log.info("SetPasswordDelegate input: {} ", model);
        deviceService.createDeviceId(model, userAgent);
        passwordService.savePassword(model);
        log.info("SetPasswordDelegate output: {} ", model);
    }
}
