package kz.eubank.registration.application.camunda.execution;

import kz.eubank.registration.presentation.rest.model.response.SmsResponse;

public interface ISmsExecution {

    SmsResponse sms(String sessionId, String code);
}
