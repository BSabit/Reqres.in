package kz.eubank.registration.application.camunda.execution;

import kz.eubank.registration.presentation.rest.model.response.IdentityCardResponse;

public interface IDigitalDocumentExecution {

    IdentityCardResponse identityCard(String sessionId, String otpCode);
}
