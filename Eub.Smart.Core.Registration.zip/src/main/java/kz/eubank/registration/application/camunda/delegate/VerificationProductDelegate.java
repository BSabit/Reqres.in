package kz.eubank.registration.application.camunda.delegate;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.service.IVerificationProductService;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class VerificationProductDelegate implements JavaDelegate {

    private final Logger log = LogManager.getLogger(getClass());
    private final IVerificationProductService service;

    @Override
    public void execute(DelegateExecution execution) throws Exception {
        var model = (BaseModel) execution.getVariableTyped("model").getValue();
        log.info("VerificationProductDelegate input: {}", model);
        service.recoveryAccount(model);
        execution.setVariable("model", model);
        log.info("VerificationProductDelegate output: {}", model);

        if ((model.getError() != null) && (model.getError().isInGroupError(SelfErrorCode.Error.recoveryProduct))) {
            throw new BpmnError(model.getError().toString());
        }
    }
}
