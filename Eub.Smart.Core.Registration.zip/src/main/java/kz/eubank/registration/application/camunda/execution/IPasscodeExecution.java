package kz.eubank.registration.application.camunda.execution;

public interface IPasscodeExecution {

    void createPasscode(String sessionId, String passcode);
}
