package kz.eubank.registration.application.camunda.delegate;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.service.IIdentityProviderService;
import kz.eubank.registration.domain.service.IRegistrationService;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class ClearUserCacheDelegate implements JavaDelegate {
    private final Logger log = LogManager.getLogger(getClass());
    private final IIdentityProviderService providerService;
    @Override
    public void execute(DelegateExecution execution) throws Exception {
        var model = (BaseModel) execution.getVariableTyped("model").getValue();
        log.info("CheckWhiteListDelegate input: {}", model);
        providerService.clearUserByUsername(model.getPhoneNumber(), model.getSessionId());
    }
}
