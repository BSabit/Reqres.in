package kz.eubank.registration.application.camunda.execution.impl;

import kz.eubank.registration.application.camunda.execution.IRegistrationExecution;
import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.util.HeaderUtil;
import kz.eubank.registration.presentation.rest.model.request.DefineRouteRequest;
import kz.eubank.registration.presentation.rest.model.response.DefineRouteResponse;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.variable.Variables;
import org.springframework.stereotype.Component;

import static kz.eubank.registration.domain.constant.UserTask.LOGIN;
import static kz.eubank.registration.domain.model.enums.RouteType.NTFC;
import static kz.eubank.registration.domain.model.enums.RouteType.WHLS;

@Component
public class RegistrationExecution extends BaseExecution implements IRegistrationExecution {

    public RegistrationExecution(ProcessEngine engine) {
        super(engine);
    }

    @Override
    public DefineRouteResponse defineRoute(DefineRouteRequest request) {
        var frontEnd = HeaderUtil.extractFrontEndFromUserAgent(request.userAgent());
        var model = BaseModel.builder()
                .phoneNumber(request.phoneNumber())
                .deviceId(request.deviceId())
                .versionFront(request.versionFront())
                .frontEnd(frontEnd)
                .build();
        var modelValue = Variables
                .objectValue(model)
                .serializationDataFormat(Variables.SerializationDataFormats.JAVA)
                .create();
        var process = startProcessAndGetVariables(modelValue);

        model = (BaseModel) process.getVariables().getValueTyped("model").getValue();

        if (NTFC.name().equals(model.getRoute())) {
            var task = getTaskBySessionId(model.getSessionId());
            model = getBaseModelByExecutionId(task.getExecutionId());
            model.setRoute(NTFC.name());
            setBaseModelByExecutionId(task.getExecutionId(), model);
        }

        var nextStep = getNextStepBySessionId(model.getSessionId(), model.getError());
        if (WHLS.name().equals(model.getRoute())) {
            nextStep = LOGIN;
        }
        return new DefineRouteResponse(nextStep, model.getSessionId());
    }
}
