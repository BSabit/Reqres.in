package kz.eubank.registration.application.camunda.delegate;

import com.fasterxml.jackson.core.JsonProcessingException;
import javassist.NotFoundException;
import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.service.IClientDigitalDocumentService;
import kz.eubank.registration.domain.service.IForensicService;
import kz.eubank.registration.domain.service.IKiscService;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;

@Component
@RequiredArgsConstructor
public class MatchPhotoDelegate implements JavaDelegate {

    private final Logger log = LogManager.getLogger(getClass());
    private final IKiscService kiscService;
    private final IForensicService forensicService;

    @Override
    public void execute(DelegateExecution execution) {
        //todo delete
        if (true) {
            log.info("test GKB service");
            throw new BpmnError("test GKB service");
        }

        var model = (BaseModel) execution.getVariableTyped("model").getValue();
        log.info("MatchPhotoDelegate input: {}", model);
        String photoEncoded = forensicService.downloadFileOrTrowException(model.getBestShotUrl());
        try {
            kiscService.isSimilar(model, photoEncoded);
        } catch (SelfException | JsonProcessingException e) {
            log.warn("ERROR MatchPhotoDelegate Session-Id: {}, code: SelfException | JsonProcessingException", model.getSessionId());
            log.error("Response not success or could not parse " + e);
            throw new BpmnError(e.getMessage());
        } catch (RestClientException e) {
            log.warn("ERROR MatchPhotoDelegate Session-Id: {}, code: RestClientException", model.getSessionId());
            log.error("KISC SYSTEM IS NOT AVAILABLE " + e);
            throw new BpmnError(e.getMessage());
        } catch (NotFoundException e) {
            log.error(e);
            throw new SelfException(SelfErrorCode.E_DB_600);
        }

        execution.setVariable("model", model);
        log.info("MatchPhotoDelegate output: {}", model);
    }
}
