package kz.eubank.registration.application.camunda.util;

import java.util.Map;

import static kz.eubank.registration.domain.constant.UserTask.*;

public class Element2StepUtil {

    public static final Map<String, String> methodMapStep = Map.of(
            SMS, "sms",
            DIGITAL_DOCUMENT, "identityCard",
            ERROR_TEXT, "getErrorText",
            STATUS_ANALYSE, "statusAnalyze",
            UPLOAD_SELFIE, "uploadSelfie",
            PASSCODE_SET, "createPasscode",
            VERIFICATION_IIN, "verificationIIN",
            VERIFICATION_PRODUCT, "verificationProduct",
            LOGIN, "notMethodImplements"
    );

    public static String convert(String taskDefinitionKey) {
        return switch (taskDefinitionKey) {
            case "Activity_0qpr1pf" -> VERIFICATION_PRODUCT;
            case "Activity_0mqk2py", "Activity_053qo6m", "Activity_0papde2",
                    "Activity_13l7hha", "Activity_193hn40" -> VERIFICATION_IIN;
            case "Activity_0h0gb13", "Activity_1962f95", "Activity_1yfkxul" -> PASSCODE_SET;
            case "Activity_0gmhaib", "Activity_01nj5qi" -> UPLOAD_SELFIE;
            case "Activity_02bt36i", "Activity_1em4v4z", "Activity_00djn3i",
                    "Activity_11m9sd6" -> STATUS_ANALYSE;
            case "Activity_0r3nopf", "Activity_1f9xgq8", "Activity_1skysdp",
                    "Activity_136sp5j", "Activity_0mvwrzc", "Activity_1txkh5n",
                    "Activity_11ih3ne", "Activity_1r6nv8x", "Activity_1mr7w24",
                    "Activity_0j7orbp", "Activity_082drpm", "Activity_1m8zx2q",
                    "Activity_08lgxti", "Activity_0519bt6", "Activity_0avsxzj",
                    "Activity_1iytcnu", "Activity_133ixtt", "Activity_0wv7zy5",
                    "Activity_0b10zqa", "Activity_1jjcw6a", "Activity_15ihsg3",
                    "Activity_02qdv2w", "Activity_14q8zf1", "Activity_0prrcbl",
                    "Activity_02jtn3f", "Activity_1t79f6t", "Activity_0f4k2sr",
                    "Activity_0m14u7z", "Activity_02efp0o" -> ERROR_TEXT;
            case "Activity_0bk7fnm", "Activity_0tyl8u1" -> DIGITAL_DOCUMENT;
            case "Activity_0dk40on", "Activity_04vfadj", "Activity_1o4un15" -> SMS;
            default -> taskDefinitionKey;
        };
    }
}
