package kz.eubank.registration.application.camunda.delegate;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.service.IBiometryService;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class GetQualityAnalyzeDelegate implements JavaDelegate {

    private final Logger log = LogManager.getLogger(getClass());
    private final IBiometryService biometryService;

    @Override
    public void execute(DelegateExecution execution) throws Exception {
        var model = (BaseModel) execution.getVariableTyped("model").getValue();
        log.info("GetQualityAnalyzeDelegate input: {}", model);
        biometryService.getQualityAnalyses(model);
        execution.setVariable("model", model);
        log.info("GetQualityAnalyzeDelegate output: {}", model);
    }
}
