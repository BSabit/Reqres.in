package kz.eubank.registration.application.camunda.execution.impl;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.application.camunda.util.Element2StepUtil;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.runtime.ProcessInstanceWithVariables;
import org.camunda.bpm.engine.task.Task;
import org.camunda.bpm.engine.variable.value.ObjectValue;
import org.springframework.stereotype.Component;

import java.util.Objects;

import static kz.eubank.registration.domain.constant.UserTask.DEFINE_ROUTE;
import static kz.eubank.registration.domain.util.DateUtil.currentDate;
import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.E_BS_903;

@Component
@RequiredArgsConstructor
public class BaseExecution {

    private final static String BASE_MODEL_NAME = "model";
    private final static String REGISTRATION_PROCESS_NAME = "registration";
    private final ProcessEngine engine;

    public ProcessInstanceWithVariables startProcessAndGetVariables(ObjectValue value) {
        return engine.getRuntimeService()
                .createProcessInstanceByKey(REGISTRATION_PROCESS_NAME)
                .setVariable(BASE_MODEL_NAME, value)
                .executeWithVariablesInReturn();
    }

    public Task getTaskBySessionId(String sessionId) {
        var taskList = engine.getTaskService().createTaskQuery().taskAssignee(sessionId).list();
        if (taskList.isEmpty()) {
            return null;
        }
        var task = taskList.get(0);
        if (Objects.nonNull(task) && task.getId() == null) throw new SelfException(E_BS_903);
        return task;
    }

    public BaseModel getBaseModelByExecutionId(String executionId) {
        var model = (BaseModel) engine.getRuntimeService()
                .getVariableTyped(executionId, BASE_MODEL_NAME).getValue();
        if (Objects.nonNull(model.getSessionDateExpiration())) {
            if (currentDate().after(model.getSessionDateExpiration())) {
                throw new SelfException(SelfErrorCode.E_BS_906);
            }
        }
        return model;
    }

    public void setBaseModelByExecutionId(String executionId, BaseModel model) {
        engine.getRuntimeService().setVariable(executionId, BASE_MODEL_NAME, model);
    }

    public String getNextStepBySessionId(String sessionId) {
        var task = getTaskBySessionId(sessionId);
        var taskDefinitionKey = (task == null) ? DEFINE_ROUTE : task.getTaskDefinitionKey();
        return Element2StepUtil.convert(taskDefinitionKey);
    }

    public String getNextStepBySessionId(String sessionId, SelfErrorCode errorCode) {
        var task = getTaskBySessionId(sessionId);

        StringBuilder nextStep;
        nextStep = new StringBuilder(DEFINE_ROUTE);

        var taskDefinitionKey = (task == null) ? nextStep.toString() : task.getTaskDefinitionKey();
        return Element2StepUtil.convert(taskDefinitionKey);
    }

    public void completeTaskById(String id) {
        engine.getTaskService().complete(id);
    }
}
