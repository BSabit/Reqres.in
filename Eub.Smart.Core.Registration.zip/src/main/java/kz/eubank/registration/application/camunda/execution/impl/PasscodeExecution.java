package kz.eubank.registration.application.camunda.execution.impl;

import kz.eubank.registration.application.camunda.execution.IPasscodeExecution;
import org.camunda.bpm.engine.ProcessEngine;
import org.springframework.stereotype.Component;

@Component
public class PasscodeExecution extends BaseExecution implements IPasscodeExecution {

    public PasscodeExecution(ProcessEngine engine) {
        super(engine);
    }

    @Override
    public void createPasscode(String sessionId, String passcode) {
        var task = getTaskBySessionId(sessionId);
        var model = getBaseModelByExecutionId(task.getExecutionId());

        model.setPasscode(passcode);
        setBaseModelByExecutionId(task.getExecutionId(), model);

        completeTaskById(task.getId());
    }
}
