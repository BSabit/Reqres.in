package kz.eubank.registration.application.camunda.execution.impl;

import kz.eubank.registration.application.camunda.execution.IBiometryExecution;
import kz.eubank.registration.domain.service.IForensicService;
import kz.eubank.registration.presentation.rest.model.response.StatusAnalyseResponse;
import kz.eubank.registration.presentation.rest.model.response.UploadSelfieResponse;
import org.camunda.bpm.engine.ProcessEngine;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.multipart.MultipartFile;

import static kz.eubank.registration.domain.util.PayloadUtil.addMetadataToPayload;

@Component
public class BiometryExecution extends BaseExecution implements IBiometryExecution {

    private final IForensicService forensicService;

    public BiometryExecution(ProcessEngine engine, IForensicService forensicService) {
        super(engine);
        this.forensicService = forensicService;
    }

    @Override
    public UploadSelfieResponse uploadSelfie(String sessionId, String payload, MultiValueMap<String, MultipartFile> media) {
        var task = getTaskBySessionId(sessionId);
        var model = getBaseModelByExecutionId(task.getExecutionId());
        var biometryAttempts = model.getBiometryAttempts() == null ? 0 : model.getBiometryAttempts();
        model.setBiometryAttempts(biometryAttempts + 1);

        payload = addMetadataToPayload(payload,
                model.getClientIin(),
                model.getPhoneNumber(),
                model.getRoute());
        var folderResponse = forensicService.uploadMedia(payload, media);
        model.setFolderId(folderResponse.getFolder_id());
        model.setPayload(payload);

        setBaseModelByExecutionId(task.getExecutionId(), model);

        completeTaskById(task.getId());
        var nextStep = getNextStepBySessionId(sessionId, model.getError());
        return new UploadSelfieResponse(nextStep);
    }

    @Override
    public StatusAnalyseResponse statusAnalyze(String sessionId) {
        var task = getTaskBySessionId(sessionId);
        var model = getBaseModelByExecutionId(task.getExecutionId());

        completeTaskById(task.getId());
        var nextStep = getNextStepBySessionId(sessionId, model.getError());
        return new StatusAnalyseResponse(nextStep);
    }
}
