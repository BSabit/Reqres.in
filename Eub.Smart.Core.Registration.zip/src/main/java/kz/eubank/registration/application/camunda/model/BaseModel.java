package kz.eubank.registration.application.camunda.model;

import kz.eubank.registration.domain.model.dto.WhiteListAuthorizationDto;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import lombok.*;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class BaseModel implements Serializable {

    static final long serialVersionUID = 6L;

    private String sessionId;
    private SelfErrorCode error;

    private String phoneNumber;
    private String iin;
    private String clientIin;
    private String userStatus;
    private String deviceId;
    private String versionFront;
    private String frontEnd;
    private String route;
    private Date sessionDateExpiration;
    private String generatedSmsCode;
    private String clientSmsCode;
    private Integer checkSmsAttempts;
    private Integer sendSmsAttempts;
    private Integer biometryAttempts;
    private Integer identityCardAttempts;
    private Integer verificationIINAttempts;
    private String biometricsType;
    private String folderId;
    private Map<String, Long> mediaList;
    private Map<String, String> analyses;
    @ToString.Exclude
    private String payload;
    private Boolean isFinished;
    private Boolean isQualitySuccess;
    private Boolean isBiometricsSuccess;
    private String bestShotUrl;
    private WhiteListAuthorizationDto whiteList;
    private String productNumber;
    private Boolean isProductValid;
    private String isProductResponse;
    private String passcode;
    private String clientGKBSmsCode;
    private String analyseState;
    private Integer productRecoveryAttempts;
    private String productRecoveryStatus;
    private Boolean isKiscIinNotFound;
    private String idCardObjectName;
}
