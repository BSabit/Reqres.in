package kz.eubank.registration.application.camunda.delegate;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.service.IValidationMobileOperatorService;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import static kz.eubank.registration.domain.util.UUIDUtil.getRandomUUID;

@Component
@RequiredArgsConstructor
public class ValidationMobileOperatorDelegate implements JavaDelegate {

    private final Logger log = LogManager.getLogger(getClass());
    private final IValidationMobileOperatorService validationMobileOperatorService;

    @Override
    public void execute(DelegateExecution execution) throws Exception {
        var model = (BaseModel) execution.getVariableTyped("model").getValue();
        log.info("ValidationMobileOperatorDelegate input: {}", model);
        validationMobileOperatorService.validationMobileOperator(model);
        execution.setVariable("model", model);
        log.info("ValidationMobileOperatorDelegate output: {}", model);

        if (model.getError() != null) {
            model.setSessionId(MDC.get("Operation-Id"));
            execution.setVariable("model", model);
            throw new BpmnError(model.getError().toString());
        }
    }
}
