package kz.eubank.registration.domain.model.dto.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AnalysisConfDto {

    private Double threshold_replay;
    private Boolean extract_best_shot;
    private Double threshold_liveness;
    private Double threshold_spoofing;
    private Double threshold_max;
    private Double threshold_min;
}
