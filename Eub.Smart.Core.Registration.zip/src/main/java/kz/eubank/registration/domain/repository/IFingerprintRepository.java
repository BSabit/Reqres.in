package kz.eubank.registration.domain.repository;

public interface IFingerprintRepository {
    void updateBUPRStatus(long userId);
}
