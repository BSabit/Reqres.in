package kz.eubank.registration.domain.util;

import kz.eubank.registration.domain.model.dto.PayloadDto;
import kz.eubank.registration.domain.model.dto.PayloadMetaDataDto;

public class PayloadUtil {

    public static String addMetadataToPayload(String payload, String iin, String phoneNumber, String operation) {
        var payloadDto = JsonUtil.toObjectOrThrowException(payload, PayloadDto.class);
        var metaData = PayloadMetaDataDto.builder()
                .iin(iin)
                .phoneNumber(phoneNumber)
                .operation(operation)
                .build();
        payloadDto.setMetaData(metaData);
        return JsonUtil.toJsonOrThrowException(payloadDto);
    }
}
