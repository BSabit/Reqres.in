package kz.eubank.registration.domain.factory;

import kz.eubank.registration.domain.constant.FileName;
import kz.eubank.registration.domain.model.dto.MultipartImage;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.util.filetypedetector.FileType;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.apache.pdfbox.util.filetypedetector.FileType.PNG;
import static org.springframework.http.MediaType.IMAGE_PNG_VALUE;

@Service
public class PdfPngConvertorImpl implements PdfConvertor {

    private final int dpi;

    public PdfPngConvertorImpl(@Value("${pdf.png.dpi}") int dpi) {
        this.dpi = dpi;
    }

    @Override
    public List<MultipartFile> toMultipartFiles(byte[] pdfBytes) throws IOException {
        List<MultipartFile> multipartImages = new ArrayList<>();
        try (PDDocument document = PDDocument.load(pdfBytes)) {
            PDFRenderer pdfRenderer = new PDFRenderer(document);

            int numberOfPages = document.getNumberOfPages();
            for (int i = 0; i < numberOfPages; i++) {
                BufferedImage bImage = pdfRenderer.renderImageWithDPI(i, dpi, ImageType.RGB);
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                String fileExtension = PNG.name();
                ImageIO.write(bImage, fileExtension, baos);
                baos.flush();
                String originalName = FileName.IMAGE + (i + 1);
                MultipartFile multipartImage = new MultipartImage(baos.toByteArray(), FileName.IMAGE, originalName, IMAGE_PNG_VALUE);
                multipartImages.add(multipartImage);
            }
            return multipartImages;
        }
    }

    @Override
    public FileType fileType() {
        return PNG;
    }
}
