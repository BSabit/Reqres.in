package kz.eubank.registration.domain.model.enums;

public enum BiometricsType {

    ARCH,    //Хранилище данных
    KISC,    //ЦОИД
    DGTL     //Цифровые документы
}
