package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.domain.service.AbstractValidator;
import kz.eubank.registration.infrastructure.model.dto.kisc.MathPhotoResponseDto;
import kz.eubank.registration.presentation.rest.exception.ErrorDto;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class KiscValidator extends AbstractValidator {

    private static final String SUCCESS_CODE = "200";

    @Override
    public List<ErrorDto> validate(Object dto) {
        List<ErrorDto> errors = new ArrayList<>();
        validateByAnnotation(dto, errors);
        return errors;
    }

    public void validateMathPhotoResponse(MathPhotoResponseDto dto) {
        List<ErrorDto> errorDtos = validate(dto);
        if (!errorDtos.isEmpty() || !SUCCESS_CODE.equals(dto.getCode())) throw new SelfException(SelfErrorCode.E_DB_600);
    }
}
