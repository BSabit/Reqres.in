package kz.eubank.registration.domain.model.pojo;

import org.springframework.web.multipart.MultipartFile;

import java.io.*;

public class MinioObjectMultipartFile implements MultipartFile {

    private byte[] input;
    private final String name;
    private final String contentType;

    public MinioObjectMultipartFile(byte[] input, String name, String contentType) {
        this.input = input;
        this.name = name;
        this.contentType = contentType;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getOriginalFilename() {
        return name;
    }

    @Override
    public String getContentType() {
        return contentType;
    }

    @Override
    public boolean isEmpty() {
        return input == null || input.length == 0;
    }

    @Override
    public long getSize() {
        return input.length;
    }

    @Override
    public byte[] getBytes() throws IOException {
        return input;
    }

    @Override
    public InputStream getInputStream() throws IOException {
        return new ByteArrayInputStream(input);
    }

    @Override
    public void transferTo(File dest) throws IOException, IllegalStateException {
        new FileOutputStream(dest).write(input);
    }
}
