package kz.eubank.registration.domain.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PayloadMetaDataDto {

    @JsonProperty("iin")
    private String iin;
    @JsonProperty("phoneNumber")
    private String phoneNumber;
    @JsonProperty("Operation")
    private String operation;
}
