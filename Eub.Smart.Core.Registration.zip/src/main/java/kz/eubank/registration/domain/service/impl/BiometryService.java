package kz.eubank.registration.domain.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.model.dto.PayloadDto;
import kz.eubank.registration.domain.model.dto.PayloadMetaDataDto;
import kz.eubank.registration.domain.model.dto.response.AnalysisResponseDto;
import kz.eubank.registration.domain.model.enums.AnalyseState;
import kz.eubank.registration.domain.model.enums.BiometricsStatus;
import kz.eubank.registration.domain.model.enums.ResolutionStatus;
import kz.eubank.registration.domain.model.pojo.Biometrics;
import kz.eubank.registration.domain.repository.IDMZVerificationRepository;
import kz.eubank.registration.domain.service.*;
import kz.eubank.registration.domain.util.JsonUtil;
import kz.eubank.registration.infrastructure.config.AppProperties;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.util.HashMap;

import static java.util.Objects.nonNull;
import static kz.eubank.registration.domain.model.enums.BiometricsStatus.*;
import static kz.eubank.registration.domain.model.enums.BiometricsType.ARCH;
import static kz.eubank.registration.domain.model.enums.BiometricsType.KISC;
import static kz.eubank.registration.domain.model.enums.DMZVerificationAttemptsType.VBIO;
import static kz.eubank.registration.domain.model.enums.RouteStatus.*;
import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.*;

@Service
@RequiredArgsConstructor
public class BiometryService implements IBiometryService {

    private final Logger log = LogManager.getLogger(getClass());

    private final AppProperties properties;
    private final IBiometricsService biometricsService;
    private final IForensicService forensicService;
    private final IDMZVerificationRepository dmzVerificationRepository;
    private final IDMZVerificationAttemptsService dmzVerificationAttemptsService;
    private final IAttemptsLimitService attemptsLimitService;
    private final ObjectMapper mapper = new ObjectMapper();
    private final IClientDigitalDocumentService clientDigitalDocumentService;

    @Override
    public void checkMediaInArchiveDB(BaseModel model) {
        //TODO check DB
        var hasMedia = false;
        if (hasMedia) {
            model.setBiometricsType(ARCH.name());
        } else {
            model.setBiometricsType(KISC.name());
        }
    }

    @Override
    public void startAnalyses(BaseModel model) {
        var analyseResponse = forensicService.startAnalyses(model.getBiometricsType(), model.getFolderId());
        var analyses = new HashMap<String, String>();
        for (AnalysisResponseDto analyse : analyseResponse) {
            analyses.put(analyse.getType().toString(), analyse.getAnalyse_id());
        }
        model.setAnalyses(analyses);
    }

    @Override
    public void getQualityAnalyses(BaseModel model) {
        String status = BINM.name();
        Biometrics biometrics = biometricsService.getBiometrics(model.getFolderId());
        String qualityAnalyseId = biometrics.getQualityAnalyseId();
        if (qualityAnalyseId == null) {
            log.info("QualityAnalyseId null for folderId: {}", model.getFolderId());
            throw new SelfException(SelfErrorCode.E_BS_920, "folderId: " + model.getFolderId());
        }
        AnalysisResponseDto qualityAnalysis = forensicService.getAnalysisOrTrowException(qualityAnalyseId);
        AnalyseState analyseState = qualityAnalysis.getState();
        ResolutionStatus analyseResolutionStatus = qualityAnalysis.getResolution();
        log.info("getQualityAnalyses analyseState: {}", analyseState);
        if (checkAnalyseState(model, status, biometrics, analyseState)) return;
        String jsonData = null;
        try {
            jsonData = mapper.writeValueAsString(qualityAnalysis);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        String bestShotUrl = forensicService.getThumbUrl(qualityAnalysis);
        switch (analyseResolutionStatus) {
            case SUCCESS -> {
                model.setIsQualitySuccess(true);
                model.setBestShotUrl(bestShotUrl);
                status = SCBO.name();

            }
            case OPERATOR_REQUIRED, DECLINED -> {
                model.setError(E_BS_941);
                model.setIsQualitySuccess(false);
                model.setIsBiometricsSuccess(false);

                dmzVerificationAttemptsService.fixAttempt(model.getSessionId(), VBIO);

                var bioAttempt = attemptsLimitService.getLimitsCountByMobilePhoneAndType(model.getPhoneNumber(), VBIO);
                if (nonNull(bioAttempt) && bioAttempt.count() >= properties.getVerificationLimitCountByType(VBIO)) {
                    model.setError(SelfErrorCode.E_BS_924);
                }
            }
        }
        biometricsService.updateData(jsonData, status, biometrics.getId());

        if (!status.equals(SCBO.toString())) {
            dmzVerificationRepository.updateStatus(FAIL.toString(), biometrics.getDmzVerification().getId());
        }
    }


    @Override
    public void getBiometryAnalyses(BaseModel model) {
        var status = BINM;
        var dmzVerificationStatus = VSMS;
        var biometrics = biometricsService.getBiometrics(model.getFolderId());
        String biometryAnalyseId = biometrics.getBiometryAnalyseId();
        if (biometryAnalyseId == null) {
            log.info("BiometryAnalyseId null for folderId: {}", model.getFolderId());
            throw new SelfException(SelfErrorCode.E_BS_920, "folderId: " + model.getFolderId());
        }
        var biometryAnalysis = forensicService.getAnalysisOrTrowException(biometryAnalyseId);
        AnalyseState analyseState = biometryAnalysis.getState();
        ResolutionStatus analyseResolutionStatus = biometryAnalysis.getResolution();
        log.info("getQualityAnalyses analyseState: {}", analyseState);
        if (checkAnalyseState(model, status.name(), biometrics, analyseState)) return;
        String jsonData = null;
        try {
            jsonData = mapper.writeValueAsString(biometryAnalysis);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        String bestShotUrl = forensicService.getThumbUrl(biometryAnalysis);
        switch (analyseResolutionStatus) {
            case SUCCESS -> {
                model.setIsBiometricsSuccess(true);
                model.setBestShotUrl(bestShotUrl);
                status = SCBO;
                dmzVerificationStatus = VSCS;
            }
            case OPERATOR_REQUIRED, DECLINED -> {
                model.setIsBiometricsSuccess(false);
                status = VDDF;
                dmzVerificationStatus = FAIL;
                model.setError(E_BS_942);
            }
        }
        biometricsService.updateData(jsonData, status.name(), biometrics.getId());
        dmzVerificationRepository.updateStatus(dmzVerificationStatus.name(), biometrics.getDmzVerification().getId());
        if (isAnalysisFailed(biometryAnalysis.getState(), biometryAnalysis.getResolution_status())) {
            dmzVerificationAttemptsService.fixAttempt(model.getSessionId(), VBIO);
        }
        var bioAttempt = attemptsLimitService.getLimitsCountByMobilePhoneAndType(model.getPhoneNumber(), VBIO);
        if (nonNull(bioAttempt) && bioAttempt.count() >= properties.getVerificationLimitCountByType(VBIO)) {
            model.setError(E_BS_901);
        }
    }

    private boolean checkAnalyseState(BaseModel model, String status, Biometrics biometrics, AnalyseState analyseState) {
        switch (analyseState) {
            case PROCESSING -> {
                model.setIsFinished(false);
                return true;
            }
            case FINISHED -> {
                model.setIsFinished(true);
                return false;
            }
            default -> {
                model.setIsFinished(true);
                model.setIsQualitySuccess(false);
                model.setIsBiometricsSuccess(false);
                model.setError(E_BS_941);
                biometricsService.updateStatus(status, biometrics.getId());

                dmzVerificationAttemptsService.fixAttempt(model.getSessionId(), VBIO);

                var bioAttempt = attemptsLimitService.getLimitsCountByMobilePhoneAndType(model.getPhoneNumber(), VBIO);
                if (nonNull(bioAttempt) && bioAttempt.count() >= properties.getVerificationLimitCountByType(VBIO)) {
                    model.setError(SelfErrorCode.E_BS_924);
                }
                return true;
            }
        }
    }

    private boolean isAnalysisFailed(AnalyseState state, ResolutionStatus resolutionStatus) {
        return state == AnalyseState.FAILED ||
                (state == AnalyseState.FINISHED && resolutionStatus != ResolutionStatus.SUCCESS);
    }

//    @Override
//    public void getBiometryAnalyses(BaseModel model) {
//        var biometrics = biometricsService.getBiometrics(model.getFolderId());
//        var biometryAnalysis =
//                forensicService.getAnalysisOrTrowException(biometrics.getBiometryAnalyseId());
//        var jsonData = JsonUtil.toJsonOrThrowException(biometryAnalysis);
//        model.setAnalyseState(biometryAnalysis.getState().name());
//
//        var status = BINM;
//        var dmzVerificationStatus = VSMS;
//        if (biometryAnalysis.getState() == AnalyseState.FINISHED) {
//            if (biometryAnalysis.getResolution_status() == ResolutionStatus.SUCCESS) {
//                model.setIsBiometricsSuccess(true);
//                status = SCBO;
//                dmzVerificationStatus = VSCS;
//            } else {
//                model.setIsBiometricsSuccess(false);
//                status = VDDF;
//                dmzVerificationStatus = FAIL;
//                model.setError(E_BS_942);
//            }
//        } else {
//         model.setIsFinished(false);
//         model.setIsBiometricsSuccess(false);
//        }
//
//        biometricsService.updateData(jsonData, status.name(), biometrics.getId());
//        dmzVerificationRepository.updateStatus(dmzVerificationStatus.name(), biometrics.getDmzVerification().getId());
//
//        if (isAnalysisFailed(biometryAnalysis.getState(), biometryAnalysis.getResolution_status())) {
//            dmzVerificationAttemptsService.fixAttempt(model.getSessionId(), VBIO);
//        }
//
//        var bioAttempt = attemptsLimitService.getLimitsCountByMobilePhoneAndType(model.getPhoneNumber(), VBIO);
//        if (nonNull(bioAttempt) && bioAttempt.count() >= properties.getVerificationLimitCountByType(VBIO)) {
//            model.setError(E_BS_901);
//        }
//    }
}
