package kz.eubank.registration.domain.constant;

public interface SCB {
    int CODE_KAZAKHSTAN = 398;
    int STATUS_ACTIVE = 0;
    int IDENTITY_TYPE = 2;
    int PASSPORT_TYPE = 1;
    String PAPER_STATUS_APPR = "APPR";
    String BSYSTEM_SMBK = "SMBK";
    String REGISTERED_BY_SMBK = "Зарегистрирован в SmartBank 3.0";
    String REG_CHANNEL_WEBB = "WEBB";
}
