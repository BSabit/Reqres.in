package kz.eubank.registration.domain.model.pojo.data;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class PhotoValidationResponse {

    private String code;
    private Date date;
    private Long id;
    private String iin;
    private String message;
    private String similarity;
    private String vendorName;
    private String url;
}
