package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.service.IAttemptsLimitService;
import kz.eubank.registration.domain.service.IDMZVerificationAttemptsService;
import kz.eubank.registration.domain.service.IVerificationIINService;
import kz.eubank.registration.infrastructure.config.AppProperties;
import kz.eubank.registration.infrastructure.repository.mssql.impl.view.UserDefineRouteViewRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import static java.util.Objects.nonNull;
import static kz.eubank.registration.domain.model.enums.DMZVerificationAttemptsType.VIIN;
import static kz.eubank.registration.domain.model.enums.RouteType.RBYB;
import static kz.eubank.registration.domain.model.enums.RouteType.REGR;
import static kz.eubank.registration.domain.util.IINUtil.*;
import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.*;

@Component
@RequiredArgsConstructor
public class VerificationIINService implements IVerificationIINService {

    private final AppProperties properties;
    private final UserDefineRouteViewRepository userDefineRouteViewRepository;
    private final IDMZVerificationAttemptsService dmzVerificationAttemptsService;
    private final IAttemptsLimitService attemptsLimitService;

    @Override
    public void verificationIIN(BaseModel model) {
        if (REGR.name().equals(model.getRoute())) {
            verificationIINInREGRRoute(model);
        } else if (RBYB.name().equals(model.getRoute())) {
            verificationIINInRBYBRoute(model);
        }

        var iinAttempts = attemptsLimitService.getLimitsCountByMobilePhoneAndType(model.getPhoneNumber(), VIIN);
        if (nonNull(iinAttempts) && iinAttempts.count() >= properties.getVerificationLimitCountByType(VIIN)) {
            model.setError(E_BS_901);
        }
    }

    private void verificationIINInREGRRoute(BaseModel model) {
        if (isValid(model.getClientIin()) && getAgeFromIIN(model.getClientIin()) < properties.getSuitableAgeForVerificationIIN()) {
            model.setError(E_BS_908);
            return;
        }

        if (isNotValid(model.getClientIin())) {
            dmzVerificationAttemptsService.fixAttempt(model.getSessionId(), VIIN);
            model.setError(E_BS_913);
            return;
        }
        if (userDefineRouteViewRepository.getActiveIINCount(model.getClientIin()) > 0) {
            dmzVerificationAttemptsService.fixAttempt(model.getSessionId(), VIIN);
            model.setError(E_BS_907);
            return;
        }
        model.setIin(model.getClientIin());
    }

    private void verificationIINInRBYBRoute(BaseModel model) {
        if (isValid(model.getClientIin()) && getAgeFromIIN(model.getClientIin()) < properties.getSuitableAgeForVerificationIIN()) {
            model.setError(E_BS_908);
            return;
        }

        if (!model.getIin().equals(model.getClientIin())) {
            dmzVerificationAttemptsService.fixAttempt(model.getSessionId(), VIIN);
            model.setError(E_BS_912);
            return;
        }
        if (isNotValid(model.getClientIin())) {
            dmzVerificationAttemptsService.fixAttempt(model.getSessionId(), VIIN);
            model.setError(E_BS_913);
        }
    }
}
