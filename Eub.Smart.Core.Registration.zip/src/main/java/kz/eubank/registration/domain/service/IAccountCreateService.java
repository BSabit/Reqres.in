package kz.eubank.registration.domain.service;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.infrastructure.repository.mssql.procedure.RequestCreateUserProcedure;
import java.sql.SQLException;

public interface IAccountCreateService {
    RequestCreateUserProcedure createAccount(BaseModel model) throws SQLException;
}
