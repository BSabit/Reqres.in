package kz.eubank.registration.domain.service;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.model.dto.DMZVerificationDto;
import kz.eubank.registration.domain.model.enums.RouteStatus;

public interface IDMZVerificationService {

    void createDMZVerification(BaseModel model);

    int getVerificationLimitCountByMobilePhone(String phoneNumber);

    DMZVerificationDto getNotFinishedSessionByMobilePhoneAndDeviceId(String phoneNumber, String deviceId);

    void updateDMZVerificationRouteStatus(String sessionId, RouteStatus status);

    void updateDMZVerificationRouteType(String sessionId, String type);
}
