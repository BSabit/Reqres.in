package kz.eubank.registration.domain.util;

import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import org.springframework.core.io.FileSystemResource;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileUtil {

    public static File toFileOrThrowException(MultipartFile file) {
        File convFile = new File("/tmp/" + file.getName());

        try (FileOutputStream fos = new FileOutputStream(convFile)) {
            fos.write(file.getBytes());
        } catch (IOException e) {
            throw new SelfException(SelfErrorCode.E_EX_700);
        }
        return convFile;
    }

    public static FileSystemResource toFileSystemResourceOrThrowException(MultipartFile multipartFile) {
        File file = toFileOrThrowException(multipartFile);
        return new FileSystemResource(file);
    }
}
