package kz.eubank.registration.domain.model.pojo;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class FrontEnd {

    private String id;
    private String title;
    private Channel chanel;
    private Long term;
    private int platformCode;
}