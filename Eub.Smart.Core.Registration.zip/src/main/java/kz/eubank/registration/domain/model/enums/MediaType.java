package kz.eubank.registration.domain.model.enums;

public enum MediaType {

    IMAGE_USER_PROFILE,
    IMAGE_FOLDER,
    IMAGE_SHOTS_SET,
    IMAGE_RESULT_ANALYSE_SINGLE,
    IMAGE_RESULT_ANALYSE_GROUP,
    IMAGE_COLLECTION_PERSON,
    SHOTS_SET_FOLDER,
    VIDEO_FOLDER
}
