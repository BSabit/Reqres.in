package kz.eubank.registration.domain.service;

import kz.eubank.registration.application.camunda.model.BaseModel;

import java.util.Map;

public interface IRegistrationService {

    void defineRoute(BaseModel model);

    void checkWhiteList(BaseModel model);

    void checkLimits(BaseModel model);

    void checkSessionExistence(BaseModel model);
}
