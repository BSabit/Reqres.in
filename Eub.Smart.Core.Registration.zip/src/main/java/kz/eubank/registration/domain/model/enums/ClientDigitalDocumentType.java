package kz.eubank.registration.domain.model.enums;

public enum ClientDigitalDocumentType {

    IDCD,   //цифровой удостоверяющий документ
    PHTO    //Фото клиента
}
