package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.model.enums.PasscodeStatusEnum;
import kz.eubank.registration.domain.model.enums.RouteStatus;
import kz.eubank.registration.domain.model.enums.UserStatus;
import kz.eubank.registration.domain.model.pojo.DMZVerification;
import kz.eubank.registration.domain.model.pojo.NewPasscode;
import kz.eubank.registration.domain.model.pojo.User;
import kz.eubank.registration.domain.repository.IDMZVerificationRepository;
import kz.eubank.registration.domain.repository.IPasscodeRepository;
import kz.eubank.registration.domain.repository.IUserRepository;
import kz.eubank.registration.domain.service.IHashService;
import kz.eubank.registration.domain.service.IPasscodeService;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.Optional;

import static kz.eubank.registration.domain.model.enums.PasscodeStatusEnum.BUPR;
import static kz.eubank.registration.domain.util.DateUtil.currentDate;

@Service
@Qualifier("passcode")
@RequiredArgsConstructor
public class PasscodeService implements IPasscodeService {

    private final IDMZVerificationRepository dmzVerificationRepository;
    private final IPasscodeRepository passcodeRepository;
    private final IUserRepository userRepository;
    private final IHashService hashService;

    @Override
    public void saveWhiteListPasscode(BaseModel model) {
        changeStatusByDeviceId(BUPR.toString(), model.getDeviceId());
        changeStatusByUserId(BUPR.toString(), String.valueOf(model.getWhiteList().getUserId()));

        NewPasscode passcode = NewPasscode.builder()
                .hash(model.getWhiteList().getNewHash())
                .deviceId(model.getDeviceId())
                .userId(model.getWhiteList().getUserId())
                .status(PasscodeStatusEnum.ACTV.toString())
                .dateCreated(currentDate())
                .build();

        NewPasscode returnPasscode = passcodeRepository.saveAndGet(passcode);
        dmzVerificationRepository.updatePasscode(model.getSessionId(), returnPasscode.getId());
        dmzVerificationRepository.updateStatusWithSessionId(RouteStatus.PSET.toString(), model.getSessionId());
    }

    @Override
    public void savePasscode(String dmzSessionId, String pin) {
        String deviceId = dmzVerificationRepository.findDeviceId(dmzSessionId);
        long userId = dmzVerificationRepository.findUserIdByIin(dmzSessionId);

        if (deviceId == null) throw new SelfException(SelfErrorCode.E_BS_901, "SessionID not found: " + dmzSessionId);
        if (userId == 0)
            throw new SelfException(SelfErrorCode.E_BS_901, "UserId through sessionId not found: " + dmzSessionId);

        this.changeStatusByDeviceId(BUPR.toString(), deviceId);
        this.changeStatusByUserId(BUPR.toString(), String.valueOf(userId));

        String hashPasscode = hashService.getHash(pin);
        NewPasscode passcode = NewPasscode.builder()
                .hash(hashPasscode)
                .deviceId(deviceId)
                .userId(userId)
                .status("ACTV")
                .dateCreated(currentDate())
                .build();
        NewPasscode returnPasscode = passcodeRepository.saveAndGet(passcode);
        dmzVerificationRepository.updatePasscode(dmzSessionId, returnPasscode.getId());
        dmzVerificationRepository.updateStatusWithSessionId(RouteStatus.PSET.toString(), dmzSessionId);
        Optional<DMZVerification> dmzVerification = dmzVerificationRepository.findBySessionId(dmzSessionId);
        Optional<User> user;
        if (dmzVerification.isPresent()) {
            user = userRepository.findUserWithIin(dmzVerification.get().getIin());
        } else {
            throw new SelfException(SelfErrorCode.E_DB_600);
        }
        if (user.isPresent() && !user.get().getStatus().equals(UserStatus.ACTV.toString())) {
            userRepository.updateUserStatus(UserStatus.ACTV.toString(), user.get().getId());
        }
    }

    @Override
    public boolean validatePasscode(String dmzSessionId, String pin) {
        String storedHash = passcodeRepository.findHash(dmzSessionId);
        return hashService.validatePasscode(pin, storedHash);
    }

    @Override
    public void changeStatusByDeviceId(String status, String deviceId) {
        passcodeRepository.changeStatus(status, deviceId);
    }

    @Override
    public void changeStatusByUserId(String status, String userID) {
        passcodeRepository.changeStatusByUserId(status, userID);
    }
}
