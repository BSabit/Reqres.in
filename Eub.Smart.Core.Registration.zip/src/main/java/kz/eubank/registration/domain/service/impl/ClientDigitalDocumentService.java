package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.model.pojo.ClientDigitalDocument;
import kz.eubank.registration.domain.model.pojo.ClientDigitalDocumentType;
import kz.eubank.registration.domain.model.pojo.MinioObjectMultipartFile;
import kz.eubank.registration.domain.repository.IClientDigitalDocumentRepository;
import kz.eubank.registration.domain.repository.IMetaDocumentRepository;
import kz.eubank.registration.domain.service.IClientDigitalDocumentService;
import kz.eubank.registration.domain.service.IForensicService;
import kz.eubank.registration.domain.util.DateUtil;
import kz.eubank.registration.infrastructure.repository.feignclient.s3.S3FeignClient;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Base64;
import java.util.Date;

import static kz.eubank.registration.domain.constant.TargetTable.CLIENT_DIGITAL_DOCUMENT;
import static kz.eubank.registration.domain.model.enums.ClientDigitalDocumentType.IDCD;
import static kz.eubank.registration.domain.model.enums.ClientDigitalDocumentType.PHTO;
import static org.springframework.http.MediaType.IMAGE_JPEG_VALUE;
import static org.springframework.http.MediaType.IMAGE_PNG_VALUE;

@Service
@RequiredArgsConstructor
public class ClientDigitalDocumentService implements IClientDigitalDocumentService {

    private final IClientDigitalDocumentRepository clientDigitalDocumentRepository;
    private final IMetaDocumentRepository metaDocumentRepository;
    private final IForensicService forensicService;
    private final S3FeignClient s3Client;
    @Value("${media_type.image}")
    private String MEDIA_TYPE;

    @Override
    public void saveBestShotToS3(String iin, String photoEncoded) {
        var decodedBestShot = Base64.getDecoder().decode(photoEncoded);
        var file = new MinioObjectMultipartFile(decodedBestShot, PHTO.name(), IMAGE_JPEG_VALUE);
        var savedDoc = saveClientDigitalDocument(iin, PHTO.name());
        s3Client.uploadFileOrThrowException(MEDIA_TYPE, file, CLIENT_DIGITAL_DOCUMENT, savedDoc.getId(), PHTO.name());
    }

    @Override
    public void getActualIDCardIfExists(BaseModel model) {
        var clientDigitalDocument = clientDigitalDocumentRepository.findActualByIin(model.getIin());

        if (clientDigitalDocument.isPresent()) {
            var metaDoc = metaDocumentRepository.findActiveByTargetTableAndTargetId(CLIENT_DIGITAL_DOCUMENT,
                    clientDigitalDocument.get().getId());

            metaDoc.ifPresent(doc -> model.setIdCardObjectName(doc.getFileUid()));
        }
    }

    @Override
    public void getIdentityCardFromS3(BaseModel model) {
        var fileBytes = s3Client.downloadFileOrThrowException(model.getIdCardObjectName());
        var file = new MinioObjectMultipartFile(fileBytes, IDCD.name(), IMAGE_PNG_VALUE);//minioService.getObject(model.getIdCardObjectName());
        forensicService.uploadMediaIntoFolder(model.getFolderId(), file, model.getPayload());
    }

    @Override
    public ClientDigitalDocument saveClientDigitalDocument(String iin, String type) {
        var clientDocType = new ClientDigitalDocumentType();
        clientDocType.setId(type);
        var clientDoc = ClientDigitalDocument.builder()
                .dateCreated(DateUtil.currentDate())
                .dateExpired(DateUtil.addYearsToCurrentDate(2L))
                .iin(iin)
                .isVerified(true)
                .clientDigitalDocumentType(clientDocType)
                .build();
        return clientDigitalDocumentRepository.save(clientDoc);
    }

    @Override
    @Transactional
    public void verifyByFileUid(String fileUid) {
        clientDigitalDocumentRepository.verifyByFileUid(fileUid);
    }

    @Override
    @Transactional
    public void updateDateExpiredByIin(Date expiredDate, String iin) {
        clientDigitalDocumentRepository.updateDateExpiredByIin(expiredDate, iin);
    }
}
