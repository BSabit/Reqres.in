package kz.eubank.registration.domain.model.pojo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import java.util.Date;

@Getter
@Setter
@Builder
public class Device {

    private String deviceId;
    private Long userId;
    private FrontEnd frontEnd;
    private Date loginDate;
    private Long idPrimary;
    private boolean isActualDevice;
    private Boolean isConfirmed;
    private Date createDate;
    private String deviceName;
    private MessageSender messageSenderIDREF;
}