package kz.eubank.registration.domain.model.pojo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@Builder
public class Passcode {

    private Long id;
    private Long userId;
    private PasscodeStatus status;
    private String hash;
    private String salt;
    private String deviceId;
    private Date dateCreated;
    private int invalidUses;
}
