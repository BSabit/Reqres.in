package kz.eubank.registration.domain.model.mapper;

import kz.eubank.registration.domain.model.dto.DMZVerificationDto;
import kz.eubank.registration.domain.model.pojo.DMZVerification;
import kz.eubank.registration.domain.model.pojo.RouteStatus;
import kz.eubank.registration.domain.model.pojo.RouteType;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface DMZVerificationMapper {

    DMZVerificationMapper INSTANCE = Mappers.getMapper(DMZVerificationMapper.class);

    DMZVerificationDto toDto(DMZVerification dmzVerification);

    default String routeType2String(RouteType routeType) {
        return routeType != null ? routeType.getId() : null;
    }

    default RouteType string2RouteType(String type) {
        if (type != null) {
            RouteType routeType = new RouteType();
            routeType.setId(type);
            return routeType;
        }
        return null;
    }

    default String routeStatus2String(RouteStatus routeStatus) {
        return routeStatus != null ? routeStatus.getId() : null;
    }

    default RouteStatus string2RouteStatus(String status) {
        if (status != null) {
            RouteStatus routeStatus = new RouteStatus();
            routeStatus.setId(status);
            return routeStatus;
        }
        return null;
    }
}
