package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.factory.PdfConvertorFactory;
import kz.eubank.registration.domain.service.*;
import kz.eubank.registration.infrastructure.config.AppProperties;
import kz.eubank.registration.infrastructure.repository.feignclient.GKBFeignClient;
import kz.eubank.registration.infrastructure.repository.feignclient.s3.S3FeignClient;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static kz.eubank.registration.domain.constant.TargetTable.CLIENT_DIGITAL_DOCUMENT;
import static kz.eubank.registration.domain.model.enums.ClientDigitalDocumentType.IDCD;
import static kz.eubank.registration.domain.model.enums.DMZVerificationAttemptsType.ESMS;
import static kz.eubank.registration.infrastructure.repository.feignclient.model.IdentityCards.IDENTITY_CARD;
import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.E_BS_901;
import static org.apache.pdfbox.util.filetypedetector.FileType.PNG;

@Service
@RequiredArgsConstructor
public class GKBService implements IGKBService {

    private final Logger log = LogManager.getLogger(getClass());

    private final AppProperties properties;
    private final GKBFeignClient gkbClient;
    private final PdfConvertorFactory pdfConvertorFactory;
    private final IForensicService forensicService;
    private final IDMZVerificationAttemptsService dmzVerificationAttemptsService;
    private final IAttemptsLimitService attemptsLimitService;
    private final IClientDigitalDocumentService clientDigitalDocumentService;
    private final S3FeignClient s3Client;
    @Value("${media_type.image}")
    private String MEDIA_TYPE;

    @Override
    public void getProfile(BaseModel model) {
        try {
            gkbClient.getProfileOrThrowException(model.getClientIin(), model.getSessionId());
        } catch (SelfException e) {
            log.info("ERROR getProfile Session-Id: {}, code: {}", model.getSessionId(), e.getCode());
            model.setError(e.getCode());
        }
    }

    @Override
    public void receiveSms(BaseModel model) {
        try {
            gkbClient.accessDocumentOrThrowException(model.getClientIin(), IDENTITY_CARD, model.getSessionId());
        } catch (SelfException e) {
            log.info("ERROR receiveSms Session-Id: {}, code: {}", model.getSessionId(), e.getCode());
            model.setError(e.getCode());
        }
    }

    @Override
    public void getDigitalDocument(BaseModel model) {
        var identityCardAttempt = isNull(model.getIdentityCardAttempts()) ? 1 : model.getIdentityCardAttempts() + 1;
        model.setIdentityCardAttempts(identityCardAttempt);
        var encryptedPdf = "";
        try {
            var documentResponse = gkbClient.getIdentityCardOrThrowException(model.getClientIin(),
                    model.getClientGKBSmsCode(), model.getSessionId());
            encryptedPdf = documentResponse.content();
        } catch (SelfException e) {
            dmzVerificationAttemptsService.fixAttempt(model.getSessionId(), ESMS);
            log.info("ERROR getDigitalDocument Session-Id: {}, code: {}", model.getSessionId(), e.getCode());
            model.setError(e.getCode());

            var esmsAttempt = attemptsLimitService.getLimitsCountByMobilePhoneAndType(model.getPhoneNumber(), ESMS);
            if (nonNull(esmsAttempt) && esmsAttempt.count() >= properties.getVerificationLimitCountByType(ESMS)) {
                model.setError(E_BS_901);
            }
            return;
        }

        var multipartFiles = pdfConvertorFactory.toMultipartFiles(encryptedPdf, PNG);
        try {
            var createdDoc = clientDigitalDocumentService.saveClientDigitalDocument(model.getIin(), IDCD.name());
            var uploadedFile = s3Client.uploadFileOrThrowException(
                    MEDIA_TYPE,
                    multipartFiles.get(0),
                    CLIENT_DIGITAL_DOCUMENT,
                    createdDoc.getId(),
                    IDCD.name()
            );

            model.setIdCardObjectName(uploadedFile.fileUid());
        } catch (SelfException e) {
            throw new RuntimeException(e);
        }
        forensicService.uploadMediaIntoFolder(model.getFolderId(), multipartFiles.get(0), model.getPayload());
    }
}
