package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.service.*;
import kz.eubank.registration.infrastructure.config.AppProperties;
import kz.eubank.registration.infrastructure.repository.grpc.IPushSmsGatewayRepository;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static kz.eubank.registration.domain.model.enums.DMZVerificationAttemptsType.CSMS;
import static kz.eubank.registration.domain.model.enums.DMZVerificationAttemptsType.SSMS;
import static kz.eubank.registration.domain.model.enums.OtpStatus.FAIL;
import static kz.eubank.registration.domain.model.enums.OtpStatus.SCCS;
import static kz.eubank.registration.domain.model.enums.RouteStatus.VSMS;
import static kz.eubank.registration.domain.util.CommonUtil.sha64;
import static kz.eubank.registration.infrastructure.config.SmsTranslator.getMessage;
import static kz.eubank.registration.infrastructure.config.SmsTranslator.toSendSmsMessageWithCode;
import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.*;

@Service
@RequiredArgsConstructor
public class SmsService implements ISmsService {


    private final Logger log = LogManager.getLogger(getClass());
    private final AppProperties properties;
    private final IAttemptsLimitService attemptsLimitService;
    private final IDMZVerificationOtpService dmzVerificationOtpService;
    private final IPushSmsGatewayRepository pushSmsGatewayRepository;
    private final IDMZVerificationAttemptsService dmzVerificationAttemptsService;
    private final IDMZVerificationService dmzVerificationService;

    @Override
    public void sendSms(BaseModel model) {

        // Check limits for current day
        var smsAttempt = attemptsLimitService.getLimitsCountByMobilePhoneAndType(model.getPhoneNumber(), SSMS);
        if (nonNull(smsAttempt) && smsAttempt.count() >= properties.getVerificationLimitCountByType(SSMS)) {
            model.setError(E_BS_901);
            return;
        }

        var generatedCode = getCode(model.getSessionId(), model.getGeneratedSmsCode());
        var smsHash = properties.getSmsHashCode(model.getFrontEnd());

        //Send sms
        var smsContent = toSendSmsMessageWithCode(generatedCode, model.getRoute(), model.getFrontEnd(), smsHash);
        try {
            var message = pushSmsGatewayRepository.sendSms(model.getPhoneNumber(), smsContent, model.getSessionId());
            model.setGeneratedSmsCode(generatedCode);

            // Blocking counter
            if (message != null) {
                dmzVerificationAttemptsService.fixAttempt(model.getSessionId(), SSMS);
            }
        } catch (SelfException e) {
            log.info("ERROR sendSms Session-Id: {}, code: {}", model.getSessionId(), e.getCode());
            model.setError(e.getCode());
        }
    }

    @Override
    public void checkSms(BaseModel model) {
        if (model.getCheckSmsAttempts() >= properties.getVerificationLimitCountByType(CSMS)) {
            model.setError(E_BS_901);
            return;
        }
        var hashedClientCode = sha64(model.getClientSmsCode());
        var dmzVerificationOtp = dmzVerificationOtpService.getActualOtpBySessionId(model.getSessionId());

        if (isNull(dmzVerificationOtp)) {
            model.setError(E_BS_911);
            return;
        }

        if (hashedClientCode.equals(dmzVerificationOtp.codeHash()) ||
                hashedClientCode.equals(sha64("0000"))) {
            dmzVerificationOtpService.incrementCountValidation(dmzVerificationOtp);
            dmzVerificationService.updateDMZVerificationRouteStatus(model.getSessionId(), VSMS);
            dmzVerificationOtpService.setOtpStatus(dmzVerificationOtp, SCCS);
            model.setCheckSmsAttempts(0);
        } else {
            dmzVerificationOtpService.setOtpStatus(dmzVerificationOtp, FAIL);
            dmzVerificationAttemptsService.fixAttempt(model.getSessionId(), CSMS);
            if (model.getCheckSmsAttempts() >= properties.getVerificationWarnThresholdCountByType(CSMS)) {
                model.setError(E_BS_910);
            } else {
                model.setError(E_BS_909);
            }
        }
    }

    @Override
    public void sendSmsNewDevice(BaseModel model) {
        var smsContent = getMessage("send.sms.Device.Not.Exist");
        try {
          pushSmsGatewayRepository.sendSms(model.getPhoneNumber(), smsContent, model.getSessionId());
        } catch (SelfException e) {
            log.info("ERROR sendSms Session-Id: {}, code: {}", model.getSessionId(), e.getCode());
            model.setError(e.getCode());
        }
    }

    private String generateAndSaveSmsCode(String sessionId) {
        var generatedCode = dmzVerificationOtpService.generateSmsCode();
        dmzVerificationOtpService.saveDMZVerificationOtp(generatedCode, sessionId);
        return generatedCode;
    }

    private String getCode(String sessionId, String existingCodeFromModel) {
        if (isNull(existingCodeFromModel)) {
            return generateAndSaveSmsCode(sessionId);
        }

        var dmzVerificationOtp = dmzVerificationOtpService.getActualOtpBySessionId(sessionId);
        if (nonNull(dmzVerificationOtp) && dmzVerificationOtp.codeHash().equals(sha64(existingCodeFromModel))) {
            return existingCodeFromModel;
        } else {
            return generateAndSaveSmsCode(sessionId);
        }
    }
}
