package kz.eubank.registration.domain.repository;

import kz.eubank.registration.domain.model.pojo.RecoveryProductStatus;

public interface IRecoveryProductStatusRepository {
    RecoveryProductStatus findById(String id);
}
