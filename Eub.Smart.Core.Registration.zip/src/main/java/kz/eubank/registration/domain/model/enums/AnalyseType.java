package kz.eubank.registration.domain.model.enums;

public enum AnalyseType {

    DOCUMENTS,
    BIOMETRY,
    QUALITY
}
