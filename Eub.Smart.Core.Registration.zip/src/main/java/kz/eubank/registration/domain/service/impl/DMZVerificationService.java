package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.model.dto.DMZVerificationDto;
import kz.eubank.registration.domain.model.mapper.DMZVerificationMapper;
import kz.eubank.registration.domain.model.pojo.DMZVerification;
import kz.eubank.registration.domain.model.pojo.RouteStatus;
import kz.eubank.registration.domain.model.pojo.RouteType;
import kz.eubank.registration.domain.repository.IDMZVerificationRepository;
import kz.eubank.registration.domain.service.IDMZVerificationService;
import kz.eubank.registration.infrastructure.config.AppProperties;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;

import static kz.eubank.registration.domain.model.enums.RouteStatus.NEWW;
import static kz.eubank.registration.domain.util.DateUtil.addMinutesToCurrentDate;
import static kz.eubank.registration.domain.util.DateUtil.currentDate;

@Service
@RequiredArgsConstructor
public class DMZVerificationService implements IDMZVerificationService {

    private final IDMZVerificationRepository dmzVerificationRepository;
    private final AppProperties properties;

    @Override
    public void createDMZVerification(BaseModel model) {
        var routeType = new RouteType();
        routeType.setId(model.getRoute());
        var routeStatus = new RouteStatus();
        routeStatus.setId(NEWW.name());
        var sessionId = MDC.get("Operation-Id");

        var dmzVerification = DMZVerification.builder()
                .sessionId(sessionId)
                .routeType(routeType)
                .routeStatus(routeStatus)
                .dateCreated(currentDate())
                .dateExpired(addMinutesToCurrentDate(properties.getSessionExpirationMinutes()))
                .mobilePhone(model.getPhoneNumber())
                .iin(model.getIin())
                .deviceId(model.getDeviceId())
                .versionFront(model.getVersionFront())
                .frontEnd(model.getFrontEnd())
                .build();
        dmzVerificationRepository.save(dmzVerification);

        model.setSessionDateExpiration(dmzVerification.getDateExpired());
        model.setSessionId(dmzVerification.getSessionId());
    }

    @Override
    public int getVerificationLimitCountByMobilePhone(String phoneNumber) {
        return dmzVerificationRepository.getVerificationLimitCountByMobilePhone(phoneNumber);
    }

    @Override
    public DMZVerificationDto getNotFinishedSessionByMobilePhoneAndDeviceId(String phoneNumber, String deviceId) {
        var dmzVerification =
                dmzVerificationRepository.getNotFinishedSessionByMobilePhoneAndDeviceId(phoneNumber, deviceId);
        return DMZVerificationMapper.INSTANCE.toDto(dmzVerification.orElse(null));
    }

    @Override
    public void updateDMZVerificationRouteStatus(String sessionId, kz.eubank.registration.domain.model.enums.RouteStatus status) {
        var dmzVerification = dmzVerificationRepository.findBySessionId(sessionId)
                .orElseThrow(() -> new SelfException(SelfErrorCode.E_DB_600));
        var routeStatus = new RouteStatus();
        routeStatus.setId(status.name());

        dmzVerification.setRouteStatus(routeStatus);
        dmzVerificationRepository.save(dmzVerification);
    }

    @Override
    public void updateDMZVerificationRouteType(String sessionId, String type) {
        var dmzVerification = dmzVerificationRepository.findBySessionId(sessionId)
                .orElseThrow(() -> new SelfException(SelfErrorCode.E_DB_600));
        var routeType = new RouteType();
        routeType.setId(type);

        dmzVerification.setRouteType(routeType);
        dmzVerificationRepository.save(dmzVerification);
    }
}
