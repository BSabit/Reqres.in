package kz.eubank.registration.domain.model.pojo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@Builder
public class MetaDocument {

    private Long id;
    private String targetTable;
    private Long targetId;
    private String documentType;
    private Boolean isActive;
    private String langKey;
    private Date dateCreated;
    private String fileUid;
}
