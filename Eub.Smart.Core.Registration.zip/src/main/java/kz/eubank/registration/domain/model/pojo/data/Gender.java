package kz.eubank.registration.domain.model.pojo.data;

public enum Gender {

    FEML, MALE, UNKN
}
