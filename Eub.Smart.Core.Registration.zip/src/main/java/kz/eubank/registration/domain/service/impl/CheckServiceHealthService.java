package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.service.ICheckServiceHealthService;
import kz.eubank.registration.infrastructure.config.AppProperties;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.E_BS_970;

@Service
@RequiredArgsConstructor
public class CheckServiceHealthService implements ICheckServiceHealthService {

    private final AppProperties appProperties;


    @Override
    public void checkHealth(BaseModel model) {
        var isRegistrationHealthy = appProperties.isServiceHealthy("registration");
        if (!isRegistrationHealthy) {
            model.setError(E_BS_970);
        }
    }
}
