package kz.eubank.registration.domain.repository;

import kz.eubank.registration.domain.model.pojo.User;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface IUserRepository {

    void updateUserRegion(int userId, int regionId);
    void updateUserStatus(String status, long userId);
    Optional<User> findUserWithIin(String iin);
}
