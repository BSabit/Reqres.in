package kz.eubank.registration.domain.model.pojo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@Builder
public class DMZVerificationAttempts {

    private Long id;
    private String mobilePhone;
    private String type;
    private DMZVerification dmzVerification;
    private Date createdDate;
    private boolean passcodeSet;
}
