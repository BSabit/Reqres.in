package kz.eubank.registration.domain.service;

import kz.eubank.registration.application.camunda.model.BaseModel;

public interface ICheckServiceHealthService {

    void checkHealth(BaseModel model);
}
