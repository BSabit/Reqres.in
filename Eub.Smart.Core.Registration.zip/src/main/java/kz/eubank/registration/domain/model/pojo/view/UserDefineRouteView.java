package kz.eubank.registration.domain.model.pojo.view;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDefineRouteView {

    private String mobilePhone;
    private String iin;
    private boolean isResident;
    private String userStatus;
}
