package kz.eubank.registration.domain.repository.view;

import kz.eubank.registration.domain.model.pojo.view.AttemptsLimitView;

import java.util.List;
import java.util.Optional;

public interface IAttemptsLimitViewRepository {

    List<AttemptsLimitView> getLimitsCountByMobilePhone(String mobilePhone);

    Optional<AttemptsLimitView> getLimitsCountByMobilePhoneAndType(String mobilePhone, String type);
}
