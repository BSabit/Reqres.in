package kz.eubank.registration.domain.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
public class AuthorizeRequestDto {

    private final Credentials credentials;

    public AuthorizeRequestDto(String email, String password) {
        this.credentials = new Credentials(email, password);
    }

    @Getter
    @AllArgsConstructor
    public class Credentials {

        private final String email;
        private final String password;
    }
}
