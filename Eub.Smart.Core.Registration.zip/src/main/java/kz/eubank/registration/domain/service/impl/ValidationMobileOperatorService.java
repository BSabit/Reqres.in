package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.repository.IMobileOperatorRepository;
import kz.eubank.registration.domain.service.IValidationMobileOperatorService;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ValidationMobileOperatorService implements IValidationMobileOperatorService {

    private final IMobileOperatorRepository mobileOperatorRepository;

    @Override
    public void validationMobileOperator(BaseModel model) {
        var kzOperators = mobileOperatorRepository.getAllMobileOperators();
        var kzCode = "7";

        if (!(model.getPhoneNumber().length() == 11 && model.getPhoneNumber().startsWith(kzCode))) {
            model.setError(SelfErrorCode.E_BS_916);
            return;
        }
        var operator = model.getPhoneNumber().substring(1, 4);
        if (!kzOperators.contains(operator)) {
            model.setError(SelfErrorCode.E_BS_917);
        }
    }
}
