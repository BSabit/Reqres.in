package kz.eubank.registration.domain.service;

import kz.eubank.registration.application.camunda.model.BaseModel;

public interface IGKBService {

    void getProfile(BaseModel model);

    void receiveSms(BaseModel model);

    void getDigitalDocument(BaseModel model);
}
