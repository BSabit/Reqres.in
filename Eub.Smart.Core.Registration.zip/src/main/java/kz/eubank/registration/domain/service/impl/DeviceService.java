package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.model.pojo.Device;
import kz.eubank.registration.domain.model.pojo.FrontEnd;
import kz.eubank.registration.domain.model.pojo.MessageSender;
import kz.eubank.registration.domain.repository.IDMZVerificationRepository;
import kz.eubank.registration.domain.repository.IDeviceRepository;
import kz.eubank.registration.domain.service.IDeviceService;
import kz.eubank.registration.domain.service.ISmsService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import static kz.eubank.registration.domain.util.DateUtil.currentDate;

@Service
@RequiredArgsConstructor
public class DeviceService implements IDeviceService{

    private final IDeviceRepository deviceRepository;
    private final IDMZVerificationRepository dmzVerificationRepository;
    private final ISmsService smsService;
    private static final boolean IS_CONFIRMED = true;
    private static final String NEW_APP = "NAAP";
    private static final int NO_RECORDS = 0;

    @Override
    public void updateDeviceAndLogoutOthers(BaseModel model) {

        Long userId = PasswordService.getUserId(model, dmzVerificationRepository);
        String deviceId = model.getDeviceId();
        deviceRepository.makeDeviceValid(userId, deviceId);
        deviceRepository.logoutOtherDevices(userId, deviceId);
    }

    @Override
    public void checkAndAddDevice(BaseModel model) {
        Long userId = PasswordService.getUserId(model,dmzVerificationRepository);
        int deviceRecordsCount = deviceRepository.checkDeviceIsExistAmount(model.getDeviceId(), userId);
        if (deviceRecordsCount == NO_RECORDS) smsService.sendSmsNewDevice(model);
    }

    @Override
    public void createDeviceId(BaseModel model, Object userAgent) {

        Long userId = PasswordService.getUserId(model, dmzVerificationRepository);
        String deviceId = model.getDeviceId();
        String frontEndIDREF = model.getFrontEnd();
        String nameDevice = extractDeviceName(userAgent);

        int deviceRecordsCount  = deviceRepository.checkDeviceIsExistAmount(deviceId, userId);
        if (deviceRecordsCount == NO_RECORDS) createDevice(deviceId, userId, frontEndIDREF, nameDevice);
    }

    private void createDevice(String deviceId, Long userId, String frontEndIDREF, String nameDevice) {
        var frontEnd = new FrontEnd();
        frontEnd.setId(frontEndIDREF);
        var messageSender = new MessageSender();
        messageSender.setId(NEW_APP);
        Device device = Device.builder()
                .deviceId(deviceId)
                .userId(userId)
                .frontEnd(frontEnd)
                .loginDate(currentDate())
                .isConfirmed(IS_CONFIRMED)
                .createDate(currentDate())
                .deviceName(nameDevice)
                .messageSenderIDREF(messageSender)
                .build();
        deviceRepository.save(device);
    }


    private String extractDeviceName(Object userAgent) {
        if (userAgent == null) { return null; }

        String nameDevice = userAgent.toString();
        String[] userAgentArray = nameDevice.split("[;/\\.:,]");
        return userAgentArray.length >= 2 ? userAgentArray[0] + " " + userAgentArray[1] : userAgentArray[0];
    }
}
