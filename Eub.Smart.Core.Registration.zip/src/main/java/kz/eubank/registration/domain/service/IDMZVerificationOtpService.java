package kz.eubank.registration.domain.service;

import kz.eubank.registration.domain.model.dto.DMZVerificationOtpDto;
import kz.eubank.registration.domain.model.enums.OtpStatus;

public interface IDMZVerificationOtpService {

    String generateSmsCode();

    void saveDMZVerificationOtp(String generatedCode, String sessionId);

    DMZVerificationOtpDto getActualOtpBySessionId(String sessionId);

    void incrementCountValidation(DMZVerificationOtpDto dmzVerificationOtpDto);

    void setOtpStatus(DMZVerificationOtpDto dmzVerificationOtpDto, OtpStatus status);
}
