package kz.eubank.registration.domain.service;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.model.pojo.Biometrics;

public interface IBiometricsService {

    void saveBiometrics(BaseModel model);

    Biometrics getBiometrics(String folderId);

    void updateData(Object analyseResponse, String status, long biometryId);

    void updateStatus(String status, long biometryId);

    void updateSimilarityPercentByFolderId(String folderId, double similarityPercent);
}
