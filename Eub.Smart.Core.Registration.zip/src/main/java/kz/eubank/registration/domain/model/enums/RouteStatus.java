package kz.eubank.registration.domain.model.enums;

public enum RouteStatus {

    NEWW,   //Сессия создана
    VSMS,   //Провалидирован СМС
    VSCS,   //Валидацию прошел
    PSET,   //Код доступа установлена
    FAIL    //Валидацию не прошел
}
