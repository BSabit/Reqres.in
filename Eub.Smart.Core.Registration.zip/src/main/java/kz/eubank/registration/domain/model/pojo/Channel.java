package kz.eubank.registration.domain.model.pojo;

import javax.persistence.Column;
import javax.persistence.Id;

public class Channel {

    private String id;
    private String title;
    private Long term;
}

