package kz.eubank.registration.domain.model.enums;

public enum FrontEnd {

    ANDP,    //Приложение для Android
    APTS,    //Test application
    IPHN,    //Приложение для iPhone
    UNKN     //Неизвестное устроиство
}
