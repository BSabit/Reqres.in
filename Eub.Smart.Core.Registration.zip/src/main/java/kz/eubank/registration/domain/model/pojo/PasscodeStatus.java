package kz.eubank.registration.domain.model.pojo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PasscodeStatus {

    private String id;
    private String title;
    private boolean isValid;
    private Long termId;
}
