package kz.eubank.registration.domain.service;

public interface IFingerprintService {

    void updateBUPRStatus(String sessionId);
}
