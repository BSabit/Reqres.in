package kz.eubank.registration.domain.model.pojo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import java.util.Date;

@Getter
@Setter
@Builder
public class Password {

    private Long id;
    private String hash;
    private Long userId;
    private Date dateCreated;
    private int isValid;
    private int isTechnical;
}