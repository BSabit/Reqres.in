package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.model.enums.RouteStatus;
import kz.eubank.registration.domain.repository.IDMZVerificationRepository;
import kz.eubank.registration.domain.repository.IUserRepository;
import kz.eubank.registration.domain.service.IAccountCreateService;
import kz.eubank.registration.domain.service.IClientDigitalDocumentService;
import kz.eubank.registration.infrastructure.model.dto.scb.SCBPersonalData;
import kz.eubank.registration.infrastructure.model.dto.scb.subclass.ListOfDocument;
import kz.eubank.registration.infrastructure.model.entity.GbdflRegion;
import kz.eubank.registration.infrastructure.model.mapper.SCBMapper;
import kz.eubank.registration.infrastructure.repository.feignclient.GKBFeignClient;
import kz.eubank.registration.infrastructure.repository.mssql.GbdflRegionHiberRepository;
import kz.eubank.registration.infrastructure.repository.mssql.procedure.AccountCreateProcedure;
import kz.eubank.registration.infrastructure.repository.mssql.procedure.RequestCreateUserProcedure;
import kz.eubank.registration.infrastructure.repository.mssql.procedure.ResponseCreateUserProcedure;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.springframework.stereotype.Service;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import static kz.eubank.registration.domain.constant.SCB.*;
import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.E_BS_961;
import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.E_DB_600;

@Service
@RequiredArgsConstructor
public class AccountCreateService implements IAccountCreateService {

    private final Logger log = LogManager.getLogger(getClass());
    private final GKBFeignClient gkbFeignClient;
    private final AccountCreateProcedure procedure;
    private final GbdflRegionHiberRepository gbdflRegionHiberRepository;
    private final IUserRepository userRepository;
    private final IDMZVerificationRepository dmzVerificationRepository;
    private final IClientDigitalDocumentService clientDigitalDocumentService;

    @Override
    public RequestCreateUserProcedure createAccount(BaseModel model) throws SQLException {
        UUID uuid = UUID.randomUUID();
        SCBPersonalData responseSCB;
        responseSCB = gkbFeignClient.getClientDataByIinOrThrowException(model.getClientIin(), String.valueOf(uuid));

        var idCard = responseSCB.getDocuments().getListOfDocuments().stream()
                .filter(doc -> "002".equals(doc.getType().getCode()))
                .filter(doc -> "00".equals(doc.getStatus().getCode()))
                .findFirst();

        ListOfDocument document = getActiveIdentityOrPassport(responseSCB);
        responseSCB.getDocuments().setListOfDocuments(List.of(document));
        RequestCreateUserProcedure requestCreateUserProcedure = SCBMapper.INSTANCE.toDto(responseSCB);

        String mobilePhone = model.getPhoneNumber();
        if (model.getPhoneNumber().length() == 11) {
            mobilePhone = model.getPhoneNumber().substring(1);
        }

        requestCreateUserProcedure.setMobilePhone(mobilePhone);
        Optional<GbdflRegion> gbdflRegion = gbdflRegionHiberRepository.findById(responseSCB.getRegAddress().getDistrict().getCode());

        if (gbdflRegion.isEmpty()) {
            throw new SelfException(E_DB_600);
        }

        int regionId = Integer.parseInt(gbdflRegion.get().getRegion());
        ResponseCreateUserProcedure response;

        response = procedure.execute(requestCreateUserProcedure);

        if (response == null || !response.getStatus().equals("OK")) {
            model.setError(E_BS_961);
            throw new BpmnError(E_BS_961.toString());
        }

        dmzVerificationRepository.updateIin(model.getSessionId(), model.getClientIin());
        userRepository.updateUserRegion(response.getUserId(), regionId);
        dmzVerificationRepository.updateStatusWithSessionId(RouteStatus.VSCS.toString(), model.getSessionId());

            if (idCard.isPresent()) {
                var endDate = idCard.get().getEndDate();
                clientDigitalDocumentService.updateDateExpiredByIin(endDate, model.getIin());
            }

        return requestCreateUserProcedure;
    }

    private ListOfDocument getActiveIdentityOrPassport(SCBPersonalData data) {
        ListOfDocument documentIdentity = null;
        ListOfDocument documentPassport = null;
        ListOfDocument response;
        for (ListOfDocument element : data.getDocuments().getListOfDocuments()) {
            int statusCode = Integer.parseInt(element.getStatus().getCode());
            int typeCode = Integer.parseInt(element.getType().getCode());
            if (statusCode == STATUS_ACTIVE) {
                if (typeCode == IDENTITY_TYPE) {
                    if (documentIdentity == null) {
                        documentIdentity = element;
                    } else if (compareDate(documentIdentity, element)) {
                        documentIdentity = element;
                    }
                } else if (typeCode == PASSPORT_TYPE) {
                    if (documentPassport == null) {
                        documentPassport = element;
                    } else if (compareDate(documentPassport, element)) {
                        documentPassport = element;
                    }
                }
            }
        }
        if (documentIdentity != null) {
            response = documentIdentity;
        } else {
            response = documentPassport;
        }
        return response;
    }

    private boolean compareDate(ListOfDocument primaryDate, ListOfDocument elementDate) {
        return primaryDate.getEndDate().compareTo(elementDate.getEndDate()) < 0;
    }
}
