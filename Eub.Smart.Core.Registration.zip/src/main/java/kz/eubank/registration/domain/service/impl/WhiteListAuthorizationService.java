package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.domain.model.dto.WhiteListAuthorizationDto;
import kz.eubank.registration.domain.model.mapper.WhiteListAuthorizationMapper;
import kz.eubank.registration.domain.repository.IWhiteListAuthorizationRepository;
import kz.eubank.registration.domain.service.IWhiteListAuthorizationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class WhiteListAuthorizationService implements IWhiteListAuthorizationService {

    private final IWhiteListAuthorizationRepository whiteListAuthorizationRepository;

    @Override
    public WhiteListAuthorizationDto getWhiteListByPhoneNumber(String phoneNumber) {
        var whiteList = whiteListAuthorizationRepository.findByMobilePhone(phoneNumber);
        return WhiteListAuthorizationMapper.INSTANCE.toDto(whiteList.orElse(null));
    }
}
