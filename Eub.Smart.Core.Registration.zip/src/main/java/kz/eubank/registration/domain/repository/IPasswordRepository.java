package kz.eubank.registration.domain.repository;

import kz.eubank.registration.domain.model.pojo.Password;

public interface IPasswordRepository {
    void save(Password password);
    void makePasswordInvalid(Long userId);
}
