package kz.eubank.registration.domain.repository;

import kz.eubank.registration.domain.model.pojo.DMZVerificationOtp;

import java.util.Optional;

public interface IDMZVerificationOtpRepository {

    Optional<DMZVerificationOtp> getActualOtpBySessionId(String sessionId);

    void save(DMZVerificationOtp dmzVerificationOtp);
}
