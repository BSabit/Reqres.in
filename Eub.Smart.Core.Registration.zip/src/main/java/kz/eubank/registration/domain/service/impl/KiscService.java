package kz.eubank.registration.domain.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import javassist.NotFoundException;
import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.model.enums.BiometricsStatus;
import kz.eubank.registration.domain.model.enums.RouteStatus;
import kz.eubank.registration.domain.model.pojo.DMZVerification;
import kz.eubank.registration.domain.repository.IDMZVerificationRepository;
import kz.eubank.registration.domain.service.*;
import kz.eubank.registration.infrastructure.config.AppProperties;
import kz.eubank.registration.infrastructure.model.dto.kisc.BaseRequestKisc;
import kz.eubank.registration.infrastructure.model.dto.kisc.MatchByIdRequestDto;
import kz.eubank.registration.infrastructure.model.dto.kisc.MatchPhotoRequestDto;
import kz.eubank.registration.infrastructure.model.dto.kisc.MathPhotoResponseDto;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Optional;
import java.util.UUID;

import static java.util.Objects.nonNull;
import static kz.eubank.registration.domain.model.enums.DMZVerificationAttemptsType.VBIO;
import static kz.eubank.registration.domain.model.enums.RouteType.RBYB;
import static kz.eubank.registration.domain.util.DateUtil.currentDate;
import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.E_BS_931;

@Service
@RequiredArgsConstructor
@Log4j2
public class KiscService implements IKiscService {

    private final AppProperties properties;
    private final IDMZVerificationRepository dmzVerificationRepository;
    private final IDMZVerificationAttemptsService dmzVerificationAttemptsService;
    private final IBiometricsService biometricsService;
    private final IAttemptsLimitService attemptsLimitService;
    private final IClientDigitalDocumentService clientDigitalDocumentService;

    @Value("${kisc.matchingUrl}")
    private String kiscUrl;
    @Value("${kisc.matchingByIdUrl}")
    private String kiscByIdUrl;
    private static final String success = "200";
    private static final String timeOut = "504";
    private static final String notFoundPerson = "404";
    @Value("${kisc.min-similarity}")
    private double minSimilarity;
    @Value("${kisc.vendor}")
    private String vendor;
    @Value("${kisc.system}")
    private String system;
    private final ObjectMapper mapper = new ObjectMapper();
    private final RestTemplate restTemplate = new RestTemplate();

    @Override
    public MathPhotoResponseDto matchPhoto(MatchPhotoRequestDto dto) throws JsonProcessingException {
        MathPhotoResponseDto response;

        String responseJson = this.getResponseExternalKisc(kiscUrl, dto);
        String parseJson = this.customParseJson(responseJson);
        response = this.getMathPhotoResponseDto(parseJson);

        if (response.getCode().equals(timeOut)) {
            MatchByIdRequestDto matchByIdRequest = new MatchByIdRequestDto(dto.getIdempotencyKey(), system);
            String retryResponseJson = this.getResponseExternalKisc(kiscByIdUrl, matchByIdRequest);
            String retryParseJson = this.customParseJson(retryResponseJson);
            response = this.getMathPhotoResponseDto(retryParseJson);
        }
        if (response.getCode().equals(notFoundPerson)) {
            return response;
        }
        if (response.getCode().equals(success)) {
            return response;
        } else {
            log.warn(response);
            throw new SelfException(SelfErrorCode.E_EX_704);
        }
    }

    @Override
    public void isSimilar(BaseModel model, String encodedPhoto) throws JsonProcessingException, NotFoundException {
        String idempotencyKey = String.valueOf(UUID.randomUUID());
        MatchPhotoRequestDto request = new MatchPhotoRequestDto(encodedPhoto, model.getIin(), vendor, system, idempotencyKey);
        MathPhotoResponseDto mathPhotoResponseDto = this.matchPhoto(request);
        log.info("MathPhotoResponse time: {}, url: {}, sessionId: {}, response: {}",
                currentDate(), kiscUrl, model.getSessionId(), mathPhotoResponseDto);

        if (mathPhotoResponseDto.getCode().equals(notFoundPerson)) {
//            dmzVerificationAttemptsService.fixAttempt(model.getSessionId(), VBIO); TODO check with business
            System.out.println("notFOUND");
            model.setIsBiometricsSuccess(false);
            model.setIsKiscIinNotFound(true);
            model.setError(E_BS_931);
            return;
        }

        model.setIsKiscIinNotFound(false);
        double similarity = Double.parseDouble(mathPhotoResponseDto.getSimilarity());
        boolean isBiometricsSuccess = minSimilarity < similarity;
        model.setIsBiometricsSuccess(isBiometricsSuccess);
        biometricsService.updateSimilarityPercentByFolderId(model.getFolderId(), similarity);

        if (isBiometricsSuccess) {
            if (model.getRoute().equals(RBYB.name())) {
                dmzVerificationRepository.updateIin(model.getSessionId(), model.getIin());
            }
            dmzVerificationRepository.updateStatusWithSessionId(RouteStatus.VSCS.name(), model.getSessionId());
            clientDigitalDocumentService.saveBestShotToS3(model.getIin(), encodedPhoto);
        } else {
            model.setError(SelfErrorCode.E_BS_923);
            dmzVerificationAttemptsService.fixAttempt(model.getSessionId(), VBIO);

            var bioAttempt = attemptsLimitService.getLimitsCountByMobilePhoneAndType(model.getPhoneNumber(), VBIO);
            if (nonNull(bioAttempt) && bioAttempt.count() >= properties.getVerificationLimitCountByType(VBIO)) {
                this.entryDBFailedAttempts(model);
            }
        }
    }

    private void entryDBFailedAttempts(BaseModel model) throws NotFoundException {
        model.setError(SelfErrorCode.E_BS_924);
        dmzVerificationRepository.updateStatusWithSessionId(RouteStatus.FAIL.name(), model.getSessionId());
        Optional<DMZVerification> dmzVerification = dmzVerificationRepository.findBySessionId(model.getSessionId());
        if (dmzVerification.isEmpty()) {
            throw new NotFoundException("SessionID: " + model.getSessionId() + " not founded!");
        }
        biometricsService.updateStatus(BiometricsStatus.BINM.name(), dmzVerification.get().getId());
    }

    private String getResponseExternalKisc(String url, BaseRequestKisc request) {
        return restTemplate.postForObject(url, new HttpEntity<>(request), String.class);
    }

    private MathPhotoResponseDto getMathPhotoResponseDto(String parseJson) throws JsonProcessingException {
        return mapper.readValue(parseJson, MathPhotoResponseDto.class);
    }

    private String customParseJson(String responseJson) {
        StringBuilder replace = new StringBuilder(responseJson.replace("\\", ""));

        if (replace.charAt(0) == '"' && replace.charAt(replace.length() - 1) == '"') {
            replace.deleteCharAt(0);
            replace.deleteCharAt(replace.length() - 1);
        }

        char[] chars = replace.toString().toCharArray();
        char a = '{';
        char b = '}';
        ArrayList<Integer> arrayList = new ArrayList<>();

        for (int i = 0; i < chars.length; i++) {
            if (i > 2 && i < chars.length - 2) {
                if ((chars[i] == a) || (chars[i] == b)) {
                    arrayList.add(i);
                }
            }
        }

        if (!arrayList.isEmpty()) {
            replace.deleteCharAt(arrayList.get(0) - 1);
            replace.deleteCharAt(arrayList.get(1));
        }
        return replace.toString();
    }
}