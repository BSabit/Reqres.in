package kz.eubank.registration.domain.model.pojo.data;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class KiscAnalysisInfo {

    @Schema(description = "сообщение")
    private String message;
    @Schema(description = "статус")
    private String status;
    @Schema(description = "тип")
    private String type;
}
