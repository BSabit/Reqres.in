package kz.eubank.registration.domain.repository;

import kz.eubank.registration.domain.model.pojo.Passcode;

public interface IOldPasscodeRepository {
    void save(Passcode passcode);
    Passcode saveAndGet(Passcode passcode);
    void changeStatusByDeviceId(String status, String deviceId);
    void changeStatusByUserId(String status, String deviceId);
}
