package kz.eubank.registration.domain.model.enums;

public enum AnalyseState {

    PROCESSING,
    FAILED,
    FINISHED
}
