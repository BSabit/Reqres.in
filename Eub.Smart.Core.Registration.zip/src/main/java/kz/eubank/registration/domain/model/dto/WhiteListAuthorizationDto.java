package kz.eubank.registration.domain.model.dto;

import lombok.*;

import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class WhiteListAuthorizationDto implements Serializable {

    static final long serialVersionUID = 1L;

    private Long id;
    private String mobilePhone;
    private String newHash;
    private String hash;
    private String salt;
    private Long userId;
    private boolean isActive;
    private Date dateValid;
}
