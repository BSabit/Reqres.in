package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.domain.model.dto.request.AuthorizeRequestDto;
import kz.eubank.registration.domain.model.dto.request.RefreshRequestDto;
import kz.eubank.registration.domain.model.dto.response.AnalysisResponseDto;
import kz.eubank.registration.domain.model.dto.response.AuthorizeResponseDto;
import kz.eubank.registration.domain.model.dto.response.FolderResponseDto;
import kz.eubank.registration.domain.model.dto.response.UploadMediaResponseDto;
import kz.eubank.registration.domain.service.IForensicService;
import kz.eubank.registration.domain.util.JsonUtil;
import kz.eubank.registration.infrastructure.config.AppProperties;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.PostConstruct;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static java.util.Objects.nonNull;
import static kz.eubank.registration.domain.constant.HeaderName.FORENSIC_ACCESS_TOKEN;
import static kz.eubank.registration.domain.util.FileUtil.toFileSystemResourceOrThrowException;
import static kz.eubank.registration.domain.util.StringUtil.isAnyEmpty;
import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.E_EX_701;
import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.E_EX_702;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.http.MediaType.MULTIPART_FORM_DATA;

@Service
@RequiredArgsConstructor
public class ForensicService implements IForensicService {

    private final Logger log = LogManager.getLogger(getClass());

    private final AppProperties properties;
    private String accessToken;
    private String expireToken;


    private RestTemplate restTemplate() {
        //var socketAddress = new InetSocketAddress(properties.getProxyServerHost(), properties.getProxyServerPort());
        //var proxy = new Proxy(HTTP, socketAddress);
        var requestFactory = new SimpleClientHttpRequestFactory();
        //requestFactory.setProxy(proxy);

        var restTemplate = new RestTemplate(requestFactory);
        //TODO add error handler
        //restTemplate.setErrorHandler(new ForensicRestResponseErrorHandler());
        return restTemplate;
    }

    @Override
    public Optional<AuthorizeResponseDto> getAuthorize() {
        var authorizeRequestDto = new AuthorizeRequestDto(properties.getForensicEmail(), properties.getForensicPassword());
        var json = JsonUtil.toJsonOrThrowException(authorizeRequestDto);

        var fullUrl = properties.getForensicUrl() + "/authorize/auth";
        var headers = new HttpHeaders();
        headers.setContentType(APPLICATION_JSON);
        var entity = new HttpEntity<>(json, headers);

        var authorizeResponseDto = restTemplate()
                .postForObject(fullUrl, entity, AuthorizeResponseDto.class);
        return Optional.ofNullable(authorizeResponseDto);
    }

    @Override
    @PostConstruct
    public void setAuthTokenOrThrowException() {
        var authorizeResponseDto = getAuthorize()
                .orElseThrow(() -> new SelfException(E_EX_701));
        accessToken = authorizeResponseDto.getAccess_token();
        expireToken = authorizeResponseDto.getExpire_token();
        if (isAnyEmpty(accessToken, expireToken)) throw new SelfException(E_EX_702);
    }

    @Override
    @Scheduled(fixedRateString = "${forensic.refresh-rate}", initialDelayString = "${forensic.refresh-delay}")
    public void refreshToken() {
        var refreshRequestDto = new RefreshRequestDto(expireToken);
        var json = JsonUtil.toJsonOrThrowException(refreshRequestDto);

        var fullUrl = properties.getForensicUrl() + "/authorize/refresh";
        var headers = new HttpHeaders();
        headers.setContentType(APPLICATION_JSON);
        headers.set(FORENSIC_ACCESS_TOKEN, accessToken);
        var entity = new HttpEntity<>(json, headers);

        var authorizeResponseDto = restTemplate()
                .postForObject(fullUrl, entity, AuthorizeResponseDto.class);
        if (authorizeResponseDto == null) throw new SelfException(E_EX_701);
        accessToken = authorizeResponseDto.getAccess_token();
        expireToken = authorizeResponseDto.getExpire_token();
        if (isAnyEmpty(accessToken, expireToken)) throw new SelfException(E_EX_702);
    }

    @Override
    public AnalysisResponseDto[] startAnalyses(String biometricsType, String folderId) {
        var fullUrl = properties.getForensicUrl() + "/folders/" + folderId + "/analyses";
        var payload = properties.getBiometricsAnalyseType(biometricsType);

        var headers = new HttpHeaders();
        headers.set(FORENSIC_ACCESS_TOKEN, accessToken);
        var entity = new HttpEntity<>(payload, headers);

        return restTemplate()
                .postForObject(fullUrl, entity, AnalysisResponseDto[].class);
    }

    @Override
    public FolderResponseDto uploadMedia(String payload, MultiValueMap<String, MultipartFile> mediaList) {
        var fullUrl = properties.getForensicUrl() + "/folders";

        var headers = new HttpHeaders();
        headers.setContentType(MULTIPART_FORM_DATA);
        headers.set(FORENSIC_ACCESS_TOKEN, accessToken);

        var body = new LinkedMultiValueMap<String, Object>();
        body.add("payload", payload);
        for (Map.Entry<String, List<MultipartFile>> el : mediaList.entrySet()) {
            var files = el.getValue();
            if (nonNull(files) && !files.isEmpty()) {
                var file = files.get(0);
                var mediaResource = toFileSystemResourceOrThrowException(file);
                body.add(el.getKey(), mediaResource);
            }
        }
        var entity = new HttpEntity<>(body, headers);

        var exchange =
                restTemplate().exchange(fullUrl, POST, entity, FolderResponseDto.class);
        return exchange.getBody();
    }

    @Override
    public UploadMediaResponseDto[] uploadMediaIntoFolder(String folderId, MultipartFile media, String payload) {
        var mediaResource = toFileSystemResourceOrThrowException(media);
        var fullUrl = properties.getForensicUrl() + "/folders/" + folderId + "/media";
        var headers = new HttpHeaders();
        headers.setContentType(MULTIPART_FORM_DATA);
        headers.set(FORENSIC_ACCESS_TOKEN, accessToken);

        var body = new LinkedMultiValueMap<>();
        body.add("payload", payload);
        body.add("media", mediaResource);
        var entity = new HttpEntity<>(body, headers);

        var exchange =
                restTemplate().exchange(fullUrl, HttpMethod.POST, entity, UploadMediaResponseDto[].class);
        return exchange.getBody();
    }

    @Override
    public Optional<AnalysisResponseDto[]> getAnalysis(String folderId) {
        log.info("start getAnalysis folderId: {}", folderId);

        var fullUrl = properties.getForensicUrl() + "/folders/" + folderId + "/analyses";
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<String> entity = new HttpEntity<>(headers);
        headers.set(FORENSIC_ACCESS_TOKEN, accessToken);

        ResponseEntity<AnalysisResponseDto[]> responseEntity = restTemplate().exchange(fullUrl, HttpMethod.GET, entity, AnalysisResponseDto[].class);
        AnalysisResponseDto[] authorizeResponseDto = responseEntity.getBody();
        return Optional.ofNullable(authorizeResponseDto);
    }

    @Override
    public Optional<AnalysisResponseDto> getAnalysisById(String analyzeId) {
        log.info("start getAnalysisById folderId: {}", analyzeId);

        var fullUrl = properties.getForensicUrl() + "/analyses/" + analyzeId;
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<String> entity = new HttpEntity<>(headers);
        headers.set(FORENSIC_ACCESS_TOKEN, accessToken);

        ResponseEntity<AnalysisResponseDto> responseEntity = restTemplate().exchange(fullUrl, HttpMethod.GET, entity, AnalysisResponseDto.class);
        AnalysisResponseDto authorizeResponseDto = responseEntity.getBody();
        return Optional.ofNullable(authorizeResponseDto);
    }

    @Override
    public AnalysisResponseDto getAnalysisOrTrowException(String analyzeId) {
        log.info("start getAnalysisOrTrowException analyzeId: {}", analyzeId);
        AnalysisResponseDto analysisResponseDtos = this.getAnalysisById(analyzeId)
                .orElseThrow(() -> new SelfException(SelfErrorCode.E_BS_920, "not found analyze for analyzeId: " + analyzeId));
        if (analysisResponseDtos == null)
            throw new SelfException(SelfErrorCode.E_BS_921, "analyze empty analyzeId: " + analyzeId);
        return analysisResponseDtos;
    }

    @Override
    public String getThumbUrl(AnalysisResponseDto analysisResponseDto) {
        log.info("analysisResponse: {}", analysisResponseDto);
        if (analysisResponseDto == null) throw new SelfException(SelfErrorCode.E_BS_940);
        if (analysisResponseDto.getSource_media().isEmpty())
            throw new SelfException(SelfErrorCode.E_BS_940, "get Source url empty");
        return analysisResponseDto.getSource_media().get(0).getThumb_url();
    }

    @Override
    public String downloadFileOrTrowException(String url) {
        log.info("start downloadFileOrTrowException url: {}", url);
        HttpHeaders headers = new HttpHeaders();
        headers.set(FORENSIC_ACCESS_TOKEN, accessToken);
        HttpEntity<String> entity = new HttpEntity<>(headers);
        ResponseEntity<byte[]> responseEntity = restTemplate().exchange(url, HttpMethod.GET, entity, byte[].class);
        byte[] photoBytes = responseEntity.getBody();
        return Base64.getEncoder().encodeToString(photoBytes);
    }
}
