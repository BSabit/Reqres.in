package kz.eubank.registration.domain.repository;

import kz.eubank.registration.domain.model.pojo.WhiteListAuthorization;

import java.util.Optional;

public interface IWhiteListAuthorizationRepository {

    Optional<WhiteListAuthorization> findByMobilePhone(String mobilePhone);
}
