package kz.eubank.registration.domain.model.enums;

public enum DMZVerificationAttemptsType {

    SSMS,   //Отправка СМС\ОТП
    VIIN,   //Неуспешная проверка ИИН
    VBIO,   //Неуспешная биометрия
    VBDY,   //Неуспешная проверка даты рождения
    VRPA,   //Неуспешная валидация по номеру продукта
    CSMS,   //Неуспешная проверка СМС\ОТП
    ESMS    //Неуспешная проверка СМС\ОТП от EGOV
}
