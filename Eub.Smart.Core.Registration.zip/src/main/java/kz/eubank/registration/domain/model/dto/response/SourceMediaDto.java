package kz.eubank.registration.domain.model.dto.response;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class SourceMediaDto {

    private List<String> tags;
    private String thumb_url;
}
