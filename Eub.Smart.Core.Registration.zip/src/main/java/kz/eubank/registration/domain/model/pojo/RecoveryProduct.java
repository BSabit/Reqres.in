package kz.eubank.registration.domain.model.pojo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@Builder
public class RecoveryProduct {
    private String id;
    private Date dateCreated;
    private String productNumber;
    private RecoveryProductAccountType type;
    private RecoveryProductStatus status;
    private String iin;
    private DMZVerification dmzVerification;
    private String customer;
    private String mobilePhone;
    private String bsystem;
}
