package kz.eubank.registration.domain.model.dto;

public record UserDefineRouteDto(String mobilePhone,
                                 String iin,
                                 boolean isResident,
                                 String userStatus) {
}
