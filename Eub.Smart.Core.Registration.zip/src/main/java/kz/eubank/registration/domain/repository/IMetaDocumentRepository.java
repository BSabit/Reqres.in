package kz.eubank.registration.domain.repository;

import kz.eubank.registration.domain.model.pojo.MetaDocument;

import java.util.Optional;

public interface IMetaDocumentRepository {

    Optional<MetaDocument> findActiveByTargetTableAndTargetId(String targetTable, Long targetId);
}
