package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.service.*;
import kz.eubank.registration.infrastructure.config.AppProperties;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import static java.util.Objects.nonNull;
import static kz.eubank.registration.domain.model.enums.DMZVerificationAttemptsType.*;
import static kz.eubank.registration.domain.model.enums.RouteType.*;
import static kz.eubank.registration.domain.model.enums.UserStatus.BBUP;
import static kz.eubank.registration.domain.model.enums.UserStatus.BBUS;
import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.E_BS_901;
import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.E_BS_914;

@Service
@RequiredArgsConstructor
public class RegistrationService implements IRegistrationService {

    private final AppProperties properties;
    private final IWhiteListAuthorizationService whiteListAuthorizationService;
    private final IDMZVerificationService dmzVerificationService;
    private final IAttemptsLimitService attemptsLimitService;
    private final IUserDefineRouteService userDefineRouteService;

    @Override
    public void defineRoute(BaseModel model) {
        var user = userDefineRouteService.getUserDefineRouteByMobilePhone(model.getPhoneNumber());

        if (nonNull(user)) {
            model.setIin(user.iin());
            model.setClientIin(user.iin());
            model.setUserStatus(user.userStatus());

            if (BBUS.name().equals(user.userStatus()) || BBUP.name().equals(user.userStatus())) {
                model.setError(E_BS_914);
                return;
            }

            if (user.isResident()) {
                model.setRoute(RBYB.name());
            } else {
                model.setRoute(RBYP.name());
            }
        } else {
            model.setRoute(REGR.name());
        }
    }

    @Override
    public void checkWhiteList(BaseModel model) {
        var whiteList = whiteListAuthorizationService.getWhiteListByPhoneNumber(model.getPhoneNumber());
        if (nonNull(whiteList)) {
            model.setWhiteList(whiteList);
            model.setRoute(WHLS.name());
        }
    }

    @Override
    public void checkLimits(BaseModel model) {
        var limitCount = dmzVerificationService.getVerificationLimitCountByMobilePhone(model.getPhoneNumber());
        if (limitCount >= properties.getVerificationLimitCount()) {
            model.setError(E_BS_901);
            return;
        }

        var limits = attemptsLimitService.getLimitsCountByMobilePhone(model.getPhoneNumber());
        for (var limit : limits) {
            if ((SSMS.name().equals(limit.type()) && limit.count() >= properties.getVerificationLimitCountByType(SSMS)) ||
                    (VBIO.name().equals(limit.type()) && limit.count() >= properties.getVerificationLimitCountByType(VBIO)) ||
                    (VIIN.name().equals(limit.type()) && limit.count() >= properties.getVerificationLimitCountByType(VIIN)) ||
                    (ESMS.name().equals(limit.type()) && limit.count() >= properties.getVerificationLimitCountByType(ESMS)) ||
                    (VRPA.name().equals(limit.type()) && limit.count() >= properties.getVerificationLimitCountByType(VRPA))) {
                model.setError(E_BS_901);
                return;
            }
        }
    }

    @Override
    public void checkSessionExistence(BaseModel model) {
        var notFinishedSession =
                dmzVerificationService.getNotFinishedSessionByMobilePhoneAndDeviceId(model.getPhoneNumber(), model.getDeviceId());
        if (nonNull(notFinishedSession)) {
            model.setSessionId(notFinishedSession.sessionId());
            model.setRoute(NTFC.name());
            dmzVerificationService.updateDMZVerificationRouteType(notFinishedSession.sessionId(), NTFC.name());
        }
    }
}
