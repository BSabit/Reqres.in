package kz.eubank.registration.domain.model.enums;

public enum PasscodeStatusEnum {
    ACTV,
    BBBN,
    BBUS,
    BLAE,
    BUPR
}
