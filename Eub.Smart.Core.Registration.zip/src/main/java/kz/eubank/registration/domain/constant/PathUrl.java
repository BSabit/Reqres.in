package kz.eubank.registration.domain.constant;

public interface PathUrl {
    String registration = "registration";
}
