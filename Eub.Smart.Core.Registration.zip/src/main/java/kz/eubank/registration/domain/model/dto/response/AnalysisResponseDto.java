package kz.eubank.registration.domain.model.dto.response;

import kz.eubank.registration.domain.model.enums.AnalyseState;
import kz.eubank.registration.domain.model.enums.AnalyseType;
import kz.eubank.registration.domain.model.enums.ResolutionStatus;
import lombok.Getter;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;

@Getter
@Setter
public class AnalysisResponseDto implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;
    private Integer time_created;
    private Integer time_updated;
    private Object technical_meta_data;
    private Object meta_data;
    private String analyse_id;
    private String folder_id;
    private AnalyseType type;
    private AnalyseState state;
    private Object results_data;
    private AnalysisConfDto confs;
    private String error_message;
    private Integer error_code;
    private Object resolution_operator;
    private Integer time_task_send_to_broker;
    private Integer time_task_received;
    private Integer time_task_finished;
    private List<SourceMediaDto> source_media;
    private Object results_media;
    private Object results_group;
    private ResolutionStatus resolution_status;
    private ResolutionStatus resolution;
}
