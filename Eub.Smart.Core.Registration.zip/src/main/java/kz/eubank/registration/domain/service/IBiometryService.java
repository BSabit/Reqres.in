package kz.eubank.registration.domain.service;

import kz.eubank.registration.application.camunda.model.BaseModel;

public interface IBiometryService {

    void checkMediaInArchiveDB(BaseModel model);

    void startAnalyses(BaseModel model);

    void getQualityAnalyses(BaseModel model);

    void getBiometryAnalyses(BaseModel model);
}
