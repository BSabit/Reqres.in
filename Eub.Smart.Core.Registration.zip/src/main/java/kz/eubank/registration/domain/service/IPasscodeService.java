package kz.eubank.registration.domain.service;

import kz.eubank.registration.application.camunda.model.BaseModel;

public interface IPasscodeService {

    void saveWhiteListPasscode(BaseModel model);

    void savePasscode(String dmzSessionId, String password);

    boolean validatePasscode(String password, String storedPassword);

    void changeStatusByDeviceId(String status, String deviceId);

    void changeStatusByUserId(String status, String deviceId);

}
