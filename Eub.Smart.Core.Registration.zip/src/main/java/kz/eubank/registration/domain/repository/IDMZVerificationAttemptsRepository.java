package kz.eubank.registration.domain.repository;

import kz.eubank.registration.domain.model.pojo.DMZVerificationAttempts;

public interface IDMZVerificationAttemptsRepository {

    void save(DMZVerificationAttempts dmzVerificationAttempts);
}
