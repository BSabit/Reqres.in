package kz.eubank.registration.domain.service;

import kz.eubank.registration.domain.model.dto.response.AnalysisResponseDto;
import kz.eubank.registration.domain.model.dto.response.AuthorizeResponseDto;
import kz.eubank.registration.domain.model.dto.response.FolderResponseDto;
import kz.eubank.registration.domain.model.dto.response.UploadMediaResponseDto;
import org.springframework.util.MultiValueMap;
import org.springframework.web.multipart.MultipartFile;

import java.util.Optional;

public interface IForensicService {

    Optional<AuthorizeResponseDto> getAuthorize();

    void setAuthTokenOrThrowException();

    void refreshToken();

    AnalysisResponseDto[] startAnalyses(String biometricsType, String folderId);

    FolderResponseDto uploadMedia(String payload, MultiValueMap<String, MultipartFile> mediaList);

    UploadMediaResponseDto[] uploadMediaIntoFolder(String folderId, MultipartFile media, String payload);

    Optional<AnalysisResponseDto[]> getAnalysis(String folderId);

    Optional<AnalysisResponseDto> getAnalysisById(String analyzeId);

    AnalysisResponseDto getAnalysisOrTrowException(String folderId);

    String getThumbUrl(AnalysisResponseDto analysisResponseDtos);

    String downloadFileOrTrowException(String url);
}