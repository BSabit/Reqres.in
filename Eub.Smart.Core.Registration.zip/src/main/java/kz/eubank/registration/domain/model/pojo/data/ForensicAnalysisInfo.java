package kz.eubank.registration.domain.model.pojo.data;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ForensicAnalysisInfo {

    @Schema(description = "id анализа")
    private String analyseId;
    @Schema(description = "резолюция")
    private String resolution;
    @Schema(description = "Анализ состояния")
    private String state;
    @Schema(description = "Тип анализа")
    private String type;
}
