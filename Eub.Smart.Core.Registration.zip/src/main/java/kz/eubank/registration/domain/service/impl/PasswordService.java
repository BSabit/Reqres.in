package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.model.pojo.DMZVerification;
import kz.eubank.registration.domain.model.pojo.Password;
import kz.eubank.registration.domain.repository.IDMZVerificationRepository;
import kz.eubank.registration.domain.repository.IPasswordRepository;
import kz.eubank.registration.domain.service.IPasswordService;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import static kz.eubank.registration.domain.util.DateUtil.currentDate;
import org.springframework.stereotype.Service;

import java.util.Optional;

import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.E_BS_903;

@Service
@RequiredArgsConstructor
public class PasswordService implements IPasswordService {

    private final IPasswordRepository passwordRepository;
    private final IDMZVerificationRepository dmzVerificationRepository;


    @Override
    public void savePassword(BaseModel model) {
        Long userId = getUserId(model, dmzVerificationRepository);
        passwordRepository.makePasswordInvalid(userId);

        String hash = "Smartbank 3.0";
        int isTechnical = 0;
        int isValid = 1;

        Password password = Password.builder()
                .hash(hash)
                .userId(userId)
                .isTechnical(isTechnical)
                .dateCreated(currentDate())
                .isValid(isValid)
                .build();
        passwordRepository.save(password);
    }

    static Long getUserId(BaseModel model, IDMZVerificationRepository dmzVerificationRepository) {
        Optional<DMZVerification> dmzVerification = dmzVerificationRepository.findBySessionId(model.getSessionId());
        if (dmzVerification.isEmpty()) throw new SelfException(E_BS_903, "not found sessionId: " + model.getSessionId());

        long userId = dmzVerificationRepository.findUserIdByIin(model.getSessionId());
        if (userId == 0) throw new SelfException(SelfErrorCode.E_BS_901, "userId through sessionId not found: " + model.getSessionId());
        return userId;
    }
}
