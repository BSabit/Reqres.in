package kz.eubank.registration.domain.model.enums;

public enum BiometricsStatus {

    BINM,   //Биометрия не совпала
    RDDE,   //Не удалось получить ЦД из EGOV
    VDDF,   //Верификация по Цифровым документам не прошла
    CDDN,   //ЦОИД не работает, цифровых доков нет
    AZST,   //Анализ запушен
    VIIN,   //Ожидает проверки ИИН
    VODD,   //Ожидает кода ОТП от Цифровых документов
    SCBO    //Биометрия прошла успешно
}
