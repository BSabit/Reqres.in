package kz.eubank.registration.domain.repository;

import kz.eubank.registration.domain.model.pojo.ClientDigitalDocument;

import java.util.Date;
import java.util.Optional;

public interface IClientDigitalDocumentRepository {

    ClientDigitalDocument save(ClientDigitalDocument clientDigitalDocument);

    Optional<ClientDigitalDocument> findActualByIin(String iin);

    void verifyByFileUid(String fileUid);

    void updateDateExpiredByIin(Date expiredDate, String iin);
}
