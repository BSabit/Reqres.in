package kz.eubank.registration.domain.model.dto;

public record AttemptsLimitDto(String type,
                               int count) {
}
