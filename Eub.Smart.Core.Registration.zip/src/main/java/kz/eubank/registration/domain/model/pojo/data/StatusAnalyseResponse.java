package kz.eubank.registration.domain.model.pojo.data;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class StatusAnalyseResponse {

    @Schema(description = "анализ внутреннии (forensic)")
    List<ForensicAnalysisInfo> analysis;
    @Schema(description = "анализ банка (kisc)")
    List<KiscAnalysisInfo> bankAnalysis;
    @Schema(description = "id требования")
    String claimId;
    @Schema(description = "флаг завершенности анализа")
    Boolean done;
    @Schema(description = "id папки")
    String folderId;
    @Schema(description = "фото")
    String photo;
    @Schema(description = "флаг успешности анализа")
    Boolean success;
}
