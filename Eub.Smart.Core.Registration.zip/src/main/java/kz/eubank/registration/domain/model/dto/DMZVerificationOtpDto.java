package kz.eubank.registration.domain.model.dto;

import java.util.Date;

public record DMZVerificationOtpDto(Long id,
                                    Date createdDate,
                                    String otpStatus,
                                    Date expiredDate,
                                    String codeHash,
                                    Long dmzVerification,
                                    int countValidation) {
}
