package kz.eubank.registration.domain.util;

import java.time.LocalDate;
import java.time.Period;

public class IINUtil {

    public static int getAgeFromIIN(String iin) {
        String yearStr = iin.substring(0, 2);
        var year = 0;
        var month = Integer.parseInt(iin.substring(2, 4));
        var day = Integer.parseInt(iin.substring(4, 6));

        if (iin.charAt(6) == '3' || iin.charAt(6) == '4' || iin.charAt(6) == '0') {
            year = Integer.parseInt(19 + yearStr);
        } else if (iin.charAt(6) == '5' || iin.charAt(6) == '6') {
            year = Integer.parseInt(20 + yearStr);
        }
        LocalDate now = LocalDate.now();
        LocalDate birthDate = LocalDate.of(year, month, day);
        return Period.between(birthDate, now).getYears();
    }

    public static boolean isValid(String iin) {
        if (iin.length() != 12) {
            return false;
        }
        var year = Integer.parseInt(iin.substring(0, 2));
        var month = Integer.parseInt(iin.substring(2, 4));
        var day = Integer.parseInt(iin.substring(4, 6));
        var century = Integer.parseInt(iin.substring(6, 7));

        return year >= 0 && year <= 99 &&
                month >= 1 && month <= 12 &&
                day >= 1 && day <= 31 &&
                century >= 0 && century <= 6;
    }

    public static boolean isNotValid(String iin) {
        return !isValid(iin);
    }
}
