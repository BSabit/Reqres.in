package kz.eubank.registration.domain.model.pojo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@Builder
public class DMZVerificationOtp {

    private Long id;
    private Date createdDate;
    private OtpStatus otpStatus;
    private Date expiredDate;
    private String codeHash;
    private DMZVerification dmzVerification;
    private int countValidation;
}
