package kz.eubank.registration.domain.repository;

import kz.eubank.registration.domain.model.pojo.DMZVerification;

import java.util.Optional;

public interface IDMZVerificationRepository {

    int getVerificationLimitCountByMobilePhone(String mobilePhone);

    Optional<DMZVerification> getNotFinishedSessionByMobilePhoneAndDeviceId(String mobilePhone, String deviceId);

    Optional<DMZVerification> findBySessionId(String sessionId);

    void save(DMZVerification dmzVerification);

    String findDeviceId(String sessionId);

    long findUserIdByIin(String sessionId);

    void updateIin(String sessionId, String iin);

    void updatePasscode(String sessionId, long passcode);

    void updateOldPasscode(String sessionId, long oldPasscodeId);

    void updateStatus(String status, long dmzverificationId);

    void updateStatusWithSessionId(String status, String sessionId);
}
