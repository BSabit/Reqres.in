package kz.eubank.registration.domain.model.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;



@Data
@NoArgsConstructor
@AllArgsConstructor
public class Fingerprint {

    private long id;

    private int userId;

    private String status;

    private byte[] publicKey;

    private String deviceId;

    private Date dateCreated;

    private int invalidUses;

    private Date lastInvalidUse;
}
