package kz.eubank.registration.domain.model.enums;

public enum Gender {
    MALE,
    FEML,
    UNKN
}
