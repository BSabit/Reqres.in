package kz.eubank.registration.domain.service;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.model.pojo.ClientDigitalDocument;

import java.util.Date;

public interface IClientDigitalDocumentService {

    void saveBestShotToS3(String iin, String photoEncoded);

    void getActualIDCardIfExists(BaseModel model);

    void getIdentityCardFromS3(BaseModel model);

    ClientDigitalDocument saveClientDigitalDocument(String iin, String type);

    void verifyByFileUid(String fileUid);

    void updateDateExpiredByIin(Date expiredDate, String iin);
}
