package kz.eubank.registration.domain.repository;

import java.util.Set;

public interface IMobileOperatorRepository {

    Set<String> getAllMobileOperators();
}
