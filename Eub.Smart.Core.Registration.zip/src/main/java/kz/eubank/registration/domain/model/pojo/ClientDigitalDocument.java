package kz.eubank.registration.domain.model.pojo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@Builder
public class ClientDigitalDocument {

    private Long id;
    private Date dateCreated;
    private Date dateExpired;
    private String iin;
    private boolean isVerified;
    private ClientDigitalDocumentType clientDigitalDocumentType;
}
