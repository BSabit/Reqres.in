package kz.eubank.registration.domain.model.pojo.data;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Getter
@Setter
public class GbdflClientInfo {

    private List<GbdflDocumentDetails> documentList;
    private Date birthDate;
    private String iin;
    private String firstName;
    private String patronymic;
    private String surname;
    private AddressInfo regAddress;
    private AddressInfo birthPlace;
    private String citizenshipIso;
    private Gender gender;
}
