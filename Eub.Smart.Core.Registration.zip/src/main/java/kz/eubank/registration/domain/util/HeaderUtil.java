package kz.eubank.registration.domain.util;

import static kz.eubank.registration.domain.model.enums.FrontEnd.*;

public class HeaderUtil {

    public static String extractFrontEndFromUserAgent(String userAgent) {
        var agents = userAgent.split(";");
        var frontEnd = UNKN;
        if (agents.length == 3) {
            var temp = agents[2].split(":");
            var platform = temp[0];

            if ("android".equalsIgnoreCase(platform)) {
                frontEnd = ANDP;
            } else if ("ios".equalsIgnoreCase(platform)) {
                frontEnd = IPHN;
            } else if ("swagger".equalsIgnoreCase(platform)) {
                frontEnd = APTS;
            }
        }
        return frontEnd.name();
    }
}
