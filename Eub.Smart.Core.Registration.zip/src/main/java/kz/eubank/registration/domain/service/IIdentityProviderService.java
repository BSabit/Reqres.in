package kz.eubank.registration.domain.service;

public interface IIdentityProviderService {

    void clearUserByUsername(String mobilePhone, String correlationId);
}
