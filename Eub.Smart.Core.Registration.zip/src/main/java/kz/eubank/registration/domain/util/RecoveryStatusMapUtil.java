package kz.eubank.registration.domain.util;

public class RecoveryStatusMapUtil {

    public static String convert(String status) {
        return switch (status) {
            case "WPHE" -> "E_BS_1000";
            case "CNEW" -> "E_BS_1001";
            case "ARST" -> "E_BS_1002";
            case "FCNF" -> "E_BS_1003";
            case "FCIE" -> "E_BS_1005";
            case "RSPE" -> "E_BS_1006";
            case "FAOW" -> "E_BS_1007";
            case "ANAR" -> "E_BS_1008";
            case "ANER" -> "E_BS_1009";
            case "PNER" -> "E_BS_1010";
            case "CNER" -> "E_BS_1011";
            case "CNAR" -> "E_BS_1012";
            case "FMPO" -> "E_BS_1013";
            case "W4NA" -> "E_BS_1014";
            case "FPHE" -> "E_BS_1015";
            case "FPHN" -> "E_BS_1016";
            default -> "E_BS_1004";
        };
    }
}
