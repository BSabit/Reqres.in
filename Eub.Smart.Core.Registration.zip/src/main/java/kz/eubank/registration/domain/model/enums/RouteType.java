package kz.eubank.registration.domain.model.enums;

public enum RouteType {

    NTFC,   //Незавершенный время жизни
    RBYB,   //Восстановление по биометрии
    RBYP,   //Восстановление по продукту
    REGR,   //Регистрация
    WHLS    //Белый список
}
