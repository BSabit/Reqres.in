package kz.eubank.registration.domain.service;

import kz.eubank.registration.domain.model.enums.DMZVerificationAttemptsType;

public interface IDMZVerificationAttemptsService {

    void fixAttempt(String sessionId, DMZVerificationAttemptsType type);
}
