package kz.eubank.registration.domain.model.pojo.data;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class AddressInfo {

    private Date changeDate;
    private String city;
    private String country;
    private String countryIsoNum;
    private String district;
    private String flat;
    private String house;
    private String region;
    private String status;
    private String street;
}
