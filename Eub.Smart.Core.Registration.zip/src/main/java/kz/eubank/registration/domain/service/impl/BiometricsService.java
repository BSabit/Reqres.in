package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.model.pojo.Biometrics;
import kz.eubank.registration.domain.model.pojo.BiometricsStatus;
import kz.eubank.registration.domain.model.pojo.BiometricsType;
import kz.eubank.registration.domain.repository.IBiometricsRepository;
import kz.eubank.registration.domain.repository.IDMZVerificationRepository;
import kz.eubank.registration.domain.service.IBiometricsService;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

import static kz.eubank.registration.domain.model.enums.AnalyseType.BIOMETRY;
import static kz.eubank.registration.domain.model.enums.AnalyseType.QUALITY;
import static kz.eubank.registration.domain.model.enums.BiometricsStatus.AZST;
import static kz.eubank.registration.domain.util.DateUtil.currentDate;

@Service
@RequiredArgsConstructor
public class BiometricsService implements IBiometricsService {

    private final IBiometricsRepository biometricsRepository;
    private final IDMZVerificationRepository dmzVerificationRepository;

    @Override
    public void saveBiometrics(BaseModel model) {
        var dmzVerification = dmzVerificationRepository.findBySessionId(model.getSessionId())
                .orElseThrow(() -> new SelfException(SelfErrorCode.E_DB_600));
        var type = new BiometricsType();
        type.setId(model.getBiometricsType());
        var status = new BiometricsStatus();
        status.setId(AZST.name());

        //TODO save Data
        var biometrics = Biometrics.builder()
                .dateCreated(currentDate())
                .type(type)
                .status(status)
                .folderId(model.getFolderId())
                .dmzVerification(dmzVerification)
                .data("")
                .biometryAnalyseId(model.getAnalyses().get(BIOMETRY.name()))
                .qualityAnalyseId(model.getAnalyses().get(QUALITY.name()))
                .build();
        biometricsRepository.save(biometrics);
    }

    public Biometrics getBiometrics(String folderId) {
        Optional<Biometrics> biometrics = biometricsRepository.findByFolderId(folderId);
        if (biometrics.isEmpty()) throw new SelfException(SelfErrorCode.E_DB_600);
        String status = biometrics.get().getStatus().getId();
        if (!status.equals(AZST.name())) throw new SelfException(SelfErrorCode.E_BS_909);
        return biometrics.get();
    }

    public void updateData(Object analyseResponse, String status, long biometryId) {
        biometricsRepository.updateData(analyseResponse, status, biometryId);
    }

    @Override
    public void updateStatus(String status, long biometryId) {
        biometricsRepository.updateStatus(status, biometryId);
    }

    @Override
    public void updateSimilarityPercentByFolderId(String folderId, double similarityPercent) {
        biometricsRepository.updateSimilarityPercentByFolderId(folderId, similarityPercent);
    }
}
