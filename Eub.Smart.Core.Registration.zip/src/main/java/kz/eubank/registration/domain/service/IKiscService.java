package kz.eubank.registration.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import javassist.NotFoundException;
import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.infrastructure.model.dto.kisc.MatchPhotoRequestDto;
import kz.eubank.registration.infrastructure.model.dto.kisc.MathPhotoResponseDto;

import java.util.Map;

public interface IKiscService {

    MathPhotoResponseDto matchPhoto(MatchPhotoRequestDto dto) throws JsonProcessingException;
    void isSimilar(BaseModel model, String encodedPhoto) throws JsonProcessingException, NotFoundException;
}
