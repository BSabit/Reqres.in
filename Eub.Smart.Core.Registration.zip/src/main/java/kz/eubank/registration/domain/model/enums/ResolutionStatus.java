package kz.eubank.registration.domain.model.enums;

public enum ResolutionStatus {

    INITIAL,
    PROCESSING,
    FAILED,
    FINISHED,
    DECLINED,
    SUCCESS,
    OPERATOR_REQUIRED
}
