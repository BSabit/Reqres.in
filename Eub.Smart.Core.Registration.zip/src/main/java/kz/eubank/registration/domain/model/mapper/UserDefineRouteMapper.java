package kz.eubank.registration.domain.model.mapper;

import kz.eubank.registration.domain.model.dto.UserDefineRouteDto;
import kz.eubank.registration.domain.model.pojo.view.UserDefineRouteView;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface UserDefineRouteMapper {

    UserDefineRouteMapper INSTANCE = Mappers.getMapper(UserDefineRouteMapper.class);

    @Mapping(source = "resident", target = "isResident")
    UserDefineRouteDto toDto(UserDefineRouteView userDefineRouteView);
}
