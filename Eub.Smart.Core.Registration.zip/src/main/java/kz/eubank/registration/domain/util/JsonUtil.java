package kz.eubank.registration.domain.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;

import java.util.Optional;

public class JsonUtil {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static <T> Optional<T> toObject(String json, Class<T> clazz) {
        try {
            T result = objectMapper.readValue(json, clazz);
            return Optional.of(result);
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    public static <T> T toObjectOrThrowException(String json, Class<T> clazz) {
        return toObject(json, clazz)
                .orElseThrow(() -> new SelfException(SelfErrorCode.E_SM_500));
    }

    public static Optional<String> toJson(Object object) {
        try {
            String result = objectMapper.writeValueAsString(object);
            return Optional.of(result);
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    public static String toJsonOrThrowException(Object object) {
        return toJson(object)
                .orElseThrow(() -> new SelfException(SelfErrorCode.E_SM_501));
    }
}
