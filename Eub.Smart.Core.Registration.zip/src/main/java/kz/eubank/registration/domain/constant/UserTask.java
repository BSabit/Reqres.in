package kz.eubank.registration.domain.constant;

public interface UserTask {

    String DEFINE_ROUTE = "DefineRoute";
    String LOGIN = "Login";
    String VERIFICATION_PRODUCT = "VerificationProduct";
    String VERIFICATION_IIN = "VerificationIIN";
    String PASSCODE_SET = "PasscodeSet";
    String UPLOAD_SELFIE = "UploadSelfie";
    String STATUS_ANALYSE = "StatusAnalyse";
    String DIGITAL_DOCUMENT = "DigitalDocument";
    String ERROR_TEXT = "ErrorText";
    String SMS = "Sms";
    String CONTACT_SUPPORT = "ContactSupport";
}
