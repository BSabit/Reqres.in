package kz.eubank.registration.domain.factory;

import org.apache.pdfbox.util.filetypedetector.FileType;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface PdfConvertor {

    List<MultipartFile> toMultipartFiles(byte[] pdfBytes) throws IOException;

    FileType fileType();
}
