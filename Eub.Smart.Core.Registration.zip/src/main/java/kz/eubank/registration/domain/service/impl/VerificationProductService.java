package kz.eubank.registration.domain.service.impl;

import SmartRegistration.V1.EubAggregatorCoreSmartRegistration;
import kz.eubank.registration.application.camunda.model.BaseModel;
import kz.eubank.registration.domain.model.pojo.DMZVerification;
import kz.eubank.registration.domain.model.pojo.RecoveryProduct;
import kz.eubank.registration.domain.model.pojo.RecoveryProductAccountType;
import kz.eubank.registration.domain.model.pojo.RecoveryProductStatus;
import kz.eubank.registration.domain.repository.IDMZVerificationRepository;
import kz.eubank.registration.domain.repository.IRecoveryProductRepository;
import kz.eubank.registration.domain.repository.IRecoveryProductStatusRepository;
import kz.eubank.registration.domain.service.IDMZVerificationAttemptsService;
import kz.eubank.registration.domain.service.IVerificationProductService;
import kz.eubank.registration.domain.util.RecoveryStatusMapUtil;
import kz.eubank.registration.infrastructure.repository.grpc.IVerifyClientRepository;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Optional;

import static kz.eubank.registration.domain.model.enums.DMZVerificationAttemptsType.VRPA;
import static kz.eubank.registration.domain.model.enums.RouteStatus.FAIL;
import static kz.eubank.registration.domain.model.enums.RouteStatus.VSCS;
import static kz.eubank.registration.domain.model.enums.RouteType.NTFC;
import static kz.eubank.registration.domain.model.enums.RouteType.RBYP;
import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.*;

@Service
@RequiredArgsConstructor
public class VerificationProductService implements IVerificationProductService {

    private final Logger log = LogManager.getLogger(getClass());

    private final IVerifyClientRepository verifyClientRepository;
    private final IDMZVerificationRepository dmzVerificationRepository;
    private final IDMZVerificationAttemptsService dmzVerificationAttemptsService;
    private final IRecoveryProductRepository recoveryProductRepository;
    private final IRecoveryProductStatusRepository recoveryProductStatusRepository;
    private static final EubAggregatorCoreSmartRegistration.RecoveryProductAccountType card = EubAggregatorCoreSmartRegistration.RecoveryProductAccountType.CARD;
    private static final EubAggregatorCoreSmartRegistration.RecoveryProductAccountType acct = EubAggregatorCoreSmartRegistration.RecoveryProductAccountType.ACCT;

    private RecoveryProductAccountType getAccountTypeByProduct(String product) {
        RecoveryProductAccountType recoveryProductAccountType = new RecoveryProductAccountType();
        if (product.length() == 20) {
            recoveryProductAccountType.setId("ACCT");
            return recoveryProductAccountType;
        }
        if (product.length() == 40) {
            recoveryProductAccountType.setId("CARD");
            return recoveryProductAccountType;
        }
        throw new SelfException(SelfErrorCode.E_BS_902, "incorrect product type: " + product);
    }

    @Override
    public void recoveryAccount(BaseModel model) {

        int recoveryAttempts = model.getProductRecoveryAttempts();
        if (recoveryAttempts == 1) {
            model.setProductRecoveryAttempts(2);
        }
        String mobilePhone = model.getPhoneNumber();
        if (mobilePhone.length() == 11) {
            mobilePhone = model.getPhoneNumber().substring(1);
        }
        Optional<DMZVerification> checkSessionId = dmzVerificationRepository.findBySessionId(model.getSessionId());
        if (checkSessionId.isEmpty()) throw new SelfException(E_BS_903, "not found sessionId: " + model.getSessionId());
        String typeSessionId = checkSessionId.get().getRouteType().getId();

        if (typeSessionId.equals(NTFC.name())) throw new SelfException(E_BS_906, "session expired: " + typeSessionId);
        if (!typeSessionId.equals(RBYP.name())) throw new SelfException(E_BS_905, "route type not correct: " + typeSessionId);

        String routeStatusSessionId = checkSessionId.get().getRouteStatus().getId();
        //if (!routeStatusSessionId.equals("VSMS")) throw new SelfException(E_BS_904, "route status not correct: " + routeStatusSessionId);

        EubAggregatorCoreSmartRegistration.VerifyClientReply response;
        RecoveryProductAccountType type = this.getAccountTypeByProduct(model.getProductNumber());
        log.debug("Start recoveryAccount sessionId: {}, type: {}, product: {}, mobilePhone: {}",
                model.getSessionId(), type, model.getProductNumber(), mobilePhone);
        if (type.getId().equals("ACCT")) {
            response = verifyClientRepository.sendRequestVerifyClient(acct, model.getProductNumber(), model.getClientIin(), mobilePhone, model.getSessionId());
        } else if (type.getId().equals("CARD")) {
            response = verifyClientRepository.sendRequestVerifyClient(card, model.getProductNumber(), model.getClientIin(), mobilePhone, model.getSessionId());
        } else {
            throw new SelfException(E_BS_902, "incorrect product type: " + model.getProductNumber());
        }

        if (response == null) throw new SelfException(E_BS_902, "VerifyClient grpc service response null");

        dmzVerificationRepository.updateIin(model.getSessionId(), model.getClientIin());

        String responseStatus = response.getStatus().toString();
        String responseCustomerId = response.getCustomerId();
        String responseMobilePhone = response.getPhoneNumber();
        String responseSystem = response.getSystem().toString();
        log.info("VerifyClient response customerId: {}, mobilePhone: {}, status: {}, system: {}",
                         responseCustomerId, responseMobilePhone, responseStatus, responseSystem);
        //if (mobilePhone.equals(responseMobilePhone)) throw new SelfException(E_BS_902,
        // "mobilePhone entered differs from the response to the system: " + mobilePhone + "/" + responseMobilePhone);

        RecoveryProductStatus recoveryProductStatus = recoveryProductStatusRepository.findById(responseStatus);

        RecoveryProduct recoveryProduct = RecoveryProduct.builder()
                .productNumber(model.getProductNumber())
                .dateCreated(new Date())
                .iin(model.getClientIin())
                .dmzVerification(checkSessionId.get())
                .type(type)
                .status(recoveryProductStatus)
                .customer(responseCustomerId)
                .mobilePhone(responseMobilePhone)
                .bsystem(responseSystem)
                .build();
        recoveryProductRepository.save(recoveryProduct);

        if (!responseStatus.equals("RGOK")) {
            dmzVerificationRepository.updateStatus(FAIL.toString(), checkSessionId.get().getId());
            dmzVerificationAttemptsService.fixAttempt(model.getSessionId(), VRPA);
            String error = RecoveryStatusMapUtil.convert(responseStatus);
            model.setIsProductValid(false);
            if (!E_BS_1017.equals(model.getError())) {
                model.setError(SelfErrorCode.valueOf(error));
            }
            return;
        }
        dmzVerificationRepository.updateStatus(VSCS.toString(), checkSessionId.get().getId());
        model.setIsProductValid(true);
    }
}
