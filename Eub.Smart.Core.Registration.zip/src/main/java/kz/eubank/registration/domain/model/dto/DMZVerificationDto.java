package kz.eubank.registration.domain.model.dto;

import java.util.Date;

public record DMZVerificationDto(Long id,
                                 String sessionId,
                                 String routeType,
                                 Date dateCreated,
                                 Date dateExpired,
                                 String mobilePhone,
                                 String iin,
                                 String routeStatus,
                                 String deviceId,
                                 String versionFront,
                                 String frontEnd,
                                 String oldPasscode,
                                 String passcode) {
}
