package kz.eubank.registration.domain.service;

import kz.eubank.registration.application.camunda.model.BaseModel;

public interface IVerificationIINService {

    void verificationIIN(BaseModel model);
}
