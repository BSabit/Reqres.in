package kz.eubank.registration.domain.model.enums;

public enum OtpStatus {

    SEND,   //Отправлено
    FAIL,   //ОТП не совпадает
    SCCS   //Провалидировано
}
