package kz.eubank.registration.domain.model.mapper;

import kz.eubank.registration.domain.model.dto.WhiteListAuthorizationDto;
import kz.eubank.registration.domain.model.pojo.WhiteListAuthorization;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface WhiteListAuthorizationMapper {

    WhiteListAuthorizationMapper INSTANCE = Mappers.getMapper(WhiteListAuthorizationMapper.class);

    @Mapping(source = "active", target = "active")
    WhiteListAuthorizationDto toDto(WhiteListAuthorization whiteListAuthorization);
}
