package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.domain.model.dto.AttemptsLimitDto;
import kz.eubank.registration.domain.model.enums.DMZVerificationAttemptsType;
import kz.eubank.registration.domain.model.mapper.AttemptsLimitMapper;
import kz.eubank.registration.domain.repository.view.IAttemptsLimitViewRepository;
import kz.eubank.registration.domain.service.IAttemptsLimitService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AttemptsLimitService implements IAttemptsLimitService {

    private final IAttemptsLimitViewRepository attemptsLimitViewRepository;

    @Override
    public List<AttemptsLimitDto> getLimitsCountByMobilePhone(String phoneNumber) {
        var attemptsLimit = attemptsLimitViewRepository.getLimitsCountByMobilePhone(phoneNumber);
        return AttemptsLimitMapper.INSTANCE.toDtoList(attemptsLimit);
    }

    @Override
    public AttemptsLimitDto getLimitsCountByMobilePhoneAndType(String phoneNumber, DMZVerificationAttemptsType type) {
        var attemptLimit =
                attemptsLimitViewRepository.getLimitsCountByMobilePhoneAndType(phoneNumber, type.name());
        return AttemptsLimitMapper.INSTANCE.toDto(attemptLimit.orElse(null));
    }
}
