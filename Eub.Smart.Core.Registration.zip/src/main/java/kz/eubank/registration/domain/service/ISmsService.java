package kz.eubank.registration.domain.service;

import kz.eubank.registration.application.camunda.model.BaseModel;

public interface ISmsService {

    void sendSms(BaseModel model);

    void checkSms(BaseModel model);
    void sendSmsNewDevice(BaseModel model);
}
