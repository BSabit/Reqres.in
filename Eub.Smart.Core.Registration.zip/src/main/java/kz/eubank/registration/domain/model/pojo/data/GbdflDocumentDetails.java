package kz.eubank.registration.domain.model.pojo.data;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class GbdflDocumentDetails {

    private String documentNumber;
    private String documentStatus;
    private String documentTypeCode;
    private String issuerCode;
    private Date expiryDate;
    private String firstName;
    private Date issueDate;
    private String issuer;
    private String patronymic;
    private String surname;
    private String typeNameKz;
    private String typeNameRu;
}
