package kz.eubank.registration.domain.model.pojo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;
import java.util.Locale;

@Getter
@Setter
@Builder
public class User {
    private Long id;
    private String username;
    private Integer person;
    private String locale;
    private String status;
    private Long layout;
    private Long theme;
    private Integer loginHourStart;
    private Integer loginHourEnd;
    private Integer failedLogins;
    private String codeWord;
    private Integer passwordAge;
    private Integer sessionTimeout;
    private Date dateRegistered;
    private Integer branch;
    private String registeredBy;
    private String regChannelId;
    private Date regFinishDate;
    private Date dateCreated;
    private boolean useSmallCards;
    private Integer region;
}
