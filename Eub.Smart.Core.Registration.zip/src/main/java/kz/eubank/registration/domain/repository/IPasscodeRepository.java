package kz.eubank.registration.domain.repository;

import kz.eubank.registration.domain.model.pojo.NewPasscode;


public interface IPasscodeRepository {
    NewPasscode saveAndGet(NewPasscode newPasscode);
    void changeStatus(String status, String deviceId);
    void changeStatusByUserId(String status, String userID);
    String findHash(String sessionId);
}
