package kz.eubank.registration.domain.constant;

public interface TargetTable {

    String CLIENT_DIGITAL_DOCUMENT = "ClientDigitalDocument";
}
