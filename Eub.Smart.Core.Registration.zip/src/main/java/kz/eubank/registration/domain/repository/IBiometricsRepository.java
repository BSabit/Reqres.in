package kz.eubank.registration.domain.repository;

import kz.eubank.registration.domain.model.pojo.Biometrics;

import java.util.Optional;

public interface IBiometricsRepository {

    void save(Biometrics biometrics);
    Optional<Biometrics> findByFolderId(String folderId);
    void updateData(Object analyseResponse, String status, long biometryId);
    void updateStatus(String status, long biometryId);

    void updateSimilarityPercentByFolderId(String folderId, double similarityPercent);
}
