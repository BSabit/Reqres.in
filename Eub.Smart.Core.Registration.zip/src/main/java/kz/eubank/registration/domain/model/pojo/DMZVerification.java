package kz.eubank.registration.domain.model.pojo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@Builder
public class DMZVerification {

    private Long id;
    private String sessionId;
    private RouteType routeType;
    private Date dateCreated;
    private Date dateExpired;
    private String mobilePhone;
    private String iin;
    private RouteStatus routeStatus;
    private String deviceId;
    private String versionFront;
    private String frontEnd;
    private String oldPasscode;
    private String passcode;
}
