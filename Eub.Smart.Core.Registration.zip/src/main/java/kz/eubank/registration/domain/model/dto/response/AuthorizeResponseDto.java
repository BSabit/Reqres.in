package kz.eubank.registration.domain.model.dto.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuthorizeResponseDto {

    private String access_token;
    private String expire_token;
}
