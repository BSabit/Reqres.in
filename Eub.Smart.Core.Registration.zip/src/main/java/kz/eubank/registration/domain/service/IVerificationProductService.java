package kz.eubank.registration.domain.service;

import kz.eubank.registration.application.camunda.model.BaseModel;

public interface IVerificationProductService {

    void recoveryAccount(BaseModel model);
}
