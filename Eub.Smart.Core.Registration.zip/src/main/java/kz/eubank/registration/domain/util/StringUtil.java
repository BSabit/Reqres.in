package kz.eubank.registration.domain.util;

import org.camunda.bpm.engine.impl.util.CollectionUtil;

import java.util.Arrays;
import java.util.stream.Stream;

public class StringUtil {

    public static boolean isNotEmpty(String value) {
        return !isEmpty(value);
    }

    public static boolean isEmpty(String value) {
        int strLen;
        if (value == null || (strLen = value.length()) == 0) {
            return true;
        }
        for (int i = 0; i < strLen; i++) {
            if (!Character.isWhitespace(value.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    public static boolean isAnyEmpty(String... values) {
        return CollectionUtil.isEmpty(Arrays.asList(values)) || Stream.of(values).anyMatch(StringUtil::isEmpty);
    }
}
