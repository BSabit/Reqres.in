package kz.eubank.registration.domain.repository;

import kz.eubank.registration.domain.model.pojo.Device;

public interface IDeviceRepository {
    int checkDeviceIsExistAmount(String deviceId, Long userId);
    void save(Device device);
    void makeDeviceValid(Long userId, String deviceId);
    void logoutOtherDevices(Long userId, String deviceId);
}
