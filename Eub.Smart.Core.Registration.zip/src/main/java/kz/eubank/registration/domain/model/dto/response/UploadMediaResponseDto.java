package kz.eubank.registration.domain.model.dto.response;

import kz.eubank.registration.domain.model.enums.MediaType;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class UploadMediaResponseDto {

    private Integer time_created;
    private Integer time_updated;
    private Object technical_meta_data;
    private Object meta_data;
    private String media_id;
    private MediaType media_type;
    private Object info;
    private List<String> tags;
    private String original_name;
    private String image_id;
    private String original_url;
    private String thumb_url;
}
