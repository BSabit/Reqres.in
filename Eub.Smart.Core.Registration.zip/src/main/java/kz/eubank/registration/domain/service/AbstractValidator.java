package kz.eubank.registration.domain.service;


import kz.eubank.registration.presentation.rest.exception.ErrorDto;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.util.List;
import java.util.Set;

public abstract class AbstractValidator {

    private final Logger log = LogManager.getLogger(getClass());

    public abstract List<ErrorDto> validate(Object dto);

    protected void validateByAnnotation(Object dto, List<ErrorDto> errorDtoList) {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<Object>> violations = validator.validate(dto);
        for (ConstraintViolation<Object> violation : violations) {
            ErrorDto errorDto = new ErrorDto();
            errorDto.setErrorMessage(violation.getPropertyPath().toString());
            errorDto.setErrorDetails(violation.getMessageTemplate());
            errorDtoList.add(errorDto);
            log.error("Exception in Requirement with field {} error message {}",
                    errorDto.getErrorMessage(), errorDto.getErrorDetails());
        }
    }
}
