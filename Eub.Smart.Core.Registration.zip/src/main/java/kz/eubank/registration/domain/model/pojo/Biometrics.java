package kz.eubank.registration.domain.model.pojo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@Builder
public class Biometrics {

    private Long id;
    private Date dateCreated;
    private BiometricsType type;
    private BiometricsStatus status;
    private String folderId;
    private DMZVerification dmzVerification;
    private String data;
    private String biometryAnalyseId;
    private String qualityAnalyseId;
    private Double similarityPercent;
}
