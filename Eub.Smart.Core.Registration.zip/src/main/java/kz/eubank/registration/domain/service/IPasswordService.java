package kz.eubank.registration.domain.service;

import kz.eubank.registration.application.camunda.model.BaseModel;

public interface IPasswordService {
    void savePassword(BaseModel model);
}
