package kz.eubank.registration.domain.constant;

public interface HeaderName {

    String FORENSIC_ACCESS_TOKEN = "X-Forensic-Access-Token";
    String X_CORRELATION_ID = "X-Correlation-Id";
}
