package kz.eubank.registration.domain.model.pojo.data;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BiometricsData {

    private String status;
    private String mobilePhone;
    private String folderId;
    private String applicationId;
    private StatusAnalyseResponse analysis;
    private GbdflClientInfo gbdflClientInfo;
    private Object userCreateInfo;
    private String iin;
    private String documentNumber;
    private List<Object> userDocuments;
    private PhotoValidationResponse photoValidationResponse;

    public BiometricsData() {
        this.status = "NEW";
    }
}
