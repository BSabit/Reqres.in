package kz.eubank.registration.domain.service.impl;

import feign.FeignException;
import kz.eubank.registration.domain.service.IIdentityProviderService;
import kz.eubank.registration.infrastructure.repository.feignclient.IdentityProviderFeignClient;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class IdentityProviderService implements IIdentityProviderService {

    private final Logger log = LogManager.getLogger(getClass());
    private final IdentityProviderFeignClient identityProviderFeignClient;

    @Override
    public void clearUserByUsername(String mobilePhone, String correlationId) {
        try {
            identityProviderFeignClient.clearUserCache(mobilePhone, correlationId);
            log.info("remove cache user: {} successfully", mobilePhone);
        } catch (FeignException.NotFound e) {
            log.info("user: {} not found remove cache is not required", mobilePhone);
        } catch (Exception e) {
            log.error("remove cache user: {} not successfully", mobilePhone);
        }
    }
}
