package kz.eubank.registration.domain.model.dto.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FolderResponseDto {

    private Integer time_created;
    private Integer time_updated;
    private Object technical_meta_data;
    private Object meta_data;
    private String folder_id;
    private String user_id;
    private Integer resolution_time;
    private String resolution_status;
    private String resolution_endpoint;
    private String resolution_state_hash;
    private String resolution_comment;
    private String operator_status;
    private String operator_comment;
    private String resolution_author_id;
    private Boolean is_archive;
    private Boolean is_cleared;
    private Object media;
}
