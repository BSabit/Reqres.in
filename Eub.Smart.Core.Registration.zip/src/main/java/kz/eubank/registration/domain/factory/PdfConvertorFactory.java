package kz.eubank.registration.domain.factory;

import org.apache.pdfbox.util.filetypedetector.FileType;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.*;

import static kz.eubank.registration.domain.util.StringUtil.isEmpty;

@Service
public class PdfConvertorFactory {

    private final Map<FileType, PdfConvertor> pdfMapperMap = new HashMap<>();

    public PdfConvertorFactory(Set<PdfConvertor> pdfConvertorImpls) {
        pdfConvertorImpls.forEach(pdfConvertorImpl -> pdfMapperMap.put(pdfConvertorImpl.fileType(), pdfConvertorImpl));
    }

    public List<MultipartFile> toMultipartFiles(String pdfEncode, FileType fileType) {
        if (isEmpty(pdfEncode)) throw new RuntimeException();
        try {
            return process(pdfEncode, fileType);
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }

    private List<MultipartFile> process(String pdfEncode, FileType fileType) throws IOException {
        byte[] pdfBytes = Base64.getDecoder().decode(pdfEncode);
        return pdfMapperMap.get(fileType).toMultipartFiles(pdfBytes);
    }
}
