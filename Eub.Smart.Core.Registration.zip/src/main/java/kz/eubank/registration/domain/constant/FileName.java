package kz.eubank.registration.domain.constant;

public interface FileName {

    String IMAGE = "image";
}
