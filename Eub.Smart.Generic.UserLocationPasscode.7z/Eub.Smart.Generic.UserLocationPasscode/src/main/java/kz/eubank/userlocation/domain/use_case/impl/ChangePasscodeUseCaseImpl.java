package kz.eubank.userlocation.domain.use_case.impl;

import kz.eubank.userlocation.domain.repository.PasscodeRepository;
import kz.eubank.userlocation.domain.use_case.ChangePasscodeUseCase;
import lombok.AllArgsConstructor;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

@AllArgsConstructor

public class ChangePasscodeUseCaseImpl implements ChangePasscodeUseCase {

    private final PasscodeRepository passcodeRepository;
    public static final String ALGORITHM = "PBKDF2WithHmacSHA1";


    @Override
    public void invoke(String deviceId, String userId, String phoneNumber, String oldPasscode, String newPasscode) {
        String hash = passcodeRepository.getPasscodeHash(phoneNumber);
        if (validatePasscode(oldPasscode, hash)) {
            System.out.println("Тогда меняем пасскод");
        }
    }

    private static boolean validatePasscode(String originalPasscode, String storedPasscode) {
        String[] parts = storedPasscode.split(":");
        if (parts.length <= 2 | parts.length > 3) {
            throw new RuntimeException("Stored hash composition is incorrect: " + storedPasscode);
        }
        if (!(parts[1].length() == 32 && parts[2].length() == 128)) {
            throw new RuntimeException("Stored salt or hash length is incorrect: " + storedPasscode);
        }
        int iterations = 0;
        try {
            iterations = Integer.parseInt(parts[0]);
        } catch (NumberFormatException e) {
            throw new RuntimeException("Stored hash iterations not correct format: " + storedPasscode, e);
        }

        byte[] salt = fromHex(parts[1]);
        byte[] hash = fromHex(parts[2]);

        PBEKeySpec spec = new PBEKeySpec(originalPasscode.toCharArray(),
                salt, iterations, hash.length * 8);

        SecretKeyFactory skf = null;
        byte[] testHash = new byte[0];
        try {
            skf = SecretKeyFactory.getInstance(ALGORITHM);
            testHash = skf.generateSecret(spec).getEncoded();
        } catch (InvalidKeySpecException | NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }

        int diff = hash.length ^ testHash.length;
        for (int i = 0; i < hash.length && i < testHash.length; i++) {
            diff |= hash[i] ^ testHash[i];
        }
        return diff == 0;
    }

    private static byte[] fromHex(String hex) {
        byte[] bytes = new byte[hex.length() / 2];
        for (int i = 0; i < bytes.length; i++) {
            bytes[i] = (byte) Integer.parseInt(hex.substring(2 * i, 2 * i + 2), 16);
        }
        return bytes;
    }
}
