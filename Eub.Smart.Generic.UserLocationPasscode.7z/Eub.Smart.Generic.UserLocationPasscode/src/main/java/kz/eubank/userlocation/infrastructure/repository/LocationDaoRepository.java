package kz.eubank.userlocation.infrastructure.repository;


import kz.eubank.userlocation.infrastructure.entity.LocationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LocationDaoRepository extends JpaRepository<LocationEntity, Long> {

}
