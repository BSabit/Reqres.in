package kz.eubank.userlocation.infrastructure.repository;

import kz.eubank.userlocation.infrastructure.entity.ShortUserInfoEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserDaoRepository extends JpaRepository<ShortUserInfoEntity, Long> {

    @Query(nativeQuery = true, value = """
        select u.User_ID as userId,
        	   u.UserStatus_IDREF as userStatus,
        	   p.IIN as iin,
        	   p.FirstName as firstName,
        	   p.LastName as lastName,
        	   p.FathersName as middleName,
        	   p.BirthDate as birthDate
        from [User] u, Person p where
        	u.Person_IDREF = p.Person_ID and
        	p.PersonStatus_IDREF='ACTV' and
        	p.IIN = :iin
    """)
    List<ShortUserInfoEntity> getShortUserInfo(@Param("iin") String iin);

    @Modifying
    @Query(nativeQuery = true, value = """
        update [User] set UserStatus_IDREF = :userStatus where USER_ID = :userId 
    """)
    void updateUserStatus(@Param("userStatus") String userStatus, @Param("userId") Long userId);
}
