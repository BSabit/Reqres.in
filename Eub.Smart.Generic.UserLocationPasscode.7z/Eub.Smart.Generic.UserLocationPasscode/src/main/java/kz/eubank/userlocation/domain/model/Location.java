package kz.eubank.userlocation.domain.model;

public class Location {
    private String deviceId;
    private Double latitude;
    private Double longitude;
    private Long userId;
    private Long clientId;
    private Long personId;
    private String iin;
    private String mobilePhone;
    private boolean isAccess;

    public Location(String deviceId, Double latitude, Double longitude, Long userId, Long clientId, Long personId, String iin, String mobilePhone, boolean isAccess) {
        this.deviceId = deviceId;
        this.latitude = latitude;
        this.longitude = longitude;
        this.userId = userId;
        this.clientId = clientId;
        this.personId = personId;
        this.iin = iin;
        this.mobilePhone = mobilePhone;
        this.isAccess = isAccess;
    }

    public Location() {
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getClientId() {
        return clientId;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public Long getPersonId() {
        return personId;
    }

    public void setPersonId(Long personId) {
        this.personId = personId;
    }

    public String getIin() {
        return iin;
    }

    public void setIin(String iin) {
        this.iin = iin;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public boolean isAccess() {
        return isAccess;
    }

    public void setAccess(boolean access) {
        this.isAccess = access;
    }

    @Override
    public String toString() {
        return "Location{" +
                "deviceId='" + deviceId + '\'' +
                ", latitude=" + latitude +
                ", longitude=" + longitude +
                ", userId=" + userId +
                ", clientId=" + clientId +
                ", personId=" + personId +
                ", iin='" + iin + '\'' +
                ", mobilePhone='" + mobilePhone + '\'' +
                ", isAccess='" + isAccess + '\'' +
                '}';
    }
}