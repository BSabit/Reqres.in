package kz.eubank.userlocation.domain.use_case;

import kz.eubank.userlocation.domain.model.UserStatus;

import java.util.List;

public interface GetListOfUserStatusUseCase {
    List<UserStatus> invoke();
}
