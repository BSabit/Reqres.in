package kz.eubank.userlocation.domain.repository;

import kz.eubank.userlocation.domain.model.UserStatus;

import java.util.List;

public interface UserStatusRepository {

    List<UserStatus> getListOfUserStatus();
}
