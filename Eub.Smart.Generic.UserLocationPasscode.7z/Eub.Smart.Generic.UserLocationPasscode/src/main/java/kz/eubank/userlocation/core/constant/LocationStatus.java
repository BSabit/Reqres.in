package kz.eubank.userlocation.core.constant;

public interface LocationStatus {

    String ACCESS = "Access";
    String DENIED = "Permission Denied";
    String UNKN = "Unknown";
}
