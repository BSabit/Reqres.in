package kz.eubank.userlocation.core.constant;

public interface Channel {

    String UFO = "UFO";
}
