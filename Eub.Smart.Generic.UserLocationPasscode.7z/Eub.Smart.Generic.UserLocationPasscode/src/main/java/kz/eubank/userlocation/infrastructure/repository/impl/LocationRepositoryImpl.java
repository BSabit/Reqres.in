package kz.eubank.userlocation.infrastructure.repository.impl;

import kz.eubank.userlocation.domain.model.Location;
import kz.eubank.userlocation.domain.repository.LocationRepository;
import kz.eubank.userlocation.infrastructure.entity.LocationEntity;
import kz.eubank.userlocation.infrastructure.mapper.InfrastructureMapper;
import kz.eubank.userlocation.infrastructure.repository.LocationDaoRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Repository;

@Repository
@AllArgsConstructor
public class LocationRepositoryImpl implements LocationRepository {

    private final InfrastructureMapper mapper;
    private final LocationDaoRepository locationDaoRepository;

    @Override
    public void save(Location location) {
        LocationEntity locationEntity = mapper.toEntity(location);
        locationDaoRepository.save(locationEntity);
    }
}
