package kz.eubank.userlocation.presentation.controller;


import kz.eubank.userlocation.domain.use_case.ChangeUserStatusUseCase;
import kz.eubank.userlocation.domain.use_case.GetListOfUserStatusUseCase;
import kz.eubank.userlocation.domain.use_case.GetShortUserInfoUseCase;
import kz.eubank.userlocation.presentation.model.ChangeUserStatusRequest;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/")
@AllArgsConstructor
public class UserController {

    private final GetShortUserInfoUseCase getShortUserInfoUseCase;
    private final GetListOfUserStatusUseCase getListOfUserStatusUseCase;
    private final ChangeUserStatusUseCase changeUserStatusUseCase;

    @GetMapping("short-info")
    public ResponseEntity<?> getShortInfo(@RequestHeader("channel") String channel,
                                          @RequestParam("iin") String iin) {
        var result = getShortUserInfoUseCase.invoke(iin);
        return ResponseEntity.ok(result);
    }

    @GetMapping("status-list")
    public ResponseEntity<?> getStatusList(@RequestHeader("channel") String channel) {
        var result = getListOfUserStatusUseCase.invoke();
        return ResponseEntity.ok(result);
    }

    @PutMapping("{userId}/change-status")
    public ResponseEntity<?> changeStatus(
            @RequestHeader("channel") String channel,
            @PathVariable("userId") Long userId,
            @RequestBody ChangeUserStatusRequest request){
        changeUserStatusUseCase.invoke(userId, request.getUserStatus());
        return new ResponseEntity<>(HttpStatus.ACCEPTED);
    }
}
