package kz.eubank.userlocation.domain.repository;

public interface PasscodeRepository {

    String getPasscodeHash(String phoneNumber);
}
