package kz.eubank.userlocation.infrastructure.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity(name = "UserStatus")
public class UserStatusEntity {
    @Id
    @Column(name = "UserStatus_ID")
    public String id;

    @Column(name = "UserStatus_Title")
    public String title;

    @Column(name = "IsValid")
    public boolean isValid;
}
