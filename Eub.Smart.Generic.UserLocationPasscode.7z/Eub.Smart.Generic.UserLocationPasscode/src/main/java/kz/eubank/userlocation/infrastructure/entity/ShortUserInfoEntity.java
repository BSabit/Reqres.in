package kz.eubank.userlocation.infrastructure.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.sql.Date;

@Data
@Entity
public class ShortUserInfoEntity {
    @Id
    @Column(name = "userId")
    private Long id;
    private String userStatus;
    private String iin;
    private String firstName;
    private String lastName;
    private String middleName;
    private Date birthDate;
}
