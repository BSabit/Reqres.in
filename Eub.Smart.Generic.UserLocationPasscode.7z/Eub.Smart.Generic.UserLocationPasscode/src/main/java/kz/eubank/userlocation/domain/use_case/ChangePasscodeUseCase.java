package kz.eubank.userlocation.domain.use_case;

public interface ChangePasscodeUseCase {

    void invoke(String deviceId, String userId, String phoneNumber, String oldPasscode, String newPasscode);
}
