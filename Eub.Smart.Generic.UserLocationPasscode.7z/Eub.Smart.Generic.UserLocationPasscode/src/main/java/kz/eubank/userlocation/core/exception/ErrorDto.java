package kz.eubank.userlocation.core.exception;

public class ErrorDto {

    private Integer code;
    private String fieldName;
    private String message;

    public ErrorDto() {
    }

    public ErrorDto(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    @Override
    public String toString() {
        return "ErrorDto{" +
                "fieldName=" + fieldName +
                ", message=" + message +
                ", code=" + code +
                "}";
    }
}
