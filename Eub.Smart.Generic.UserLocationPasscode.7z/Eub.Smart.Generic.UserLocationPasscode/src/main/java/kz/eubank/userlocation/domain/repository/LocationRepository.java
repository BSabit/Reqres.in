package kz.eubank.userlocation.domain.repository;

import kz.eubank.userlocation.domain.model.Location;

public interface LocationRepository {

    void save(Location location);
}
