package kz.eubank.userlocation.domain.mapper;


import kz.eubank.userlocation.core.model.UserDetails;
import kz.eubank.userlocation.domain.model.Location;

public class UserDetailsToLocationMapper {

    public static Location toLocation(UserDetails userDetails,
                                      Double latitude,
                                      Double longitude,
                                      String deviceId,
                                      boolean status) {
        Location location = new Location();
        location.setDeviceId(deviceId);
        location.setLatitude(latitude);
        location.setLongitude(longitude);
        location.setUserId(userDetails.getUserId());
        location.setClientId(userDetails.getClientId());
        location.setIin(userDetails.getIin());
        location.setMobilePhone(userDetails.getPreferredUsername());
        location.setPersonId(userDetails.getPersonId());
        location.setAccess(status);
        return location;
    }
}
