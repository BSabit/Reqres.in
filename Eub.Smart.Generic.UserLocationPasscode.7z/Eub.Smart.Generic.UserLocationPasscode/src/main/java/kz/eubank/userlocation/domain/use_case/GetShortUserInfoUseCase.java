package kz.eubank.userlocation.domain.use_case;

import kz.eubank.userlocation.domain.model.ShortUserInfo;

public interface GetShortUserInfoUseCase {
    ShortUserInfo invoke(String iin);
}
