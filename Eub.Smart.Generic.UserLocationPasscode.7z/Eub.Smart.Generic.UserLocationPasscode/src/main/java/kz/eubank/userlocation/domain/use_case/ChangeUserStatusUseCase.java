package kz.eubank.userlocation.domain.use_case;

public interface ChangeUserStatusUseCase {

    void invoke(Long userId, String userStatus);
}
