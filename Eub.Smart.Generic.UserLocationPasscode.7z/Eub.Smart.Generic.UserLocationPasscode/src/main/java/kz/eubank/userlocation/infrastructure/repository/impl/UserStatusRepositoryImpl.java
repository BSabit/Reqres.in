package kz.eubank.userlocation.infrastructure.repository.impl;

import kz.eubank.userlocation.domain.model.UserStatus;
import kz.eubank.userlocation.domain.repository.UserStatusRepository;
import kz.eubank.userlocation.infrastructure.mapper.InfrastructureMapper;
import kz.eubank.userlocation.infrastructure.repository.UserStatusDaoRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@AllArgsConstructor
public class UserStatusRepositoryImpl implements UserStatusRepository {

    private final UserStatusDaoRepository userStatusDaoRepository;
    private final InfrastructureMapper mapper;

    @Override
    public List<UserStatus> getListOfUserStatus() {
        return mapper.toDomain(userStatusDaoRepository.findAll());
    }
}
