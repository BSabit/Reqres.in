package kz.eubank.userlocation.core.util;

import java.util.Collection;

public class CollectionUtil {

    public static <T> boolean isOneResult(Collection<T> col) {
        return col.size() == 1;
    }
}
