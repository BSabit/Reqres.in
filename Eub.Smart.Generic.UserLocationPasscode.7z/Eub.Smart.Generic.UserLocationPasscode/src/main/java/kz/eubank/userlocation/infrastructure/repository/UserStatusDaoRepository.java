package kz.eubank.userlocation.infrastructure.repository;

import kz.eubank.userlocation.infrastructure.entity.UserStatusEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface UserStatusDaoRepository extends JpaRepository<UserStatusEntity, String> {

}
