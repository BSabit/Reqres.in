package kz.eubank.userlocation.core.constant;

public interface Headers {
    String AUTHORIZATION = "authorization";
    String X_FORWARDED_FOR = "X-Forwarded-For";
    String CHANNEL = "Channel";
}
