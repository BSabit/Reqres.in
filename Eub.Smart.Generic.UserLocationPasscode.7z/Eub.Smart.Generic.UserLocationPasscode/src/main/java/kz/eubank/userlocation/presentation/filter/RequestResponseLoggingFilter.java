package kz.eubank.userlocation.presentation.filter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import kz.eubank.userlocation.core.component.AuthToken;
import kz.eubank.userlocation.core.model.UserDetails;
import kz.eubank.userlocation.presentation.filter.logger.AccessLogger;
import kz.eubank.userlocation.presentation.filter.logger.RequestResponseLogger;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;


import java.io.IOException;

import static kz.eubank.userlocation.core.constant.Channel.UFO;
import static kz.eubank.userlocation.core.constant.Headers.CHANNEL;
import static kz.eubank.userlocation.core.constant.Headers.X_FORWARDED_FOR;
import static kz.eubank.userlocation.core.constant.UserDetails.*;


@Component
public class RequestResponseLoggingFilter extends OncePerRequestFilter {

    private final AccessLogger accessLogger;
    private final AuthToken authToken;
    private final RequestResponseLogger reqResLogger;
    private final HttpServletRequest request;

    public RequestResponseLoggingFilter(AccessLogger accessLogger, AuthToken authToken,
                                        RequestResponseLogger reqResLogger,
                                        HttpServletRequest request) {
        this.accessLogger = accessLogger;
        this.authToken = authToken;
        this.reqResLogger = reqResLogger;
        this.request = request;
    }

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain) throws ServletException, IOException {
        ContentCachingRequestWrapper requestWrapper = new ContentCachingRequestWrapper(request);
        ContentCachingResponseWrapper responseWrapper = new ContentCachingResponseWrapper(response);

        if(!UFO.equalsIgnoreCase(requestWrapper.getHeader(CHANNEL)) &&
                !requestWrapper.getRequestURI().contains("swagger-ui") &&
                !requestWrapper.getRequestURI().contains("api-docs")
        ) {
            addToMDC();
        }
        filterChain.doFilter(requestWrapper, responseWrapper);
        reqResLogger.log(requestWrapper, responseWrapper);
        responseWrapper.copyBodyToResponse();
    }

    private void addToMDC() {
        String payload = authToken.getDecodedPayload();
        UserDetails userDetails = UserDetails.build(payload);
        MDC.put(PREFERRED_USERNAME, userDetails.getPreferredUsername());
        MDC.put(USER_ID, userDetails.getUserId().toString());
        MDC.put(CLIENT_ID, userDetails.getClientId().toString());
        MDC.put(IIN, userDetails.getIin());
        MDC.put(X_FORWARDED_FOR, accessLogger.getClientIp());
    }

}
