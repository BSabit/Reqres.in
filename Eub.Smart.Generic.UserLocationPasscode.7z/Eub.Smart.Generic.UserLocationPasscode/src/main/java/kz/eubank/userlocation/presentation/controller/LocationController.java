package kz.eubank.userlocation.presentation.controller;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import kz.eubank.userlocation.domain.use_case.RecordLocationUseCase;
import kz.eubank.userlocation.presentation.model.LocationRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/location")
@SecurityRequirement(name = "bearer-jwt")
public class LocationController {

    private final RecordLocationUseCase recordLocationUseCase;

    public LocationController( RecordLocationUseCase recordLocationUseCase) {
        this.recordLocationUseCase = recordLocationUseCase;
    }

    @PostMapping
    public ResponseEntity<?> recordLocation(@RequestHeader("deviceId") String deviceId,
                                            @RequestBody LocationRequest locationRequest) {
        recordLocationUseCase.invoke(locationRequest.latitude(), locationRequest.longitude(), deviceId);
        return new ResponseEntity<>(HttpStatus.ACCEPTED);
    }
}
