package kz.eubank.userlocation.domain.repository;

import kz.eubank.userlocation.domain.model.ShortUserInfo;

import java.util.Optional;

public interface UserRepository {

    Optional<ShortUserInfo> getShortUserInfo(String iin);

    ShortUserInfo getShortUserInfoOrException(String iin);

    void changeUserStatus(String userStatus, Long userId);
}
