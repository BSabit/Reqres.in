package kz.eubank.userlocation.domain.model;

public record UserStatus (
    String id,
    String title,
    boolean isValid
){}
