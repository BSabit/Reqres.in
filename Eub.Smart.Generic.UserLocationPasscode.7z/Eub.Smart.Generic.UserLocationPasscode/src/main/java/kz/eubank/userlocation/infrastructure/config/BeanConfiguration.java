package kz.eubank.userlocation.infrastructure.config;

import kz.eubank.userlocation.UserLocationApplication;
import kz.eubank.userlocation.core.component.AuthToken;
import kz.eubank.userlocation.domain.repository.LocationRepository;
import kz.eubank.userlocation.domain.repository.UserRepository;
import kz.eubank.userlocation.domain.repository.UserStatusRepository;
import kz.eubank.userlocation.domain.use_case.ChangeUserStatusUseCase;
import kz.eubank.userlocation.domain.use_case.GetListOfUserStatusUseCase;
import kz.eubank.userlocation.domain.use_case.GetShortUserInfoUseCase;
import kz.eubank.userlocation.domain.use_case.impl.ChangeUserStatusUseCaseImpl;
import kz.eubank.userlocation.domain.use_case.impl.GetListOfUserStatusUseCaseImpl;
import kz.eubank.userlocation.domain.use_case.impl.GetShortUserInfoUseCaseImpl;
import kz.eubank.userlocation.domain.use_case.impl.RecordLocationUseCaseImpl;
import kz.eubank.userlocation.domain.use_case.RecordLocationUseCase;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackageClasses = UserLocationApplication.class)
public class BeanConfiguration {

    @Bean
    RecordLocationUseCase recordLocationUseCase(AuthToken authToken,
                                                LocationRepository repository) {
        return new RecordLocationUseCaseImpl(authToken, repository);
    }

    @Bean
    GetShortUserInfoUseCase getShortUserInfo(UserRepository userRepository) {
        return new GetShortUserInfoUseCaseImpl(userRepository);
    }

    @Bean
    GetListOfUserStatusUseCase getListOfUserStatusUseCase(UserStatusRepository userStatusRepository){
        return new GetListOfUserStatusUseCaseImpl(userStatusRepository);
    }

    @Bean
    ChangeUserStatusUseCase changeUserStatusUseCase(UserRepository userRepository){
        return new ChangeUserStatusUseCaseImpl(userRepository);
    }
}
