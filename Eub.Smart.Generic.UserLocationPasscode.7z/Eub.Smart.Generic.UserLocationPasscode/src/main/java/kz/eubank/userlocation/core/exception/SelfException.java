package kz.eubank.userlocation.core.exception;

import java.util.List;

public class SelfException extends RuntimeException {

    public SelfException(SelfErrorCode selfErrorCode, List<ErrorDto> errorDtos) {
        super(errorDtos.toString());
        this.selfErrorCode = selfErrorCode;
    }

    public SelfException(SelfErrorCode selfErrorCode) {
        super(selfErrorCode.message());
        this.selfErrorCode = selfErrorCode;
    }

    public SelfException(SelfErrorCode selfErrorCode, String additionalMessage) {
        super(selfErrorCode.message() + additionalMessage);
        this.selfErrorCode = selfErrorCode;
    }

    public SelfException(SelfErrorCode selfErrorCode, Throwable throwable) {
        super(throwable);
        if (throwable.getCause() instanceof SelfException se) this.selfErrorCode = se.selfErrorCode;
        else this.selfErrorCode = selfErrorCode;
    }

    private final SelfErrorCode selfErrorCode;

    public SelfErrorCode getCode() {
        return selfErrorCode;
    }
}
