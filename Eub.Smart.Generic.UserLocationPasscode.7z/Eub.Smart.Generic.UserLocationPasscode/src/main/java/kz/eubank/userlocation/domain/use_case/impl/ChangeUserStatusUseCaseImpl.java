package kz.eubank.userlocation.domain.use_case.impl;

import kz.eubank.userlocation.domain.repository.UserRepository;
import kz.eubank.userlocation.domain.use_case.ChangeUserStatusUseCase;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public class ChangeUserStatusUseCaseImpl implements ChangeUserStatusUseCase {

    private final UserRepository userRepository;

    @Override
    public void invoke(Long userId, String userStatus) {
        userRepository.changeUserStatus(userStatus, userId);
    }
}
