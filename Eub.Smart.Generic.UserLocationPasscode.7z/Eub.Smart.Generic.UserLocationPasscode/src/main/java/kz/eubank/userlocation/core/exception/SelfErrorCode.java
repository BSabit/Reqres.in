package kz.eubank.userlocation.core.exception;


import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;


public enum SelfErrorCode {
    E_VD_400("error.validate"),                                         //VALIDATION 400-499
    E_VD_401("error.validate.annotation_validate"),

    E_SM_500("error.system"),                                           //SYSTEM 500-599
    E_SM_501("error.system.object-to-json"),
    E_SM_502("error.system.json-to-object"),
    E_SM_503("error.system.execution-exception"),
    E_SM_504("error.system.interrupted-exception"),
    E_SM_505("error.system.timeout-exception"),

    E_DB_600("error.db.object-not-found"),                              //DB 600-699
    E_DB_601("error.db.result-more-than-expect"),
    E_DB_602("error.db.exec-procedure"),
    E_DB_603("error.db.incorrect-field"),
    E_DB_604("error.db.unique-constraint-exception"),

    E_EX_700("error.external.response-error"),                          //EXTERNAL 700-799
    E_EX_701("error.external.system-not-available"),

    E_LG_800("error.logical"),                                          //LOGICAL 800-899
    E_LG_800_VLBS("error.logical.validation-vlbs"),
    E_LG_800_VLSU("error.logical.validation-vlsu"),
    E_LG_800_VLSS("error.logical.validation-vlss"),
    E_LG_800_MTNT("error.logical.validation-mtmt"),
    E_LG_801("error.logical.invalid-data"),
    E_LG_802("error.logical.not-implemented");

    private final String message;

    private SelfErrorCode(String message) {
        this.message = message;
    }

    public String message() {
        return message;
    }

    private static final Set<SelfErrorCode> DOMAIN_ERROR_CODES = Arrays.stream(values())
            .filter(e -> e.message().startsWith(E_LG_800.message()))
            .collect(Collectors.toSet());

    public static boolean isDomainErrorCode(SelfException e) {
        return DOMAIN_ERROR_CODES.contains(e.getCode());
    }
}
