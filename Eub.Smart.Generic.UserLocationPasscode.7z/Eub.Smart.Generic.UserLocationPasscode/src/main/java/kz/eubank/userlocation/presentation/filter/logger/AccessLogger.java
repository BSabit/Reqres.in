package kz.eubank.userlocation.presentation.filter.logger;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Component;

import static kz.eubank.userlocation.core.constant.Headers.X_FORWARDED_FOR;
import static kz.eubank.userlocation.core.util.StringUtil.isNotEmpty;


@Component
public class AccessLogger {

    private final HttpServletRequest request;

    public AccessLogger(HttpServletRequest request) {
        this.request = request;
    }

    public String getClientIp() {
        String xForwardedFor = request.getHeader(X_FORWARDED_FOR);
        if (isNotEmpty(xForwardedFor)) {
            return xForwardedFor.split(",")[0].trim();
        } else {
            return request.getRemoteAddr();
        }
    }
}