package kz.eubank.userlocation.domain.use_case.impl;

import kz.eubank.userlocation.domain.model.ShortUserInfo;
import kz.eubank.userlocation.domain.repository.UserRepository;
import kz.eubank.userlocation.domain.use_case.GetShortUserInfoUseCase;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public class GetShortUserInfoUseCaseImpl implements GetShortUserInfoUseCase {

    private final UserRepository userRepository;

    @Override
    public ShortUserInfo invoke(String iin) {
        return userRepository.getShortUserInfoOrException(iin);
    }
}
