package kz.eubank.userlocation.infrastructure.repository.impl;

import kz.eubank.userlocation.domain.repository.PasscodeRepository;
import lombok.AllArgsConstructor;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

@Repository
@AllArgsConstructor
public class PasscodeRepositoryImpl implements PasscodeRepository {

    private final NamedParameterJdbcTemplate template;

    @Override
    public String getPasscodeHash(String phoneNumber) {
        Map<String, Object> map = new HashMap<>();
        map.put("phoneNumber", phoneNumber);

        String sql = """
                SELECT p.Hash
                FROM MobilePhone m
                INNER JOIN AuthSMS a ON a.MobilePhone_IDREF = m.MobilePhone_ID
                INNER JOIN map_User_AuthTool mua ON mua.AuthTool_IDREF = a.AuthTool_IDREF
                INNER JOIN AuthTool at ON at.AuthTool_ID = mua.AuthTool_IDREF
                INNER JOIN [dbo].[User] u ON u.User_ID = mua.User_IDREF
                INNER JOIN Person pr ON pr.Person_ID = u.Person_IDREF
                INNER JOIN Client c ON c.Person_IDREF = pr.Person_ID
                INNER JOIN NewPasscode p ON u.User_ID = p.User_IDREF
                WHERE m.MobilePhone = :phoneNumber AND  at.AuthToolStatus_IDREF = 'ACTV' 
                                                    AND p.PasscodeStatus_IDREF = 'ACTV' 
                                                    AND m.MobilePhoneStatus_IDREF = 'ACTV' 
                                                    AND u.UserStatus_IDREF IN ('ACTV', 'BLAE', 'BLSF', 'APWR')
                """;
        return template.queryForObject(sql, map, String.class);
    }
}
