package kz.eubank.userlocation.infrastructure.mapper;

import java.util.Date;

public class DateUse {

    public Date toUtilDate(java.sql.Date sqlDate){
        return new Date(sqlDate.getTime());
    }
}
