package kz.eubank.userlocation.infrastructure.repository.impl;

import kz.eubank.userlocation.core.exception.SelfErrorCode;
import kz.eubank.userlocation.core.exception.SelfException;
import kz.eubank.userlocation.domain.model.ShortUserInfo;
import kz.eubank.userlocation.domain.repository.UserRepository;
import kz.eubank.userlocation.infrastructure.mapper.InfrastructureMapper;
import kz.eubank.userlocation.infrastructure.repository.UserDaoRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

import static kz.eubank.userlocation.core.exception.SelfErrorCode.E_DB_600;
import static kz.eubank.userlocation.core.util.CollectionUtil.isOneResult;

@Repository
@AllArgsConstructor
public class UserRepositoryImpl implements UserRepository {

    private final UserDaoRepository userDaoRepository;
    private final InfrastructureMapper mapper;

    @Override
    public Optional<ShortUserInfo> getShortUserInfo(String iin) {

        var queryResult = userDaoRepository.getShortUserInfo(iin);
        if(isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst().map(mapper::toDomain);
        }
        if(queryResult.isEmpty()) {
            return Optional.empty();
        }
        else {
            throw new SelfException(SelfErrorCode.E_DB_601, ": UserRepositoryImpl getShortUserInfo - " + iin);
        }
    }

    @Override
    public ShortUserInfo getShortUserInfoOrException(String iin) {
        return getShortUserInfo(iin)
                .orElseThrow(() -> new SelfException(E_DB_600, ": UserRepositoryImpl getShortUserInfoOrException - " + iin));
    }

    @Transactional
    @Override
    public void changeUserStatus(String userStatus, Long userId) {
        userDaoRepository.updateUserStatus(userStatus, userId);
    }
}
