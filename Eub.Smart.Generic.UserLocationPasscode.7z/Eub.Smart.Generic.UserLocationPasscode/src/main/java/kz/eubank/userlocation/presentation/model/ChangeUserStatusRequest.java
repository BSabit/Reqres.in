package kz.eubank.userlocation.presentation.model;

public class ChangeUserStatusRequest {

    private String userStatus;

    public String getUserStatus() {
        return userStatus;
    }

    public void setUserStatus(String userStatus) {
        this.userStatus = userStatus;
    }
}
