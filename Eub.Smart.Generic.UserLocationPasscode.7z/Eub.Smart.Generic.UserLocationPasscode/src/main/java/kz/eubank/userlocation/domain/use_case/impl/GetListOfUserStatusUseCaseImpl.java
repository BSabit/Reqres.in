package kz.eubank.userlocation.domain.use_case.impl;

import kz.eubank.userlocation.domain.model.UserStatus;
import kz.eubank.userlocation.domain.repository.UserStatusRepository;
import kz.eubank.userlocation.domain.use_case.GetListOfUserStatusUseCase;
import lombok.AllArgsConstructor;

import java.util.List;

@AllArgsConstructor
public class GetListOfUserStatusUseCaseImpl implements GetListOfUserStatusUseCase {

    private final UserStatusRepository userStatusRepository;

    @Override
    public List<UserStatus> invoke() {
        return userStatusRepository.getListOfUserStatus();
    }
}
