package kz.eubank.userlocation.domain.use_case.impl;


import kz.eubank.userlocation.core.component.AuthToken;
import kz.eubank.userlocation.core.model.UserDetails;
import kz.eubank.userlocation.domain.mapper.UserDetailsToLocationMapper;
import kz.eubank.userlocation.domain.model.Location;
import kz.eubank.userlocation.domain.repository.LocationRepository;
import kz.eubank.userlocation.domain.use_case.RecordLocationUseCase;

import static kz.eubank.userlocation.core.util.DoubleUtil.isNotNullOrZero;


public class RecordLocationUseCaseImpl implements RecordLocationUseCase {
    private final AuthToken authToken;
    private final LocationRepository repository;

    public RecordLocationUseCaseImpl(AuthToken authToken, LocationRepository repository) {
        this.authToken = authToken;
        this.repository = repository;
    }

    @Override
    public void invoke(Double latitude, Double longitude, String deviceId) {
        String decodedPayload = authToken.getDecodedPayload();
        UserDetails userDetails = UserDetails.build(decodedPayload);

        boolean isLocationAccessDenied  = isNotNullOrZero(latitude) && isNotNullOrZero(longitude);

        Location location = UserDetailsToLocationMapper.toLocation(userDetails, latitude, longitude, deviceId, isLocationAccessDenied);
        repository.save(location);
    }
}
