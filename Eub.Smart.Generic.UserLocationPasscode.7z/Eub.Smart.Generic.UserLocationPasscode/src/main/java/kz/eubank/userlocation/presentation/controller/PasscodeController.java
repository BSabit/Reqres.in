package kz.eubank.userlocation.presentation.controller;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import kz.eubank.userlocation.core.model.UserDetails;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/passcode")
@SecurityRequirement(name = "bearer-jwt")
@AllArgsConstructor
public class PasscodeController {

    private final UserDetails userDetails;


    @PostMapping("/change")
    public ResponseEntity<?> change(@RequestParam String phoneNumber,
                                    @RequestParam String oldPasscode,
                                    @RequestParam String newPasscode,
                                    @RequestParam String deviceId) {
        Long userId = userDetails.getUserId();
        return new ResponseEntity<>("Пароль успешно изменён!", HttpStatus.OK);
    }
}
