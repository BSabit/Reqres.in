package kz.eubank.userlocation.domain.use_case;


public interface RecordLocationUseCase {

    void invoke(Double latitude, Double longitude, String deviceId);
}
