package kz.eubank.userlocation.core.util;

public class DoubleUtil {

    public static boolean isNullOrZero(Double number) {
        return number == null || number.compareTo(0.0) == 0;
    }
    public static boolean isNotNullOrZero(Double number) {
        return number != null && number.compareTo(0.0) != 0;
    }
}
