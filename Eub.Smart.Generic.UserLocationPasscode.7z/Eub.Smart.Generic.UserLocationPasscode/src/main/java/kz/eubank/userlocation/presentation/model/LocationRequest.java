package kz.eubank.userlocation.presentation.model;

public record LocationRequest(
        Double latitude,
        Double longitude) {
}