package kz.eubank.userlocation.infrastructure.mapper;

import kz.eubank.userlocation.domain.model.Location;
import kz.eubank.userlocation.domain.model.ShortUserInfo;
import kz.eubank.userlocation.domain.model.UserStatus;
import kz.eubank.userlocation.infrastructure.entity.LocationEntity;
import kz.eubank.userlocation.infrastructure.entity.ShortUserInfoEntity;
import kz.eubank.userlocation.infrastructure.entity.UserStatusEntity;
import org.mapstruct.Mapper;

import java.util.List;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING, uses = { DateUse.class })
public interface InfrastructureMapper {

    Location toDomain(LocationEntity entity);
    LocationEntity toEntity(Location location);

    ShortUserInfo toDomain(ShortUserInfoEntity entity);

    List<UserStatus> toDomain(List<UserStatusEntity> entities);
}
