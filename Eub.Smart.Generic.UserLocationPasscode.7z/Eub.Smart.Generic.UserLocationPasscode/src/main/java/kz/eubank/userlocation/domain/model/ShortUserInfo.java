package kz.eubank.userlocation.domain.model;

public record ShortUserInfo (
        Long id,
        String userStatus,
        String iin,
        String firstName,
        String lastName,
        String middleName,
        String birthDate
){}
