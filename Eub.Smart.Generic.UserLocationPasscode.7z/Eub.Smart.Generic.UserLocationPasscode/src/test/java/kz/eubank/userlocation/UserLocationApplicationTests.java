package kz.eubank.userlocation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserLocationApplicationTests {

	@Test
	void contextLoads() {
	}

}
