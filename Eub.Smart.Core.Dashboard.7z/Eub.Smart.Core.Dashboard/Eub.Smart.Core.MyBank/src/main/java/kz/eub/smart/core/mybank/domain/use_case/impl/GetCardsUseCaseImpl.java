package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.domain.comparator.CardBalanceComparator;
import kz.eub.smart.core.mybank.domain.mapper.AdditionalCardMapper;
import kz.eub.smart.core.mybank.domain.mapper.CardBalanceMapper;
import kz.eub.smart.core.mybank.domain.mapper.CardMapper;
import kz.eub.smart.core.mybank.domain.model.AccountBalance;
import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.card.AdditionalCard;
import kz.eub.smart.core.mybank.domain.model.card.Card;
import kz.eub.smart.core.mybank.domain.model.card.CardBalance;
import kz.eub.smart.core.mybank.core.constants.AccountType;
import kz.eub.smart.core.mybank.domain.repository.DetailsUrlRepository;
import kz.eub.smart.core.mybank.domain.use_case.GetProductStatusUseCase;
import kz.eub.smart.core.mybank.domain.use_case.GetCardsUseCase;
import lombok.AllArgsConstructor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@AllArgsConstructor
public class GetCardsUseCaseImpl implements GetCardsUseCase {

    private final GetProductStatusUseCase getProductStatusUseCase;
    private final DetailsUrlRepository detailsUrlRepository;

    @Override
    public List<Card> invoke(List<AccountCard> accountCards, List<AccountBalance> accountBalances, boolean isInstallment) {
        List<Card> cards = new ArrayList<>();
        var uniqueAccounts = getUniqueAccounts(accountCards, isInstallment);

        for (var acc : uniqueAccounts){
            var mainCard = getMainCard(acc, accountCards);
            var balances = getBalances(acc,accountBalances, accountCards);
            var additionalCards = getAdditionalCards(acc, accountCards, mainCard);
            mainCard.setAmount(balances);
            mainCard.setAdditionalCards(additionalCards);
            cards.add(mainCard);
        }
        return cards;
    }

    private List<AccountCard> getUniqueAccounts(List<AccountCard> accountCards, boolean isInstallment) {
        return accountCards.stream()
                .filter(accountCard -> AccountType.CARD.name().equals(accountCard.getAccountType())
                        && accountCard.getParentAccountId() == null
                        && isInstallment == accountCard.getIsInstallment())
                .distinct()
                .toList();
    }

    private Card getMainCard(AccountCard mainAccount, List<AccountCard> accountCards){

        var mainCard = accountCards.stream()
                .filter(card -> accountBelongsMainAccount(card, mainAccount))
                .sorted(Comparator.comparing(AccountCard::getCardIdForSort, Comparator.reverseOrder()))
                .max(Comparator.comparing(AccountCard::isBasic)
                        .thenComparing(AccountCard::additionalIsMy));

        return mainCard.map(accountCard -> accountCard.getCardId() != null
                ? CardMapper.getCard(accountCard, getProductStatusUseCase.invoke(accountCard),detailsUrlRepository.getMainCardDetails())
                : CardMapper.getCardAccount(mainAccount, getProductStatusUseCase.invoke(mainAccount),detailsUrlRepository.getCardAccountDetails())
        ).orElse(new Card());
    }

    private List<AdditionalCard> getAdditionalCards(AccountCard mainAccount, List<AccountCard> accountCards, Card mainCard){
        return accountCards.stream()
                    .filter(card -> this.isAdditionalCard(card,mainAccount, mainCard ))
                    .map(accountCard -> AdditionalCardMapper.getAdditionalCard(accountCard, getProductStatusUseCase.invoke(accountCard), detailsUrlRepository.getAdditionalCardDetails()))
                    .toList();
    }

    private boolean isAdditionalCard(AccountCard card, AccountCard mainAccount,Card mainCard) {
        return card.getAccountId().equals(mainAccount.getAccountId())
                && card.getCardId() != null
                && !card.getCardId().equals(mainCard.getId());

    }

    private List<CardBalance> getBalances(AccountCard mainAccount, List<AccountBalance> allAccountBalances, List<AccountCard> allCards){
        return allAccountBalances.stream()
                .filter(accountBalance -> allCards
                        .stream()
                        .anyMatch(account ->
                                balanceBelongsAccount(account,accountBalance)
                                && accountBelongsMainAccount(account, mainAccount)
                        ))
                .map(CardBalanceMapper::getCardBalance)
                .sorted(new CardBalanceComparator())
                .sorted(Comparator.comparing(card -> card.getAmount().compareTo(BigDecimal.ZERO) == 0))
                .toList();
    }

    private boolean accountBelongsMainAccount(AccountCard account, AccountCard mainAccount) {
        return isMainAccount(account, mainAccount)
                || isChild(account, mainAccount)
                || isSameParent(account, mainAccount)
                || isParent(account, mainAccount);
    }

    private boolean isParent(AccountCard account, AccountCard mainAccount) {
        return account.getAccountId().equals(mainAccount.getParentAccountId());
    }

    private boolean isSameParent(AccountCard account, AccountCard mainAccount) {
        return account.getParentAccountId() != null && account.getParentAccountId().equals(mainAccount.getParentAccountId());
    }

    private boolean isChild(AccountCard account, AccountCard mainAccount) {
        return mainAccount.getAccountId().equals(account.getParentAccountId());
    }

    private boolean isMainAccount(AccountCard account, AccountCard mainAccount) {
        return account.getAccountId().equals(mainAccount.getAccountId());
    }

    private boolean balanceBelongsAccount(AccountCard card, AccountBalance accountBalance) {
        return card.getAccountOutref().equals(accountBalance.getAccountOutref());
    }

}
