package kz.eub.smart.core.mybank.core.component;

import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
@Data
public class UserDetails {
    private Long userId;
    private Date birthDate;
    private String name;
    private String preferredUsername;
    private String middleName;
    private String givenName;
    private String familyName;
    private Long clientId;
    private String iin;
    private Long personId;
}
