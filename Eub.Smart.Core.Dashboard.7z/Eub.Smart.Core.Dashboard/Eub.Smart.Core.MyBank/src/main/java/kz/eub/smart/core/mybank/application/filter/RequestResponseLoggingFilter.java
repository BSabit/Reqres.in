package kz.eub.smart.core.mybank.application.filter;

import kz.eub.smart.core.mybank.application.filter.logger.AccessLogger;
import kz.eub.smart.core.mybank.application.filter.logger.RequestResponseLogger;
import kz.eub.smart.core.mybank.core.component.AuthToken;
import kz.eub.smart.core.mybank.core.component.UserDetails;
import kz.eub.smart.core.mybank.core.model.UserDetailsModel;
import lombok.AllArgsConstructor;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import static kz.eub.smart.core.mybank.core.constants.HeaderName.CORRELATION_ID;
import static kz.eub.smart.core.mybank.core.constants.MdcConstants.X_FORWARDED_FOR;
import static kz.eub.smart.core.mybank.core.constants.UserDetailsConstants.*;


@Component
@AllArgsConstructor
public class RequestResponseLoggingFilter extends OncePerRequestFilter {

    private final AccessLogger accessLogger;
    private final AuthToken authToken;
    private final RequestResponseLogger reqResLogger;
    private final HttpServletRequest request;
    private final UserDetails userDetails;
    private final Set<String> SWAGGER_REQUEST_URI = new HashSet<>(Set.of("/swagger-ui/index.html", "/v3/api-docs/swagger-config","/v3/api-docs", "/swagger-ui/swagger-ui.css", "/swagger-ui/index.css", "/swagger-ui/swagger-initializer.js", "/swagger-ui/swagger-ui-standalone-preset.js", "/swagger-ui/favicon-32x32.png", "/swagger-ui/swagger-ui-bundle.js"));

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain) throws ServletException, IOException {
        ContentCachingRequestWrapper requestWrapper = new ContentCachingRequestWrapper(request);
        ContentCachingResponseWrapper responseWrapper = new ContentCachingResponseWrapper(response);
        if (isNotSwaggerRequest(request)){
            addToUserDetailsComponent();
            addToMDC();
        }
        filterChain.doFilter(requestWrapper, responseWrapper);
        reqResLogger.log(requestWrapper, responseWrapper);
        responseWrapper.copyBodyToResponse();

    }

    private void addToUserDetailsComponent() {
        var payload = authToken.getDecodedPayload();
        var userDetailsModel = UserDetailsModel.build(payload);
        userDetails.setUserId(userDetailsModel.getUserId());
        userDetails.setBirthDate(userDetailsModel.getBirthDate());
        userDetails.setName(userDetailsModel.getName());
        userDetails.setPreferredUsername(userDetailsModel.getPreferredUsername());
        userDetails.setMiddleName(userDetailsModel.getMiddleName());
        userDetails.setGivenName(userDetailsModel.getGivenName());
        userDetails.setFamilyName(userDetailsModel.getFamilyName());
        userDetails.setClientId(userDetailsModel.getClientId());
        userDetails.setIin(userDetailsModel.getIin());
        userDetails.setPersonId(userDetailsModel.getPersonId());
    }

    private void addToMDC() {
        var payload = authToken.getDecodedPayload();
        var userDetails = UserDetailsModel.build(payload);
        MDC.put(PREFERRED_USERNAME, userDetails.getPreferredUsername());
        MDC.put(USER_ID, userDetails.getUserId().toString());
        MDC.put(CLIENT_ID, userDetails.getClientId().toString());
        MDC.put(IIN, userDetails.getIin());
        MDC.put(X_FORWARDED_FOR, accessLogger.getClientIp());
        MDC.put(CORRELATION_ID, request.getHeader(CORRELATION_ID));
    }

    private boolean isNotSwaggerRequest(HttpServletRequest request){
        return request != null && request.getRequestURI() != null && !SWAGGER_REQUEST_URI.contains(request.getRequestURI());
    }
}
