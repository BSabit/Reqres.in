package kz.eub.smart.core.mybank.domain.use_case;

import kz.eub.smart.core.mybank.domain.model.Application;
import kz.eub.smart.core.mybank.domain.model.current_account.Account;

import java.util.List;

public interface GetCurrentAccountApplicationsUseCase {
    List<Account> invoke(List<Application> applications);
}
