package kz.eub.smart.core.mybank.domain.repository;

import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.domain.model.AccountCard;

import java.util.List;

public interface AccountCardRepository {

    List<AccountCard> getListOfAccountCard(Long userId, LangKey langKey);
}
