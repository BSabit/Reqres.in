package kz.eub.smart.core.mybank.domain.use_case;

import kz.eub.smart.core.mybank.domain.model.AccountBalance;
import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.current_account.Account;

import java.util.List;

public interface GetAccountsUseCase{
    List<Account> invoke(List<AccountCard> accountCards, List<AccountBalance> accountBalances);
}
