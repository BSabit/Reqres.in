package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.core.exception.MyBankException;
import kz.eub.smart.core.mybank.domain.mapper.AccountMapper;
import kz.eub.smart.core.mybank.domain.model.AccountBalance;
import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.current_account.Account;
import kz.eub.smart.core.mybank.domain.repository.DetailsUrlRepository;
import kz.eub.smart.core.mybank.domain.use_case.GetAccountsUseCase;
import kz.eub.smart.core.mybank.core.constants.AccountType;
import kz.eub.smart.core.mybank.domain.use_case.GetProductStatusUseCase;
import lombok.AllArgsConstructor;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static kz.eub.smart.core.mybank.core.exception.MyBankErrorCode.E_EX_700;

@AllArgsConstructor
public class GetAccountUseCaseImpl implements GetAccountsUseCase {

    DetailsUrlRepository detailsUrlRepository;
    GetProductStatusUseCase getProductStatusUseCase;

    @Override
    public List<Account> invoke(List<AccountCard> accountCards, List<AccountBalance> accountBalances) {
        return accountCards.stream()
                .filter(account -> account.getAccountType().equals(AccountType.CURR.name()))
                .distinct()
                .map(accountCard -> AccountMapper.getAccount(accountCard,
                                                            getBalance(accountCard, accountBalances),
                                                            getProductStatusUseCase.invoke(accountCard),
                                                            detailsUrlRepository.getCurrentAccountDetails())
                )
                .collect(Collectors.toList());
    }

    private AccountBalance getBalance(AccountCard accountCard, List<AccountBalance> accountBalances){
        return accountBalances
                .stream()
                .filter( balance -> Objects.nonNull(balance.getAccountOutref()) && balance.getAccountOutref().equals(accountCard.getAccountOutref()))
                .findFirst()
                .orElseThrow(() -> new MyBankException(E_EX_700, "GetAccountUseCaseImpl getBalance"));
    }

}
