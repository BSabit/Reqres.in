package kz.eub.smart.core.mybank.domain.mapper;

import kz.eub.smart.core.mybank.domain.model.Application;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;
import kz.eub.smart.core.mybank.domain.model.deposit.Deposit;

public class DepositApplicationMapper {

    public static Deposit toDeposit(Application application, String detailsLink) {
        Deposit deposit = new Deposit();
        deposit.setId(application.getApplicationId());
        deposit.setAmount(application.getAmount());
        deposit.setCurrency(application.getCurrency());
        deposit.setTitle(application.getTitle());
        deposit.setStatus(new ProductStatus(application.getStatusType(), application.getStatusTitle(), application.getStatusLink()));
        deposit.setImageUrl(application.getImageUrl());
        deposit.setDetailsLink(detailsLink);
        return deposit;
    }

}
