package kz.eub.smart.core.mybank.domain.model.credit;

import lombok.Data;

@Data
public class Period {
    Long paid;
    Long full;
}
