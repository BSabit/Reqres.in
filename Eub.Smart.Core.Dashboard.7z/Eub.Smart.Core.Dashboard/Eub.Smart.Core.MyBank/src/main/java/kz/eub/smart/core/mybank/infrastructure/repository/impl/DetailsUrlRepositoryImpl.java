package kz.eub.smart.core.mybank.infrastructure.repository.impl;

import kz.eub.smart.core.mybank.domain.repository.DetailsUrlRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

@Repository
public class DetailsUrlRepositoryImpl implements DetailsUrlRepository {

    @Value("${app.details-urls.cardAccountDetails}")
    String cardAccountDetails;

    @Value("${app.details-urls.mainCardDetails}")
    String mainCardDetails;

    @Value("${app.details-urls.additionalCardDetails}")
    String additionalCardDetails;

    @Value("${app.details-urls.cardApplication}")
    String cardApplication;

    @Value("${app.details-urls.openCard}")
    String openCard;

    @Value("${app.details-urls.depositDetails}")
    String depositDetails;

    @Value("${app.details-urls.depositApplication}")
    String depositApplication;

    @Value("${app.details-urls.openDeposit}")
    String openDeposit;

    @Value("${app.details-urls.currentAccountDetails}")
    String currentAccountDetails;

    @Value("${app.details-urls.currentAccountApplication}")
    String currentAccountApplication;

    @Value("${app.details-urls.openCurrentAccount}")
    String openCurrentAccount;

    @Value("${app.details-urls.creditDetails}")
    String creditDetails;

    @Value("${app.details-urls.creditApplication}")
    String creditApplication;

    @Value("${app.details-urls.openCredit}")
    String openCredit;

    @Value("${app.details-urls.installmentPay}")
    String installmentPay;

    @Value("${app.details-urls.creditPay}")
    String creditPay;

    @Value("${app.details-urls.creditPayList}")
    String creditPayList;

    @Value("${app.details-urls.bonusDetails}")
    String bonusDetails;

    @Value("${app.details-urls.bonusInfo}")
    String bonusInfo;


    @Override
    public String getCardAccountDetails() {
        return this.cardAccountDetails;
    }

    @Override
    public String getMainCardDetails() {
        return this.mainCardDetails;
    }

    @Override
    public String getAdditionalCardDetails() {
        return this.additionalCardDetails;
    }

    @Override
    public String getCardApplication() {
        return this.cardApplication;
    }

    @Override
    public String getOpenCard() {
        return this.openCard;
    }

    @Override
    public String getDepositDetails() {
        return this.depositDetails;
    }

    @Override
    public String getDepositApplication() {
        return this.depositApplication;
    }

    @Override
    public String getOpenDeposit() {
        return this.openDeposit;
    }

    @Override
    public String getCurrentAccountDetails() {
        return this.currentAccountDetails;
    }

    @Override
    public String getCurrentAccountApplication() {
        return this.currentAccountApplication;
    }

    @Override
    public String getOpenCurrentAccount() {
        return this.openCurrentAccount;
    }

    @Override
    public String getCreditDetails() {
        return this.creditDetails;
    }

    @Override
    public String getCreditApplication() {
        return this.creditApplication;
    }

    @Override
    public String getOpenCredit() {
        return this.openCredit;
    }

    @Override
    public String getInstallmentPay() {
        return this.installmentPay;
    }

    @Override
    public String getCreditPay() {
        return this.creditPay;
    }

    @Override
    public String getCreditPayList() {
        return this.creditPayList;
    }

    @Override
    public String getBonusDetails() {
        return this.bonusDetails;
    }

    @Override
    public String getBonusInfo() {
        return this.bonusInfo;
    }
}
