package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.core.constants.AccountType;
import kz.eub.smart.core.mybank.domain.mapper.BannerBonusMapper;
import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.Application;
import kz.eub.smart.core.mybank.domain.model.OpenProduct;
import kz.eub.smart.core.mybank.domain.model.bonus.BannerBonus;
import kz.eub.smart.core.mybank.domain.use_case.GetBannerBonusUseCase;

import java.util.Comparator;
import java.util.List;

public class GetBannerBonusUseCaseImpl implements GetBannerBonusUseCase {

    @Override
    public BannerBonus invoke(List<OpenProduct> openProducts, List<AccountCard> accountCards, List<Application> applications) {
        if (!hasApplication(applications) && !hasCard(accountCards)){
            return openProducts
                    .stream()
                    .max(Comparator.comparing(openProduct -> AccountType.BONS.name().equals(openProduct.getProductType())))
                    .map(BannerBonusMapper::toBannerBonus)
                    .orElse(null);
        }
        return null;
    }

    private boolean hasCard(List<AccountCard> accountCards) {
        return accountCards
                .stream()
                .anyMatch(accountCard -> accountCard.getAccountType().equals(AccountType.CARD.name()) &&
                        accountCard.getCardId() != null && accountCard.isCardUserAccountUserSame());
    }

    private boolean hasApplication(List<Application> applications) {
        return applications
                .stream()
                .anyMatch(application -> application.getApplicationType().equals(AccountType.CARD.name()));
    }
}
