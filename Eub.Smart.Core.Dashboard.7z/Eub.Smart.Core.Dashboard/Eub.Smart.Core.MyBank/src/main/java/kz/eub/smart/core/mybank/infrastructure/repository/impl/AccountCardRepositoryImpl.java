package kz.eub.smart.core.mybank.infrastructure.repository.impl;

import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.repository.AccountCardRepository;
import kz.eub.smart.core.mybank.infrastructure.mapper.InfrastructureMapper;
import kz.eub.smart.core.mybank.infrastructure.repository.AccountCardDaoRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@AllArgsConstructor
public class AccountCardRepositoryImpl implements AccountCardRepository {

    private final AccountCardDaoRepository accountCardDaoRepository;
    private final InfrastructureMapper mapper;

    @Override
    public List<AccountCard> getListOfAccountCard(Long userId, LangKey langKey) {
        return mapper.toDomain(accountCardDaoRepository.getAccountCard(userId, langKey.name()));
    }
}
