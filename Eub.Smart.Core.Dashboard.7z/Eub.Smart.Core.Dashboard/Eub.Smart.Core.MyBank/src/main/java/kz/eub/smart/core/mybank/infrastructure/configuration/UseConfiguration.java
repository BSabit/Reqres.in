package kz.eub.smart.core.mybank.infrastructure.configuration;

import kz.eub.smart.core.mybank.domain.repository.*;
import kz.eub.smart.core.mybank.domain.use_case.*;
import kz.eub.smart.core.mybank.domain.use_case.impl.*;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class UseConfiguration {

    @Bean
    public GetAccountsUseCase getAccountUseCase(DetailsUrlRepository detailsUrlRepository, GetProductStatusUseCase getProductStatusUseCase){
        return new GetAccountUseCaseImpl(detailsUrlRepository, getProductStatusUseCase);
    }

    @Bean
    public GetDepositsUseCase getDepositsUseCase(DetailsUrlRepository detailsUrlRepository,GetDepositStatusUseCase getDepositStatusUseCase){
        return new GetDepositsUseCaseImpl(detailsUrlRepository,getDepositStatusUseCase);
    }

    @Bean
    public GetCardsUseCase getCardsUseCase(GetProductStatusUseCase getProductStatusUseCase, DetailsUrlRepository detailsUrlRepository){
        return new GetCardsUseCaseImpl(getProductStatusUseCase, detailsUrlRepository);
    }

    @Bean
    public GetProductStatusUseCase getCardStatusUseCase(){
        return new GetProductStatusUseCaseImpl();
    }

    @Bean
    public GetBonusUseCase getBonusUseCase(BonusBalanceRepository bonusBalanceRepository, DetailsUrlRepository detailsUrlRepository){
        return new GetBonusUseCaseImpl(bonusBalanceRepository, detailsUrlRepository);
    }

    @Bean
    public GetCardApplicationsUseCase getCardApplicationsUseCase(DetailsUrlRepository detailsUrlRepository){
        return new GetCardApplicationsUseCaseImpl(detailsUrlRepository);
    }

    @Bean
    public GetDepositApplicationsUseCase getDepositApplicationsUseCase(DetailsUrlRepository detailsUrlRepository){
        return new GetDepositApplicationsUseCaseImpl(detailsUrlRepository);
    }

    @Bean
    public GetCurrentAccountApplicationsUseCase getCurrentAccountApplicationsUseCase(DetailsUrlRepository detailsUrlRepository){
        return new GetCurrentAccountApplicationsUseCaseImpl(detailsUrlRepository);
    }

    @Bean
    public GetBankUseCase getBankUseCase(GetAccountsUseCase getAccountsUseCase, GetCardsUseCase getCardsUseCase,
                                         AccountCardRepository accountCardRepository, CardBalanceRepository cardBalanceRepository,
                                         DepositCurrentAccountBalanceRepository depositCurrentAccountBalanceRepository,
                                         GetDepositsUseCase getDepositsUseCase,GetBonusUseCase getBonusUseCase,
                                         ApplicationRepository applicationRepository, GetCardApplicationsUseCase getCardApplicationsUseCase,
                                         GetDepositApplicationsUseCase getDepositApplicationsUseCase, GetCurrentAccountApplicationsUseCase getCurrentAccountApplicationsUseCase,
                                         GetOpenProductsUseCase getOpenProductsUseCase, GetBannerBonusUseCase getBannerBonusUseCase, OpenProductRepository openProductRepository){
        return new GetBankUseCaseImpl(getAccountsUseCase,getDepositsUseCase,getCardsUseCase,getBonusUseCase,accountCardRepository,cardBalanceRepository,depositCurrentAccountBalanceRepository,applicationRepository, getCardApplicationsUseCase, getDepositApplicationsUseCase, getCurrentAccountApplicationsUseCase,getOpenProductsUseCase, getBannerBonusUseCase, openProductRepository);
    }

    @Bean
    public SetBonusSpendUseCase getSetBonusSpendUseCase(BonusSpendRepository bonusSpendRepository){
        return new SetBonusSpendUseCaseImpl(bonusSpendRepository);
    }

    @Bean
    public GetDepositStatusUseCase getDepositStatusUseCase(){
        return new GetDepositStatusUseCaseImpl();
    }

    @Bean
    public GetProductStatusUseCase getProductStatusUseCase(){
        return new GetProductStatusUseCaseImpl();
    }

    @Bean
    public GetOpenProductsUseCase getOpenProductsUseCase(){
        return new GetOpenProductsUseCaseImpl();
    }

    @Bean
    public GetBannerBonusUseCase getBannerBonusUseCase(){
        return new GetBannerBonusUseCaseImpl();
    }


}
