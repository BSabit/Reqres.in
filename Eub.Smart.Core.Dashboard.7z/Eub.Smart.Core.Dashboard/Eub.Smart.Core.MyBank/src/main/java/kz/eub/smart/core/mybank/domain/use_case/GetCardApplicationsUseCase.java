package kz.eub.smart.core.mybank.domain.use_case;

import kz.eub.smart.core.mybank.domain.model.Application;
import kz.eub.smart.core.mybank.domain.model.card.Card;

import java.util.List;

public interface GetCardApplicationsUseCase {
    List<Card> invoke(List<Application> applications);
}
