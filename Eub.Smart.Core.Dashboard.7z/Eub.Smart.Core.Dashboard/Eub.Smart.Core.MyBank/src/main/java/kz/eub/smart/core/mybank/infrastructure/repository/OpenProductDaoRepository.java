package kz.eub.smart.core.mybank.infrastructure.repository;

import kz.eub.smart.core.mybank.infrastructure.entity.OpenProductEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OpenProductDaoRepository extends JpaRepository<OpenProductEntity, Long> {

    @Query(nativeQuery = true, value = """
                   select
                   	op.OpenProduct_ID                as openProductId,
                   	op.Details_Url                   as detailsLink,
                   	op.ProductType_IDREF             as productType,
                   	case
                   		when :lang = 'KK' THEN t.Term_KZ
                   		when :lang = 'RU' THEN t.Term_RU
                   		when :lang = 'EN' THEN t.Term_EN
                   		else ''
                   	end  COLLATE DATABASE_DEFAULT     as title,
                   	case
                   		when :lang = 'KK' THEN t.Desc_KZ
                   		when :lang = 'RU' THEN t.Desc_RU 
                   		when :lang = 'EN' THEN t.Desc_EN
                   		else ''
                   	end   COLLATE DATABASE_DEFAULT   as description,
                   	md.FileUid                       as imageUid
                   FROM OpenProduct op
                   left join Term t on t.Term_ID = op.Term_OUTREF
                   left JOIN MetaDocument md on md.Target_ID = op.OpenProduct_ID and md.Target_Table = 'OpenProduct' and md.IsActive = 'true' and md.LangKey = :lang
                    order by op.Priority asc
                   
                   
                    """)
    List<OpenProductEntity> getOpenProducts(@Param("lang") String language);

}
