package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.domain.model.AccountBalance;
import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;
import kz.eub.smart.core.mybank.core.constants.StatusType;
import kz.eub.smart.core.mybank.domain.use_case.GetDepositStatusUseCase;

public class GetDepositStatusUseCaseImpl implements GetDepositStatusUseCase{

    @Override
    public ProductStatus invoke(AccountCard accountCard, AccountBalance accountBalance) {
        if (accountCard != null && accountCard.getStatusTitle() != null){
            if (accountCard.getStatusPriority() > 1 && accountBalance.getBalance() != null && accountBalance.getBalance().compareTo(accountCard.getMinBalance()) < 0){
                return new ProductStatus(StatusType.warning.name(), "Пополните депозит", "https://local/module/deposit/accountMinBalance");
            }
            return new ProductStatus(accountCard.getStatusType(), accountCard.getStatusTitle(), accountCard.getStatusLink());
        }
        return null;
    }

}
