package kz.eub.smart.core.mybank.domain.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

@Data
public class OpenProduct {
    private Long openProductId;
    private String title;
    private String description;
    private String detailsLink;
    private String imageUrl;
    @JsonIgnore
    private String productType;
}
