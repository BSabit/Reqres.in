package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.bank.Bank;
import kz.eub.smart.core.mybank.domain.repository.*;
import kz.eub.smart.core.mybank.domain.use_case.*;
import kz.eub.smart.core.mybank.core.constants.AccountType;
import lombok.AllArgsConstructor;

import java.util.ArrayList;
import java.util.stream.Collectors;

@AllArgsConstructor
public class GetBankUseCaseImpl implements GetBankUseCase {

    GetAccountsUseCase getAccountsUseCase;

    GetDepositsUseCase getDepositsUseCase;

    GetCardsUseCase getCardsUseCase;

    GetBonusUseCase getBonusUseCase;

    private final AccountCardRepository accountCardRepository;

    private final CardBalanceRepository cardBalanceRepository;

    private final DepositCurrentAccountBalanceRepository depositCurrentAccountBalanceRepository;

    private final ApplicationRepository applicationRepository;

    private final GetCardApplicationsUseCase getCardApplicationsUseCase;

    private final GetDepositApplicationsUseCase getDepositApplicationsUseCase;

    private final GetCurrentAccountApplicationsUseCase getCurrentAccountApplicationsUseCase;

    private final GetOpenProductsUseCase getOpenProductsUseCase;

    private final GetBannerBonusUseCase getBannerBonusUseCase;

    private final OpenProductRepository openProductRepository;

    @Override
    public Bank invoke(Long userId, String iin, LangKey langKey) {

        var accountCards = accountCardRepository.getListOfAccountCard(userId, langKey);
        var depositAccountOutrefs = accountCards.stream().filter(acc -> acc.getAccountType().equals(AccountType.SAVE.name()) || acc.getAccountType().equals(AccountType.CURR.name())).map(AccountCard::getAccountOutref).collect(Collectors.toSet());
        var cardOutrefs = accountCards.stream().filter(acc -> acc.getAccountType().equals(AccountType.CARD.name())).map(AccountCard::getAccountOutref).collect(Collectors.toSet());
        var cardBalances = cardBalanceRepository.getListBalances(cardOutrefs);
        var depCurrBalances = depositCurrentAccountBalanceRepository.getListBalances(depositAccountOutrefs);

        var applications = applicationRepository.getApplications(userId, langKey);
        var cardApplications = getCardApplicationsUseCase.invoke(applications);
        var depApplications = getDepositApplicationsUseCase.invoke(applications);
        var accountApplications = getCurrentAccountApplicationsUseCase.invoke(applications);

        var installmentCards = getCardsUseCase.invoke(accountCards, cardBalances ,true);
        var allCards = getCardsUseCase.invoke(accountCards, cardBalances, false);
        var allAccounts = getAccountsUseCase.invoke(accountCards, depCurrBalances);
        var allDeposits = getDepositsUseCase.invoke(accountCards, depCurrBalances);
        allAccounts.addAll(accountApplications);
        allCards.addAll(cardApplications);
        allDeposits.addAll(depApplications);

        var openProducts = openProductRepository.getAll(langKey);

        return Bank.builder()
                .accounts(allAccounts)
                .cards(allCards)
                .deposits(allDeposits)
                .bonus(getBonusUseCase.invoke(accountCards, iin, applications))
                .installmentCards(installmentCards)
                .credits(new ArrayList<>())
                .openProducts(getOpenProductsUseCase.invoke(openProducts, accountCards, applications))
                .bannerBonus(getBannerBonusUseCase.invoke(openProducts, accountCards, applications))
                .build();

    }
}
