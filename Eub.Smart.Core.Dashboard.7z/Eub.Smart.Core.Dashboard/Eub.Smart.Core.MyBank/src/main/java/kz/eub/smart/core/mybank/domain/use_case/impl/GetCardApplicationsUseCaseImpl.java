package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.domain.mapper.CardApplicationMapper;
import kz.eub.smart.core.mybank.domain.mapper.CardBalanceMapper;
import kz.eub.smart.core.mybank.domain.model.Application;
import kz.eub.smart.core.mybank.domain.model.card.Card;
import kz.eub.smart.core.mybank.core.constants.AccountType;
import kz.eub.smart.core.mybank.domain.repository.DetailsUrlRepository;
import kz.eub.smart.core.mybank.domain.use_case.GetCardApplicationsUseCase;
import lombok.AllArgsConstructor;

import java.util.List;

@AllArgsConstructor
public class GetCardApplicationsUseCaseImpl implements GetCardApplicationsUseCase {

    private final DetailsUrlRepository detailsUrlRepository;

    @Override
    public List<Card> invoke(List<Application> applications) {
        return applications.stream()
                .filter(application -> AccountType.CARD.name().equals(application.getApplicationType()))
                .map(application ->  CardApplicationMapper.getCard(application, CardBalanceMapper.toCardBalance(application), detailsUrlRepository.getCardApplication()))
                .toList();
    }

}
