package kz.eub.smart.core.mybank.domain.model.bonus;

import lombok.Data;

@Data
public class BannerBonus {
    private String imageUrl;
    private String link;
}
