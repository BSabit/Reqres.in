package kz.eub.smart.core.mybank.infrastructure.repository.grpc;

import kz.eub.smart.core.mybank.core.exception.MyBankException;
import kz.eub.smart.core.mybank.domain.repository.BonusSpendRepository;
import kz.eubank.grpc.EubAggregatorCoreMyBank;
import kz.eubank.grpc.MyBankInfoGrpc;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.springframework.stereotype.Service;

import static kz.eub.smart.core.mybank.core.exception.MyBankErrorCode.E_DB_602;

@Service
public class BonusSpendRepositoryImpl implements BonusSpendRepository {

    @GrpcClient("dashboard")
    private MyBankInfoGrpc.MyBankInfoBlockingStub stub;

    @Override
    public void setSpend(String iin, boolean isSpending) {
        EubAggregatorCoreMyBank.SetSonusSpendRequest request = EubAggregatorCoreMyBank.SetSonusSpendRequest.newBuilder()
                .setBonusSpendIsAllowed(isSpending)
                .setIin(iin)
                .build();
        var statusReply = stub.setSonusSpend(request);
        if (!statusReply.getStatus()){
            throw new MyBankException(E_DB_602, "BonusSpendRepository setSpend " + statusReply.getMessage());
        }
    }
}
