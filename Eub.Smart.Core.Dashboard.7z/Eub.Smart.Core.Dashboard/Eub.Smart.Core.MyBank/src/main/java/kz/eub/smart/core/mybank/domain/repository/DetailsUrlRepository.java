package kz.eub.smart.core.mybank.domain.repository;

public interface DetailsUrlRepository {
    String getCardAccountDetails();
    String getMainCardDetails();
    String getAdditionalCardDetails();
    String getCardApplication();
    String getOpenCard();
    String getDepositDetails();
    String getDepositApplication();
    String getOpenDeposit();
    String getCurrentAccountDetails();
    String getCurrentAccountApplication();
    String getOpenCurrentAccount();
    String getCreditDetails();
    String getCreditApplication();
    String getOpenCredit();
    String getInstallmentPay();
    String getCreditPay();
    String getCreditPayList();
    String getBonusDetails();
    String getBonusInfo();
}
