package kz.eub.smart.core.mybank.core.constants;

public enum ApplicationTechStatus {
    NEWW,
    PICK,
    RJCT,
    PROC
}
