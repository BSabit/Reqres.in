package kz.eub.smart.core.mybank.infrastructure.repository;

import kz.eub.smart.core.mybank.infrastructure.entity.AccountCardEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AccountCardDaoRepository extends JpaRepository<AccountCardEntity, Long> {

    @Query(nativeQuery = true, value = """
                    SELECT *
                    FROM (
                    select  NEWID()						as accountCardId,
                            a.AccountType_IDREF			as accountType,
                            a.Account_ID				as accountId,
                            a.Account_IDREF				as parentAccountId,
                    		case
                    			when 'KK' = :lang
                    				then COALESCE(tps.Term_KZ, ps.ProductState_Title)
                    			when 'RU' = :lang
                    				then COALESCE(tps.Term_RU, ps.ProductState_Title)
                    			else COALESCE(tps.Term_EN, ps.ProductState_Title)
                    		end                        as statusTitle,
                            ps.StatusColor_IDREF       as statusType,
                            ps.Link                    as statusLink,
                    		ps.Priority                as statusPriority,
                    		min(ps.Priority) OVER (PARTITION BY a.Account_ID) as minPriorityStatus,
                            a.Number					as accountNumber,
                            COALESCE(cut.Symbol, a.Currency) as currency,
                    		md.FileUid					as imageUid,
                    		isnull(cpo.IsInstallment,0) as isInstallment,
                    		case
                      			when ct.CardType_Title is not null and isnull(cpo.IsInstallment,0) != 1
                      				THEN
                      				case
                      					WHEN :lang = 'EN' then COALESCE(muc.Pseudonym, ctt.Term_EN,ct.CardType_Title)
                      				 	WHEN :lang = 'KK' then COALESCE(muc.Pseudonym, ctt.Term_KZ,ct.CardType_Title)
                      				 	ELSE COALESCE(muc.Pseudonym, ctt.Term_RU,ct.CardType_Title)
                      				end
                      			else 
                      				CASE
                      					WHEN :lang = 'EN' THEN COALESCE(mua.Pseudonym, psnt.Term_EN, psn.ProductShortName_Title, actt.Term_EN, act.AccountType_Title)
                      					WHEN :lang = 'KK' THEN COALESCE(mua.Pseudonym, psnt.Term_KZ, psn.ProductShortName_Title, actt.Term_KZ, act.AccountType_Title)
                      					else COALESCE(mua.Pseudonym, psnt.Term_RU, psn.ProductShortName_Title, actt.Term_RU, act.AccountType_Title)
                      				END
                      			
                      		end                         as productTitle,
                            a.Account_OUTREF			as accountOutref,
                            mua.User_IDREF				as accountUserId,
                            muc.User_IDREF				as cardUserId,
                            a.AccountStatus_IDREF		as accountStatus,
                            acs.AccountStatus_Title		as accountStatusTitle,
                            a.IsMultiCurrency			as isMultiCurrency,
                            c.Card_ID					as cardId,
                            right(c.MaskedNumber,4)		as cardMaskedNumber,
                            c.CardStatus_IDREF			as cardStatus,
                            c.CardPinStatus_IDREF		as cardPinStatus,
                            c.isBasic					as isBasic,
                            c.ShortName					as cardCyrillicShortName,
                            c.FirstName					as cardCyrillicFirstName,
                            c.LastName					as cardCyrillicLastName,
                            c.FathersName				as cardCyrillicMiddleName,
                            c.IsDigital					as cardIsDigital,
                            case
                                when CURRENT_TIMESTAMP > dateadd(day, -30, depAcc.ExitDate)
                                    and CURRENT_TIMESTAMP < depAcc.ExitDate then 'true'
                            	else 'false'
                            end                        as depAccPeriodExpires,
                            a.MinBalance              as minBalance,
                            a.HasArrestOrCardFile     as hasArrestOrCardFile
                    From Account a
                            join AccountType act on a.AccountType_IDREF = act.AccountType_ID
                            join map_User_Account mua on a.Account_ID = mua.Account_IDREF
                            join AccountStatus acs on acs.AccountStatus_ID = a.AccountStatus_IDREF
                    		left join CurrencyType cut on cut.Currency_Code = a.Currency
                            left join Card c on a.Account_ID = c.Account_IDREF
                            left join CardType ct on c.CardType_IDREF = ct.CardType_ID
                            left join map_User_Card muc on c.Card_ID = muc.Card_IDREF
                            left join MetaDocument md on md.IsActive = 1 and md.Screen = 'mybank' and
                    		md.Target_ID =  case	
                    			when ct.Target_ID is not null
                    			then ct.Target_ID
                    			else act.Target_ID
                    		end
                    		and md.Target_Table = case
                    			when ct.Target_ID is not null
                    			then 'CardType'
                    			else 'AccountType'
                    		end
                    		left join DepositAccount depAcc on depAcc.Account_IDREF = a.Account_ID
                            left join CardDeliveryApplication cda on cda.Card_IDREF = c.Card_ID
                            left join ApplicationState ast on ast.Application_IDREF  = cda.Application_IDREF
                      		left join CardProductOperation cpo on a.Product_IDREF = cpo.Product_IDREF
                      		left join AccountProduct as ap on ap.ProductCompound_OUTREF = a.ProductCompound_OUTREF and a.AccountType_IDREF in ('CURR','BONS')
                      		left join DepositProduct as dp on dp.ProductCompound_OUTREF = a.ProductCompound_OUTREF and a.AccountType_IDREF = 'SAVE'
                      		left join CardAccountProduct as cap on cap.ProductCompound_OUTREF = a.ProductCompound_OUTREF and a.AccountType_IDREF = 'CARD'
                      		left join ProductShortName as psn on ap.ProductShortName_IDREF = psn.ProductShortName_ID
                      		or dp.ProductShortName_IDREF = psn.ProductShortName_ID
                      		or cap.ProductShortName_IDREF = psn.ProductShortName_ID
                      		left join Term actt on actt.Term_ID = act.Term_OUTREF
                      		left join Term psnt on psnt.Term_ID = psn.Term_OUTREF
                      		left join Term ctt on ctt.Term_ID = ct.Term_OUTREF
                      		LEFT JOIN ProductState ps ON ps.ProductType_IDREF = a.AccountType_IDREF AND ps.isApplication = 0
                      		AND ps.ProductStateCode in ( CASE
                                        WHEN a.HasArrestOrCardFile = 1 THEN 'arrest_or_cardFile'
                                        ELSE 'null'
                                    END,
                        			CASE
                                        WHEN acs.AccountStatus_ID = 'BLOC' or c.CardStatus_IDREF = 'BLOC' THEN 'card_is_blocked'
                                        ELSE 'null'
                                    END,
                        			CASE
                                        WHEN ast.AppTechStatus_IDREF is not null THEN 'card_is_delivered'
                                        ELSE 'null'
                                    END,
                        			CASE
                                        WHEN c.CardPinStatus_IDREF = 'Y' THEN 'PIN_code_not_set'
                                        ELSE 'null'
                                    END,
                        			CASE
                        			when CURRENT_TIMESTAMP > dateadd(day, -30, depAcc.ExitDate)
                        			then 'deposit_deadline'
                        			else 'null'
                        			end)
                            LEFT JOIN Term tps ON tps.Term_ID = ps.Term_OUTREF
                        	LEFT JOIN MetaDocument mdps ON mdps.IsActive = 1 AND mdps.Target_ID = ps.ProductState_ID AND mdps.Target_Table = 'ProductState'
                        where (mua.User_IDREF = :userId or muc.User_IDREF = :userId) and
                                a.AccountStatus_IDREF not in ('DLTD', 'CLOS') and
                                ISNULL(c.CardStatus_IDREF, 'NULL') not in ('DLTD', 'CLOS') and
                                ISNULL(ast.AppTechStatus_IDREF, 'NULL') in ('PROC', 'NEWW', 'NULL')
                        ) AS SubQueryForPartitionProductState
                        WHERE  isnull (statusPriority,-1) = isnull(minPriorityStatus,-1);
                              
                    """)
    List<AccountCardEntity> getAccountCard(@Param("userId") Long userId, @Param("lang") String lang);

}
