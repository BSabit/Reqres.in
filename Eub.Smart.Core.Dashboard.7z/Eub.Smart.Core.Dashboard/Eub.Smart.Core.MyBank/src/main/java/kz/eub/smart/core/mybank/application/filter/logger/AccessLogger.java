package kz.eub.smart.core.mybank.application.filter.logger;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;

import static kz.eub.smart.core.mybank.core.constants.MdcConstants.X_FORWARDED_FOR;
import static kz.eub.smart.core.mybank.core.util.StringUtil.isNotEmpty;


@Component
@AllArgsConstructor
public class AccessLogger {

    private final HttpServletRequest request;

    public String getClientIp() {
        String xForwardedFor = request.getHeader(X_FORWARDED_FOR);
        if (isNotEmpty(xForwardedFor)) {
            return xForwardedFor.split(",")[0].trim();
        } else {
            return request.getRemoteAddr();
        }
    }
}
