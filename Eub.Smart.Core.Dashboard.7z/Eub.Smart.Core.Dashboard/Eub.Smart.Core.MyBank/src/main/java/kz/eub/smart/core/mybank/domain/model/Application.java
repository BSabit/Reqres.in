package kz.eub.smart.core.mybank.domain.model;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class Application {

    private Long applicationId;
    private String applicationType;
    private String statusTitle;
    private String statusType;
    private String statusLink;
    private String imageUrl;
    private String title;
    private String currency;
    private BigDecimal amount;
}
