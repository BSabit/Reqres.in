package kz.eub.smart.core.mybank.core.constants;

public enum CardPinStatus {
    A,
    S,
    Y
}
