package kz.eub.smart.core.mybank.domain.use_case;

import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.Application;
import kz.eub.smart.core.mybank.domain.model.bonus.Bonus;

import java.util.List;

public interface GetBonusUseCase {
    Bonus invoke(List<AccountCard> accountCards, String iin, List<Application> applications);
}
