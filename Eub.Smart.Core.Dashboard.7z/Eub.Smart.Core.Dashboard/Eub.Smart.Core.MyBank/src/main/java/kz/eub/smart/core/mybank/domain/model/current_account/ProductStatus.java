package kz.eub.smart.core.mybank.domain.model.current_account;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductStatus {
    String type;
    String title;
    String link;
}
