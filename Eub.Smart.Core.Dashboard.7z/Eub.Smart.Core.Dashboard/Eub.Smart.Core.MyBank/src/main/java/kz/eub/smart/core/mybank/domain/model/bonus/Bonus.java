package kz.eub.smart.core.mybank.domain.model.bonus;

import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class Bonus {

    String imageUrl;
    BigDecimal amount;
    Boolean enabled;
    ProductStatus status;
    String detailsLink;

}
