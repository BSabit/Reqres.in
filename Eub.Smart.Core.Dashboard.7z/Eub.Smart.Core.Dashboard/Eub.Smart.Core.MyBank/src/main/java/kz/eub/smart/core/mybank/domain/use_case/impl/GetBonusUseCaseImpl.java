package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.domain.mapper.BonusAccountMapper;
import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.Application;
import kz.eub.smart.core.mybank.domain.model.bonus.Bonus;
import kz.eub.smart.core.mybank.domain.repository.BonusBalanceRepository;
import kz.eub.smart.core.mybank.domain.repository.DetailsUrlRepository;
import kz.eub.smart.core.mybank.domain.use_case.GetBonusUseCase;
import kz.eub.smart.core.mybank.core.constants.AccountType;
import lombok.AllArgsConstructor;

import java.util.List;

@AllArgsConstructor
public class GetBonusUseCaseImpl implements GetBonusUseCase {

    BonusBalanceRepository bonusBalanceRepository;

    DetailsUrlRepository detailsUrlRepository;

    @Override
    public Bonus invoke(List<AccountCard> accountCards, String iin, List<Application> applications) {
        if (hasApplicationForCard(applications) || hasCard(accountCards)) {
            return accountCards
                    .stream()
                    .filter(accountCard -> AccountType.BONS.name().equals(accountCard.getAccountType()))
                    .findFirst()
                    .map(bonus -> BonusAccountMapper.getBonusAccount(bonus, bonusBalanceRepository.getBalance(iin), detailsUrlRepository.getBonusDetails()))
                    .orElse(null);
        }
        return null;
    }

    private boolean hasCard(List<AccountCard> accountCards) {
        return accountCards
                .stream()
                .anyMatch(accountCard ->  AccountType.CARD.name().equals(accountCard.getAccountType()) && accountCard.getCardId() != null && accountCard.isCardUserAccountUserSame());
    }

    private boolean hasApplicationForCard(List<Application> applications) {
        return applications
                .stream()
                .anyMatch(application -> AccountType.CARD.name().equals(application.getApplicationType()));
    }
}
