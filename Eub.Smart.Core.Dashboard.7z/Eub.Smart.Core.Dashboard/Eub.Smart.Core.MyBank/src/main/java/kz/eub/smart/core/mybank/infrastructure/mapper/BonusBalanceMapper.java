package kz.eub.smart.core.mybank.infrastructure.mapper;

import kz.eub.smart.core.mybank.domain.model.AccountBalance;
import kz.eub.smart.core.mybank.domain.model.bonus.BonusBalanceInfo;
import kz.eub.smart.core.mybank.infrastructure.mapper.uses.CustomTypeDecimalValueToBigDecimal;
import kz.eubank.grpc.EubAggregatorCoreMyBank;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING,uses = { CustomTypeDecimalValueToBigDecimal.class})
public interface BonusBalanceMapper {

    @Mapping(target = "spendIsAllowed", source = "bonusSpendIsAllowed")
    BonusBalanceInfo toDomain(EubAggregatorCoreMyBank.GetClientBonusInfoReply balance);

}
