package kz.eub.smart.core.mybank.presentation.controller;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import kz.eub.smart.core.mybank.application.model.ErrorResponse;
import kz.eub.smart.core.mybank.core.component.UserDetails;
import kz.eub.smart.core.mybank.core.exception.MyBankException;
import kz.eub.smart.core.mybank.domain.use_case.SetBonusSpendUseCase;
import kz.eub.smart.core.mybank.presentation.model.BonusSpendRequest;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/bonus/spend")
@RestController
@AllArgsConstructor
public class BonusSpendController {

    private SetBonusSpendUseCase setBonusSpendUseCase;
    private UserDetails userDetails;

    @PostMapping("/set")
    @SecurityRequirement(name = "Bearer Authentication")
    @Operation(summary = "Включение/Отключение бонусов", description = "Включение/Отключение траты бонусов пользователя")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK"),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}
            )
    })
    public ResponseEntity<?> enable(@RequestBody BonusSpendRequest bonusSpendRequest) {
        try {
            setBonusSpendUseCase.invoke(userDetails.getIin(), bonusSpendRequest.isSpending());
            return new ResponseEntity<>(HttpStatus.OK);
        }catch (MyBankException myBankException){
            return new ResponseEntity<>(new ErrorResponse(myBankException), HttpStatus.INTERNAL_SERVER_ERROR);
        }catch (Exception exception){
            return new ResponseEntity<>(new ErrorResponse(exception), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
