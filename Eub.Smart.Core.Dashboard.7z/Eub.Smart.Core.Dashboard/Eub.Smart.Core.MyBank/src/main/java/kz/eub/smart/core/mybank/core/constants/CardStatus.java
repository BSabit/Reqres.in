package kz.eub.smart.core.mybank.core.constants;

public enum CardStatus {
    ACTV,
    BLOC,
    CLOS,
    DLTD,
    EXPD,
    LSTA,
    LSTK,
    NACT,
    UNKN
}
