package kz.eub.smart.core.mybank.infrastructure.mapper;

import kz.eub.smart.core.mybank.domain.model.Application;
import kz.eub.smart.core.mybank.infrastructure.entity.ApplicationEntity;
import kz.eub.smart.core.mybank.core.util.S3UrlUtil;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING, uses = S3UrlUtil.class)
public interface ApplicationMapper {

    List<Application> toDomain(List<ApplicationEntity> entities);

    @Mapping(target = "imageUrl", source = "entity.imageUid", qualifiedByName = "buildImageUrl")
    Application toDomain(ApplicationEntity entity);

}
