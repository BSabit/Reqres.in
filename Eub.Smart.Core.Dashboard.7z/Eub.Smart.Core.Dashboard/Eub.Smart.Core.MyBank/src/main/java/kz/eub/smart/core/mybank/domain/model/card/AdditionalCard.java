package kz.eub.smart.core.mybank.domain.model.card;

import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;
import lombok.Data;

@Data
public class AdditionalCard {
    Long id;
    String number;
    String name;
    String imageUrl;
    String title;
    ProductStatus status;
    String detailsLink;
}
