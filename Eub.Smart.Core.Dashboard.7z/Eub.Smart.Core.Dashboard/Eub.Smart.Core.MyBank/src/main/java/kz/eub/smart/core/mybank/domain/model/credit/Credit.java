package kz.eub.smart.core.mybank.domain.model.credit;

import lombok.Data;

@Data
public class Credit {

    Long id;
    String imageUrl;
    String title;
    Period period;
}
