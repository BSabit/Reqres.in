package kz.eub.smart.core.mybank.infrastructure.repository.grpc;

import kz.eub.smart.core.mybank.domain.model.bonus.BonusBalanceInfo;
import kz.eub.smart.core.mybank.domain.repository.BonusBalanceRepository;
import kz.eub.smart.core.mybank.infrastructure.mapper.BonusBalanceMapper;
import kz.eubank.grpc.EubAggregatorCoreMyBank;
import kz.eubank.grpc.MyBankInfoGrpc;
import lombok.RequiredArgsConstructor;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Service
public class BonusBalanceRepositoryImpl implements BonusBalanceRepository {

    @GrpcClient("dashboard")
    private MyBankInfoGrpc.MyBankInfoBlockingStub stub;


    private final BonusBalanceMapper mapper;


    @Override
    public BonusBalanceInfo getBalance(String iin) {
        return mapper.toDomain(getClientBonusInfoReply(iin));
    }

    public EubAggregatorCoreMyBank.GetClientBonusInfoReply getClientBonusInfoReply(String iin){
        EubAggregatorCoreMyBank.GetClientBonusInfoRequest request = EubAggregatorCoreMyBank.GetClientBonusInfoRequest
                .newBuilder()
                .setIin(iin)
                .build();
        return stub.getClientBonusInfo(request);
    }

}
