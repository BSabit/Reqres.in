package kz.eub.smart.core.mybank.infrastructure.repository.grpc;

import kz.eub.smart.core.mybank.domain.model.AccountBalance;
import kz.eub.smart.core.mybank.infrastructure.mapper.BalanceMapper;
import kz.eub.smart.core.mybank.domain.repository.DepositCurrentAccountBalanceRepository;
import kz.eubank.grpc.EubAggregatorCoreMyBank;
import kz.eubank.grpc.MyBankInfoGrpc;
import lombok.RequiredArgsConstructor;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Collections;
import java.util.List;
import java.util.Set;

@RequiredArgsConstructor
@Service
public class DepositCurrentAccountBalanceRepositoryImpl implements DepositCurrentAccountBalanceRepository {

    @GrpcClient("dashboard")
    private MyBankInfoGrpc.MyBankInfoBlockingStub stub;

    private final BalanceMapper mapper;

    @Override
    public List<AccountBalance> getListBalances(Set<Long> accountOutrefs) {
        if (!CollectionUtils.isEmpty(accountOutrefs)) {
            return mapper.toDomain(getBalances(accountOutrefs).getBalancesList());
        }
        return Collections.emptyList();
    }

    public EubAggregatorCoreMyBank.AccountBalanceReply getBalances(Set<Long> accountOutrefs){
        EubAggregatorCoreMyBank.AccountBalanceRequest request = EubAggregatorCoreMyBank.AccountBalanceRequest
                .newBuilder()
                .addAllAccountIds(accountOutrefs)
                .build();
        return stub.getCurrentAccountBalance(request);
    }
}
