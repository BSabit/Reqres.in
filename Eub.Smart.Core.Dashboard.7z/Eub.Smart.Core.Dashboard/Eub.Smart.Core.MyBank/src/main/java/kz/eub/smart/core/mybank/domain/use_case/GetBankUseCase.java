package kz.eub.smart.core.mybank.domain.use_case;

import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.domain.model.bank.Bank;

public interface GetBankUseCase {

    Bank invoke(Long userId, String iin, LangKey langKey);

}
