package kz.eub.smart.core.mybank.domain.mapper;


import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.card.AdditionalCard;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;


public class AdditionalCardMapper {

    public static AdditionalCard getAdditionalCard(AccountCard accountCard, ProductStatus productStatus,String detailsLink){
        AdditionalCard additionalCard = new AdditionalCard();
        additionalCard.setName(getFormattedName(accountCard));
        additionalCard.setId(accountCard.getCardId());
        additionalCard.setTitle(accountCard.getProductTitle());
        additionalCard.setImageUrl(accountCard.getImageUrl());
        additionalCard.setNumber(accountCard.getCardMaskedNumber());
        additionalCard.setStatus(productStatus);
        additionalCard.setDetailsLink(detailsLink);
        return additionalCard;
    }

    private static String getFormattedName(AccountCard accountCard){
        var lastName =  accountCard.getCardCyrillicLastName();
        var firsName = accountCard.getCardCyrillicFirstName();
        var middleName = accountCard.getCardCyrillicMiddleName();
        String shortName = lastName;
        if (lastName != null && lastName.length() >  1){
            shortName = Character.toUpperCase(lastName.charAt(0)) + lastName.substring(1).toLowerCase();
        }
        shortName += " ";
        if (firsName != null && firsName.length() > 0){
            shortName += Character.toUpperCase(firsName.charAt(0)) + ".";
        }
        if (middleName != null && middleName.length() > 0){
            shortName += Character.toUpperCase(middleName.charAt(0)) + ".";
        }
        return shortName;
    }

}
