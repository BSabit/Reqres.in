package kz.eub.smart.core.mybank.domain.model.current_account;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class Account {

    Long id;
    BigDecimal amount;
    String currency;
    String imageUrl;
    String title;
    ProductStatus status;
    String detailsLink;
}
