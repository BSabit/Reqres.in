package kz.eub.smart.core.mybank.core.constants;

public enum AccountStatusEnum {
    ACTV,
    BLOC,
    CLOS,
    COLL,
    CRBA,
    DLTD,
    PRBL,
    SUSP,
    UNCL
}
