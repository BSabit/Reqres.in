package kz.eub.smart.core.mybank.domain.use_case.impl;

import kz.eub.smart.core.mybank.domain.mapper.DepositApplicationMapper;
import kz.eub.smart.core.mybank.domain.model.Application;
import kz.eub.smart.core.mybank.domain.model.deposit.Deposit;
import kz.eub.smart.core.mybank.core.constants.AccountType;
import kz.eub.smart.core.mybank.domain.repository.DetailsUrlRepository;
import kz.eub.smart.core.mybank.domain.use_case.GetDepositApplicationsUseCase;
import lombok.AllArgsConstructor;

import java.util.List;

@AllArgsConstructor
public class GetDepositApplicationsUseCaseImpl implements GetDepositApplicationsUseCase {

    private final DetailsUrlRepository detailsUrlRepository;

    @Override
    public List<Deposit> invoke(List<Application> applications) {
        return applications.stream()
                .filter(application -> AccountType.SAVE.name().equals(application.getApplicationType()))
                .map(application-> DepositApplicationMapper.toDeposit(application, detailsUrlRepository.getDepositApplication()))
                .toList();
    }
}
