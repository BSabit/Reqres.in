package kz.eub.smart.core.mybank.domain.mapper;

import kz.eub.smart.core.mybank.domain.model.OpenProduct;
import kz.eub.smart.core.mybank.domain.model.bonus.BannerBonus;

public class BannerBonusMapper {
    public static BannerBonus toBannerBonus(OpenProduct openProduct) {
        BannerBonus bannerBonus = new BannerBonus();
        bannerBonus.setImageUrl(openProduct.getImageUrl());
        bannerBonus.setLink(openProduct.getDetailsLink());
        return bannerBonus;
    }
}
