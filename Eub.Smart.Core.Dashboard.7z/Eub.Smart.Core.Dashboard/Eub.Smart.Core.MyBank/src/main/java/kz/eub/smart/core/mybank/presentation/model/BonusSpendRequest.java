package kz.eub.smart.core.mybank.presentation.model;


import io.swagger.v3.oas.annotations.media.Schema;

public record BonusSpendRequest(
        @Schema(description = "Включение или отключение траты бонусов")
        boolean isSpending
) {
}
