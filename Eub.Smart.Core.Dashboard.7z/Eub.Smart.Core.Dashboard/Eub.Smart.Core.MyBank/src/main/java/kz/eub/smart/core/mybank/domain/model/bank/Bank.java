package kz.eub.smart.core.mybank.domain.model.bank;

import kz.eub.smart.core.mybank.domain.model.OpenProduct;
import kz.eub.smart.core.mybank.domain.model.bonus.BannerBonus;
import kz.eub.smart.core.mybank.domain.model.bonus.Bonus;
import kz.eub.smart.core.mybank.domain.model.card.Card;
import kz.eub.smart.core.mybank.domain.model.credit.Credit;
import kz.eub.smart.core.mybank.domain.model.current_account.Account;
import kz.eub.smart.core.mybank.domain.model.deposit.Deposit;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class Bank {

    List<Card> installmentCards;
    List<Card> cards;
    Bonus bonus;
    List<Deposit> deposits;
    List<Account> accounts;
    List<Credit> credits;
    List<OpenProduct> openProducts;
    BannerBonus bannerBonus;

}
