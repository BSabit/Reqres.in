package kz.eub.smart.core.mybank.domain.model.card;

import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;
import lombok.Data;

import java.util.List;

@Data
public class Card {
    Long id;
    String number;
    String imageUrl;
    String title;
    ProductStatus status;
    List<AdditionalCard> additionalCards;
    List<CardBalance> amount;
    String detailsLink;
}
