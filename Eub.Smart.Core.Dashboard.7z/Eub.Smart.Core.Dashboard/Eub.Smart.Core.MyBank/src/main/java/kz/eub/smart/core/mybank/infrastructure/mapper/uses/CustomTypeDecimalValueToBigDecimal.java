package kz.eub.smart.core.mybank.infrastructure.mapper.uses;

import kz.eubank.grpc.CustomTypes;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Component
public class CustomTypeDecimalValueToBigDecimal {

    public BigDecimal toBigDecimal(CustomTypes.DecimalValue decimalValue) {
        BigDecimal whole = new BigDecimal(decimalValue.getUnits());
        BigDecimal nanos = new BigDecimal(decimalValue.getNanos());
        BigDecimal tenPowMinusNine = new BigDecimal("0.000000001");
        BigDecimal fractional = nanos.multiply(tenPowMinusNine);
        return whole.add(fractional).setScale(2, RoundingMode.DOWN);
    }
}
