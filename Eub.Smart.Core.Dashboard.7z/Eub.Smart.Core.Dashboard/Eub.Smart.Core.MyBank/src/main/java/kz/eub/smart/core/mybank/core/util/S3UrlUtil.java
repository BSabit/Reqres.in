package kz.eub.smart.core.mybank.core.util;

import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import static java.util.Objects.nonNull;


@Component
public class S3UrlUtil {

    @Value("${app.s3-download-address}")
    private String s3Url;
    private final static String S3_QUERY_PARAM = "%s?fileUid=%s";

    @Named("buildImageUrl")
    public String buildImageUrl(String imageUid) {
        return (nonNull(imageUid)) ? String.format(S3_QUERY_PARAM, s3Url, imageUid) : "";
    }
}
