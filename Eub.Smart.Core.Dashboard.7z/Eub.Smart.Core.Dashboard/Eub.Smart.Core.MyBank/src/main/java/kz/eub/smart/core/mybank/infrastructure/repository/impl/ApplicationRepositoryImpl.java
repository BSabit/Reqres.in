package kz.eub.smart.core.mybank.infrastructure.repository.impl;

import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.domain.model.Application;
import kz.eub.smart.core.mybank.domain.repository.ApplicationRepository;
import kz.eub.smart.core.mybank.infrastructure.mapper.ApplicationMapper;
import kz.eub.smart.core.mybank.infrastructure.repository.ApplicationDaoRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@AllArgsConstructor
public class ApplicationRepositoryImpl implements ApplicationRepository {

    private final ApplicationDaoRepository applicationDaoRepository;

    private final ApplicationMapper applicationMapper;

    @Override
    public List<Application> getApplications(Long userId, LangKey language) {
        return applicationMapper.toDomain(applicationDaoRepository.getApplications(userId, language.name()));
    }
}
