package kz.eub.smart.core.mybank.domain.model.bonus;

import lombok.Data;
import java.math.BigDecimal;
@Data
public class BonusBalanceInfo {
    BigDecimal amount;
    Boolean spendIsAllowed;
    String status;
}
