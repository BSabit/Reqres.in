package kz.eub.smart.core.mybank.infrastructure.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

@Entity
@Getter
@Setter
public class ApplicationEntity {

    @Id
    private Long applicationId;
    private String applicationType;
    private String statusTitle;
    private String statusType;
    private String statusLink;
    private String imageUid;
    private String title;
    private String currency;
    private BigDecimal amount;

}
