package kz.eub.smart.core.mybank.domain.model.card;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
public class CardBalance {

    BigDecimal amount;
    String currency;
}
