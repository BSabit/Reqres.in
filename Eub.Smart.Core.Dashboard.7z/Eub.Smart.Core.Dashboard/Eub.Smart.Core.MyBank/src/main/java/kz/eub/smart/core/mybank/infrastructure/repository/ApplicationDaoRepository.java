package kz.eub.smart.core.mybank.infrastructure.repository;

import kz.eub.smart.core.mybank.infrastructure.entity.ApplicationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ApplicationDaoRepository extends JpaRepository<ApplicationEntity, Long> {

    @Query(nativeQuery = true, value = """
                    select
                    	Application.Application_ID      as applicationId,
                    	case
                    		when 'KZ' = :lang then COALESCE(tps.Term_KZ, ps.ProductState_Title)
                    		when 'RU' = :lang then COALESCE(tps.Term_RU, ps.ProductState_Title)
                    		else COALESCE(tps.Term_EN, ps.ProductState_Title)
                    	end                      		as statusTitle,
                    	ps.StatusColor_IDREF     		as statusType,
                    	ps.Link 				 		as statusLink,
                    	ps.Priority				 		as priorityForStatus,
                    	md.FileUid 				 		as imageUid,
                    	case
                    		when 'KZ' = :lang
                    			then
                    			case
                    				when ct.CardType_Title is not null
                    					then COALESCE(ctt.Term_KZ, ct.CardType_Title)
                    				else COALESCE(DigitalCardType.DigitalCardType_Title , psnt.Term_KZ, psn.ProductShortName_Title, actt.Term_KZ, act.AccountType_Title)
                    		end
                    		when 'RU' = :lang
                    			then case
                    					when ct.CardType_Title is not null
                    						then COALESCE(ctt.Term_RU, ct.CardType_Title)
                    						else COALESCE(DigitalCardType.DigitalCardType_Title , psnt.Term_RU, psn.ProductShortName_Title, actt.Term_RU, act.AccountType_Title)
                    				 end
                    		else case
                    				when ct.CardType_Title is not null
                    					then COALESCE(ctt.Term_EN, ct.CardType_Title)
                    				else COALESCE(DigitalCardType.DigitalCardType_Title , psnt.Term_EN, psn.ProductShortName_Title, actt.Term_EN, act.AccountType_Title)
                    			 end
                    	end 							  as title,
                    	Application.ApplicationType_IDREF as applicationType,
                    	COALESCE(cut.Symbol, CurrentAccountProduct.Currency, DepositApplication.Currency, DigitalCardProduct.Currency, '')  as Currency,
                    	case
                    		when Application.ApplicationType_IDREF = 'SAVE'
                    			then DepositApplication.Amount
                    		else 0
                    	end  							  as amount
                    	
                    from Application
                    join ApplicationState on Application.Application_ID = ApplicationState.Application_IDREF
                    left join OpenCardApplication on OpenCardApplication.Application_IDREF = Application.Application_ID
                    left join DigitalCardType on DigitalCardType.DigitalCardType_ID = OpenCardApplication.DigitalCardType_IDREF
                    left join DigitalCardProduct on DigitalCardType.DigitalCardProduct_IDREF = DigitalCardProduct.DigitalCardProduct_ID
                    left join Term as CardTerm on CardTerm.Term_ID = DigitalCardType.Term_OUTREF
                    left join DepositApplication on DepositApplication.Application_IDREF = Application.Application_ID
                    left join DepositProduct dp on dp.DepositProduct_ID = DepositApplication.DepositProduct_IDREF
                    left join CurrentAccountApplication on CurrentAccountApplication.Application_IDREF = Application.Application_ID
                    left join CurrentAccountProduct on CurrentAccountProduct.CurrentAccountProduct_ID = CurrentAccountApplication.CurrentAccountProduct_IDREF
                    left join AccountProduct ap on ap.ProductCompound_OUTREF = CurrentAccountProduct.ProductCompound_OUTREF
                    left join Term as CurrentTerm on CurrentTerm.Term_ID = CurrentAccountProduct.Term_OUTREF
                    left join CardType ct on ct.CardType_ID = DigitalCardType.DigitalCardType_ID
                    left join Term ctt on ctt.Term_ID = ct.Term_OUTREF
                    left join AccountType act on act.AccountType_ID = Application.ApplicationType_IDREF
                    left join Term actt on actt.Term_ID = act.Term_OUTREF
                    left join ProductShortName psn on ap.ProductShortName_IDREF = psn.ProductShortName_ID or dp.ProductShortName_IDREF = psn.ProductShortName_ID
                    left join Term psnt on psnt.Term_ID = psn.Term_OUTREF
                    left join MetaDocument md on md.IsActive = 1 and md.Screen = 'mybank'
                    and md.Target_ID =
                    case	
                                        when
                    ct.Target_ID is not null
                                            then ct.Target_ID
                                        else act.Target_ID
                                    end
                                and md.Target_Table =
                                    case
                                        when ct.Target_ID is not null
                                            then 'CardType'
                                        else 'AccountType'
                                    end
                            join ProductState ps ON ps.ProductType_IDREF = Application.ApplicationType_IDREF AND ps.isApplication = 1
                                AND ps.ProductStateCode = (CASE
                                    WHEN ApplicationState.AppTechStatus_IDREF in ('NEWW', 'PICK') THEN 'application_in_progress'
                                    WHEN ApplicationState.AppTechStatus_IDREF = 'RJCT' THEN 'application_rejected'
                                    WHEN ApplicationState.AppTechStatus_IDREF = '' THEN 'application_refused'
                                    ELSE 'null'
                                END)
                    LEFT JOIN Term tps ON tps.Term_ID = ps.Term_OUTREF
                            left
                    join CurrencyType cut on cut.Currency_Code = CurrentAccountProduct.Currency or cut.Currency_Code = DepositApplication.Currency or cut.Currency_Code = DigitalCardProduct.Currency
                            Where
                                ApplicationType_IDREF in ( 'CARD', 'SAVE', 'CURR' )
                                and ApplicationState.AppTechStatus_IDREF in ('PICK', 'NEWW', 'RJCT' )
                                and Application.User_IDREF = :userId		
                    """)
    List<ApplicationEntity> getApplications(@Param("userId") Long userId, @Param("lang") String language);

}
