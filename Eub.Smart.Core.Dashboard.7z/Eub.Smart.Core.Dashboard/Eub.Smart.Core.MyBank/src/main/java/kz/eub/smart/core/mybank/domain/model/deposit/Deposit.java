package kz.eub.smart.core.mybank.domain.model.deposit;

import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;
import lombok.Data;
import java.math.BigDecimal;
@Data
public class Deposit {
    Long id;
    BigDecimal amount;
    String currency;
    String imageUrl;
    String title;
    ProductStatus status;
    String detailsLink;
}
