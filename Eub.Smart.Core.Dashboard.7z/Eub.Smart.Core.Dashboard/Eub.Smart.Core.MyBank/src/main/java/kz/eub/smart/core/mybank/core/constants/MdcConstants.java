package kz.eub.smart.core.mybank.core.constants;

public interface MdcConstants {

    String X_FORWARDED_FOR = "X-Forwarded-For";
}
