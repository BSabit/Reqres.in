package kz.eub.smart.core.mybank.domain.mapper;

import kz.eub.smart.core.mybank.domain.model.Application;
import kz.eub.smart.core.mybank.domain.model.current_account.Account;
import kz.eub.smart.core.mybank.domain.model.current_account.ProductStatus;

public class AccountApplicationMapper {

    public static Account toAccount(Application application, String detailsLink) {
        Account account = new Account();
        account.setId(application.getApplicationId());
        account.setTitle(application.getTitle());
        account.setAmount(application.getAmount());
        account.setCurrency(application.getCurrency());
        account.setStatus(new ProductStatus(application.getStatusType(), application.getStatusTitle(), application.getStatusLink()));
        account.setImageUrl(application.getImageUrl());
        account.setDetailsLink(detailsLink);
        return account;
    }

}
