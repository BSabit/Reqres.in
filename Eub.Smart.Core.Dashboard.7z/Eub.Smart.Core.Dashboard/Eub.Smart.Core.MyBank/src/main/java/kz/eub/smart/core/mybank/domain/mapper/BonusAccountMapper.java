package kz.eub.smart.core.mybank.domain.mapper;


import kz.eub.smart.core.mybank.domain.model.AccountCard;
import kz.eub.smart.core.mybank.domain.model.bonus.Bonus;
import kz.eub.smart.core.mybank.domain.model.bonus.BonusBalanceInfo;

public class BonusAccountMapper {

    public static Bonus getBonusAccount(AccountCard accountCard, BonusBalanceInfo bonusBalanceInfo, String detailsLink) {
        Bonus bonus = new Bonus();
        bonus.setAmount(bonusBalanceInfo.getAmount());
        bonus.setEnabled(bonusBalanceInfo.getSpendIsAllowed());
        bonus.setImageUrl(accountCard.getImageUrl());
        bonus.setDetailsLink(detailsLink);
        return bonus;
    }
}
