package kz.eub.smart.core.mybank.core.constants;

public class LocalizationConstants {

    public static final String RU = "RU";
    public static final String KZ = "KZ";
    public static final String EN = "EN";

    public static final String CARD_DELIVERY_TIME = "card.delivery.time";
}
