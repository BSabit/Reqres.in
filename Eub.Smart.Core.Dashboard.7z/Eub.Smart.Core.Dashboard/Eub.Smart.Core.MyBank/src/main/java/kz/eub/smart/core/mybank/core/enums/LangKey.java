package kz.eub.smart.core.mybank.core.enums;

public enum LangKey {
    ru,
    kk,
    en
}
