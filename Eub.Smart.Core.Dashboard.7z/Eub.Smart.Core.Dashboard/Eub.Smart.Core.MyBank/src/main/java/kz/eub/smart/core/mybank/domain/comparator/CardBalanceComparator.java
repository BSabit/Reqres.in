package kz.eub.smart.core.mybank.domain.comparator;

import kz.eub.smart.core.mybank.domain.model.card.CardBalance;
import kz.eub.smart.core.mybank.core.constants.CurrencyPriority;
import lombok.AllArgsConstructor;

import java.util.Comparator;

@AllArgsConstructor
public class CardBalanceComparator implements Comparator<CardBalance> {

    @Override
    public int compare(CardBalance o1, CardBalance o2) {
        var currencies = CurrencyPriority.currencies;
        int index1 = currencies.indexOf(o1.getCurrency());
        int index2 = currencies.indexOf(o2.getCurrency());

        return Integer.compare(index1, index2);
    }
}