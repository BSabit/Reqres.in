package kz.eub.smart.core.mybank.core.constants;

public interface HeaderName {

    String CORRELATION_ID = "X-Correlation-Id";
    String FRONT_END_ID = "Front-End-Id";
    String LANG_KEY = "Accept-Language";
}
