package kz.eub.smart.core.mybank.domain.mapper;


import kz.eub.smart.core.mybank.domain.model.AccountBalance;
import kz.eub.smart.core.mybank.domain.model.Application;
import kz.eub.smart.core.mybank.domain.model.card.CardBalance;

import java.util.ArrayList;
import java.util.List;

public class CardBalanceMapper {

    public static CardBalance getCardBalance(AccountBalance accountBalance){
        return new CardBalance(accountBalance.getBalance(),accountBalance.getCurrency());
    }

    public static List<CardBalance> toCardBalance(Application application){
        List<CardBalance> balance = new ArrayList<>(1);
        CardBalance cardBalance = new CardBalance(application.getAmount(), application.getCurrency());
        balance.add(cardBalance);
        return balance;
    }

}
