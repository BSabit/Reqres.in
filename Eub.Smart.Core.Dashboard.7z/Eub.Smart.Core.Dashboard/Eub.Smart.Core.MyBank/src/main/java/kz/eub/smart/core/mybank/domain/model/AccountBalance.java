package kz.eub.smart.core.mybank.domain.model;


import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class AccountBalance {

    private Long accountOutref;
    private BigDecimal balance;
    private String currency;

}
