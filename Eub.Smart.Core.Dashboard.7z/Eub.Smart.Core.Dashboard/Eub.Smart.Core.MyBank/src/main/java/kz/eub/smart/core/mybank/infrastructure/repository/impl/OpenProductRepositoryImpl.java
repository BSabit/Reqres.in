package kz.eub.smart.core.mybank.infrastructure.repository.impl;

import kz.eub.smart.core.mybank.core.enums.LangKey;
import kz.eub.smart.core.mybank.domain.model.OpenProduct;
import kz.eub.smart.core.mybank.domain.repository.OpenProductRepository;
import kz.eub.smart.core.mybank.infrastructure.mapper.OpenProductMapper;
import kz.eub.smart.core.mybank.infrastructure.repository.OpenProductDaoRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@AllArgsConstructor
public class OpenProductRepositoryImpl implements OpenProductRepository {

    private final OpenProductDaoRepository openProductDaoRepository;
    private final OpenProductMapper openProductMapper;

    @Override
    public List<OpenProduct> getAll(LangKey langKey) {
        return openProductMapper.toDomain(openProductDaoRepository.getOpenProducts(langKey.name()));
    }
}
