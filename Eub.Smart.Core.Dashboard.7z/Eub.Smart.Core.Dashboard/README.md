### Описание проекта
Dashboard - сервисы главного экрана Smart Bank-а:
- Карточные счета
- Текущие счета
- Депозиты
- Бонусы
- Категории бонусов
- Настройки бонусов
- Получение обрабатываемых(PROC) доставок карт по пользователю
- Получение временных цифровых карт по пользователю
- Курс валют
- Список кредитов
- Заявки по кредиту
- Получение зарплатного листка по пользователю.

### Информация по K8s деплою (DevOps):
- project_name: **smart-core-dashboard**
- namespace: **smart-core**
- image: **kzlk8simstor01.eub.kz/k8s-smart-dashboard-core/k8s-smart-dashboard-core**
- dns: **smart-core-dashboard.devk8s.eub.kz**
- port: **8080**
- limits: **cpu: 500m, memory: 500Mi**
- requests: **cpu: 200m, memory: 200Mi**
- labels: **[app: "smart-core-dashboard", domain: "core"]**
- autoscale **on** replicas min 1, max 3 (cpu, memory threshold 80%)

### Инструкция для начала работы:
- Восстановление пакетов: `mvn package`
- Компиляция: `mvn compile`
- Адрес тестовой среды проекта: 
    - service name: smart-core-dashboard.smart-core:8080
    - node port: 
    - dns: 
- Адрес gRpcUI/Swagger: 
  <br/> https://smart-generic-swaggercentral.devk8s.eub.kz/swagger-ui/index.html?urls.primaryName=dashboard
- Инструкция для запуска исходного кода: `mvn install`
- Dashboard K8s: 
  <br/> https://dashboard.devk8s.eub.kz/#/service/smart-core/smart-core-dashboard?namespace=smart-core
- ELK: 
  <br/> http://172.25.43.147/s/smartbank/app/discover 
  <br> !!!NOTE: Необходимо выбрать smart-core.smart-core-dashboard
- Docker Image Repo: https://nexus-dev.eub.kz/#browse/browse:docker-registry:v2%2Frepository%2Fsmart-core%2Fsmart-core-dashboard
- Nexus: 
  <br> https://nexus-dev.eub.kz 
  <br> !!!NOTE: Все необходимые библиотеки скачивать с Nexus-а

### Инструкция для тестирования:
- Алгоритм тестирования адаптера в программе Postman и / или прочих:
- Виды тестов, которые можно произвести над проектом:

### Статус сборки: 
Сборка в пилотном тестировании

### Установка дополнительного ПО
https://www.jetbrains.com/idea/download/ (Ultimate)

### Связи и обращения
- api-gateway:
    - dev: smart-generic-apigateway.devk8s.eub.kz
    - prod: smart-generic-apigateway.eub.kz
- mssql:
    - dev: 172.25.43.31:1433
    - prod: kzwsqlsmart.eub.kz:1433
- aggregator:
    - dev: aggregator-core-dashboard.nebl-core:10500
    - prod: aggregator-core-dashboard.nebl-core: 10500

![Logic schema](/logic-schema/dashboard.png)