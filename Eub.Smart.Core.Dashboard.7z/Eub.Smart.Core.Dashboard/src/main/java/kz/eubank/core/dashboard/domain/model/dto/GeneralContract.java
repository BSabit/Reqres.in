package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
public class GeneralContract extends Contract implements Serializable {

	private static final long serialVersionUID = 3213589868703278109L;

	private String accountNumber;
    private Date dateOpened;
    private Date dateClosed;
    private String type;
    private String status;
}
