package kz.eubank.core.dashboard.domain.model.dto

data class SettlementOperationName(
    var fullName: String? = null,
    var shortName: String? = null
)