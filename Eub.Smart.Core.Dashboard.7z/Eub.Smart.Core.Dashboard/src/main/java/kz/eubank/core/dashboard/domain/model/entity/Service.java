package kz.eubank.core.dashboard.domain.model.entity;

import kz.eubank.core.dashboard.domain.model.entity.core.Operation;
import kz.eubank.core.dashboard.domain.model.entity.core.Region;
import kz.eubank.core.dashboard.domain.model.entity.core.Term;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "Service")
public class Service {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Service_ID")
    private Long id;

    @Column(name = "Service_Title")
    private String title;

    @OneToOne
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;

    @OneToOne
    @JoinColumn(name = "Provider_IDREF")
    private Provider provider;

    @OneToOne
    @JoinColumn(name = "ServiceType_IDREF")
    private ServiceType serviceType;

    @Column(name = "Service_Desc")
    private String serviceDesc;

    @Column(name = "ShortName")
    private String shortName;

    @Column(name = "ProviderCode")
    private String providerCode;

    @OneToOne
    @JoinColumn(name = "Operation_IDREF")
    private Operation operation;

    @OneToOne
    @JoinColumn(name = "ServiceStatus_IDREF")
    private ServiseStatus status;

    @Column(name = "KNP_IDREF")
    private String knp;

    @Column(name = "KNP_Text")
    private String knpText;

    @OneToMany
    @JoinTable(name = "map_Service_Region",
            joinColumns = @JoinColumn(name = "Service_IDREF"),
            inverseJoinColumns = @JoinColumn(name = "Region_IDREF"))
    private List<Region> regions;

    @Column(name = "LogoPath")
    private String logoPath;

    @Column(name = "Priority")
    private int priority;

    @Column(name = "AllowTemplate")
    private boolean allowTemplate;

    @Column(name = "AllowStandingOrder")
    private boolean allowStandingOrder;

    @OneToOne
    @JoinColumn(name = "ServiceFormType_IDREF")
    private ServiceFormType formType;

    @Column(name = "Synonyms")
    private String synonyms;

    public ServiceFormType getFormType() {
        return formType;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Term getTerms() {
        return terms;
    }

    public void setTerms(Term terms) {
        this.terms = terms;
    }

    public Provider getProvider() {
        return provider;
    }

    public void setProvider(Provider provider) {
        this.provider = provider;
    }

    public ServiceType getServiceType() {
        return serviceType;
    }

    public void setServiceType(ServiceType serviceType) {
        this.serviceType = serviceType;
    }

    public String getServiceDesc() {
        return serviceDesc;
    }

    public void setServiceDesc(String serviceDesc) {
        this.serviceDesc = serviceDesc;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public String getProviderCode() {
        return providerCode;
    }

    public void setProviderCode(String providerCode) {
        this.providerCode = providerCode;
    }

    public Operation getOperation() {
        return operation;
    }

    public void setOperation(Operation operation) {
        this.operation = operation;
    }

    public ServiseStatus getStatus() {
        return status;
    }

    public void setStatus(ServiseStatus status) {
        this.status = status;
    }

    public List<Region> getRegions() {
        return regions;
    }

    public void setRegion(List<Region> regions) {
        this.regions = regions;
    }

    public String getLogoPath() {
        return logoPath;
    }

    public void setLogoPath(String logoPath) {
        this.logoPath = logoPath;
    }

    public String getKnp() {
        return knp;
    }

    public String getKnpText() {
        return knpText;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public boolean isAllowTemplate() {
        return allowTemplate;
    }

    public boolean isAllowStandingOrder() {
        return allowStandingOrder;
    }

    public String getSynonyms() {
        return synonyms;
    }
}
