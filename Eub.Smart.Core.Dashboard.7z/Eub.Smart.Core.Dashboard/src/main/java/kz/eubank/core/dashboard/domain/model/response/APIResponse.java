package kz.eubank.core.dashboard.domain.model.response;

import kz.eubank.core.dashboard.infrastructure.exception.ServiceException;
import lombok.Generated;
import lombok.Getter;
import lombok.Setter;

import java.util.Map;

@Setter
@Getter
public class APIResponse<T> {

    public static Integer FORM_ERRORS;
    public static Integer SUCCESS;
    public static Integer FAILURE;
    public static Integer NOT_IMPLEMENTED;
    public static Integer ACCESS_DENIED;

    private T body;
    private Integer code;
    private String errorMessage;
    private Integer errorCode;
    private Map<String, Validator.Validation> formErrors;
    private String bodyType;

    public APIResponse(final Integer code) {
        this.code = code;
        this.bodyType = null;
    }

    public APIResponse(final Integer code, final String errorMessage) {
        this.code = code;
        this.errorMessage = errorMessage;
        this.bodyType = "ErrorMessage";
    }

    public APIResponse(final ServiceException e, final Integer code) {
        this.code = code;
        this.errorMessage = e.getMessage();
        this.bodyType = "ServiceException";
    }

    public APIResponse(final Map<String, Validator.Validation> formErrors) {
        this(APIResponse.FORM_ERRORS);
        this.formErrors = formErrors;
        this.bodyType = "FormError";
    }

    public APIResponse(final T body) {
        if (body.getClass().isAssignableFrom(ServiceException.class)) {
            final ServiceException ex = (ServiceException) body;
            this.code = APIResponse.FAILURE;
            this.errorMessage = ex.getMessage();
            this.errorCode = ex.getCode();
            if (this.errorCode != null && this.errorCode == 0) {
                this.errorCode = null;
            }
            this.body = null;
        } else {
            this.code = APIResponse.SUCCESS;
            this.body = body;
        }
        this.bodyType = body.getClass().getSimpleName();
    }

    public boolean isSuccess() {
        return this.code.equals(APIResponse.SUCCESS);
    }

    public APIResponse(final Class<T> clazz) {
        this.body = null;
        this.code = APIResponse.SUCCESS;
        this.bodyType = clazz.getSimpleName();
    }

    @Generated
    @Override
    public String toString() {
        return "APIResponse(body=" + this.getBody() + ", code=" + this.getCode() + ", errorMessage="
                + this.getErrorMessage() + ", errorCode=" + this.getErrorCode() + ", formErrors="
                + this.getFormErrors() + ", bodyType=" + this.getBodyType() + ")";
    }

    static {
        APIResponse.FORM_ERRORS = 0;
        APIResponse.SUCCESS = 1;
        APIResponse.FAILURE = 2;
        APIResponse.NOT_IMPLEMENTED = 3;
        APIResponse.ACCESS_DENIED = 4;
    }
}
