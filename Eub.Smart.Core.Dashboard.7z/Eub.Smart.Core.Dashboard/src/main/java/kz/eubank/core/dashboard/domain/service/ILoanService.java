package kz.eubank.core.dashboard.domain.service;

import kz.eubank.core.dashboard.domain.model.response.AccountList;
import kz.eubank.core.dashboard.domain.model.response.LoanApplicationList;

import java.util.Date;

public interface ILoanService {

    AccountList getListCredits();

    LoanApplicationList getRequestsList(Date dateFrom, Date dateTo, int page, int pageSize, String language);
}
