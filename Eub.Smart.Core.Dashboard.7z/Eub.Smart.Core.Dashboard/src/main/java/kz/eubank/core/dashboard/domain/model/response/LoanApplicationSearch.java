// 
// Decompiled by Procyon v0.5.36
// 

package kz.eubank.core.dashboard.domain.model.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Generated;

import java.util.Date;

public class LoanApplicationSearch
{
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date dateFrom;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date dateTo;
    
    @Generated
    public LoanApplicationSearch() {
    }
    
    @Generated
    public Date getDateFrom() {
        return this.dateFrom;
    }
    
    @Generated
    public Date getDateTo() {
        return this.dateTo;
    }
    
    @Generated
    public void setDateFrom(final Date dateFrom) {
        this.dateFrom = dateFrom;
    }
    
    @Generated
    public void setDateTo(final Date dateTo) {
        this.dateTo = dateTo;
    }
    
    @Generated
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof LoanApplicationSearch)) {
            return false;
        }
        final LoanApplicationSearch other = (LoanApplicationSearch)o;
        if (!other.canEqual(this)) {
            return false;
        }
        final Object this$dateFrom = this.getDateFrom();
        final Object other$dateFrom = other.getDateFrom();
        Label_0065: {
            if (this$dateFrom == null) {
                if (other$dateFrom == null) {
                    break Label_0065;
                }
            }
            else if (this$dateFrom.equals(other$dateFrom)) {
                break Label_0065;
            }
            return false;
        }
        final Object this$dateTo = this.getDateTo();
        final Object other$dateTo = other.getDateTo();
        if (this$dateTo == null) {
            return other$dateTo == null;
        }
        else return this$dateTo.equals(other$dateTo);
    }
    
    @Generated
    protected boolean canEqual(final Object other) {
        return other instanceof LoanApplicationSearch;
    }
    
    @Generated
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $dateFrom = this.getDateFrom();
        result = result * 59 + (($dateFrom == null) ? 43 : $dateFrom.hashCode());
        final Object $dateTo = this.getDateTo();
        result = result * 59 + (($dateTo == null) ? 43 : $dateTo.hashCode());
        return result;
    }
    
    @Generated
    @Override
    public String toString() {
        return "LoanApplicationSearch(dateFrom=" + this.getDateFrom() + ", dateTo=" + this.getDateTo() + ")";
    }
}
