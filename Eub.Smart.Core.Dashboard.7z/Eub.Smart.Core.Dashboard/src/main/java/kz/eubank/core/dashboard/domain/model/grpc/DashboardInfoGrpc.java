package kz.eubank.core.dashboard.domain.model.grpc;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.15.0)",
    comments = "Source: Eub.Aggregator.Core.Dashboard.proto")
public final class DashboardInfoGrpc {

  private DashboardInfoGrpc() {}

  public static final String SERVICE_NAME = "DashboardInfo.V1.DashboardInfo";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsRequest,
      kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsReply> getGetAggregateAccountsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetAggregateAccounts",
      requestType = kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsRequest.class,
      responseType = kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsRequest,
      kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsReply> getGetAggregateAccountsMethod() {
    io.grpc.MethodDescriptor<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsRequest, kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsReply> getGetAggregateAccountsMethod;
    if ((getGetAggregateAccountsMethod = DashboardInfoGrpc.getGetAggregateAccountsMethod) == null) {
      synchronized (DashboardInfoGrpc.class) {
        if ((getGetAggregateAccountsMethod = DashboardInfoGrpc.getGetAggregateAccountsMethod) == null) {
          DashboardInfoGrpc.getGetAggregateAccountsMethod = getGetAggregateAccountsMethod = 
              io.grpc.MethodDescriptor.<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsRequest, kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "DashboardInfo.V1.DashboardInfo", "GetAggregateAccounts"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsReply.getDefaultInstance()))
                  .setSchemaDescriptor(new DashboardInfoMethodDescriptorSupplier("GetAggregateAccounts"))
                  .build();
          }
        }
     }
     return getGetAggregateAccountsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesRequest,
      kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesReply> getGetCurrencyRatesListMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetCurrencyRatesList",
      requestType = kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesRequest.class,
      responseType = kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesRequest,
      kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesReply> getGetCurrencyRatesListMethod() {
    io.grpc.MethodDescriptor<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesRequest, kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesReply> getGetCurrencyRatesListMethod;
    if ((getGetCurrencyRatesListMethod = DashboardInfoGrpc.getGetCurrencyRatesListMethod) == null) {
      synchronized (DashboardInfoGrpc.class) {
        if ((getGetCurrencyRatesListMethod = DashboardInfoGrpc.getGetCurrencyRatesListMethod) == null) {
          DashboardInfoGrpc.getGetCurrencyRatesListMethod = getGetCurrencyRatesListMethod = 
              io.grpc.MethodDescriptor.<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesRequest, kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "DashboardInfo.V1.DashboardInfo", "GetCurrencyRatesList"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesReply.getDefaultInstance()))
                  .setSchemaDescriptor(new DashboardInfoMethodDescriptorSupplier("GetCurrencyRatesList"))
                  .build();
          }
        }
     }
     return getGetCurrencyRatesListMethod;
  }

  private static volatile io.grpc.MethodDescriptor<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListRequest,
      kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListReply> getGetBonusBalanceListMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetBonusBalanceList",
      requestType = kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListRequest.class,
      responseType = kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListRequest,
      kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListReply> getGetBonusBalanceListMethod() {
    io.grpc.MethodDescriptor<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListRequest, kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListReply> getGetBonusBalanceListMethod;
    if ((getGetBonusBalanceListMethod = DashboardInfoGrpc.getGetBonusBalanceListMethod) == null) {
      synchronized (DashboardInfoGrpc.class) {
        if ((getGetBonusBalanceListMethod = DashboardInfoGrpc.getGetBonusBalanceListMethod) == null) {
          DashboardInfoGrpc.getGetBonusBalanceListMethod = getGetBonusBalanceListMethod = 
              io.grpc.MethodDescriptor.<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListRequest, kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "DashboardInfo.V1.DashboardInfo", "GetBonusBalanceList"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListReply.getDefaultInstance()))
                  .setSchemaDescriptor(new DashboardInfoMethodDescriptorSupplier("GetBonusBalanceList"))
                  .build();
          }
        }
     }
     return getGetBonusBalanceListMethod;
  }

  private static volatile io.grpc.MethodDescriptor<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsRequest,
      kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsReply> getGetReservedAmountsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetReservedAmounts",
      requestType = kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsRequest.class,
      responseType = kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsRequest,
      kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsReply> getGetReservedAmountsMethod() {
    io.grpc.MethodDescriptor<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsRequest, kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsReply> getGetReservedAmountsMethod;
    if ((getGetReservedAmountsMethod = DashboardInfoGrpc.getGetReservedAmountsMethod) == null) {
      synchronized (DashboardInfoGrpc.class) {
        if ((getGetReservedAmountsMethod = DashboardInfoGrpc.getGetReservedAmountsMethod) == null) {
          DashboardInfoGrpc.getGetReservedAmountsMethod = getGetReservedAmountsMethod = 
              io.grpc.MethodDescriptor.<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsRequest, kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "DashboardInfo.V1.DashboardInfo", "GetReservedAmounts"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsReply.getDefaultInstance()))
                  .setSchemaDescriptor(new DashboardInfoMethodDescriptorSupplier("GetReservedAmounts"))
                  .build();
          }
        }
     }
     return getGetReservedAmountsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListRequest,
      kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListReply> getGetLoanListMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetLoanList",
      requestType = kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListRequest.class,
      responseType = kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListRequest,
      kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListReply> getGetLoanListMethod() {
    io.grpc.MethodDescriptor<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListRequest, kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListReply> getGetLoanListMethod;
    if ((getGetLoanListMethod = DashboardInfoGrpc.getGetLoanListMethod) == null) {
      synchronized (DashboardInfoGrpc.class) {
        if ((getGetLoanListMethod = DashboardInfoGrpc.getGetLoanListMethod) == null) {
          DashboardInfoGrpc.getGetLoanListMethod = getGetLoanListMethod = 
              io.grpc.MethodDescriptor.<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListRequest, kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "DashboardInfo.V1.DashboardInfo", "GetLoanList"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListReply.getDefaultInstance()))
                  .setSchemaDescriptor(new DashboardInfoMethodDescriptorSupplier("GetLoanList"))
                  .build();
          }
        }
     }
     return getGetLoanListMethod;
  }

  private static volatile io.grpc.MethodDescriptor<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusRequest,
      kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusReply> getGetInternetTransactionStatusMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetInternetTransactionStatus",
      requestType = kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusRequest.class,
      responseType = kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusRequest,
      kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusReply> getGetInternetTransactionStatusMethod() {
    io.grpc.MethodDescriptor<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusRequest, kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusReply> getGetInternetTransactionStatusMethod;
    if ((getGetInternetTransactionStatusMethod = DashboardInfoGrpc.getGetInternetTransactionStatusMethod) == null) {
      synchronized (DashboardInfoGrpc.class) {
        if ((getGetInternetTransactionStatusMethod = DashboardInfoGrpc.getGetInternetTransactionStatusMethod) == null) {
          DashboardInfoGrpc.getGetInternetTransactionStatusMethod = getGetInternetTransactionStatusMethod = 
              io.grpc.MethodDescriptor.<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusRequest, kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "DashboardInfo.V1.DashboardInfo", "GetInternetTransactionStatus"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusReply.getDefaultInstance()))
                  .setSchemaDescriptor(new DashboardInfoMethodDescriptorSupplier("GetInternetTransactionStatus"))
                  .build();
          }
        }
     }
     return getGetInternetTransactionStatusMethod;
  }

  private static volatile io.grpc.MethodDescriptor<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierRequest,
      kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierReply> getGetClassifierMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetClassifier",
      requestType = kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierRequest.class,
      responseType = kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierRequest,
      kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierReply> getGetClassifierMethod() {
    io.grpc.MethodDescriptor<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierRequest, kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierReply> getGetClassifierMethod;
    if ((getGetClassifierMethod = DashboardInfoGrpc.getGetClassifierMethod) == null) {
      synchronized (DashboardInfoGrpc.class) {
        if ((getGetClassifierMethod = DashboardInfoGrpc.getGetClassifierMethod) == null) {
          DashboardInfoGrpc.getGetClassifierMethod = getGetClassifierMethod = 
              io.grpc.MethodDescriptor.<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierRequest, kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "DashboardInfo.V1.DashboardInfo", "GetClassifier"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierReply.getDefaultInstance()))
                  .setSchemaDescriptor(new DashboardInfoMethodDescriptorSupplier("GetClassifier"))
                  .build();
          }
        }
     }
     return getGetClassifierMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static DashboardInfoStub newStub(io.grpc.Channel channel) {
    return new DashboardInfoStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static DashboardInfoBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new DashboardInfoBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static DashboardInfoFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new DashboardInfoFutureStub(channel);
  }

  /**
   */
  public static abstract class DashboardInfoImplBase implements io.grpc.BindableService {

    /**
     */
    public void getAggregateAccounts(kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsRequest request,
        io.grpc.stub.StreamObserver<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsReply> responseObserver) {
      asyncUnimplementedUnaryCall(getGetAggregateAccountsMethod(), responseObserver);
    }

    /**
     */
    public void getCurrencyRatesList(kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesRequest request,
        io.grpc.stub.StreamObserver<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesReply> responseObserver) {
      asyncUnimplementedUnaryCall(getGetCurrencyRatesListMethod(), responseObserver);
    }

    /**
     */
    public void getBonusBalanceList(kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListRequest request,
        io.grpc.stub.StreamObserver<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListReply> responseObserver) {
      asyncUnimplementedUnaryCall(getGetBonusBalanceListMethod(), responseObserver);
    }

    /**
     */
    public void getReservedAmounts(kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsRequest request,
        io.grpc.stub.StreamObserver<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsReply> responseObserver) {
      asyncUnimplementedUnaryCall(getGetReservedAmountsMethod(), responseObserver);
    }

    /**
     */
    public void getLoanList(kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListRequest request,
        io.grpc.stub.StreamObserver<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListReply> responseObserver) {
      asyncUnimplementedUnaryCall(getGetLoanListMethod(), responseObserver);
    }

    /**
     */
    public void getInternetTransactionStatus(kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusRequest request,
        io.grpc.stub.StreamObserver<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusReply> responseObserver) {
      asyncUnimplementedUnaryCall(getGetInternetTransactionStatusMethod(), responseObserver);
    }

    /**
     */
    public void getClassifier(kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierRequest request,
        io.grpc.stub.StreamObserver<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierReply> responseObserver) {
      asyncUnimplementedUnaryCall(getGetClassifierMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getGetAggregateAccountsMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsRequest,
                kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsReply>(
                  this, METHODID_GET_AGGREGATE_ACCOUNTS)))
          .addMethod(
            getGetCurrencyRatesListMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesRequest,
                kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesReply>(
                  this, METHODID_GET_CURRENCY_RATES_LIST)))
          .addMethod(
            getGetBonusBalanceListMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListRequest,
                kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListReply>(
                  this, METHODID_GET_BONUS_BALANCE_LIST)))
          .addMethod(
            getGetReservedAmountsMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsRequest,
                kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsReply>(
                  this, METHODID_GET_RESERVED_AMOUNTS)))
          .addMethod(
            getGetLoanListMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListRequest,
                kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListReply>(
                  this, METHODID_GET_LOAN_LIST)))
          .addMethod(
            getGetInternetTransactionStatusMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusRequest,
                kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusReply>(
                  this, METHODID_GET_INTERNET_TRANSACTION_STATUS)))
          .addMethod(
            getGetClassifierMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierRequest,
                kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierReply>(
                  this, METHODID_GET_CLASSIFIER)))
          .build();
    }
  }

  /**
   */
  public static final class DashboardInfoStub extends io.grpc.stub.AbstractStub<DashboardInfoStub> {
    private DashboardInfoStub(io.grpc.Channel channel) {
      super(channel);
    }

    private DashboardInfoStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected DashboardInfoStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new DashboardInfoStub(channel, callOptions);
    }

    /**
     */
    public void getAggregateAccounts(kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsRequest request,
        io.grpc.stub.StreamObserver<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getGetAggregateAccountsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getCurrencyRatesList(kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesRequest request,
        io.grpc.stub.StreamObserver<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getGetCurrencyRatesListMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getBonusBalanceList(kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListRequest request,
        io.grpc.stub.StreamObserver<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getGetBonusBalanceListMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getReservedAmounts(kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsRequest request,
        io.grpc.stub.StreamObserver<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getGetReservedAmountsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getLoanList(kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListRequest request,
        io.grpc.stub.StreamObserver<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getGetLoanListMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getInternetTransactionStatus(kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusRequest request,
        io.grpc.stub.StreamObserver<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getGetInternetTransactionStatusMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getClassifier(kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierRequest request,
        io.grpc.stub.StreamObserver<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getGetClassifierMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   */
  public static final class DashboardInfoBlockingStub extends io.grpc.stub.AbstractStub<DashboardInfoBlockingStub> {
    private DashboardInfoBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private DashboardInfoBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected DashboardInfoBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new DashboardInfoBlockingStub(channel, callOptions);
    }

    /**
     */
    public kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsReply getAggregateAccounts(kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsRequest request) {
      return blockingUnaryCall(
          getChannel(), getGetAggregateAccountsMethod(), getCallOptions(), request);
    }

    /**
     */
    public kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesReply getCurrencyRatesList(kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesRequest request) {
      return blockingUnaryCall(
          getChannel(), getGetCurrencyRatesListMethod(), getCallOptions(), request);
    }

    /**
     */
    public kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListReply getBonusBalanceList(kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListRequest request) {
      return blockingUnaryCall(
          getChannel(), getGetBonusBalanceListMethod(), getCallOptions(), request);
    }

    /**
     */
    public kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsReply getReservedAmounts(kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsRequest request) {
      return blockingUnaryCall(
          getChannel(), getGetReservedAmountsMethod(), getCallOptions(), request);
    }

    /**
     */
    public kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListReply getLoanList(kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListRequest request) {
      return blockingUnaryCall(
          getChannel(), getGetLoanListMethod(), getCallOptions(), request);
    }

    /**
     */
    public kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusReply getInternetTransactionStatus(kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusRequest request) {
      return blockingUnaryCall(
          getChannel(), getGetInternetTransactionStatusMethod(), getCallOptions(), request);
    }

    /**
     */
    public kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierReply getClassifier(kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierRequest request) {
      return blockingUnaryCall(
          getChannel(), getGetClassifierMethod(), getCallOptions(), request);
    }
  }

  /**
   */
  public static final class DashboardInfoFutureStub extends io.grpc.stub.AbstractStub<DashboardInfoFutureStub> {
    private DashboardInfoFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private DashboardInfoFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected DashboardInfoFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new DashboardInfoFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsReply> getAggregateAccounts(
        kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getGetAggregateAccountsMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesReply> getCurrencyRatesList(
        kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getGetCurrencyRatesListMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListReply> getBonusBalanceList(
        kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getGetBonusBalanceListMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsReply> getReservedAmounts(
        kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getGetReservedAmountsMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListReply> getLoanList(
        kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getGetLoanListMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusReply> getInternetTransactionStatus(
        kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getGetInternetTransactionStatusMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierReply> getClassifier(
        kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getGetClassifierMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_GET_AGGREGATE_ACCOUNTS = 0;
  private static final int METHODID_GET_CURRENCY_RATES_LIST = 1;
  private static final int METHODID_GET_BONUS_BALANCE_LIST = 2;
  private static final int METHODID_GET_RESERVED_AMOUNTS = 3;
  private static final int METHODID_GET_LOAN_LIST = 4;
  private static final int METHODID_GET_INTERNET_TRANSACTION_STATUS = 5;
  private static final int METHODID_GET_CLASSIFIER = 6;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final DashboardInfoImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(DashboardInfoImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_GET_AGGREGATE_ACCOUNTS:
          serviceImpl.getAggregateAccounts((kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsRequest) request,
              (io.grpc.stub.StreamObserver<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.AggregateAccountsReply>) responseObserver);
          break;
        case METHODID_GET_CURRENCY_RATES_LIST:
          serviceImpl.getCurrencyRatesList((kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesRequest) request,
              (io.grpc.stub.StreamObserver<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.ListCurrencyRatesReply>) responseObserver);
          break;
        case METHODID_GET_BONUS_BALANCE_LIST:
          serviceImpl.getBonusBalanceList((kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListRequest) request,
              (io.grpc.stub.StreamObserver<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BonusBalanceListReply>) responseObserver);
          break;
        case METHODID_GET_RESERVED_AMOUNTS:
          serviceImpl.getReservedAmounts((kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsRequest) request,
              (io.grpc.stub.StreamObserver<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetReservedAmountsReply>) responseObserver);
          break;
        case METHODID_GET_LOAN_LIST:
          serviceImpl.getLoanList((kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListRequest) request,
              (io.grpc.stub.StreamObserver<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetLoanListReply>) responseObserver);
          break;
        case METHODID_GET_INTERNET_TRANSACTION_STATUS:
          serviceImpl.getInternetTransactionStatus((kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusRequest) request,
              (io.grpc.stub.StreamObserver<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.GetInternetTransactionStatusReply>) responseObserver);
          break;
        case METHODID_GET_CLASSIFIER:
          serviceImpl.getClassifier((kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierRequest) request,
              (io.grpc.stub.StreamObserver<kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.SolarGetClassifierReply>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class DashboardInfoBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    DashboardInfoBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("DashboardInfo");
    }
  }

  private static final class DashboardInfoFileDescriptorSupplier
      extends DashboardInfoBaseDescriptorSupplier {
    DashboardInfoFileDescriptorSupplier() {}
  }

  private static final class DashboardInfoMethodDescriptorSupplier
      extends DashboardInfoBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    DashboardInfoMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (DashboardInfoGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new DashboardInfoFileDescriptorSupplier())
              .addMethod(getGetAggregateAccountsMethod())
              .addMethod(getGetCurrencyRatesListMethod())
              .addMethod(getGetBonusBalanceListMethod())
              .addMethod(getGetReservedAmountsMethod())
              .addMethod(getGetLoanListMethod())
              .addMethod(getGetInternetTransactionStatusMethod())
              .addMethod(getGetClassifierMethod())
              .build();
        }
      }
    }
    return result;
  }
}
