package kz.eubank.core.dashboard.domain.model.response;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Collection;

@AllArgsConstructor
public class AccountList {

    @Getter
    private Collection<? extends Account> accounts;

    public int getSize() {
        return (this.getAccounts() != null) ? this.getAccounts().size() : 0;
    }
}
