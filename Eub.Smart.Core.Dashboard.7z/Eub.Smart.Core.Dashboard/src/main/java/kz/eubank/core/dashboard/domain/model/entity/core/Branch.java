package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Setter
@Getter
@Entity
@Table(name = "Branch")
public class Branch {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Branch_ID")
    private Long id;

    @Column(name = "Branch_Title")
    private String title;

    @Column(name = "Number")
    private Integer number;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "Address_IDREF")
    private Address address;

    @Column(name = "BIC")
    private String bicCode;

    @Column(name = "BIN")
    private String binCode;

    @Column(name = "RNN")
    private String rnn;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;

    @Column(name = "OpeningHours")
    private String openingHours;

    @Column(name = "Weekday_WorkTime")
    private String weekdayWorkTime;

    @Column(name = "Saturday_WorkTime")
    private String saturdayWorkTime;

    @Column(name = "Sunday_WorkTime")
    private String sundayWorkTime;

    @Column(name = "Holiday_WorkTime")
    private String holidayWorkTime;

    @Column(name = "IsActive")
    private boolean active;

    @Column(name = "BranchType_IDREF")
    private String type;
}
