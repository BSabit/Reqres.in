package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PrecessedCardResponse extends CardDeliveryApplication {

    private String deliveryTime;

    public PrecessedCardResponse() {
        this.deliveryTime = "o\u0442 3 \u0434\u043e 7 \u0434\u043d\u0435\u0439";
    }
}
