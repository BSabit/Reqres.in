package kz.eubank.core.dashboard.domain.model.response;

import lombok.Generated;

import java.io.Serializable;

public class LoanApplicationState implements Serializable {
    private Long id;
    private Long statusDate;
    private LoanApplicationStatus status;
    private String comment;
    private String userMessage;
    private boolean checkStatus;

    @Generated
    public LoanApplicationState() {
    }

    @Generated
    public Long getId() {
        return this.id;
    }

    @Generated
    public Long getStatusDate() {
        return this.statusDate;
    }

    @Generated
    public LoanApplicationStatus getStatus() {
        return this.status;
    }

    @Generated
    public String getComment() {
        return this.comment;
    }

    @Generated
    public String getUserMessage() {
        return this.userMessage;
    }

    @Generated
    public boolean isCheckStatus() {
        return this.checkStatus;
    }

    @Generated
    public void setId(final Long id) {
        this.id = id;
    }

    @Generated
    public void setStatusDate(final Long statusDate) {
        this.statusDate = statusDate;
    }

    @Generated
    public void setStatus(final LoanApplicationStatus status) {
        this.status = status;
    }

    @Generated
    public void setComment(final String comment) {
        this.comment = comment;
    }

    @Generated
    public void setUserMessage(final String userMessage) {
        this.userMessage = userMessage;
    }

    @Generated
    public void setCheckStatus(final boolean checkStatus) {
        this.checkStatus = checkStatus;
    }

    @Generated
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof LoanApplicationState)) {
            return false;
        }
        final LoanApplicationState other = (LoanApplicationState) o;
        if (!other.canEqual(this)) {
            return false;
        }
        final Object this$id = this.getId();
        final Object other$id = other.getId();
        Label_0065:
        {
            if (this$id == null) {
                if (other$id == null) {
                    break Label_0065;
                }
            } else if (this$id.equals(other$id)) {
                break Label_0065;
            }
            return false;
        }
        final Object this$statusDate = this.getStatusDate();
        final Object other$statusDate = other.getStatusDate();
        Label_0102:
        {
            if (this$statusDate == null) {
                if (other$statusDate == null) {
                    break Label_0102;
                }
            } else if (this$statusDate.equals(other$statusDate)) {
                break Label_0102;
            }
            return false;
        }
        final Object this$status = this.getStatus();
        final Object other$status = other.getStatus();
        Label_0139:
        {
            if (this$status == null) {
                if (other$status == null) {
                    break Label_0139;
                }
            } else if (this$status.equals(other$status)) {
                break Label_0139;
            }
            return false;
        }
        final Object this$comment = this.getComment();
        final Object other$comment = other.getComment();
        Label_0176:
        {
            if (this$comment == null) {
                if (other$comment == null) {
                    break Label_0176;
                }
            } else if (this$comment.equals(other$comment)) {
                break Label_0176;
            }
            return false;
        }
        final Object this$userMessage = this.getUserMessage();
        final Object other$userMessage = other.getUserMessage();
        if (this$userMessage == null) {
            if (other$userMessage == null) {
                return this.isCheckStatus() == other.isCheckStatus();
            }
        } else if (this$userMessage.equals(other$userMessage)) {
            return this.isCheckStatus() == other.isCheckStatus();
        }
        return false;
    }

    @Generated
    protected boolean canEqual(final Object other) {
        return other instanceof LoanApplicationState;
    }

    @Generated
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $id = this.getId();
        result = result * 59 + (($id == null) ? 43 : $id.hashCode());
        final Object $statusDate = this.getStatusDate();
        result = result * 59 + (($statusDate == null) ? 43 : $statusDate.hashCode());
        final Object $status = this.getStatus();
        result = result * 59 + (($status == null) ? 43 : $status.hashCode());
        final Object $comment = this.getComment();
        result = result * 59 + (($comment == null) ? 43 : $comment.hashCode());
        final Object $userMessage = this.getUserMessage();
        result = result * 59 + (($userMessage == null) ? 43 : $userMessage.hashCode());
        result = result * 59 + (this.isCheckStatus() ? 79 : 97);
        return result;
    }

    @Generated
    @Override
    public String toString() {
        return "LoanApplicationState(id=" + this.getId() + ", statusDate=" + this.getStatusDate() + ", status=" + this.getStatus() + ", comment=" + this.getComment() + ", userMessage=" + this.getUserMessage() + ", checkStatus=" + this.isCheckStatus() + ")";
    }
}
