package kz.eubank.core.dashboard.domain.repository;

import kz.eubank.core.dashboard.domain.model.entity.core.Person;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface IPersonRepository extends JpaRepository<Person, Long> {

    @Query("select c.person from Client c where c.id = ?1")
    Person findByClientId(final Long p0);
}
