package kz.eubank.core.dashboard.domain.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;

@Setter
@Getter
@NoArgsConstructor
//@JsonInclude(JsonInclude.Include.NON_NULL)
public class Account {

    private List<String> actions;
    private String currency;
    private String number;
    private Integer priority;
    private String title;
    private String type;
    private Boolean allowBalance;
    private Boolean allowCreateFinDoc;
    private BigDecimal actualBalance;
    private String status;
    private BigDecimal balance;
    private BigDecimal blockedSum;
    private Boolean hasStandingOrders;
    private Boolean multiCurrency;
    private String contractNo;
    @JsonSetter(nulls = Nulls.SET)
    private Long parentAccountId;
    private Long id;
    private Boolean allowTransfer;
    private Boolean showBalance;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Account account = (Account) o;
        return Objects.equals(actions, account.actions) && Objects.equals(currency, account.currency)
                && Objects.equals(number, account.number) && Objects.equals(priority, account.priority)
                && Objects.equals(title, account.title) && Objects.equals(type, account.type)
                && Objects.equals(allowBalance, account.allowBalance)
                && Objects.equals(allowCreateFinDoc, account.allowCreateFinDoc)
                && Objects.equals(actualBalance, account.actualBalance) && Objects.equals(status, account.status)
                && Objects.equals(balance, account.balance) && Objects.equals(blockedSum, account.blockedSum)
                && Objects.equals(hasStandingOrders, account.hasStandingOrders)
                && Objects.equals(multiCurrency, account.multiCurrency)
                && Objects.equals(contractNo, account.contractNo)
                && Objects.equals(parentAccountId, account.parentAccountId) && Objects.equals(id, account.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(actions, currency, number, priority, title, type, allowBalance, allowCreateFinDoc,
                actualBalance, status, balance, blockedSum, hasStandingOrders, multiCurrency, contractNo,
                parentAccountId, id);
    }

    @Override
    public String toString() {
        return "Account{" +
                "actions=" + actions +
                ", currency='" + currency + '\'' +
                ", number='" + number + '\'' +
                ", priority=" + priority +
                ", title='" + title + '\'' +
                ", type='" + type + '\'' +
                ", allowBalance=" + allowBalance +
                ", allowCreateFinDoc=" + allowCreateFinDoc +
                ", actualBalance=" + actualBalance +
                ", status='" + status + '\'' +
                ", balance=" + balance +
                ", blockedSum=" + blockedSum +
                ", hasStandingOrders=" + hasStandingOrders +
                ", multiCurrency=" + multiCurrency +
                ", contractNo='" + contractNo + '\'' +
                ", parentAccountId=" + parentAccountId +
                ", id=" + id +
                '}';
    }
}
    
