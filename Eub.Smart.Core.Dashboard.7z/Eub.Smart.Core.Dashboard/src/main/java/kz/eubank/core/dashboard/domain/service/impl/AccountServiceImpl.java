package kz.eubank.core.dashboard.domain.service.impl;

import com.google.protobuf.Timestamp;
import kz.eubank.core.dashboard.domain.model.converter.ProtoConverter;
import kz.eubank.core.dashboard.domain.model.dto.Currency;
import kz.eubank.core.dashboard.domain.model.dto.Error;
import kz.eubank.core.dashboard.domain.model.dto.*;
import kz.eubank.core.dashboard.domain.model.entity.SmbkAccount;
import kz.eubank.core.dashboard.domain.model.entity.core.Account;
import kz.eubank.core.dashboard.domain.model.entity.core.Account2;
import kz.eubank.core.dashboard.domain.model.entity.core.FavoriteCategory;
import kz.eubank.core.dashboard.domain.model.enums.CardTransactionStatus;
import kz.eubank.core.dashboard.domain.model.enums.ErrorMessages;
import kz.eubank.core.dashboard.domain.model.grpc.CustomTypes;
import kz.eubank.core.dashboard.domain.model.grpc.DashboardInfoGrpc;
import kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard;
import kz.eubank.core.dashboard.domain.model.response.BonusSettings;
import kz.eubank.core.dashboard.domain.repository.*;
import kz.eubank.core.dashboard.domain.service.IAccountBalanceInfo;
import kz.eubank.core.dashboard.domain.service.IAccountService;
import kz.eubank.core.dashboard.domain.service.IAllAccService;
import kz.eubank.core.dashboard.infrastructure.config.ApplicationContext;
import kz.eubank.core.dashboard.infrastructure.config.MapperHelper;
import kz.eubank.core.dashboard.infrastructure.exception.ServiceException;
import lombok.extern.log4j.Log4j2;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.*;
import java.util.stream.Collectors;

import static kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BSystemType.SOLR;

@Log4j2
@Service
public class AccountServiceImpl implements IAccountService {

    @Autowired
    private IAccount2Repository account2Repository;

    @Autowired
    private IAccountRepository accountRepository;

    @Autowired
    private IStandingOrderRepository standingOrderRepository;

    @Autowired
    private SmbkAccountRepository smbkAccountRepository;

    @Autowired
    private MapperHelper mapperHelper;

    @Autowired
    private ApplicationContext context;

    @Autowired
    private Set<IAccountBalanceInfo> accountBalanceInfos;

    @Autowired
    private ProtoConverter protoConverter;

    @Autowired
    private IFavoriteCategoryRepository favoriteCategoryRepository;

    @GrpcClient("dashboard")
    private DashboardInfoGrpc.DashboardInfoBlockingStub stub;

    @Override
    public Collection<AccountLongInfo> getAccountsInfo(String[] types, boolean isClosed, Boolean addBalances,
                                                       String balanceCurrency, int bSystemValue, String type) {
        if (addBalances == null) {
            addBalances = false;
        }
        if (balanceCurrency == null) {
            balanceCurrency = "KZT";
        }
        final Long userId = context.getCurrentUser().getUserId();
        final Long clientId = context.getCurrentUser().getClientId();
        final String lang = context.getLanguage();
        Collection<AccountLongInfo> accountLongInfos = getAccounts(types, isClosed, userId, clientId, lang);
        if (accountLongInfos == null || accountLongInfos.size() == 0) {
            return accountLongInfos;
        }
        if (addBalances) {
            GroupAccountBalanceInfo balance;
            if (bSystemValue != SOLR.getNumber()) {
                balance = getAggregateAccountBalance(getAccount(accountLongInfos), balanceCurrency, bSystemValue, type);
            } else {
                balance = getAggregateBonusBalance(accountLongInfos, balanceCurrency, bSystemValue, type);
            }
            mapAccountsAndBalances(accountLongInfos, balance.getAccountsBalances(), type);
        }
        return accountLongInfos;
    }

    private void mapAccountsAndBalances(final Collection<AccountLongInfo> accountLongInfos,
                                        final Collection<? extends AccountBalanceInfo> accountsBalances, String type) {
        for (final AccountLongInfo account : accountLongInfos) {
            final Iterator<? extends AccountBalanceInfo> iter = accountsBalances.iterator();
            while (iter.hasNext()) {
                final AccountBalanceInfo balance = iter.next();
                if (balance.getAccountNumber().equals(account.getNumber())) {
                    account.setBalanceCurrency(balance.getCurrency());
                    account.setBalance(balance.getBalance());
                    account.setActualBalance(balance.getActualBalance());
                    account.setBlockedSum(balance.getBlockedSum());

                    if (IAllAccService.DEPOSIT_ACCOUNT.equals(type)) {
                        DepositBalanceInfo depositBalanceInfo = (DepositBalanceInfo) balance;
                        account.setDateOpened(depositBalanceInfo.getDateOpened());
                        account.setInterestRate(depositBalanceInfo.getInterestRate());
                        account.setDateClosed(depositBalanceInfo.getDateClosed());
                        account.setAccruedAmountForMonth(depositBalanceInfo.getAccruedAmountForMonth());
                        account.setAccruedAmountTotal(depositBalanceInfo.getAccruedAmountTotal());
                        account.setMinBalance(depositBalanceInfo.getMinBalance());
                    } else if (IAllAccService.CARD_ACC_ACCOUNT.equals(type)) {
                        CardBalanceInfo cardBalanceInfo = (CardBalanceInfo) balance;
                        account.setMinBalance(cardBalanceInfo.getMinBalance());
                    }

                    iter.remove();
                    break;
                }
            }
        }
    }

    private String[] getAccount(final Collection<AccountLongInfo> accountsShortInfo) {
        final List<String> accounts = new ArrayList<>();
        for (final AccountShortInfo accountShortInfo : accountsShortInfo) {
            accounts.add(accountShortInfo.getNumber());
        }
        return accounts.toArray(new String[0]);
    }

    public Collection<AccountLongInfo> getAccounts(final String[] types, final boolean isClosed, final Long userId,
                                                   final Long clientId, final String lang) {
        final List<String> typeList = Arrays.asList(types);
        final List<Account2> accountList = account2Repository.findAll(userId, clientId, isClosed, typeList, lang);
        List<AccountLongInfo> accountShortInfos = mapperHelper.map(accountList).toList(AccountLongInfo.class);
        accountShortInfos.forEach(q -> {
            Optional<Account2> optional = account2Repository.findById(q.getId());
            if (optional.isPresent()) {
                Account2 account2 = optional.get();
                q.setActions(findActions(account2.getNumber()));
            }
        });
        return accountShortInfos;
    }

    @Override
    public List<String> findActions(String accountNr) {
        final Account account = accountRepository.findByNumber(accountNr);
        if (account == null) {
            throw new IllegalArgumentException("Account: " + accountNr + " not found!");
        }
        return getActions(account.getProductId());
    }

    private List<String> getActions(Long productId) {
        return accountRepository.findActions(productId);
    }

    @Override
    public Boolean getHasFutureStandingOrder(String accountNumber, String dateFromStr, String dateTillStr) {
        Date dateFrom = null;
        Date dateTill = null;
        if (dateFromStr != null && dateTillStr != null) {
            try {
                dateFrom = new SimpleDateFormat("yyyy-MM-dd").parse(dateFromStr);
                dateTill = new SimpleDateFormat("yyyy-MM-dd").parse(dateTillStr);
            } catch (ParseException e) {
                throw new ServiceException(ErrorMessages.UNABLE_TO_PARSE_DATE.getErrorMessage(), e,
                        HttpStatus.INTERNAL_SERVER_ERROR.value());
            }
        }

        return standingOrderRepository.findFutureStandingOrderCount(accountNumber, dateFrom, dateTill) > 0;
    }

    @Override
    public CurrencyRate[] getCurrencyRates(Boolean isCardRates) {
        EubAggregatorCoreDashboard.ListCurrencyRatesRequest request = EubAggregatorCoreDashboard
                .ListCurrencyRatesRequest
                .newBuilder()
                .setBSystemType(isCardRates ? EubAggregatorCoreDashboard.BSystemType.WAY4 : EubAggregatorCoreDashboard.BSystemType.RSBK)
                .build();
        EubAggregatorCoreDashboard.ListCurrencyRatesReply currencyRatesList = stub.getCurrencyRatesList(request);
        List<EubAggregatorCoreDashboard.CurrencyRate> list = currencyRatesList.getCurrencyRatesList();
        int count = 0;
        CurrencyRate[] currencyRates = new CurrencyRate[list.size()];
        for (EubAggregatorCoreDashboard.CurrencyRate grpcCurrencyRate : list) {
            CurrencyRate currencyRate = new CurrencyRate();
            Currency currency = new Currency();
            currency.setCode(grpcCurrencyRate.getCurrency().name());
            currency.setName(grpcCurrencyRate.getCurrencyName());
            currencyRate.setCurrency(currency);
            currencyRate.setBuyRate(protoConverter.convertDecimalValueToBigDecimalCurrencyRate(grpcCurrencyRate.getBuyRate()));
            currencyRate.setSellRate(protoConverter.convertDecimalValueToBigDecimalCurrencyRate(grpcCurrencyRate.getSellRate()));
            currencyRate.setCentralBankRate(protoConverter.convertDecimalValueToBigDecimalCurrencyRate(grpcCurrencyRate.getCentralBankRate()));
            currencyRates[count++] = currencyRate;
        }
        return currencyRates;
    }

    @Override
    public CardTransactionStatus getInternetTransactionStatus(Long cardId) {
        EubAggregatorCoreDashboard.GetInternetTransactionStatusRequest request = EubAggregatorCoreDashboard
                .GetInternetTransactionStatusRequest
                .newBuilder()
                .setCardId(cardId.intValue())
                .build();
        EubAggregatorCoreDashboard.GetInternetTransactionStatusReply reply = stub
                .getInternetTransactionStatus(request);
        EubAggregatorCoreDashboard.CardTransactionStatus transactionStatus = reply.getTransactionStatus();
        try {
            return CardTransactionStatus.valueOf(transactionStatus.getValueDescriptor().toString());
        } catch (Exception e) {
            return CardTransactionStatus.UNKN;
        }
    }

    @Override
    public ListCreditResponse listCreditsInfo(String iin) {
        ListCreditResponse listCreditResponse = new ListCreditResponse();

        EubAggregatorCoreDashboard.GetLoanListRequest request = EubAggregatorCoreDashboard
                .GetLoanListRequest
                .newBuilder()
                .setIin(iin)
                .build();
        EubAggregatorCoreDashboard.GetLoanListReply loanList = stub.getLoanList(request);
        EubAggregatorCoreDashboard.Loan grpcLoan = loanList.getLoan();

//        listCreditResponse.setActivityId(grpcLoan.getActivityId());
        listCreditResponse.setIin(grpcLoan.getIin());

        Error error = new Error();
        error.setMsg(grpcLoan.getError().getMsg());
        error.setCode(grpcLoan.getError().getCode());
        listCreditResponse.setError(error);

        Loan loan = new Loan();
        List<Item> items = new ArrayList<>();
        for (EubAggregatorCoreDashboard.Item grpcItem : grpcLoan.getLoans().getItemList()) {
            Item item = new Item();
            item.setSourceSystem(grpcItem.getSourceSystem());

            GeneralInfo generalInfo = new GeneralInfo();
            generalInfo.setAmount(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getGeneralInfo().getAmount()));
            generalInfo.setCurrency(grpcItem.getGeneralInfo().getCurrency());
            generalInfo.setClientFullName(grpcItem.getGeneralInfo().getClientFullName());
            generalInfo.setCurrentAmount(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getGeneralInfo().getCurrentAmount()));

            generalInfo.setDateOpen(protoConverter.convertStringDateToDate(grpcItem.getGeneralInfo().getDateOpen()));
            generalInfo.setDateClose(protoConverter.convertStringDateToDate(grpcItem.getGeneralInfo().getDateClose()));
            generalInfo.setRepaymentDateBySchedule(protoConverter.convertStringDateToDate(grpcItem.getGeneralInfo().getRepaymentDateBySchedule()));
            generalInfo.setCurrentPaymentDate(protoConverter.convertStringDateToDate(grpcItem.getGeneralInfo().getCurrentPaymentDate()));
            generalInfo.setTerm((long) grpcItem.getGeneralInfo().getTerm());

            generalInfo.setContractNumber(grpcItem.getGeneralInfo().getContractNumber());
            generalInfo.setBranch(grpcItem.getGeneralInfo().getBranch());
            generalInfo.setRateMin(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getGeneralInfo().getRateMin()));
            generalInfo.setRateEffective(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getGeneralInfo().getRateEffective()));
            generalInfo.setCountOverdueDays(grpcItem.getGeneralInfo().getCountOverdueDays());
            generalInfo.setRepaymentBySchedule(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getGeneralInfo()
                    .getRepaymentBySchedule()));
            generalInfo.setTotalOverdue(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getGeneralInfo().getTotalOverdue()));
            generalInfo.setTotalFine(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getGeneralInfo().getTotalFine()));
            generalInfo.setTotalOverpayment(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getGeneralInfo()
                    .getTotalOverpayment()));
            generalInfo.setTotalCreditBalance(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getGeneralInfo()
                    .getTotalCreditBalance()));

            String productType = grpcItem.getGeneralInfo().getProductType();
            log.info("productType: " + productType);
            generalInfo.setProductType(productType);

            CustomTypes.DecimalValue totalFullRepaymentBalDV = grpcItem.getGeneralInfo().getTotalFullRepaymentBalance();
            log.info("totalFullRepaymentBalDV: " + totalFullRepaymentBalDV);
            BigDecimal totalFullRepaymentBalanceBD = protoConverter.convertDecimalValueToBigDecimal(totalFullRepaymentBalDV);
            log.info("totalFullRepaymentBalanceBD: " + totalFullRepaymentBalanceBD);
            generalInfo.setTotalFullRepaymentBalance(totalFullRepaymentBalanceBD);

            item.setGeneralInfo(generalInfo);

            MainDebt mainDebt = new MainDebt();
            mainDebt.setTotal(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getMainDebt().getTotal()));
            mainDebt.setAmountOverdue(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getMainDebt().getAmountOverdue()));
            mainDebt.setAmountBySchedule(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getMainDebt().getAmountBySchedule()));
            mainDebt.setBalanceBySchedule(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getMainDebt()
                    .getBalanceBySchedule()));
            item.setMainDebt(mainDebt);

            Interest interest = new Interest();
            interest.setTotal(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getInterest().getTotal()));
            interest.setAmountBySchedule(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getInterest().getAmountBySchedule()));
            interest.setAmountOverdue(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getInterest().getAmountOverdue()));
            interest.setBalanceBySchedule(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getInterest()
                    .getBalanceBySchedule()));
            interest.setDistributedAmountBySchedule(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getInterest()
                    .getDistributedAmountBySchedule()));
            interest.setDistributedBalanceBySchedule(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getInterest()
                    .getDistributedBalanceBySchedule()));
            interest.setGraceAmountBySchedule(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getInterest()
                    .getGraceAmountByShcedule()));
            interest.setGraceBalanceBySchedule(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getInterest()
                    .getGraceBalanceBySchedule()));
            interest.setInterestOnToday(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getInterest().getInterestOnToday()));
            item.setInterest(interest);

            FeePeriodic feePeriodic = new FeePeriodic();
            feePeriodic.setAmountBySchedule(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getFeePeriodic()
                    .getAmountByShedule()));
            feePeriodic.setAmountOverdue(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getFeePeriodic().getAmountOverdue()));
            feePeriodic.setBalanceBySchedule(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getFeePeriodic()
                    .getBalanceBySchedule()));
            feePeriodic.setDistributedAmountBySchedule(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getFeePeriodic()
                    .getDistributedAmountBySchedule()));
            feePeriodic.setDistributedBalanceBySchedule(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getFeePeriodic()
                    .getDistributedBalanceBySchedule()));
            feePeriodic.setGraceAmountBySchedule(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getFeePeriodic()
                    .getGraceAmountBySchedule()));
            feePeriodic.setGraceBalanceBySchedule(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getFeePeriodic()
                    .getGraceBalanceBySchedule()));
            feePeriodic.setTotal(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getFeePeriodic().getTotal()));
            item.setFeePeriodic(feePeriodic);

            Fine fine = new Fine();
            fine.setTotal(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getFine().getTotal()));
            fine.setInterest(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getFine().getInterest()));
            fine.setMainDebt(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getFine().getMainDebt()));
            fine.setMainDebtOverdue(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getFine().getMainDebtOverdue()));
            item.setFine(fine);

            Receivables receivables = new Receivables();
            receivables.setAmount(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getReceivables().getAmount()));
            item.setReceivables(receivables);

            Overpayment overpayment = new Overpayment();
            overpayment.setAmountByContract(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getOverpayment()
                    .getAmountByContract()));
            overpayment.setAmountByHeap(protoConverter.convertDecimalValueToBigDecimal(grpcItem.getOverpayment().getAmountByHeap()));
            item.setOverpayment(overpayment);

            items.add(item);
        }
        loan.setItems(items);
        listCreditResponse.setLoan(loan);

        return listCreditResponse;
    }

    @Override
    public BonusSettings getBonusSettings(String iin, Date birthDate, String accountNumber) {
        BonusSettings bonusSettings = new BonusSettings();

        Account account = accountRepository.findByNumber(accountNumber);
        Instant time = birthDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate().atStartOfDay().toInstant(ZoneOffset.UTC);
        Timestamp timestamp = Timestamp
                .newBuilder()
//                .setSeconds(479779200)
                .setSeconds(time.getEpochSecond())
                .setNanos(time.getNano())
                .build();
        EubAggregatorCoreDashboard.EntityId accountId = EubAggregatorCoreDashboard.EntityId
                .newBuilder()
                .setType("ADOC")
                .setBSystem(EubAggregatorCoreDashboard.BSystemType.SMBK)
                .setValue(String.valueOf(account.getOutref()))
                .build();
        EubAggregatorCoreDashboard.ClientParameters client = EubAggregatorCoreDashboard.ClientParameters
                .newBuilder()
//                .setIin("850316300798")
                .setIin(iin)
                .setAccountId(accountId)
                .setDateOfBirth(timestamp)
                .build();
        EubAggregatorCoreDashboard.SolarGetClassifierRequest request = EubAggregatorCoreDashboard
                .SolarGetClassifierRequest
                .newBuilder()
                .setClassifier(EubAggregatorCoreDashboard.ClassifierType.FAVORITE_CATEGORY)
                .setClient(client)
                .build();

        EubAggregatorCoreDashboard.SolarGetClassifierReply reply = stub.getClassifier(request);
        if ("SUCCESS".equals(reply.getResponse().getType())) {
            bonusSettings.setSpendingChannel(reply.getBonusSpendChannel());
            bonusSettings.setSpendingAllowed(reply.getBonusSpendIsAllowed());
            if (!"START".equals(reply.getResponse().getCode())) {
                FavoriteCategory favoriteCategory = favoriteCategoryRepository.findByOutRef(reply.getResponse().getCode());
                if (favoriteCategory != null) {
                    bonusSettings.setFavoriteCategory(favoriteCategory.getId());
                }
            }
        }

        return bonusSettings;
    }

    @Override
    public AccountLongInfo getAggregateAccountBalance(String account, int bSystemValue) {
        Account accountByNumber = accountRepository.findByNumber(account);
        Set<String> set = Collections.singleton(accountByNumber.getOutref().toString());
        EubAggregatorCoreDashboard.AggregateAccountsReply aggregateAccounts = getAggregateAccountsReply(bSystemValue,
                set);
        List<EubAggregatorCoreDashboard.Account> esbAccounts = aggregateAccounts.getAccountsList();
        if (esbAccounts.isEmpty()) {
            return new AccountLongInfo();
        }
        EubAggregatorCoreDashboard.Account esbAccount = esbAccounts.get(0);

        AccountLongInfo accountLongInfo = new AccountLongInfo();
        accountLongInfo.setBalance(protoConverter.convertMoneyToBigDecimal(esbAccount.getBalance()));
        accountLongInfo.setBalanceCurrency(protoConverter.moneyToCurrency(esbAccount.getBalance()));
        accountLongInfo.setActualBalance(protoConverter.convertMoneyToBigDecimal(esbAccount.getAvailableBalance()));
        accountLongInfo.setBlockedSum(protoConverter.convertMoneyToBigDecimal(esbAccount.getBlockedSum()));
        accountLongInfo.setContractNo(esbAccount.getContractNumber());
        accountLongInfo.setDateOpened(protoConverter.timestampToDate(esbAccount.getDateOpened()));

        accountLongInfo.setDateClosed(protoConverter.timestampToDate(esbAccount.getDateClosed()));
        accountLongInfo.setBranchTermId(esbAccount.getBranchId().getType());
        accountLongInfo.setBranchTitle(esbAccount.getBranchId().getValue());

        BigDecimal minBalance = protoConverter.convertMoneyToBigDecimal(esbAccount.getMinBalance());
        if (minBalance == null) {
            accountLongInfo.setMinBalance(0);
        } else {
            accountLongInfo.setMinBalance(minBalance.intValue());
        }

        accountLongInfo.setAvailBalance(protoConverter.convertMoneyToBigDecimal(esbAccount.getAvailableBalance()));
        accountLongInfo.setFinBlocking(protoConverter.convertMoneyToBigDecimal(esbAccount.getFinBlocking()));
        accountLongInfo.setOpenBalance(protoConverter.convertMoneyToBigDecimal(esbAccount.getOpenBalance()));
        accountLongInfo.setName(esbAccount.getAccountName());
        accountLongInfo.setCurrentInterest(protoConverter.convertMoneyToBigDecimal(esbAccount.getCurrentPeriodInterest()));
        accountLongInfo.setLastMonthInterest(protoConverter.convertMoneyToBigDecimal(esbAccount.getLastMonthInterest()));
        accountLongInfo.setAllPeriodInterest(protoConverter.convertMoneyToBigDecimal(esbAccount.getAllPeriodInterest()));
        accountLongInfo.setCreditLimitForInstallment(protoConverter.convertMoneyToBigDecimal(esbAccount
                .getCreditLimitForInstallment()));
        accountLongInfo.setCreditLimitForInstallmentAvailable(protoConverter.convertMoneyToBigDecimal(esbAccount
                .getCreditLimitForInstallmentAvailable()));
        accountLongInfo.setMaxCreditLimitPayment(protoConverter.convertMoneyToBigDecimal(esbAccount.getMaxCreditLimitPayment()));
        accountLongInfo.setMinCreditLimitPayment(protoConverter.convertMoneyToBigDecimal(esbAccount.getMinCreditLimitPayment()));
        accountLongInfo.setMinCreditLimitPaymentDate(protoConverter.timestampToDate(esbAccount.getMinCreditLimitPaymentDate()));
        accountLongInfo.setFullDebtAmount(protoConverter.convertMoneyToBigDecimal(esbAccount.getFullDebtAmount()));

        AccountGraceInfo accountGraceInfo = new AccountGraceInfo();
        accountGraceInfo.setUnusedCreditLimit(protoConverter.convertMoneyToBigDecimal(esbAccount.getUnusedCreditLimit()));
        accountGraceInfo.setTotalLoan(protoConverter.convertMoneyToBigDecimal(esbAccount.getTotalLoan()));
        accountGraceInfo.setMinimalPayment(protoConverter.convertMoneyToBigDecimal(esbAccount.getMinimalPayment()));

        Date nextBillingDate = protoConverter.timestampToDate(esbAccount.getNextBillingDate());
        accountGraceInfo.setNextBillingDate(nextBillingDate == null ? null : nextBillingDate.getTime());

        Date nextDueDate = protoConverter.timestampToDate(esbAccount.getNextDueDate());
        accountGraceInfo.setNextDueDate(nextDueDate == null ? null : nextDueDate.getTime());

        accountGraceInfo.setOwn(protoConverter.convertMoneyToBigDecimal(esbAccount.getOwn()));
        accountGraceInfo.setOverdue(protoConverter.convertMoneyToBigDecimal(esbAccount.getOverdue()));
        accountGraceInfo.setOverlimit(protoConverter.convertMoneyToBigDecimal(esbAccount.getOverlimit()));
        accountGraceInfo.setPenalty(protoConverter.convertMoneyToBigDecimal(esbAccount.getPenalty()));
        accountGraceInfo.setCreditLimit(protoConverter.convertMoneyToBigDecimal(esbAccount.getCreditLimit()));
        accountGraceInfo.setGraceFailedFee(protoConverter.convertMoneyToBigDecimal(esbAccount.getGraceFailedFee()));
        accountGraceInfo.setGracePaymentAmount(protoConverter.convertMoneyToBigDecimal(esbAccount.getGracePaymentAmount()));
        accountLongInfo.setAccountGraceInfo(accountGraceInfo);

        accountLongInfo.setSubAccountBalances(protoConverter.moneyListToSubAccountBalanceList(
                esbAccount.getSubAccountBalances().getSubAccountBalanceList()));
        accountLongInfo.setSubAccountAvailableBalances(protoConverter.moneyListToSubAccountBalanceList(
                esbAccount.getSubAccountAvailableBalances().getSubAccountAvailableBalanceList()));

        String accountStatusCode = esbAccount.getAccountStatus().getValueDescriptor().toString();
        accountLongInfo.setStatus(new AccountStatus(accountStatusCode, accountStatusCode));

        accountLongInfo.setGrace(esbAccount.getIsGrace());

//        db has value, esb have not
//        accountLongInfo.setLimitFinDoc();
//        accountLongInfo.setLimitDay();
//        accountLongInfo.setLimitWeek();
//        accountLongInfo.setLimitMonth();
//        accountLongInfo.setLimitCurrency();
//        accountLongInfo.setId();
//        accountLongInfo.setTitle();
//        accountLongInfo.setType();
//        accountLongInfo.setProductId();
//        accountLongInfo.setSpriteIndex();
//        accountLongInfo.setPriority();
//        accountLongInfo.setAllowBalance();
//        accountLongInfo.setAllowCreateFinDoc();
//        accountLongInfo.setAllowSubmitFinDoc();

//        db and esb have values
//        accountLongInfo.setTermLength(esbAccount.getTermLength());
//        accountLongInfo.setCurrency(protoConverter.moneyToCurrency(esbAccount.getBalance()));
//        accountLongInfo.setNumber(esbAccount.getNumber());
//        accountLongInfo.setInterestRate(protoConverter.convertDecimalValueToBigDecimal(esbAccount.getRate()));
//        accountLongInfo.setGrace(esbAccount.getIsGrace());
//        accountLongInfo.setMultiCurrency(esbAccount.getIsMultiCurrency());

//        db and esb have not any values
//        accountLongInfo.setActions();
//        accountLongInfo.setOutref();
//        accountLongInfo.setParentAccountId();
//        accountLongInfo.setOverdraft();
//        accountLongInfo.setAccruedAmountTotal();
//        accountLongInfo.setAccruedAmountForMonth();
//        accountLongInfo.setPeriodOfCashBack();
//        accountLongInfo.setCashbackForPeriod();
//        accountLongInfo.setTotalCashback();
//        accountLongInfo.setInstallmentAccount();
//        accountLongInfo.setActiveInstallments();

        return accountLongInfo;
    }

    public GroupAccountBalanceInfo getAggregateAccountBalance(final String[] accounts, final String totalCurrency,
                                                              int bSystemValue, String type) {
        Set<String> set = Arrays.stream(accounts).map(q -> {
            Account accountByNumber = accountRepository.findByNumber(q);
            return accountByNumber.getOutref().toString();
        }).collect(Collectors.toSet());

        EubAggregatorCoreDashboard.AggregateAccountsReply aggregateAccounts = getAggregateAccountsReply(
                bSystemValue, set);
        List<EubAggregatorCoreDashboard.Account> esbAccounts = aggregateAccounts.getAccountsList();

        GroupAccountBalanceInfo groupAccountBalanceInfo = new GroupAccountBalanceInfo();

        Optional<IAccountBalanceInfo> service = accountBalanceInfos.stream().filter(q -> q.getType().equals(type))
                .findFirst();
        IAccountBalanceInfo accountBalanceInfo = service
                .orElseThrow(() -> new RuntimeException("There is not such way for sending messages."));

        List<? extends AccountBalanceInfo> accountBalances = accountBalanceInfo.getAccountBalances(esbAccounts);

        groupAccountBalanceInfo.setAccountsBalances(accountBalances);

/*        groupAccountBalanceInfo.setTotal(protoConverter.convertMoneyToBigDecimal(aggregateAccounts.get));
        groupAccountBalanceInfo.setTotalCurrency(protoConverter.moneyToCurrency(aggregateAccounts.getAccounts().getBalance()));*/

        return groupAccountBalanceInfo;
    }

    public GroupAccountBalanceInfo getAggregateBonusBalance(Collection<AccountLongInfo> accountLongInfos,
                                                            String totalCurrency,
                                                            int bSystemValue,
                                                            String type) {
        List<AccountBalanceInfo> accountBalanceInfos = new ArrayList<>();
        for (AccountLongInfo account : accountLongInfos) {
            List<SmbkAccount> smbkAccounts = smbkAccountRepository.getAllByBSystemAndAccountOutref(account.getNumber(), "SOLR");
            checkingForUniqueness(smbkAccounts);
            fillAccountBalanceInfo(smbkAccounts, accountBalanceInfos);
        }
        GroupAccountBalanceInfo groupAccountBalanceInfo = new GroupAccountBalanceInfo();
        groupAccountBalanceInfo.setAccountsBalances(accountBalanceInfos);
        return groupAccountBalanceInfo;
    }

    private void checkingForUniqueness(List<SmbkAccount> smbkAccounts) {
        Map<String, Long> grp = smbkAccounts.stream()
                .collect(Collectors.groupingBy(SmbkAccount::getUniqueValues, Collectors.counting()));
        for (Map.Entry<String, Long> item : grp.entrySet()) {
            if (item.getValue() > 1) {
                throw new RuntimeException("Больше одной записи с одинаковыми значениями iin, programCode и unit.");
            }
        }
    }

    private void fillAccountBalanceInfo(List<SmbkAccount> smbkAccounts,
                                        List<AccountBalanceInfo> accountBalanceInfos) {
        for (SmbkAccount smbkAccount : smbkAccounts) {
            EubAggregatorCoreDashboard.BonusBalanceListReply bonusBalanceListReply =
                    getBonusBalanceListReply(smbkAccount.getSmbkClientId(), smbkAccount.getIin(), smbkAccount.getDateOfBirth());
            EubAggregatorCoreDashboard.BonusBalance bonusBalance =
                    getBonusBalance(bonusBalanceListReply, smbkAccount.getProgramCode(), smbkAccount.getUnit());

            if (bonusBalance != null) {
                AccountBalanceInfo accountBalanceInfo = new AccountBalanceInfo();
                accountBalanceInfo.setAccountNumber(smbkAccount.getSmbkAccountNumber());

                BigDecimal balance = protoConverter.convertDecimalValueToBigDecimalCurrencyRate(bonusBalance.getAvailableAmount());
                BigDecimal blockedSum = protoConverter.convertDecimalValueToBigDecimalCurrencyRate(bonusBalance.getAwaitingConfirmationAmount())
                        .add(protoConverter.convertDecimalValueToBigDecimalCurrencyRate(bonusBalance.getDefferedAmount()))
                        .subtract(protoConverter.convertDecimalValueToBigDecimalCurrencyRate(bonusBalance.getBlockAmount()));
                BigDecimal actualSum = balance;

                accountBalanceInfo.setBalance(balance);
                accountBalanceInfo.setCurrency(bonusBalance.getUnit());
                accountBalanceInfo.setActualBalance(actualSum);
                accountBalanceInfo.setBlockedSum(blockedSum);

                accountBalanceInfos.add(accountBalanceInfo);
            }
        }
    }

    private EubAggregatorCoreDashboard.BonusBalanceListReply getBonusBalanceListReply(Long clientId,
                                                                                      String iin,
                                                                                      String dateOfBirth) {
        EubAggregatorCoreDashboard.BonusBalanceListRequest request = EubAggregatorCoreDashboard
                .BonusBalanceListRequest.newBuilder()
                .setClientReference(EubAggregatorCoreDashboard.ClientReference.newBuilder()
                        .setIin(iin)
                        .setClientId(clientId)
                        .setDateOfBirth(dateOfBirth).build())
                .build();
        return stub.getBonusBalanceList(request);
    }

    private EubAggregatorCoreDashboard.BonusBalance getBonusBalance(EubAggregatorCoreDashboard.BonusBalanceListReply bonusBalanceListReply,
                                                                    String programCode,
                                                                    String unit) {
        for (EubAggregatorCoreDashboard.BonusBalance bonusBalance : bonusBalanceListReply.getClient().getBonusBalancesList()) {
            if (programCode.equals(bonusBalance.getProgramCode()) && unit.equals(bonusBalance.getUnit())) {
                return bonusBalance;
            }
        }
        return null;
    }

    private EubAggregatorCoreDashboard.AggregateAccountsReply getAggregateAccountsReply(int bSystemValue, Set<String> set) {
        String value = String.join(", ", set);
        EubAggregatorCoreDashboard.EntityId entityId = EubAggregatorCoreDashboard.EntityId.newBuilder()
                .setBSystem(EubAggregatorCoreDashboard.BSystemType.forNumber(bSystemValue))
                .setValue(value)
                .setType("").build();
        EubAggregatorCoreDashboard.AggregateAccountsRequest request = EubAggregatorCoreDashboard
                .AggregateAccountsRequest
                .newBuilder()
                .addAccountId(entityId)
                .setTotalBalanceCurrency(EubAggregatorCoreDashboard.CurrencyCode.KZT).build();
        return stub.getAggregateAccounts(request);
    }
}
