package kz.eubank.core.dashboard.domain.model.entity;

import javax.persistence.*;

@Entity
@Table(name = "PaymentDetails")
public class PaymentDetails {
    
    @Id
    @Column(name = "PaymentDetails_ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    long id;

    @OneToOne()
    @JoinColumn(name = "ServiceField_IDREF")
    private ServiceField serviceField;
    
    @ManyToOne()
    @JoinColumn(name = "PaymentDoc_IDREF", nullable = false,insertable = false, updatable = false)
	private PaymentDoc payment;

    @Column(name = "FieldValue")
    String value;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public ServiceField getServiceField() {
        return serviceField;
    }

    public void setServiceField(ServiceField serviceField) {
        this.serviceField = serviceField;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

	public PaymentDoc getPayment() {
		return payment;
	}

	public void setPayment(PaymentDoc payment) {
		this.payment = payment;
	}
}
