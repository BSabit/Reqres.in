package kz.eubank.core.dashboard.domain.model.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class MapUserAccount_PK implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5296958581755250463L;
	@Column(name = "User_IDREF")
    Long userId;
    @Column(name = "Account_IDREF")
    Long accountId;
    
    public Long getUserId() {
        return userId;
    }
    public Long getAccountId() {
        return accountId;
    }
}
