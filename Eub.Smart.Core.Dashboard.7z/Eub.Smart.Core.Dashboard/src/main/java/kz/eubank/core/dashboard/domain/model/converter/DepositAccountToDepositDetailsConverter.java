package kz.eubank.core.dashboard.domain.model.converter;

import kz.eubank.core.dashboard.domain.model.dto.DepositDetails;
import kz.eubank.core.dashboard.domain.model.entity.core.DepositAccount;
import org.dozer.CustomConverter;
import org.springframework.beans.BeanUtils;

public class DepositAccountToDepositDetailsConverter implements CustomConverter {

    @Override
    public Object convert(Object dest, Object source, Class<?> arg2, Class<?> arg3) {
        if (source == null) {
            return null;
        }
        if (source instanceof DepositAccount) {
            DepositAccount depositAccount = (DepositAccount) source;
            DepositDetails depositDetails = new DepositDetails();
            depositDetails.setTermCode(depositAccount.getTermCode());
            depositDetails.setTermPeriod(depositAccount.getTermPeriod());
            depositDetails.setEffectiveRate(depositAccount.getEffectiveRate());
            depositDetails.setExpiration(depositAccount.getExitDate());
            return depositDetails;
        } else if (source instanceof DepositDetails) {//todo
            DepositDetails depositDetails = (DepositDetails) source;
            DepositAccount depositAccount = new DepositAccount();
            BeanUtils.copyProperties(depositDetails, depositAccount);
            return depositAccount;
        }
        return null;
    }
}
