package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "ForexApplication")
public class ForexApplication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ForexApplication_ID")
    private Long id;

    @OneToOne
    @JoinColumn(name = "SourceAccount_IDREF")
    private Account sourceAccount;

    @OneToOne
    @JoinColumn(name = "TargetAccount_IDREF")
    private Account targetAccount;

    @OneToOne
    @JoinColumn(name = "DepositAccount_IDREF")
    private Account depositAccount;

    @Column(name = "OperationAmount")
    private BigDecimal operationAmount;

    @Column(name = "OperationCurrency")
    private String operationCurrency;

    @Column(name = "DepositPercent")
    private BigDecimal depositPercent;

    @Column(name = "DepositAmount")
    private BigDecimal depositAmount;

    @Column(name = "DepositCurrency")
    private String depositCurrency;

    @Column(name = "DayShift")
    private String dateShift;

    @Column(name = "DealDate")
    private Date dealDate;

    @OneToOne
    @JoinColumn(name = "Application_IDREF", insertable = false, updatable = false)
    private Application application;
}
