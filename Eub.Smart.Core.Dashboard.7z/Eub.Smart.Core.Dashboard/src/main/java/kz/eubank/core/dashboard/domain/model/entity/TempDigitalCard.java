package kz.eubank.core.dashboard.domain.model.entity;

import kz.eubank.core.dashboard.domain.model.entity.core.Application;
import kz.eubank.core.dashboard.domain.model.entity.core.User;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TempDigitalCard")
public class TempDigitalCard {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "TempDigitalCard_ID")
    private Long id;

    @OneToOne
    @JoinColumn(name = "User_IDREF", insertable = false, updatable = false)
    private User user;

    @Column(name = "User_IDREF")
    private Long userId;

    @OneToOne
    @JoinColumn(name = "Application_IDREF", insertable = false, updatable = false)
    private Application application;

    @Column(name = "Application_IDREF")
    private Long applicationId;

    @Column(name = "IBAN")
    private String iban;

    @Column(name = "MaskedNumber")
    private String maskedNumber;

    @Column(name = "DateCreate")
    private Date created;
}
