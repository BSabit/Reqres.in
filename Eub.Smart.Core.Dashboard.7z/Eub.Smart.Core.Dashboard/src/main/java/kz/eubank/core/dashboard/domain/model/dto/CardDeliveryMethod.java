package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CardDeliveryMethod {

    private String code;
    private String title;
    private boolean active;

    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof CardDeliveryMethod)) {
            return false;
        }
        CardDeliveryMethod other = (CardDeliveryMethod) o;
        if (!other.canEqual(this)) {
            return false;
        }
        Object this$code = this.getCode();
        Object other$code = other.getCode();
        Label_0065:
        {
            if (this$code == null) {
                if (other$code == null) {
                    break Label_0065;
                }
            } else if (this$code.equals(other$code)) {
                break Label_0065;
            }
            return false;
        }
        Object this$title = this.getTitle();
        Object other$title = other.getTitle();
        if (this$title == null) {
            if (other$title == null) {
                return this.isActive() == other.isActive();
            }
        } else if (this$title.equals(other$title)) {
            return this.isActive() == other.isActive();
        }
        return false;
    }

    @Override
    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        Object $code = this.getCode();
        result = result * PRIME + (($code == null) ? 43 : $code.hashCode());
        Object $title = this.getTitle();
        result = result * PRIME + (($title == null) ? 43 : $title.hashCode());
        result = result * PRIME + (this.isActive() ? 79 : 97);
        return result;
    }

    protected boolean canEqual(Object other) {
        return other instanceof CardDeliveryMethod;
    }
}
