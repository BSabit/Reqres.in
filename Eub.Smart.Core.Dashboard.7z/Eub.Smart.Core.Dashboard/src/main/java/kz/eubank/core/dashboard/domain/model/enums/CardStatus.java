package kz.eubank.core.dashboard.domain.model.enums;

public enum CardStatus {
    ACTIVE, INACTIVE, BLOCKED, CLOSED, UNKNOWN, DELETED, EXPIRED, LSTK, LSTA;

    public static CardStatus getValue(String text) {
        if (text.equalsIgnoreCase("ACTV")) {
            return ACTIVE;
        } else if (text.equalsIgnoreCase("NACT")) {
            return INACTIVE;
        } else if (text.equalsIgnoreCase("BLOC")) {
            return BLOCKED;
        } else if (text.equalsIgnoreCase("CLOS")) {
            return CLOSED;
        } else if (text.equalsIgnoreCase("UNKN")) {
            return UNKNOWN;
        } else if (text.equalsIgnoreCase("DLTD")) {
            return DELETED;
        } else if (text.equalsIgnoreCase("EXPD")) {
            return EXPIRED;
        } else if (text.equalsIgnoreCase("LSTK")) {
            return LSTK;
        } else if (text.equalsIgnoreCase("LSTA")) {
            return LSTA;
        } else if (text.equalsIgnoreCase("TEMP")) {
            return BLOCKED;
        }
        return null;
    }
}
