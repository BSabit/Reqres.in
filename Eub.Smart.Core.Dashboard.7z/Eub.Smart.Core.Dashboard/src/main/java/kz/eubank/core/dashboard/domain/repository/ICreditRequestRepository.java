package kz.eubank.core.dashboard.domain.repository;

import kz.eubank.core.dashboard.domain.model.entity.core.LoanApplication;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Date;

public interface ICreditRequestRepository extends JpaRepository<LoanApplication, Long> {

    @Query("select la from LoanApplication la"
            + " where la.application.userId = :userId"
            + " and la.dateCreated between :dateFrom and :dateTo"
    )
    Page<LoanApplication> findByUserIdAndDates(Pageable pageable, Date dateFrom, Date dateTo, Long userId);
}
