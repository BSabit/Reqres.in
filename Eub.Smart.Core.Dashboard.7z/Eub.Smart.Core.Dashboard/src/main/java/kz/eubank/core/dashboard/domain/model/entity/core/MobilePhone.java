package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "MobilePhone")
public class MobilePhone {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MobilePhone_ID")
    private Long id;

    @Column(name = "MobilePhone")
    private String mobilePhone;

    @OneToOne
    @JoinColumn(name = "MobilePhoneStatus_IDREF")
    private MobilePhoneStatus status;
}
