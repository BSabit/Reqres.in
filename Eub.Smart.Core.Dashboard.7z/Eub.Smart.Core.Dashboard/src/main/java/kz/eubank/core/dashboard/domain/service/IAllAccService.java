package kz.eubank.core.dashboard.domain.service;

import kz.eubank.core.dashboard.domain.model.response.AccountList;

import static kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BSystemType.RSBK;
import static kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BSystemType.WAY4;

public interface IAllAccService {

    int CARD_ACC_ACCOUNT_TYPE = WAY4.getNumber();
    int CURR_ACC_ACCOUNT_TYPE = RSBK.getNumber();
    int DEPOSIT_ACCOUNT_TYPE = RSBK.getNumber();

    String CARD_ACC_ACCOUNT = "card";
    String CURR_ACC_ACCOUNT = "current_account";
    String DEPOSIT_ACCOUNT = "deposit";

    AccountList getCardAccounts(String balanceCurrency, String dateFromStr, String dateTillStr);

    AccountList getCurrentAccounts(String balanceCurrency);

    AccountList getDeposits(String balanceCurrency, String dateFromStr, String dateTillStr);
}
