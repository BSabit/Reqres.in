package kz.eubank.core.dashboard.domain.model.converter;

import kz.eubank.core.dashboard.domain.model.dto.AccountLongInfo;
import kz.eubank.core.dashboard.domain.model.dto.AccountStatus;
import kz.eubank.core.dashboard.domain.model.entity.core.Account2;
import org.dozer.CustomConverter;
import org.springframework.beans.BeanUtils;

public class Account2ToAccountLongInfoConverter implements CustomConverter {

    @Override
    public Object convert(Object dest, Object source, Class<?> arg2, Class<?> arg3) {
        if (source == null) {
            return null;
        }
        if (source instanceof Account2 && arg2.equals(AccountLongInfo.class)) {//todo
            Account2 account = (Account2) source;
            AccountLongInfo accountLongInfo = new AccountLongInfo();
            BeanUtils.copyProperties(account, accountLongInfo);
            if (account.getStatus() != null) {
                AccountStatus accountStatus = String2AccountStatus_Converter.convert(account.getStatus());
                if (accountStatus != null) {
                    String code = accountStatus.getCode();
                    accountLongInfo.setStatus(new AccountStatus(code, code));
                }
            }
            return accountLongInfo;
        } else if (source instanceof AccountLongInfo && arg2.equals(Account2.class)) {//todo remove
            AccountLongInfo accountLongInfo = (AccountLongInfo) source;
            Account2 account = new Account2();
            BeanUtils.copyProperties(accountLongInfo, account);
            return account;
        }
        return null;
    }
}