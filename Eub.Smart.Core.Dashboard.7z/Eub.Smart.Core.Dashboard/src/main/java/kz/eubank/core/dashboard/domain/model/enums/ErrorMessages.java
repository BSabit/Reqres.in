package kz.eubank.core.dashboard.domain.model.enums;

import lombok.Getter;

public enum ErrorMessages {

    UNABLE_TO_COMPLETE_OPERATION("Unable to complete the operation"),
    UNABLE_TO_PARSE_DATE("Unable to parse date"),
    CLIENT_IS_NOT_FOUND("Client is not found"),
    BIRTH_DATE_OR_IIN_IS_NULL("Birth date or iin is null"),
    ;

    @Getter
    private final String errorMessage;

    ErrorMessages(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}