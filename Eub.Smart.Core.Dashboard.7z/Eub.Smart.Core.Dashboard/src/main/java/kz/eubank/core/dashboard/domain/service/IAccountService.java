package kz.eubank.core.dashboard.domain.service;

import kz.eubank.core.dashboard.domain.model.dto.AccountLongInfo;
import kz.eubank.core.dashboard.domain.model.dto.CurrencyRate;
import kz.eubank.core.dashboard.domain.model.dto.ListCreditResponse;
import kz.eubank.core.dashboard.domain.model.enums.CardTransactionStatus;
import kz.eubank.core.dashboard.domain.model.response.BonusSettings;

import java.util.Collection;
import java.util.Date;
import java.util.List;

public interface IAccountService {

    Boolean getHasFutureStandingOrder(final String accountNumber, final String dateFromStr, final String dateTillStr);

    List<String> findActions(String accountNr);

    Collection<AccountLongInfo> getAccountsInfo(String[] types, boolean isClosed, Boolean addBalances,
                                                String balanceCurrency, int bSystemValue, String type);

    CurrencyRate[] getCurrencyRates(Boolean isCardRates);

    CardTransactionStatus getInternetTransactionStatus(final Long p0);

    ListCreditResponse listCreditsInfo(String iin);

    AccountLongInfo getAggregateAccountBalance(String account, int bSystemValue);

    BonusSettings getBonusSettings(String iin, Date birthDate, String account);
}
