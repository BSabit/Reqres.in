package kz.eubank.core.dashboard.domain.model.mapper;

import kz.eubank.core.dashboard.domain.model.dto.SSGPOEmployeeInfo;
import kz.eubank.core.dashboard.domain.model.entity.SSGPOEmployeesInfo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface SSGPOEmployeeInfoMapper {

    SSGPOEmployeeInfoMapper INSTANCE = Mappers.getMapper(SSGPOEmployeeInfoMapper.class);

    @Mappings({
            @Mapping(target = "id", expression = "java(ssgpoEmployeesInfo.getId())"),
            @Mapping(target = "departmentCode", expression = "java(ssgpoEmployeesInfo.getSsgpoCodeDictionary().getCode())"),
            @Mapping(target = "period", expression = "java(ssgpoEmployeesInfo.getSsgpoTickets().getExportPeriod())"),
            @Mapping(target = "iin", expression = "java(ssgpoEmployeesInfo.getPersonIIN())"),
            @Mapping(target = "salary", expression = "java(ssgpoEmployeesInfo.getChtsAmount())"),
            @Mapping(target = "departmentCodeDesc", expression = "java(\"ru\".equals(lang) " +
                    "? ssgpoEmployeesInfo.getSsgpoCodeDictionary().getCodeDescRu()" +
                    ": ssgpoEmployeesInfo.getSsgpoCodeDictionary().getCodeDescKz())"),
            @Mapping(target = "departmentCodeDescShort", expression = "java(\"ru\".equals(lang) " +
                    "? ssgpoEmployeesInfo.getSsgpoCodeDictionary().getCodeDescShortRu()" +
                    ": ssgpoEmployeesInfo.getSsgpoCodeDictionary().getCodeDescShortKz())")
    })
    SSGPOEmployeeInfo toDto(SSGPOEmployeesInfo ssgpoEmployeesInfo, String lang);
}
