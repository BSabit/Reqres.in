package kz.eubank.core.dashboard.domain.model.entity.core;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "DepositAccount")
public class DepositAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DepositAccount_ID")
    private Long id;

    @Column(name = "Account_IDREF")
    private Long accountId;

    @Column(name = "ExitDate")
    private Date exitDate;

    @Column(name = "ProlongationsLeft")
    private int prolongationsLeft;
    
    @Column(name = "Term")
    private Integer termPeriod;
    
    @Column(name = "TermPeriod")
    private String termCode;
    
    @Column(name = "EffectiveRate")
    private BigDecimal effectiveRate;

    public Long getId() {
        return id;
    }

    public Long getAccountId() {
        return accountId;
    }

    public Date getExitDate() {
        return exitDate;
    }

    public int getProlongationsLeft() {
        return prolongationsLeft;
    }

    public Integer getTermPeriod() {
        return termPeriod;
    }

    public String getTermCode() {
        return termCode;
    }

    public BigDecimal getEffectiveRate() {
        return effectiveRate;
    }
}
