package kz.eubank.core.dashboard.domain.service;

import kz.eubank.core.dashboard.domain.model.dto.TempDigitalCardList;

public interface DigitalCardOpenService {

    TempDigitalCardList getTempCards();
}
