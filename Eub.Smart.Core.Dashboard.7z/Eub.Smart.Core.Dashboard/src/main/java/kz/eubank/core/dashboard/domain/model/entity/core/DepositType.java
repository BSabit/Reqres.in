package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "DepositType")
public class DepositType {

    @Id
    @Column(name = "DepositType_ID")
    private String code;

    @Column(name = "DepositType_Title")
    private String title;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    @NotFound(action = NotFoundAction.IGNORE)
    private Term terms;

    @Column(name = "IsStaff")
    private boolean staff;

    @Column(name = "IsSalary")
    private boolean salary;

    @Column(name = "IsAffiliated")
    private boolean affiliated;

    @Column(name = "ClientRank_Min")
    private int clientRankMin;

    @Column(name = "ClientRank_Max")
    private int clientRankMax;

    @Column(name = "OfferNew")
    private boolean offerNew;

    @Column(name = "Priority")
    private int priority;

}
