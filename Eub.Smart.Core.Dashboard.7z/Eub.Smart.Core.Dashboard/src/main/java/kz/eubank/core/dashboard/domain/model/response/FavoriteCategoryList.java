package kz.eubank.core.dashboard.domain.model.response;

import java.util.Collection;

public class FavoriteCategoryList {

    private final Collection<FavoriteCategory> categories;

    public FavoriteCategoryList(final Collection<FavoriteCategory> categories) {
        this.categories = categories;
    }

    public int getSize() {
        return (this.getCategories() != null) ? this.getCategories().size() : 0;
    }

    public Collection<FavoriteCategory> getCategories() {
        return this.categories;
    }
}
