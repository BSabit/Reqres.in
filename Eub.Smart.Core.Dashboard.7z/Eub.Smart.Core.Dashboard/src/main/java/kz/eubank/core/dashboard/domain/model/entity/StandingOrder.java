package kz.eubank.core.dashboard.domain.model.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Entity(name = "StandingOrder")
@Table(name = "StandingOrder")
public class StandingOrder {

    @Id
    @Column(name = "StandingOrder_ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "StandingOrder_Title")
    private String title;

    @Temporal(TemporalType.DATE)
    @Column(name = "DateStart")
    private Date dateStart;

    @Temporal(TemporalType.DATE)
    @Column(name = "DateEnd")
    private Date dateEnd;

    @Column(name = "IsWeekly")
    private Boolean weekly;

    @Column(name = "DayNum")
    private Integer dayNum;

    @Column(name = "DateSaved")
    private Date created;

    @Column(name = "Service_IDREF")
    private Long serviceId;

    @Column(name = "Description")
    private String description;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "FinDoc_IDREF")
    private FinDoc finDoc;
}
