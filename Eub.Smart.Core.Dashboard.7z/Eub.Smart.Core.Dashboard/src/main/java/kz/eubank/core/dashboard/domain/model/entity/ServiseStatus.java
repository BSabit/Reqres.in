package kz.eubank.core.dashboard.domain.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ServiceStatus")
public class ServiseStatus {

    @Id
    @Column(name = "ServiceStatus_ID")
    private String code;

    @Column(name = "IsValid")
    private boolean valid;

    public String getCode() {
        return code;
    }

    public boolean isValid() {
        return valid;
    }
}

