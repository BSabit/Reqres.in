package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "ClientStatus")
public class ClientStatus {

    @Id
    @Column(name = "ClientStatus_ID")
    private String code;

    @Column(name = "ClientStatus_Title")
    private String title;

    @Column(name = "IsValid")
    private boolean valid;

    @OneToOne
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;
}
