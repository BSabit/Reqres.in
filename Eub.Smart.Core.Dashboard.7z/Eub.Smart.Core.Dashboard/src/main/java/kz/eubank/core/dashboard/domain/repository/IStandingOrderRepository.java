package kz.eubank.core.dashboard.domain.repository;

import kz.eubank.core.dashboard.domain.model.entity.StandingOrder;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;

@Repository
public interface IStandingOrderRepository extends CrudRepository<StandingOrder, Long> {

    @Query("select count(so)" +
            " from Order o,StandingOrder so, FinDocState fs" +
            " where o.account.number= :accountNumber and o.id = so.finDoc.id and o.id=fs.finDoc.id" +
            " and fs.docTechStatus.id='STND' and o.dateCreated >= :dateStart and o.dateCreated < :dateEnd" +
            " and NOT EXISTS (select OChild from Order OChild where OChild.parentFinDocId = o.id" +
            " and OChild.dateCreated >= getdate() and OChild.dateCreated < DateAdd(day, 1, getdate()))" +
            " and so.dateStart < DateAdd(day, 1, so.dateEnd)")
    int findFutureStandingOrderCount(@Param("accountNumber") final String p0, @Param("dateStart") final Date p1,
                                     @Param("dateEnd") final Date p2);
}
