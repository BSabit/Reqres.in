package kz.eubank.core.dashboard.domain.repository;

import kz.eubank.core.dashboard.domain.model.entity.core.DepositAccount;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface IDepositAccountRepository extends CrudRepository<DepositAccount, Long> {

    @Query("select d from DepositAccount d, Account a where a.id=d.accountId and a.number = :accountNumber")
    DepositAccount findOne(@Param("accountNumber") final String p0);
}
