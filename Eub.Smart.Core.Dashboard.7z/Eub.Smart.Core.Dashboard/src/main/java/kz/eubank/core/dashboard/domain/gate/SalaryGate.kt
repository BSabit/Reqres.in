package kz.eubank.core.dashboard.domain.gate

import kz.eubank.core.dashboard.domain.model.dto.SettlementSheetEmployeeList

interface SalaryGate {

    suspend fun getSettlementSheetEmployeesResult(iin: String, size: Int): SettlementSheetEmployeeList
}