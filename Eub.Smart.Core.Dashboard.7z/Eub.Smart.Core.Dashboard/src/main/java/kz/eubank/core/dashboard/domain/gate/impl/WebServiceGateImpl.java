package kz.eubank.core.dashboard.domain.gate.impl;

import kz.eubank.core.dashboard.domain.gate.WebServiceGate;
import kz.eubank.core.dashboard.domain.model.dto.AccountLongInfo;
import kz.eubank.core.dashboard.domain.service.IAccountService;
import kz.eubank.core.dashboard.domain.service.IAllAccService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WebServiceGateImpl implements WebServiceGate {

    @Autowired
    private IAccountService accountService;

    public AccountLongInfo getAccountDetails(final String accountNumber, AccountLongInfo accountLongInfo) {
        AccountLongInfo aggregateAccountBalance = accountService.getAggregateAccountBalance(accountNumber,
                IAllAccService.CARD_ACC_ACCOUNT_TYPE);

        aggregateAccountBalance.setLimitFinDoc(accountLongInfo.getLimitFinDoc());
        aggregateAccountBalance.setLimitDay(accountLongInfo.getLimitDay());
        aggregateAccountBalance.setLimitWeek(accountLongInfo.getLimitWeek());
        aggregateAccountBalance.setLimitMonth(accountLongInfo.getLimitMonth());
        aggregateAccountBalance.setLimitCurrency(accountLongInfo.getLimitCurrency());
        aggregateAccountBalance.setId(accountLongInfo.getId());
        aggregateAccountBalance.setTitle(accountLongInfo.getTitle());
        aggregateAccountBalance.setType(accountLongInfo.getType());
        aggregateAccountBalance.setProductId(accountLongInfo.getProductId());
        aggregateAccountBalance.setSpriteIndex(accountLongInfo.getSpriteIndex());
        aggregateAccountBalance.setPriority(accountLongInfo.getPriority());
        aggregateAccountBalance.setAllowBalance(accountLongInfo.isAllowBalance());
        aggregateAccountBalance.setAllowCreateFinDoc(accountLongInfo.isAllowCreateFinDoc());
        aggregateAccountBalance.setAllowSubmitFinDoc(accountLongInfo.isAllowSubmitFinDoc());
        aggregateAccountBalance.setTermLength(accountLongInfo.getTermLength());
        aggregateAccountBalance.setCurrency(accountLongInfo.getCurrency());
        aggregateAccountBalance.setNumber(accountLongInfo.getNumber());
        aggregateAccountBalance.setInterestRate(accountLongInfo.getInterestRate());
        aggregateAccountBalance.setMultiCurrency(accountLongInfo.isMultiCurrency());
        aggregateAccountBalance.setParentAccountId(accountLongInfo.getParentAccountId());

        return aggregateAccountBalance;
    }
}
