package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Getter
@Setter
@Entity
@Table(name = "ApplicationFormType")
public class ApplicationFormType implements Serializable {

    private static final long serialVersionUID = 2357392518648565202L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ApplicationFormType_ID")
    private Long id;

    @Column(name = "ApplicationFormType_Code")
    private String code;

    @Column(name = "ApplicationFormType_Title")
    private String title;
}
