package kz.eubank.core.dashboard.domain.service;

import kz.eubank.core.dashboard.domain.model.dto.AccountBalanceInfo;
import kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard;

import java.util.List;

public interface IAccountBalanceInfo {

    List<? extends AccountBalanceInfo> getAccountBalances(List<EubAggregatorCoreDashboard.Account> esbAccounts);

    String getType();
}

