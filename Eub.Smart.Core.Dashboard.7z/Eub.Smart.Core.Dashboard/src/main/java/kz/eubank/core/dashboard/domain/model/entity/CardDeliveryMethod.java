package kz.eubank.core.dashboard.domain.model.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "CardDeliveryMethod")
public class CardDeliveryMethod {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CardDeliveryMethod_ID")
    private String code;

    @Column(name = "CardDeliveryMethod_Title")
    private String title;

    @Column(name = "IsActive")
    private boolean active;
}
