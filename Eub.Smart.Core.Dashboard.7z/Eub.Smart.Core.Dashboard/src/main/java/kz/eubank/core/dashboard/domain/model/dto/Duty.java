package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class Duty {

    private BigDecimal nextPaymentAmount;
    private BigDecimal amount;
    private Long nextPaymentDate;
    private Long dateClosed;
    private Long dateOpened;
    private Debt debt;
    private Debt delayedDebt;
    private Debt delayedDebtFine;
    private Long id;
    private BigDecimal interestRate;
    private String status;
    private String type;
    private String number;
    private BigDecimal overpayment;
}
