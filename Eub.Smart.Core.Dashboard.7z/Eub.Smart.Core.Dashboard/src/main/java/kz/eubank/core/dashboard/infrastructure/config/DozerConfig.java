package kz.eubank.core.dashboard.infrastructure.config;

import org.dozer.DozerBeanMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class DozerConfig {

    @Bean("dozerBeanMapper")
    public DozerBeanMapper initDozerBeanMapper() {
        List<String> myMappingFiles = new ArrayList<>();
        myMappingFiles.add("dozer_custom_convertor.xml");
        DozerBeanMapper mapper = new DozerBeanMapper();
        mapper.setMappingFiles(myMappingFiles);
        return mapper;
    }
}
