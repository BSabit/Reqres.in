package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@Entity
@Table(name = "LoanApplicationScoringStatus")
public class LoanApplicationScoringStatus {

    @Id
    @Column(name = "LoanApplicationScoringStatus_ID")
    private String id;

    @Column(name = "LoanApplicationScoringStatus_Title")
    private String title;
}
