package kz.eubank.core.dashboard.domain.model.dto;

import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import lombok.Generated;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Card extends CardBaseInfo {

    private Integer priority;
    private List<CardLimit> cardLimits = new ArrayList<>();
    private Long expiration;
    private Boolean allowCNP;
    private String cardTransactionStatus;
    private Boolean isPINSet;
    private Boolean isIVR;
    private String hash;
    private String type;
    private Boolean isDigital;

    public Boolean getAllowWebTransactions() {
        return this.allowCNP;
    }

    public void setAllowWebTransactions(final Boolean allowCNP) {
        this.allowCNP = allowCNP;
    }

    @Generated
    public Card() {
    }

    @Generated
    public Integer getPriority() {
        return this.priority;
    }

    @Generated
    public Collection<CardLimit> getCardLimits() {
        return this.cardLimits;
    }

    @Generated
    public Long getExpiration() {
        return this.expiration;
    }

    @Generated
    public Boolean getAllowCNP() {
        return this.allowCNP;
    }

    @Generated
    public String getCardTransactionStatus() {
        return this.cardTransactionStatus;
    }

    @Generated
    public Boolean getIsPINSet() {
        return this.isPINSet;
    }

    @Generated
    public Boolean getIsIVR() {
        return this.isIVR;
    }

    @Generated
    public String getHash() {
        return this.hash;
    }

    @Generated
    public String getType() {
        return this.type;
    }

    @Generated
    public Boolean getIsDigital() {
        return this.isDigital;
    }

    @Generated
    public void setPriority(final Integer priority) {
        this.priority = priority;
    }

    @Generated
    @JsonSetter(nulls = Nulls.AS_EMPTY)
    public void setCardLimits(final List<CardLimit> cardLimits) {
        this.cardLimits = cardLimits;
    }

    @Generated
    public void setExpiration(final Long expiration) {
        this.expiration = expiration;
    }

    @Generated
    public void setAllowCNP(final Boolean allowCNP) {
        this.allowCNP = allowCNP;
    }

    @Generated
    public void setCardTransactionStatus(final String cardTransactionStatus) {
        this.cardTransactionStatus = cardTransactionStatus;
    }

    @Generated
    public void setIsPINSet(final Boolean isPINSet) {
        this.isPINSet = isPINSet;
    }

    @Generated
    public void setIsIVR(final Boolean isIVR) {
        this.isIVR = isIVR;
    }

    @Generated
    public void setHash(final String hash) {
        this.hash = hash;
    }

    @Generated
    public void setType(final String type) {
        this.type = type;
    }

    @Generated
    public void setIsDigital(final Boolean isDigital) {
        this.isDigital = isDigital;
    }

    @Generated
    @Override
    public String toString() {
        return "Card(priority=" + this.getPriority() + ", cardLimits=" + this.getCardLimits() + ", expiration=" + this.getExpiration() + ", allowCNP=" + this.getAllowCNP() + ", cardTransactionStatus=" + this.getCardTransactionStatus() + ", isPINSet=" + this.getIsPINSet() + ", isIVR=" + this.getIsIVR() + ", hash=" + this.getHash() + ", type=" + this.getType() + ", isDigital=" + this.getIsDigital() + ")";
    }

    @Generated
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof Card)) {
            return false;
        }
        final Card other = (Card) o;
        if (!other.canEqual(this)) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }
        final Object this$priority = this.getPriority();
        final Object other$priority = other.getPriority();
        Label_0075:
        {
            if (this$priority == null) {
                if (other$priority == null) {
                    break Label_0075;
                }
            } else if (this$priority.equals(other$priority)) {
                break Label_0075;
            }
            return false;
        }
        final Object this$cardLimits = this.getCardLimits();
        final Object other$cardLimits = other.getCardLimits();
        Label_0112:
        {
            if (this$cardLimits == null) {
                if (other$cardLimits == null) {
                    break Label_0112;
                }
            } else if (this$cardLimits.equals(other$cardLimits)) {
                break Label_0112;
            }
            return false;
        }
        final Object this$expiration = this.getExpiration();
        final Object other$expiration = other.getExpiration();
        Label_0149:
        {
            if (this$expiration == null) {
                if (other$expiration == null) {
                    break Label_0149;
                }
            } else if (this$expiration.equals(other$expiration)) {
                break Label_0149;
            }
            return false;
        }
        final Object this$allowCNP = this.getAllowCNP();
        final Object other$allowCNP = other.getAllowCNP();
        Label_0186:
        {
            if (this$allowCNP == null) {
                if (other$allowCNP == null) {
                    break Label_0186;
                }
            } else if (this$allowCNP.equals(other$allowCNP)) {
                break Label_0186;
            }
            return false;
        }
        final Object this$cardTransactionStatus = this.getCardTransactionStatus();
        final Object other$cardTransactionStatus = other.getCardTransactionStatus();
        Label_0223:
        {
            if (this$cardTransactionStatus == null) {
                if (other$cardTransactionStatus == null) {
                    break Label_0223;
                }
            } else if (this$cardTransactionStatus.equals(other$cardTransactionStatus)) {
                break Label_0223;
            }
            return false;
        }
        final Object this$isPINSet = this.getIsPINSet();
        final Object other$isPINSet = other.getIsPINSet();
        Label_0260:
        {
            if (this$isPINSet == null) {
                if (other$isPINSet == null) {
                    break Label_0260;
                }
            } else if (this$isPINSet.equals(other$isPINSet)) {
                break Label_0260;
            }
            return false;
        }
        final Object this$isIVR = this.getIsIVR();
        final Object other$isIVR = other.getIsIVR();
        Label_0297:
        {
            if (this$isIVR == null) {
                if (other$isIVR == null) {
                    break Label_0297;
                }
            } else if (this$isIVR.equals(other$isIVR)) {
                break Label_0297;
            }
            return false;
        }
        final Object this$hash = this.getHash();
        final Object other$hash = other.getHash();
        Label_0334:
        {
            if (this$hash == null) {
                if (other$hash == null) {
                    break Label_0334;
                }
            } else if (this$hash.equals(other$hash)) {
                break Label_0334;
            }
            return false;
        }
        final Object this$type = this.getType();
        final Object other$type = other.getType();
        Label_0371:
        {
            if (this$type == null) {
                if (other$type == null) {
                    break Label_0371;
                }
            } else if (this$type.equals(other$type)) {
                break Label_0371;
            }
            return false;
        }
        final Object this$isDigital = this.getIsDigital();
        final Object other$isDigital = other.getIsDigital();
        if (this$isDigital == null) {
            return other$isDigital == null;
        } else return this$isDigital.equals(other$isDigital);
    }

    @Generated
    protected boolean canEqual(final Object other) {
        return other instanceof Card;
    }

    @Generated
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = super.hashCode();
        final Object $priority = this.getPriority();
        result = result * 59 + (($priority == null) ? 43 : $priority.hashCode());
        final Object $cardLimits = this.getCardLimits();
        result = result * 59 + (($cardLimits == null) ? 43 : $cardLimits.hashCode());
        final Object $expiration = this.getExpiration();
        result = result * 59 + (($expiration == null) ? 43 : $expiration.hashCode());
        final Object $allowCNP = this.getAllowCNP();
        result = result * 59 + (($allowCNP == null) ? 43 : $allowCNP.hashCode());
        final Object $cardTransactionStatus = this.getCardTransactionStatus();
        result = result * 59 + (($cardTransactionStatus == null) ? 43 : $cardTransactionStatus.hashCode());
        final Object $isPINSet = this.getIsPINSet();
        result = result * 59 + (($isPINSet == null) ? 43 : $isPINSet.hashCode());
        final Object $isIVR = this.getIsIVR();
        result = result * 59 + (($isIVR == null) ? 43 : $isIVR.hashCode());
        final Object $hash = this.getHash();
        result = result * 59 + (($hash == null) ? 43 : $hash.hashCode());
        final Object $type = this.getType();
        result = result * 59 + (($type == null) ? 43 : $type.hashCode());
        final Object $isDigital = this.getIsDigital();
        result = result * 59 + (($isDigital == null) ? 43 : $isDigital.hashCode());
        return result;
    }
}
