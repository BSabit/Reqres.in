package kz.eubank.core.dashboard.domain.model.response;

public class BonusSettings {
    private String spendingChannel;
    private boolean spendingAllowed;
    private String favoriteCategory;

    public String getSpendingChannel() {
        return this.spendingChannel;
    }

    public void setSpendingChannel(final String spendingChannel) {
        this.spendingChannel = spendingChannel;
    }

    public boolean isSpendingAllowed() {
        return this.spendingAllowed;
    }

    public void setSpendingAllowed(final boolean spendingAllowed) {
        this.spendingAllowed = spendingAllowed;
    }

    public String getFavoriteCategory() {
        return this.favoriteCategory;
    }

    public void setFavoriteCategory(final String favoriteCategory) {
        this.favoriteCategory = favoriteCategory;
    }
}
