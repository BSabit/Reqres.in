package kz.eubank.core.dashboard.domain.model.response;

import lombok.Generated;

import java.io.Serializable;

public class LoanApplicationStatus implements Serializable {
    private String id;
    private String title;
    private boolean isFinal;

    @Generated
    public LoanApplicationStatus() {
    }

    @Generated
    public String getId() {
        return this.id;
    }

    @Generated
    public String getTitle() {
        return this.title;
    }

    @Generated
    public boolean isFinal() {
        return this.isFinal;
    }

    @Generated
    public void setId(final String id) {
        this.id = id;
    }

    @Generated
    public void setTitle(final String title) {
        this.title = title;
    }

    @Generated
    public void setFinal(final boolean isFinal) {
        this.isFinal = isFinal;
    }

    @Generated
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof LoanApplicationStatus)) {
            return false;
        }
        final LoanApplicationStatus other = (LoanApplicationStatus) o;
        if (!other.canEqual(this)) {
            return false;
        }
        final Object this$id = this.getId();
        final Object other$id = other.getId();
        Label_0065:
        {
            if (this$id == null) {
                if (other$id == null) {
                    break Label_0065;
                }
            } else if (this$id.equals(other$id)) {
                break Label_0065;
            }
            return false;
        }
        final Object this$title = this.getTitle();
        final Object other$title = other.getTitle();
        if (this$title == null) {
            if (other$title == null) {
                return this.isFinal() == other.isFinal();
            }
        } else if (this$title.equals(other$title)) {
            return this.isFinal() == other.isFinal();
        }
        return false;
    }

    @Generated
    protected boolean canEqual(final Object other) {
        return other instanceof LoanApplicationStatus;
    }

    @Generated
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $id = this.getId();
        result = result * 59 + (($id == null) ? 43 : $id.hashCode());
        final Object $title = this.getTitle();
        result = result * 59 + (($title == null) ? 43 : $title.hashCode());
        result = result * 59 + (this.isFinal() ? 79 : 97);
        return result;
    }

    @Generated
    @Override
    public String toString() {
        return "LoanApplicationStatus(id=" + this.getId() + ", title=" + this.getTitle() + ", isFinal=" + this.isFinal() + ")";
    }
}
