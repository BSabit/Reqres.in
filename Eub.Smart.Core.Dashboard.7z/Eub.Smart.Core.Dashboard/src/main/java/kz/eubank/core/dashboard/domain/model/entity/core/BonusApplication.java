package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "BonusSpendApplication")
public class BonusApplication {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "BonusSpendApplication_id")
    private Long id;
    
    @OneToOne
    @JoinColumn(name = "Account_IDREF")
    private Account account;
}
