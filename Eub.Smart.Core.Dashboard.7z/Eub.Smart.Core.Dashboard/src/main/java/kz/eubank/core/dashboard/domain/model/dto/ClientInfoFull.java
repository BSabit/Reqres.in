package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class ClientInfoFull {

    private Long id;
    private Person person;
    private Corporation corporation;
    private ClientStatus status;
    private String typeCode;
    private List<BSystemClient> bSystemClientsList;
}
