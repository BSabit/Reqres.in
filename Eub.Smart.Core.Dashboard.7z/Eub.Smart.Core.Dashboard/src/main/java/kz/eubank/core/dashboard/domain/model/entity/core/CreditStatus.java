package kz.eubank.core.dashboard.domain.model.entity.core;

import javax.persistence.*;

@Entity
@Table(name = "CreditStatus")
public class CreditStatus {

    @Id
    @Column(name = "CreditStatus_ID")
    private String code;

    @Column(name = "CreditStatus_Title")
    private String title;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;

    public String getCode() {
        return code;
    }

    public String getTitle() {
        return title;
    }

    public Term getTerms() {
        return terms;
    }

    public void setTerms(Term terms) {
        this.terms = terms;
    }
}
