package kz.eubank.core.dashboard.domain.model.mapper;

import kz.eubank.core.dashboard.domain.model.entity.TempDigitalCard;
import org.mapstruct.Mapper;

import java.util.Date;
import java.util.List;

@Mapper(componentModel = "spring")
public interface TempDigitalCardMapper {

    List<TempDigitalCard> toTempDigitalCardEntityList(List<kz.eubank.core.dashboard.domain.model.dto.TempDigitalCard> digitalCardDtos);

    List<kz.eubank.core.dashboard.domain.model.dto.TempDigitalCard> toTempDigitalCardDtoList(List<TempDigitalCard> digitalCards);

    TempDigitalCard toTempDigitalCardEntity(kz.eubank.core.dashboard.domain.model.dto.TempDigitalCard digitalCardDto);

    kz.eubank.core.dashboard.domain.model.dto.TempDigitalCard toTempDigitalCardDto(TempDigitalCard digitalCard);

    default Long dateInLongFromCreatedDate(Date date) {
        return date != null ? date.getTime() : null;
    }

    default Date createdDateFromDateInLong(Long dateLong) {
        if (dateLong != null) {
            return new Date(dateLong);
        }
        return null;
    }
}
