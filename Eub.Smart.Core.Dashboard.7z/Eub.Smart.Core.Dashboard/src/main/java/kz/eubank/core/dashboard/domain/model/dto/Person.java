package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class Person {

    private Long id;
    private String firstName;
    private String lastName;
    private String fathersName;
    private Date birthDate;
    private boolean resident;
    private boolean affiliated;
    private boolean employee;
    private boolean salaryAccount;
    private String iin;
    private String rnn;
    private String sik;
    private PersonStatus status;
    private ClientRank clientRank;
    private String birthPlace;
    private Gender gender;
}
