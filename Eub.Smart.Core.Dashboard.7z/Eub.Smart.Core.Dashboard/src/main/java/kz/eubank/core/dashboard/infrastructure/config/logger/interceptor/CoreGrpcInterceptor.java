//package kz.eubank.core.dashboard.infrastructure.config.logger.interceptor;
//
//import io.grpc.*;
//import kz.eubank.core.dashboard.core.util.StringUtil;
//import lombok.extern.log4j.Log4j2;
//import lombok.extern.slf4j.Slf4j;
//import net.devh.boot.grpc.client.interceptor.GrpcGlobalClientInterceptor;
//import org.slf4j.MDC;
//
//import static java.util.Objects.nonNull;
//import static kz.eubank.core.dashboard.core.constants.HeaderName.CORRELATION_ID;
//import static kz.eubank.core.dashboard.core.constants.LogEventType.EXTERNAL_CALL_gRPC;
//
//@Slf4j
//@GrpcGlobalClientInterceptor
//public class CoreGrpcInterceptor implements ClientInterceptor {
//
//    @Override
//    public <ReqT, RespT> ClientCall<ReqT, RespT> interceptCall(final MethodDescriptor<ReqT, RespT> method, final CallOptions callOptions, final Channel next) {
//
//        return new ForwardingClientCall.SimpleForwardingClientCall<>(next.newCall(method, callOptions)) {
//
//
//            @Override
//            public void sendMessage(ReqT message) {
//                if (nonNull(MDC.get(CORRELATION_ID))) {
//                    log.info("Event-Type={}, gRPC Request:[serviceName={}, method={}, message={}]",
//                            EXTERNAL_CALL_gRPC,
//                            method.getServiceName(),
//                            method.getBareMethodName(),
//                            StringUtil.removeAllLineBreakers(message));
//                }
//                super.sendMessage(message);
//            }
//
//            @Override
//            public void start(Listener<RespT> responseListener, Metadata headers) {
//                Metadata.Key<String> key = Metadata.Key.of(CORRELATION_ID, Metadata.ASCII_STRING_MARSHALLER);
//                if (nonNull(MDC.get(CORRELATION_ID))) headers.put(key, MDC.get(CORRELATION_ID));
//                super.start(new ForwardingClientCallListener.SimpleForwardingClientCallListener<>(responseListener) {
//                    @Override
//                    public void onMessage(RespT message) {
//                        if (nonNull(MDC.get(CORRELATION_ID))) {
//                            log.info("Event-Type={}, gRPC Response:[serviceName={}, method={}, message={}]",
//                                    EXTERNAL_CALL_gRPC,
//                                    method.getServiceName(),
//                                    method.getBareMethodName(),
//                                    StringUtil.removeAllLineBreakers(message));
//                        }
//                        super.onMessage(message);
//                    }
//
//                    @Override
//                    public void onClose(Status status, Metadata trailers) {
//                        if (nonNull(MDC.get(CORRELATION_ID))) {
//                            log.info("Event-Type={}, gRPC Response:[serviceName={}, method={}, status={}]",
//                                    EXTERNAL_CALL_gRPC,
//                                    method.getServiceName(),
//                                    method.getBareMethodName(),
//                                    StringUtil.removeAllLineBreakers(status));
//                        }
//                        super.onClose(status, trailers);
//                    }
//                }, headers);
//            }
//        };
//    }
//}
