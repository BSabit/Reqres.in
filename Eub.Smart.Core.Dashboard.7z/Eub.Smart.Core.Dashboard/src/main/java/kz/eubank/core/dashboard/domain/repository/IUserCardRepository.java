package kz.eubank.core.dashboard.domain.repository;

import kz.eubank.core.dashboard.domain.model.entity.UserCard_PK;
import kz.eubank.core.dashboard.domain.model.entity.UserCard;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface IUserCardRepository extends CrudRepository<UserCard, UserCard_PK> {

    @Query("select uc from UserCard uc where uc.id.userId=?1 and uc.id.cardId in (?2)")
    List<UserCard> findUserCards(final Long p0, final List<Long> p1);
}
