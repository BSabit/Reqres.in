package kz.eubank.core.dashboard.domain.gate;

import kz.eubank.core.dashboard.domain.model.dto.CardDeliveryApplication;

import java.util.List;

public interface CardDeliveryApplicationGate {

    List<CardDeliveryApplication> getProcessedCard(Long userId);
}
