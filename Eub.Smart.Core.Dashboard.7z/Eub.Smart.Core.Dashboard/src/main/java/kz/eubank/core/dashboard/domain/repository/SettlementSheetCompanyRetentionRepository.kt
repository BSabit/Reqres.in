package kz.eubank.core.dashboard.domain.repository

import kz.eubank.core.dashboard.domain.model.entity.SettlementSheetCompanyRetention
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface SettlementSheetCompanyRetentionRepository : JpaRepository<SettlementSheetCompanyRetention, Long> {
    fun findBySheetId(settlementSheetId: Long): List<SettlementSheetCompanyRetention>
}