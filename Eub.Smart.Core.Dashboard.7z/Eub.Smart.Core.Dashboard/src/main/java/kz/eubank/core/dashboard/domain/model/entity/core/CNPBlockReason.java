package kz.eubank.core.dashboard.domain.model.entity.core;


import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Getter
@Setter
@Entity
@Table(name = "CNPBlockReason")
public class CNPBlockReason implements Serializable {

    private static final long serialVersionUID = 5659196516898100412L;

    @Id
    @Column(name = "CNPBlockReason_ID")
    private String code;

    @Column(name = "CNPBlockReason_Title")
    private String title;

    @Column(name = "IsClosed")
    private boolean closed;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;

    @Column(name = "AvailableDates")
    private Integer availableDates;
}
