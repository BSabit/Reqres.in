package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;

@Getter
@Setter
@Entity
@Table(name = "Usage")
public class Usage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Usage_ID")
    private Long id;

    @Column(name = "Currency")
    private String limitCurrency;

    @Column(name = "Limit_FinDoc")
    private BigDecimal limitFinDoc;

    @Column(name = "Limit_Day")
    private BigDecimal limitDay;

    @Column(name = "Limit_Week")
    private BigDecimal limitWeek;

    @Column(name = "Limit_Month")
    private BigDecimal limitMonth;

    @Column(name = "Usage_Title")
    private String usageTitle;

    @Column(name = "IsDefault", insertable = false, updatable = false)
    private boolean defaultValue;

    @Column(name = "Term_OUTREF")
    private String term;
}
