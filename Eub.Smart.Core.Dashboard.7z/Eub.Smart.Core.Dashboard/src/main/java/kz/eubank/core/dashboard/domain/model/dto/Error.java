package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Error {

    private String code;
    private String msg;
}
