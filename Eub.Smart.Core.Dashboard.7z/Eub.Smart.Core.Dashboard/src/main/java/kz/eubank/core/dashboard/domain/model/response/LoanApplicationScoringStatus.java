package kz.eubank.core.dashboard.domain.model.response;

import lombok.Generated;

public class LoanApplicationScoringStatus {
    private String id;
    private String title;

    @Generated
    public LoanApplicationScoringStatus() {
    }

    @Generated
    public String getId() {
        return this.id;
    }

    @Generated
    public String getTitle() {
        return this.title;
    }

    @Generated
    public void setId(final String id) {
        this.id = id;
    }

    @Generated
    public void setTitle(final String title) {
        this.title = title;
    }

    @Generated
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof LoanApplicationScoringStatus)) {
            return false;
        }
        final LoanApplicationScoringStatus other = (LoanApplicationScoringStatus) o;
        if (!other.canEqual((Object) this)) {
            return false;
        }
        final Object this$id = this.getId();
        final Object other$id = other.getId();
        Label_0065:
        {
            if (this$id == null) {
                if (other$id == null) {
                    break Label_0065;
                }
            } else if (this$id.equals(other$id)) {
                break Label_0065;
            }
            return false;
        }
        final Object this$title = this.getTitle();
        final Object other$title = other.getTitle();
        if (this$title == null) {
            return other$title == null;
        } else return this$title.equals(other$title);
    }

    @Generated
    protected boolean canEqual(final Object other) {
        return other instanceof LoanApplicationScoringStatus;
    }

    @Generated
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $id = this.getId();
        result = result * 59 + (($id == null) ? 43 : $id.hashCode());
        final Object $title = this.getTitle();
        result = result * 59 + (($title == null) ? 43 : $title.hashCode());
        return result;
    }

    @Generated
    @Override
    public String toString() {
        return "LoanApplicationScoringStatus(id=" + this.getId() + ", title=" + this.getTitle() + ")";
    }
}
