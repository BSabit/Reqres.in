package kz.eubank.core.dashboard.domain.model.entity.core;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "LoanApplication")
public class LoanApplication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "LoanApplication_ID")
    private Long id;

    @OneToOne
    @JoinColumn(name = "Application_IDREF")
    private Application application;

    @OneToOne
    @JoinColumn(name = "LoanCalcInfo_IDREF")
    private LoanCalcInfo loanCalcInfo;

    @Column(name = "DateCreated")
    private Date dateCreated;

    @Column(name = "Amount")
    private BigDecimal amount;

    @Column(name = "Period")
    private int period;

    @Column(name = "IsPensioner")
    private boolean isPensioner;

    @Column(name = "IsIndividualEntrepreneur")
    private boolean isIndividualEntrepreneur;

    @Column(name = "HasNotIncome")
    private boolean hasNotIncome;

    @Column(name = "EmployerBinFromBS")
    private String employerBinFromBS;

    @Column(name = "EmployerNameFromBS")
    private String employerNameFromBS;

    @Column(name = "PartnerCode")
    private String partnerCode;

    @Column(name = "PartnerId")
    private String partnerId;

    @Column(name = "SubProductName")
    private String subProductName;

    @Column(name = "SubProductCode")
    private String subProductCode;

    @Column(name = "InsuranceDefaultValueOn")
    private boolean insuranceDefaultValueOn;

    @Column(name = "InsuranceOrgName")
    private String insuranceOrgName;

    @Column(name = "InsurancePackage")
    private String insurancePackage;

    @Column(name = "OfficialIncomeAmount")
    private BigDecimal officialIncomeAmount;

    @Column(name = "AdditionalIncomeAmount")
    private BigDecimal additionalIncomeAmount;

    @Column(name = "AnotherLoanAmount")
    private BigDecimal anotherLoanAmount;

    @Column(name = "EmployerName")
    private String employerName;

    @Column(name = "EmployerPhoneNumber")
    private String employerPhoneNumber;

    @Column(name = "ContactPerson")
    private String contactPerson;

    @Column(name = "ContactPersonPhone")
    private String contactPersonPhone;

    @Column(name = "Staff")
    private String staff;

    @Column(name = "IBAN")
    private String iban;

    @Column(name = "BIC")
    private String bic;

    @Column(name = "BIN")
    private String bin;

    @Column(name = "LoanContractNumber")
    private String loanContractNumber;

    @Column(name = "BranchCode")
    private String branchCode;

    @Column(name = "MaritalStatus")
    private String maritalStatus;

    @Column(name = "ChildCount")
    private int childCount;

    @Column(name = "InsurancePetition_OUTREF")
    private Integer insurancePetition;

    @Column(name = "InsurancePackagePercent")
    private String insurancePackagePercent;

    @Column(name = "InsuranceAmount")
    private BigDecimal insuranceAmount;

    @OneToOne
    @JoinColumn(name = "PreApprovedLoans_IDREF")
    private PreApprovedLoans preApprovedLoans;

    @OneToOne(mappedBy = "loanApplication")
    private LoanApplicationState loanApplicationState;

    @OneToMany(mappedBy = "loanApplication", fetch = FetchType.EAGER)
    @JsonManagedReference
    private List<LoanApplicationScoring> loanApplicationScorings;
}
