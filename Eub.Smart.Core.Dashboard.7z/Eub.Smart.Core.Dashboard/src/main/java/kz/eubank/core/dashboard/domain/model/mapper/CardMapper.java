package kz.eubank.core.dashboard.domain.model.mapper;

import kz.eubank.core.dashboard.domain.model.dto.CardLongInfo;
import kz.eubank.core.dashboard.domain.model.dto.CardStatus;
import kz.eubank.core.dashboard.domain.model.dto.CardXml;
import kz.eubank.core.dashboard.domain.model.entity.core.Card;
import kz.eubank.core.dashboard.domain.model.enums.CardType;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.Collection;

@Mapper(componentModel = "spring")
public interface CardMapper {

    CardXml[] toCard(Collection<CardLongInfo> cardLongInfos);

    @Mapping(target = "type", expression = "java(java.util.Objects.toString(toCardType(cardLongInfo.getTypeTitle()), \"0\"))")
    CardXml toCard(CardLongInfo cardLongInfo);

    @Mapping(source = "maskedNumber", target = "number")
    @Mapping(target = "type", expression = "java(card.getType() == null ? null : card.getType().getCode())")
    @Mapping(target = "typeTitle", expression = "java(card.getType() == null ? null : card.getType().getTitle())")
    @Mapping(target = "status", expression = "java(card.getStatus() == null ? null : new kz.eubank.core.dashboard.domain.model.dto.CardStatus(card.getStatus().getCode(), card.getStatus().getTitle()))")
    @Mapping(target = "account.type", ignore = true)
    @Mapping(target = "account.status", ignore = true)
    CardLongInfo toCardLongInfo(Card card);

    default kz.eubank.core.dashboard.domain.model.enums.CardStatus toCardStatus(CardStatus cardStatus) {
        if (cardStatus == null) {
            return null;
        }
        return kz.eubank.core.dashboard.domain.model.enums.CardStatus.getValue(cardStatus.getCode());
    }

    default CardType toCardType(String typeTitle) {
        if (typeTitle == null) {
            return null;
        }
        return CardType.fromString(typeTitle);
    }
}