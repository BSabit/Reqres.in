package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;

@Getter
@Setter
@Entity
@Table(name = "DepositProduct")
public class DepositProduct {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DepositProduct_ID")
    private Long id;

    @Column(name = "DepositProduct_Title")
    private String title;

    @OneToOne
    @JoinColumn(name = "Product_IDREF")
    private Product product;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;

    @Column(name = "Period_Months")
    private int periodMonths;

    @Column(name = "InterestRate")
    private BigDecimal interestRate;

    @Column(name = "CanAdd")
    private boolean canAdd;

    @Column(name = "CanWithdraw")
    private boolean canWithdraw;

    @Column(name = "Prolongations")
    private int prolongations;

    @Column(name = "MinBalance")
    private BigDecimal minBalance;

    @Column(name = "MaxBalance")
    private BigDecimal maxBalance;

    @Column(name = "Product_OUTREF")
    private String productOutref;

    @Column(name = "ProductCompound_OUTREF")
    private String productCompoundOutref;

    @OneToOne
    @JoinColumn(name = "DepositType_IDREF")
    private DepositType type;

    @Column(name = "EffectiveRate")
    private BigDecimal effectiveRate;

    @Column(name = "AllowInterestIBAN")
    private boolean allowInterest;
}
