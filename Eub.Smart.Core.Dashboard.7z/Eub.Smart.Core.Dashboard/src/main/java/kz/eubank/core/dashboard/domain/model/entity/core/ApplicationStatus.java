package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Objects;

@Getter
@Setter
@Entity
@Table(name = "ApplicationStatus")
public class ApplicationStatus {

    @Id
    @Column(name = "ApplicationStatus_ID")
    private String code;

    @Column(name = "ApplicationStatus_Title")
    private String title;

    @Column(name = "IsFinal")
    private boolean _final;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;

    public void changeTitleLanguage(String language) {
        if (Objects.isNull(getTerms())) {
            return;
        }
        if ("ru".equals(language)) {
            setTitle(getTerms().getTermRU());
        } else if ("en".equals(language)) {
            setTitle(getTerms().getTermEN());
        } else if ("kz".equals(language)) {
            setTitle(getTerms().getTermKZ());
        }
    }
}
