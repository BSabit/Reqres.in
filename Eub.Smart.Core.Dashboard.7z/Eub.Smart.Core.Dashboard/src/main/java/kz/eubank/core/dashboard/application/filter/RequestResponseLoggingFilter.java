package kz.eubank.core.dashboard.application.filter;

import kz.eubank.core.dashboard.application.filter.logger.AccessLogger;
import kz.eubank.core.dashboard.application.filter.logger.RequestResponseLogger;
import kz.eubank.core.dashboard.core.component.AuthToken;
import kz.eubank.core.dashboard.core.model.UserDetails;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static kz.eubank.core.dashboard.core.constants.MdcConstants.X_FORWARDED_FOR;
import static kz.eubank.core.dashboard.core.constants.HeaderName.*;
import static kz.eubank.core.dashboard.core.constants.UserDetails.*;

@Component
public class RequestResponseLoggingFilter extends OncePerRequestFilter {

    private final AccessLogger accessLogger;
    private final AuthToken authToken;
    private final RequestResponseLogger reqResLogger;
    private final HttpServletRequest request;

    public RequestResponseLoggingFilter(AccessLogger accessLogger,
                                        AuthToken authToken,
                                        RequestResponseLogger reqResLogger,
                                        HttpServletRequest request) {
        this.accessLogger = accessLogger;
        this.authToken = authToken;
        this.reqResLogger = reqResLogger;
        this.request = request;
    }

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain) throws ServletException, IOException {
        ContentCachingRequestWrapper requestWrapper = new ContentCachingRequestWrapper(request);
        ContentCachingResponseWrapper responseWrapper = new ContentCachingResponseWrapper(response);

        addToMDC();
        filterChain.doFilter(requestWrapper, responseWrapper);
        reqResLogger.log(requestWrapper, responseWrapper);
        responseWrapper.copyBodyToResponse();
    }

    private void addToMDC() {
        String payload = authToken.getDecodedPayload();
        UserDetails userDetails = UserDetails.build(payload);
        MDC.put(PREFERRED_USERNAME, userDetails.getPreferredUsername());
        MDC.put(USER_ID, userDetails.getUserId().toString());
        MDC.put(CLIENT_ID, userDetails.getClientId().toString());
        MDC.put(IIN, userDetails.getIin());
        MDC.put(X_FORWARDED_FOR, accessLogger.getClientIp());
        MDC.put(CORRELATION_ID, request.getHeader(CORRELATION_ID));
    }
}
