package kz.eubank.core.dashboard.core.constants;

public interface HeaderName {

    String CORRELATION_ID = "X-Correlation-Id";
    String FRONT_END_ID = "Front-End-Id";
}
