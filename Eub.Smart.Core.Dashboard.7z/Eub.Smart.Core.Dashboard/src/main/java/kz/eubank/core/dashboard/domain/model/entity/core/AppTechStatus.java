package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "AppTechStatus")
public class AppTechStatus {

    @Id
    @Column(name = "AppTechStatus_ID")
    private String code;

    @Column(name = "AppTechStatus_Title")
    private String title;

    @OneToOne
    @JoinColumn(name = "ApplicationStatus_IDREF")
    private ApplicationStatus status;

    @Column(name = "IsFinal")
    private boolean _final;

    @OneToOne
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;
}
