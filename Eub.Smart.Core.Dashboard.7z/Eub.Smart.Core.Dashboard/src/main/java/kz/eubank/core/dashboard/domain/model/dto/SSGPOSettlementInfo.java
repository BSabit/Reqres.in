package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class SSGPOSettlementInfo {

    private BigDecimal accrualRate;
    private BigDecimal amount;
    private String code;
    private String codeDesc;
    private String codeDescShort;
    private String settlementMonth;
    private String settlementType;
}
