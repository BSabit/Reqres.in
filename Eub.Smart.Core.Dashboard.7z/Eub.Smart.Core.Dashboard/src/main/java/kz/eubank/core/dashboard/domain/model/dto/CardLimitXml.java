package kz.eubank.core.dashboard.domain.model.dto;

import kz.eubank.core.dashboard.domain.model.enums.CardLimitIntervalType;
import kz.eubank.core.dashboard.domain.model.enums.CardLimitType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;

@Setter
@Getter
@XmlRootElement
//@Entity//todo
@NoArgsConstructor
public class CardLimitXml implements Serializable {

    private static final long serialVersionUID = 985747972858283145L;

    private CardLimitIntervalType intervalType;
    private int interval;
    private CardLimitType type;
    private BigDecimal amount;
    private String currency;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }
}
