package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Setter
@Getter
public class Interest {

    private BigDecimal amountBySchedule;
    private BigDecimal amountOverdue;
    private BigDecimal balanceBySchedule;
    private BigDecimal distributedAmountBySchedule;
    private BigDecimal distributedBalanceBySchedule;
    private BigDecimal graceAmountBySchedule;
    private BigDecimal graceBalanceBySchedule;
    private BigDecimal interestOnToday;
    private BigDecimal total;
}
