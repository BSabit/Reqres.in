package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Setter
@Getter
@Entity
@Table(name = "FavoriteCategoryDetails")
public class FavoriteCategoryDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "FavoriteCategoryDetails_ID")
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "FavoriteCategory_IDREF")
    private FavoriteCategory category;

    @Column(name = "CardTypeTitle")
    private String title;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;

    @Column(name = "ImageAddress")
    private String imageAddress;

    @Column(name = "MaxPercent")
    private Double maxPercent;
}
