package kz.eubank.core.dashboard.domain.gate;

import kz.eubank.core.dashboard.domain.model.dto.AccountLongInfo;

public interface WebServiceGate {

    AccountLongInfo getAccountDetails(final String p0, AccountLongInfo accountLongInfo);
}
