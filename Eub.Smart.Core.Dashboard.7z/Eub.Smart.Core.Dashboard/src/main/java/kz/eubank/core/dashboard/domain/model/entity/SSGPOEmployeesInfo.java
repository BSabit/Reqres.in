package kz.eubank.core.dashboard.domain.model.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;

@Getter
@Setter
@Entity
@Table(name = "SSGPOEmployeesInfo")
public class SSGPOEmployeesInfo {

    @Id
    @Column(name = "SSGPOEmployeesInfo_ID")
    private String id;

    @OneToOne
    @JoinColumn(name = "SSGPOTickets_IDREF")
    private SSGPOTickets ssgpoTickets;

    @OneToOne
    @JoinColumn(name = "SSGPOCodeDictionary_IDREF")
    private SSGPOCodeDictionary ssgpoCodeDictionary;

    @Column(name = "PersonFio")
    private String personFio;

    @Column(name = "PersonIIN")
    private String personIIN;

    @Column(name = "PersonNumber")
    private String personNumber;

    @Column(name = "AccrualAmount")
    private BigDecimal accrualAmount;

    @Column(name = "RetentionAmount")
    private BigDecimal retentionAmount;

    @Column(name = "SocialRetentionAmount")
    private BigDecimal socialRetentionAmount;

    @Column(name = "TotalAmount")
    private BigDecimal totalAmount;

    @Column(name = "ChtsAmount")
    private BigDecimal chtsAmount;

    @Column(name = "OppvAmount")
    private BigDecimal oppvAmount;

    @Column(name = "OsmsAmount")
    private BigDecimal osmsAmount;
}
