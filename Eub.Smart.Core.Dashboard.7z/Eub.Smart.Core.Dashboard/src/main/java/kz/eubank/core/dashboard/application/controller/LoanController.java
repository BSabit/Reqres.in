package kz.eubank.core.dashboard.application.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import kz.eubank.core.dashboard.domain.model.response.APIResponse;
import kz.eubank.core.dashboard.domain.model.response.AccountList;
import kz.eubank.core.dashboard.domain.model.response.LoanApplicationList;
import kz.eubank.core.dashboard.domain.service.ILoanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

@RestController
@RequestMapping("loan")
@SecurityRequirement(name = "Bearer Authentication")
@Tag(name = "Кредиты", description = "LoanController")
public class LoanController {

    @Autowired
    private ILoanService creditService;

    @Operation(summary = "list", description = "Список кредитов")
    @GetMapping("list")
    public APIResponse<AccountList> getListCredits(@RequestHeader(value = "language", defaultValue = "ru") String language) {
        return (APIResponse<AccountList>) new APIResponse(creditService.getListCredits());
    }

    @Operation(summary = "requests", description = "Заявки по кредиту")
    @Parameters({
            @Parameter(name = "dateFrom", description = "dateFrom", required = true),
            @Parameter(name = "dateTo", description = "dateTo", required = true),
            @Parameter(name = "page", description = "page", required = true),
            @Parameter(name = "pageSize", description = "pageSize", required = true)
    })
    @GetMapping("requests")
    public APIResponse<LoanApplicationList> getRequestsList(@RequestParam("dateFrom") @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateFrom,
                                                            @RequestParam("dateTo") @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateTo,
                                                            @RequestParam(defaultValue = "0") int page,
                                                            @RequestParam(defaultValue = "10") int pageSize,
                                                            @RequestHeader(value = "language", defaultValue = "ru") String language) {
        return (APIResponse<LoanApplicationList>) new APIResponse(
                creditService.getRequestsList(dateFrom, dateTo, page, pageSize, language));
    }
}
