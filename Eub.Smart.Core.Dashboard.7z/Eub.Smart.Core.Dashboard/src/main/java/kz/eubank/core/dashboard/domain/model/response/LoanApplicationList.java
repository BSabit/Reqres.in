// 
// Decompiled by Procyon v0.5.36
// 

package kz.eubank.core.dashboard.domain.model.response;

import lombok.Generated;

import java.util.Collection;

public class LoanApplicationList {
    private Collection<LoanApplicationResponse> items;

    public LoanApplicationList() {
    }

    public LoanApplicationList(final Collection<LoanApplicationResponse> items) {
        this.items = items;
    }

    public int getSize() {
        return (this.items != null) ? this.items.size() : 0;
    }

    @Generated
    public Collection<LoanApplicationResponse> getItems() {
        return this.items;
    }

    @Generated
    public void setItems(final Collection<LoanApplicationResponse> items) {
        this.items = items;
    }
}
