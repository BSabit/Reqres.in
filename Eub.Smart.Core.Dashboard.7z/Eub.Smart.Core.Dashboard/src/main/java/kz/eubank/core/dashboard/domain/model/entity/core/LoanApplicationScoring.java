package kz.eubank.core.dashboard.domain.model.entity.core;

import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "LoanApplicationScoring")
public class LoanApplicationScoring {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "LoanApplicationScoring_ID")
    private Long id;

    @Column(name = "DateCreated")
    private Date created;

    @ManyToOne
    @JoinColumn(name = "LoanApplication_IDREF")
    @JsonBackReference
    private LoanApplication loanApplication;

    @OneToOne
    @JoinColumn(name = "LoanApplicationScoringStatus_IDREF")
    private LoanApplicationScoringStatus loanApplicationScoringStatus;

    @Column(name = "StatusComment")
    private String statusComment;

    @Column(name = "CredilogicStatus")
    private String credilogicStatus;

    @Column(name = "FullLoanAmount")
    private BigDecimal fullLoanAmount;

    @Column(name = "LoanAmount")
    private BigDecimal loanAmount;

    @Column(name = "CommissionAmount")
    private BigDecimal commissionAmount;

    @Column(name = "FeeAmount")
    private BigDecimal feeAmount;

    @Column(name = "InsuranceAmount")
    private BigDecimal insuranceAmount;

    @Column(name = "Period")
    private Integer period;

    @Column(name = "APR")
    private Double apr;

    @Column(name = "TotalInstallment")
    private BigDecimal totalInstallment;

    @Column(name = "FileStorage_OUTREF")
    private Long fileStorageId;
}
