package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name = "Product")
public class Product {

    @Id
    @Column(name = "Product_ID")
    private Long id;

    @Column(name = "Currency")
    private String currency;

    @Column(name = "Product_Title")
    private String title;

    @Column(name = "IsCorporate")
    private boolean corporate;

    @OneToOne
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;
}
