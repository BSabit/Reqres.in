package kz.eubank.core.dashboard.domain.model.converter;

import kz.eubank.core.dashboard.domain.model.dto.DepositAccount;
import kz.eubank.core.dashboard.domain.model.dto.DepositContractInfo;
import org.dozer.CustomConverter;
import org.springframework.beans.BeanUtils;

import java.math.BigDecimal;

public class DepositAccountInfoToDepositAccountConverter implements CustomConverter {

    @Override
    public Object convert(Object dest, Object source, Class<?> arg2, Class<?> arg3) {
        if (source == null) {
            return null;
        }
        if (source instanceof DepositContractInfo) {
            DepositContractInfo depositContractInfo = (DepositContractInfo) source;

            DepositAccount depositAccount = new DepositAccount();
            depositAccount.setActions(depositContractInfo.getActions());
            depositAccount.setCurrency(depositContractInfo.getCurrency());
            depositAccount.setNumber(depositContractInfo.getNumber());
            depositAccount.setTitle(depositContractInfo.getTitle());
            depositAccount.setType(depositContractInfo.getTitle());
            depositAccount.setAllowBalance(depositContractInfo.isAllowBalance());
            depositAccount.setAllowCreateFinDoc(depositContractInfo.isAllowCreateFinDoc());
            depositAccount.setActualBalance(depositContractInfo.getActualBalance());
            depositAccount.setBalance(depositContractInfo.getBalance());
            depositAccount.setBlockedSum(depositContractInfo.getBlockedSum() == null ? BigDecimal.ZERO
                    : depositContractInfo.getBlockedSum());
            depositAccount.setDateOpened(depositContractInfo.getDateOpened() == null ? null
                    : depositContractInfo.getDateOpened().getTime());
            depositAccount.setInterestRate(depositContractInfo.getInterestRate());
            depositAccount.setDateClosed(depositContractInfo.getDateClosed() == null ? 0
                    : depositContractInfo.getDateClosed().getTime());
            depositAccount.setAccruedAmountForMonth(depositContractInfo.getAccruedAmountForMonth());
            depositAccount.setAccruedAmountTotal(depositContractInfo.getAccruedAmountTotal());
            depositAccount.setMinBalance(depositContractInfo.getMinBalance());

            depositAccount.setEffectiveRate(depositContractInfo.getEffectiveRate());

            return depositAccount;
        } else if (source instanceof DepositAccount) {//todo remove
            DepositAccount depositAccount = (DepositAccount) source;
            DepositContractInfo depositContractInfo = new DepositContractInfo();
            BeanUtils.copyProperties(depositAccount, depositContractInfo);
            return depositContractInfo;
        }
        return null;
    }
}