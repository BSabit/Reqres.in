package kz.eubank.core.dashboard.domain.service.impl;

import kz.eubank.core.dashboard.infrastructure.config.ApplicationContext;
import kz.eubank.core.dashboard.domain.gate.CardDeliveryApplicationGate;
import kz.eubank.core.dashboard.domain.model.dto.PrecessedCardResponse;
import kz.eubank.core.dashboard.domain.model.dto.PrecessedCardResponseList;
import kz.eubank.core.dashboard.domain.model.mapper.PrecessedCardResponseMapper;
import kz.eubank.core.dashboard.domain.service.CardDeliveryApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CardDeliveryApplicationServiceImpl implements CardDeliveryApplicationService {

    @Autowired
    private ApplicationContext context;
    @Autowired
    private CardDeliveryApplicationGate cardDeliveryApplicationGate;
    @Autowired
    private PrecessedCardResponseMapper precessedCardResponseMapper;

    @Override
    public PrecessedCardResponseList getProcessedCards() {
        Long userId = context.getCurrentUser().getUserId();
        List<PrecessedCardResponse> precessedCardResponses =
                precessedCardResponseMapper.toPrecessedCardResponseList(cardDeliveryApplicationGate.getProcessedCard(userId));
        return new PrecessedCardResponseList(precessedCardResponses);
    }
}
