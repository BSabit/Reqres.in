package kz.eubank.core.dashboard.domain.model.dto;

import kz.eubank.core.dashboard.domain.model.response.Account;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CurrentAccount extends Account {

    private String branchTitle;
    private Long dateClosed;
    private Long dateOpened;
    private Integer interestRate;
    private Limits limits;
    private Integer minBalance;

    public CurrentAccount() {
        this.setType("CURR");
    }

    public String toString() {
        return "CurrentAccount [balance=" + this.getBalance() + ", actualBalance=" + this.getActualBalance() +
                ", blockedSum=" + this.getBlockedSum() + ", branchTitle=" + this.branchTitle + ", dateClosed="
                + this.dateClosed + ", dateOpened=" + this.dateOpened + ", interestRate=" + this.interestRate
                + ", limits=" + this.limits + ", minBalance=" + this.minBalance + ", number=" + this.getNumber()
                + ", status=" + this.getStatus() + ", type=" + this.getType() + "]";
    }
}
