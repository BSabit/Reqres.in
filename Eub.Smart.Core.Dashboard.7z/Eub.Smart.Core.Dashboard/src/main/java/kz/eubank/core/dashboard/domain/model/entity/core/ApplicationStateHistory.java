package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "ApplicationStateHistory")
public class ApplicationStateHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ApplicationStateHistory_ID")
    private Long id;

    @Column(name = "Application_IDREF", insertable = false, updatable = false)
    private Long applicationId;

    @Column(name = "Attempts")
    private int attempts;

    @Column(name = "StatusDate")
    private Date statusDate;

    @Column(name = "TechScheduled")
    private Date techScheduled;

    @OneToOne
    @JoinColumn(name = "AppTechStatus_IDREF")
    private AppTechStatus techStatus;

    @Column(name = "AppTechStatusComment")
    private String techStatusComment;

    @Column(name = "Process_ID")
    private String processId;

    @Column(name = "HistoryDate")
    private Date dateHistory;
}
