package kz.eubank.core.dashboard.application.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import kz.eubank.core.dashboard.domain.model.response.*;
import kz.eubank.core.dashboard.domain.service.IBonusesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("bonus")
@SecurityRequirement(name = "Bearer Authentication")
@Tag(name = "Бонусы", description = "BonusController")
public class BonusController {

    @Autowired
    private IBonusesService bonusesService;

    @Operation(summary = "list",
            description = "Бонусы")
    @Parameters({
            @Parameter(name = "balanceCurrency", description = "balanceCurrency"),
            @Parameter(name = "dateFrom", description = "dateFrom"),
            @Parameter(name = "dateTill", description = "dateTill")
    })
    @GetMapping({"list"})
    public APIResponse<AccountList> listBonusAccounts(@RequestParam(value = "balanceCurrency", required = false) String balanceCurrency,
                                                      @RequestParam(value = "dateFrom", required = false) String dateFrom,
                                                      @RequestParam(value = "dateTill", required = false) String dateTill,
                                                      @RequestHeader(value = "language", defaultValue = "ru") String language) {
        return (APIResponse<AccountList>) new APIResponse(bonusesService.listBonusAccounts(balanceCurrency, dateFrom, dateTill));
    }

    @Operation(summary = "categories",
            description = "Категории бонусов")
    @GetMapping("categories")
    public APIResponse<FavoriteCategoryList> getCategories(@RequestHeader(value = "language", defaultValue = "ru") String language) {
        Validator validator = new Validator();
        APIResponse<FavoriteCategoryList> response;
        if (!validator.isValid()) {
            response = (APIResponse<FavoriteCategoryList>) new APIResponse(validator.getErrors());
        } else {
            response = (APIResponse<FavoriteCategoryList>) new APIResponse(bonusesService.getCategories(language));
        }
        return response;
    }

    @Operation(summary = "settings",
            description = "Настройки бонусов")
    @Parameters({
            @Parameter(name = "account", description = "account", required = true)
    })
    @GetMapping("/settings")
    public APIResponse<BonusSettings> getBonusSettings(@RequestParam(value = "account") final String account,
                                                       @RequestHeader(value = "language", defaultValue = "ru") String language) {
        Validator validator = new Validator();
        validator.validate("account", account, Validator.Validation.NOT_BLANK);
        APIResponse<BonusSettings> response;
        if (!validator.isValid()) {
            response = (APIResponse<BonusSettings>) new APIResponse(validator.getErrors());
        } else {
            response = (APIResponse<BonusSettings>) new APIResponse(bonusesService.getBonusSettingsByAccount(account));
        }
        return response;
    }
}
