package kz.eubank.core.dashboard.domain.gate;

import kz.eubank.core.dashboard.domain.model.dto.SSGPOEmployeeInfoList;

public interface SSGPOGate {

    SSGPOEmployeeInfoList getSSGPOEmployeeInfoList(String iin, int size, String lang);
}
