package kz.eubank.core.dashboard.infrastructure.config;

import io.jsonwebtoken.ExpiredJwtException;
import kz.eubank.core.dashboard.domain.model.authorization.UserDetails;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.Base64;

@Service
public class ApplicationContextImpl implements ApplicationContext {

    @Autowired
    private CookiesManager cookiesManager;

    @Autowired
    private HttpServletRequest request;

    public String getLanguage() {
        return cookiesManager.getLanguage();
    }

    public UserDetails getCurrentUser() {
        UserDetails userDetails = new UserDetails();
        final String requestTokenHeader = request.getHeader("Authorization");
        JSONObject credentials = null;
        String jwtToken;
        if (requestTokenHeader != null && requestTokenHeader.startsWith("Bearer ")) {
            jwtToken = requestTokenHeader.substring(7);
            try {
                credentials = getJsonObject(jwtToken);
            } catch (IllegalArgumentException e) {
                System.out.println("Unable to get JWT Token");
                e.printStackTrace();
            } catch (ExpiredJwtException e) {
                System.out.println("JWT Token has expired");
            }
        } else {
            System.out.println("JWT Token does not begin with Bearer String");
        }

        if (credentials == null) return null;

        userDetails.setUserId((Long) credentials.get("user_id"));
        userDetails.setBirthDate((String) credentials.get("birth_date"));
        userDetails.setName((String) credentials.get("name"));
        userDetails.setPreferredUsername((String) credentials.get("preferred_username"));
        userDetails.setMiddleName((String) credentials.get("middle_name"));
        userDetails.setGivenName((String) credentials.get("given_name"));
        userDetails.setFamilyName((String) credentials.get("family_name"));
        userDetails.setClientId((Long) credentials.get("client_id"));
        userDetails.setIin((String) credentials.get("iin"));
        userDetails.setPersonId((Long) credentials.get("person_id"));

        return userDetails;
    }

    public JSONObject getJsonObject(String token) {
        Base64.Decoder decoder = Base64.getUrlDecoder();
        String[] chunks = token.split("\\.");
        String payload = new String(decoder.decode(chunks[1]));

        JSONParser parser = new JSONParser();
        JSONObject json;
        try {
            json = (JSONObject) parser.parse(payload);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        return json;
    }
}