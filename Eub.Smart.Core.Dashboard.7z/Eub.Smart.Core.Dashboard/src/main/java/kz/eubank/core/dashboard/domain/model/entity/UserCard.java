package kz.eubank.core.dashboard.domain.model.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Getter
@Setter
@Entity
@Table(name = "map_User_Card")
public class UserCard {

    @EmbeddedId
    private UserCard_PK id;

    @Column(name = "Card_Priority")
    private int cardPriority;
}
