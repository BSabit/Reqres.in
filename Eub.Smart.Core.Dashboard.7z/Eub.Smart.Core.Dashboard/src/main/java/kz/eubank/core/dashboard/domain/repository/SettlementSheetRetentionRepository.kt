package kz.eubank.core.dashboard.domain.repository

import kz.eubank.core.dashboard.domain.model.entity.SettlementSheetRetention
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface SettlementSheetRetentionRepository : JpaRepository<SettlementSheetRetention, Long> {
    fun findBySheetId(settlementSheetId: Long): List<SettlementSheetRetention>
}