package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "ApplicationState")
public class ApplicationState {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ApplicationState_ID")
    private Long id;

    @Column(name = "Attempts")
    private int attempts;

    @Column(name = "StatusDate")
    private Date statusDate;

    @Column(name = "TechScheduled")
    private Date techScheduled;

    @OneToOne
    @JoinColumn(name = "AppTechStatus_IDREF")
    private AppTechStatus techStatus;

    @Column(name = "AppTechStatusComment")
    private String techStatusComment;

    @Column(name = "UserMessage")
    private String userMessage;

    @Column(name = "Process_ID")
    private String processId;

    @OneToOne
    @JoinColumn(name = "Application_IDREF")
    private Application application;
}
