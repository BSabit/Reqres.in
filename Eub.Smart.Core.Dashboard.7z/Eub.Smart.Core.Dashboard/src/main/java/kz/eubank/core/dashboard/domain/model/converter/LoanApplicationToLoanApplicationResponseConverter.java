package kz.eubank.core.dashboard.domain.model.converter;

import kz.eubank.core.dashboard.domain.model.entity.core.LoanApplication;
import kz.eubank.core.dashboard.domain.model.response.*;
import org.dozer.CustomConverter;
import org.springframework.beans.BeanUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class LoanApplicationToLoanApplicationResponseConverter implements CustomConverter {

    @Override
    public Object convert(Object dest, Object source, Class<?> arg2, Class<?> arg3) {
        if (source == null) {
            return null;
        }
        if (source instanceof LoanApplication) {
            LoanApplication loanApplication = (LoanApplication) source;
            LoanApplicationResponse response = new LoanApplicationResponse();

            response.setId(loanApplication.getId());
            response.setAmount(bigDecimalToInt(loanApplication.getAmount()));
            response.setPeriod(loanApplication.getPeriod());
            response.setPensioner(loanApplication.isPensioner());
            response.setIndividualEntrepreneur(loanApplication.isIndividualEntrepreneur());
            response.setHasNotIncome(loanApplication.isHasNotIncome());
            response.setEmployerBinFromBS(loanApplication.getEmployerBinFromBS());
            response.setEmployerNameFromBS(loanApplication.getEmployerNameFromBS());
            response.setPartnerCode(loanApplication.getPartnerCode());
            response.setPartnerId(loanApplication.getPartnerId());
            response.setSubProductName(loanApplication.getSubProductName());
            response.setSubProductCode(loanApplication.getSubProductCode());
            response.setInsuranceDefaultValueOn(loanApplication.isInsuranceDefaultValueOn());
            response.setInsuranceOrgName(Objects.toString(loanApplication.getInsuranceOrgName(), ""));
            response.setInsurancePackage(Objects.toString(loanApplication.getInsurancePackage(), ""));
            response.setOfficialIncomeAmount(bigDecimalToInt(loanApplication.getOfficialIncomeAmount()));
            response.setAdditionalIncomeAmount(bigDecimalToInt(loanApplication.getAdditionalIncomeAmount()));
            response.setAnotherLoanAmount(bigDecimalToInt(loanApplication.getAnotherLoanAmount()));
            response.setEmployerName(Objects.toString(loanApplication.getEmployerName(), ""));
            response.setEmployerPhoneNumber(loanApplication.getEmployerPhoneNumber());
            response.setContactPerson(loanApplication.getContactPerson());
            response.setContactPersonPhone(loanApplication.getContactPersonPhone());
            response.setStaff(Objects.toString(loanApplication.getStaff(), ""));
            response.setLoanContractNumber(loanApplication.getLoanContractNumber());
            response.setBranchCode(loanApplication.getBranchCode());
            response.setMaritalStatus(loanApplication.getMaritalStatus());
            response.setChildCount(loanApplication.getChildCount());

            Application application = new Application();
            application.setId(loanApplication.getApplication().getId());
            application.setType(loanApplication.getApplication().getType().getCode());
            application.setTypeTitle(loanApplication.getApplication().getType().getTitle());
            application.setCompositeType("");//todo
            application.setBlob((loanApplication.getApplication().getBlob() != null)
                    ? loanApplication.getApplication().getBlob() : "".getBytes());
            application.setStatus(loanApplication.getApplication().getState().getTechStatus().getStatus().getCode());
            application.setStatusTitle(loanApplication.getApplication().getState().getTechStatus().getStatus().getTitle());
            application.setStatusMessage("");//todo
            application.setStatusIsFinal(loanApplication.getApplication().getState().getTechStatus().getStatus().is_final());
            application.setCreated(dateToLong(loanApplication.getApplication().getCreated()));
            application.setDateScheduled(dateToLong(loanApplication.getApplication().getDateScheduled()));
            application.setDateSigned(dateToLong(loanApplication.getApplication().getDateSigned()));
            application.setFee(bigDecimalToInt(loanApplication.getApplication().getFee()));
            application.setFeeCurrency(loanApplication.getApplication().getFeeCurrency());
            application.setCommissionAccount("");//todo
            response.setApplication(application);

            LoanCalcInfoResponse loanCalcInfoResponse = new LoanCalcInfoResponse();
            loanCalcInfoResponse.setId(loanApplication.getLoanCalcInfo().getId());
            loanCalcInfoResponse.setCreated(dateToLong(loanApplication.getLoanCalcInfo().getDateCreated()));
            loanCalcInfoResponse.setFullAmount(bigDecimalToInt(loanApplication.getLoanCalcInfo().getFullAmount()));
            loanCalcInfoResponse.setPeriod(loanApplication.getLoanCalcInfo().getPeriod());
            loanCalcInfoResponse.setPaymentAmountSum(bigDecimalToInt(loanApplication.getLoanCalcInfo().getPaymentAmountSum()));
            loanCalcInfoResponse.setPaymentDay(loanApplication.getLoanCalcInfo().getPaymentDay());
            loanCalcInfoResponse.setFileStorageId(loanApplication.getLoanCalcInfo().getFileStorage().longValue());
            loanCalcInfoResponse.setTariffCode(loanApplication.getLoanCalcInfo().getTarifCode());
            loanCalcInfoResponse.setInsurancePackageCode(Objects.toString(loanApplication.getLoanCalcInfo().getInsurancePackageCode(), ""));
            loanCalcInfoResponse.setInsurancePackageType(Objects.toString(loanApplication.getLoanCalcInfo().getInsurancePackageType(), ""));
            loanCalcInfoResponse.setAmount(bigDecimalToInt(loanApplication.getLoanCalcInfo().getAmount()));
            response.setLoanCalcInfo(loanCalcInfoResponse);

            LoanApplicationState loanApplicationState = new LoanApplicationState();
            loanApplicationState.setId(loanApplication.getLoanApplicationState().getId());
            loanApplicationState.setStatusDate(dateToLong(loanApplication.getLoanApplicationState().getStatusDate()));
            loanApplicationState.setComment(Objects.toString(loanApplication.getLoanApplicationState().getLoanApplicationStatusComment(), ""));
            loanApplicationState.setUserMessage(Objects.toString(loanApplication.getLoanApplicationState().getUserMessage(), ""));
            loanApplicationState.setCheckStatus(loanApplication.getLoanApplicationState().isCheckStatus());

            LoanApplicationStatus loanApplicationStatus = new LoanApplicationStatus();
            loanApplicationStatus.setId(loanApplication.getLoanApplicationState().getLoanApplicationStatus().getId());
            loanApplicationStatus.setFinal(loanApplication.getLoanApplicationState().getLoanApplicationStatus()
                    .isFinale());
            loanApplicationStatus.setTitle(loanApplication.getLoanApplicationState().getLoanApplicationStatus()
                    .getTitle());
            loanApplicationState.setStatus(loanApplicationStatus);

            response.setLoanApplicationState(loanApplicationState);


            List<LoanApplicationScoring> scorings = new ArrayList<>();
            loanApplication.getLoanApplicationScorings().forEach((scoring) -> {
                LoanApplicationScoring scoringDto = new LoanApplicationScoring();
                scoringDto.setId(scoring.getId());
                scoringDto.setCreated(dateToLong(scoring.getCreated()));

                LoanApplicationScoringStatus loanApplicationScoringStatus = new LoanApplicationScoringStatus();
                loanApplicationScoringStatus.setId(scoring.getLoanApplicationScoringStatus().getId());
                loanApplicationScoringStatus.setTitle(scoring.getLoanApplicationScoringStatus().getTitle());

                scoringDto.setStatus(loanApplicationScoringStatus);
                scoringDto.setStatusComment(scoring.getStatusComment());
                scoringDto.setCredilogicStatus(scoring.getCredilogicStatus());
                scoringDto.setFullLoanAmount(nullSafeBigDecimal(scoring.getFullLoanAmount()));
                scoringDto.setLoanAmount(nullSafeBigDecimal(scoring.getLoanAmount()));
                scoringDto.setCommissionAmount(nullSafeBigDecimal(scoring.getCommissionAmount()));
                scoringDto.setFeeAmount(nullSafeBigDecimal(scoring.getFeeAmount()));
                scoringDto.setInsuranceAmount(nullSafeBigDecimal(scoring.getInsuranceAmount()));
                scoringDto.setPeriod(scoring.getPeriod() != null ? scoring.getPeriod() : 0);
                scoringDto.setApr(scoring.getApr() != null ? scoring.getApr() : 0);
                scoringDto.setTotalInstallment(nullSafeBigDecimal(scoring.getTotalInstallment()));
                scoringDto.setFileStorageId(scoring.getFileStorageId() != null ? scoring.getFileStorageId() : 0);

                scorings.add(scoringDto);
            });
            response.setLoanApplicationScoring(scorings);

            return response;
        } else if (source instanceof LoanApplicationResponse) {//todo remove
            LoanApplicationResponse response = (LoanApplicationResponse) source;
            LoanApplication loanApplication = new LoanApplication();
            BeanUtils.copyProperties(response, loanApplication);
            return loanApplication;
        }
        return null;
    }

    private static Integer bigDecimalToInt(BigDecimal source) {
        return (source != null) ? source.intValue() : null;
    }
    private static Long dateToLong(Date date) {
        return (date != null) ? date.getTime() : null;
    }

    private static BigDecimal nullSafeBigDecimal(BigDecimal value) {
        return value != null ? value : BigDecimal.ZERO;
    }
}