package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "Address")
public class Address {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Address_ID")
    private Long id;

    @Column(name = "Address_Title")
    private String title;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "Country_IDREF")
    private Country country;

    @Column(name = "City")
    private String cityName;

    @Column(name = "Place")
    private String place;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "PlaceType_IDREF")
    private AddressPlaceType placeType;

    @Column(name = "HouseNo")
    private String houseNo;

    @Column(name = "AptNo")
    private String apartmentNo;

    @Column(name = "Zip")
    private String zip;

    @Column(name = "Phone")
    private String phone;

    @Column(name = "WorkPhone")
    private String workPhone;

    @Column(name = "Fax")
    private String fax;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "AddressStatus_IDREF")
    private AddressStatus status;

    @Column(name = "Latitude")
    private Double latitude;

    @Column(name = "Longtitude")
    private Double longitude;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;

    @OneToOne()
    @JoinColumn(name = "City_IDREF")
    private City city;
}
