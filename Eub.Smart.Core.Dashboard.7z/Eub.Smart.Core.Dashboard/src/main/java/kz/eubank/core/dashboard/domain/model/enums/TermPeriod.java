package kz.eubank.core.dashboard.domain.model.enums;

import java.util.Arrays;

public enum TermPeriod {

    DAY("D"),
    MONTH("M"),
    YEAR("Y"),
    WEEK("W");

    private final String text;

    TermPeriod(String text) {
        this.text = text;
    }

    public String getText() {
        return this.text;
    }

    public static TermPeriod fromString(String text) {
        return Arrays.stream(TermPeriod.values()).filter(q -> q.getText().equalsIgnoreCase(text))
                .findFirst().orElse(null);
    }
}
