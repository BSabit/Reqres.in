package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CardProductOperation {

    private Long id;
    private Long productId;
    private Long version;
    private boolean multiCurrency;
    private boolean installment;
}
