package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "ReferenceProperty")
public class ReferenceProperty implements Serializable {

    private static final long serialVersionUID = -5649736265559752479L;

    @Id
    @Column(name = "ApplicationType_IDREF")
    private String applicationTypeCode;

    @OneToOne(mappedBy = "referenceProperty")
    private ApplicationType applicationType;

    @Column(name = "GracePeriodBegin")
    private Date gracePeriodBegin;

    @Column(name = "GracePeriodEnd")
    private Date gracePeriodEnd;
}