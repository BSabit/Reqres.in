package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "CNPBlockApplication")
public class CNPBlockApplication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CNPBlockApplication_ID")
    private Long id;

    @OneToOne
    @JoinColumn(name = "Card_IDREF")
    private Card card;

    @OneToOne
    @JoinColumn(name = "Application_IDREF", insertable = false, updatable = false)
    private Application application;

    @OneToOne
    @JoinColumn(name = "CNPBlockReason_IDREF")
    private CNPBlockReason blockReason;

    @Column(name = "CNPBlock_Comment")
    private String comment;

    @Column(name = "CNPBlock_ExpireDate")
    @Temporal(TemporalType.DATE)
    private Date expireDate;
}
