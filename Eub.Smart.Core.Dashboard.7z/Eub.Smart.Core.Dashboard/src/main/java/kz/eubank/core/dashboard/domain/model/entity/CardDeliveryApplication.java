package kz.eubank.core.dashboard.domain.model.entity;

import kz.eubank.core.dashboard.domain.model.entity.core.Application;
import kz.eubank.core.dashboard.domain.model.entity.core.Branch;
import kz.eubank.core.dashboard.domain.model.entity.core.Card;
import kz.eubank.core.dashboard.domain.model.entity.core.City;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "CardDeliveryApplication")
public class CardDeliveryApplication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CardDeliveryApplication_ID")
    private Long id;

    @OneToOne
    @JoinColumn(name = "CardDeliveryMethod_IDREF")
    private CardDeliveryMethod cardDeliveryMethod;

    @OneToOne
    @JoinColumn(name = "Application_IDREF")
    private Application application;

    @OneToOne
    @JoinColumn(name = "Branch_IDREF")
    private Branch branch;

    @OneToOne
    @JoinColumn(name = "Card_IDREF")
    private Card card;

    @OneToOne
    @JoinColumn(name = "City_IDREF")
    private City city;

    @Column(name = "Street")
    private String street;

    @Column(name = "HouseNum")
    private String houseNum;

    @Column(name = "FlatNum")
    private String flatNum;

    @Column(name = "ContactNum")
    private String contactNum;
}
