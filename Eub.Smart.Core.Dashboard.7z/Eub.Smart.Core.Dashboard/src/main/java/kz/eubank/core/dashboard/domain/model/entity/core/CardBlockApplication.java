package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "CardBlockApplication")
public class CardBlockApplication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CardBlockApplication_ID")
    private Long id;

    @OneToOne
    @JoinColumn(name = "Card_IDREF")
    private Card card;

    @OneToOne
    @JoinColumn(name = "CardBlockReason_IDREF")
    private CardBlockReason cardBlockReason;

    @Column(name = "CardBlock_Comment")
    private String cardBlockComment;
}
