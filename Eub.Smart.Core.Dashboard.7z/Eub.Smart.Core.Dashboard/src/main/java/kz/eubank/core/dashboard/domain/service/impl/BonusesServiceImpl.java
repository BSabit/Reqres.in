package kz.eubank.core.dashboard.domain.service.impl;

import kz.eubank.core.dashboard.domain.gate.impl.TermGateService;
import kz.eubank.core.dashboard.domain.model.dto.AccountLongInfo;
import kz.eubank.core.dashboard.domain.model.dto.Person;
import kz.eubank.core.dashboard.domain.model.entity.BonusSpendChannel;
import kz.eubank.core.dashboard.domain.model.entity.core.Client;
import kz.eubank.core.dashboard.domain.model.entity.core.FavoriteCategory;
import kz.eubank.core.dashboard.domain.model.enums.ErrorMessages;
import kz.eubank.core.dashboard.domain.model.response.Account;
import kz.eubank.core.dashboard.domain.model.response.AccountList;
import kz.eubank.core.dashboard.domain.model.response.BonusSettings;
import kz.eubank.core.dashboard.domain.model.response.FavoriteCategoryList;
import kz.eubank.core.dashboard.domain.model.util.GeneralUtil;
import kz.eubank.core.dashboard.domain.repository.IBonusSpendChannelRepository;
import kz.eubank.core.dashboard.domain.repository.IClientRepository;
import kz.eubank.core.dashboard.domain.repository.IFavoriteCategoryRepository;
import kz.eubank.core.dashboard.domain.service.IAccountService;
import kz.eubank.core.dashboard.domain.service.IBonusesService;
import kz.eubank.core.dashboard.infrastructure.config.AppProperties;
import kz.eubank.core.dashboard.infrastructure.config.ApplicationContext;
import kz.eubank.core.dashboard.infrastructure.config.MapperHelper;
import kz.eubank.core.dashboard.infrastructure.exception.ServiceException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import static kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard.BSystemType.SOLR;

@Slf4j
@Service
public class BonusesServiceImpl implements IBonusesService {

    @Autowired
    private MapperHelper mapperHelper;

    @Autowired
    private IAccountService accountService;

    @Autowired
    private AppProperties appProperties;

    @Autowired
    private IFavoriteCategoryRepository favoriteCategoryRepository;

    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    private IClientRepository clientRepository;

    @Autowired
    private TermGateService termGateService;

    @Autowired
    private IBonusSpendChannelRepository bonusSpendChannelRepository;

    @Autowired
    private GeneralUtil generalUtil;

    private static final int BONUS_ACCOUNT_TYPE = SOLR.getNumber();
    private static final String CURR_ACC_ACCOUNT = "current_account";

    @Override
    public AccountList listBonusAccounts(String balanceCurrency, String dateFrom, String dateTill) {
        if (balanceCurrency == null || balanceCurrency.isEmpty()) {
            balanceCurrency = "KZT";
        }
        return generalUtil.getAsync(getBonusAccounts(balanceCurrency, dateFrom, dateTill));
    }

    @Override
    public FavoriteCategoryList getCategories(String language) {
        List<FavoriteCategory> list = favoriteCategoryRepository.findAllCategories()
                .stream()
                .peek(o -> o.setTitle(termGateService.getTitle(o.getTerms(), o.getTitle(), language)))
                .peek(o -> o.setDescription(termGateService.getDescription(o.getTerms(), o.getTerms().getDescRU(), language)))
                .collect(Collectors.toList());
        List<kz.eubank.core.dashboard.domain.model.response.FavoriteCategory> categories = mapperHelper.map(list)
                .toList(kz.eubank.core.dashboard.domain.model.response.FavoriteCategory.class);
        return new FavoriteCategoryList(categories);
    }

    @Override
    public BonusSettings getBonusSettingsByAccount(String account) {
        BonusSettings settings = gatherBonusSettings(account);
        String spendingChannel = settings.getSpendingChannel();
        if (spendingChannel != null) {
            BonusSpendChannel bonusSpendChannel = bonusSpendChannelRepository.findById(spendingChannel)
                    .orElse(new BonusSpendChannel());
            settings.setSpendingChannel(bonusSpendChannel.getId());
        }
        return settings;
    }

    private BonusSettings gatherBonusSettings(String account) {
        Long clientId = applicationContext.getCurrentUser().getClientId();
        Person person = getPerson(clientId);
        Date birthDate = person.getBirthDate();
        String iin = person.getIin();
        if (birthDate == null || iin == null) {
            throw new ServiceException((ErrorMessages.BIRTH_DATE_OR_IIN_IS_NULL.getErrorMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR.value());
        }
        return accountService.getBonusSettings(iin, birthDate, account);
    }

    private Person getPerson(Long clientId) {
        Client client = clientRepository.findById(clientId)
                .orElseThrow(() -> new ServiceException(ErrorMessages.CLIENT_IS_NOT_FOUND.getErrorMessage(),
                        HttpStatus.NOT_FOUND.value()));
        Person person = new Person();
        if (client != null && client.getPerson() != null) {
            person.setBirthDate(client.getPerson().getBirthDate());
            person.setIin(client.getPerson().getIin());
        }
        return person;
    }

    @Async
    Future<AccountList> getBonusAccounts(String balanceCurrency, String dateFrom, String dateTill) {
        String[] accountTypes = {appProperties.getBonusAccountType()};
        Collection<AccountLongInfo> bonusAccounts = accountService.getAccountsInfo(accountTypes, false, true,
                balanceCurrency, BONUS_ACCOUNT_TYPE, CURR_ACC_ACCOUNT);
        Collection<Account> accounts = mapperHelper.map(bonusAccounts).toList(Account.class);
        AccountList accountList = new AccountList(accounts);
        for (Account account : accountList.getAccounts()) {
            account.setHasStandingOrders(accountService.getHasFutureStandingOrder(account.getNumber(), dateFrom,
                    dateTill));
        }
        return (Future<AccountList>) new AsyncResult(accountList);
    }
}
