package kz.eubank.core.dashboard.core.constants;

public interface MdcConstants {

    String X_FORWARDED_FOR = "X-Forwarded-For";
}
