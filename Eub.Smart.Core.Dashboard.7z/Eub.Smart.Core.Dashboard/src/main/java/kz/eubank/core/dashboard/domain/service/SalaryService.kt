package kz.eubank.core.dashboard.domain.service

import kz.eubank.core.dashboard.domain.model.dto.SSGPOEmployeeInfoList
import kz.eubank.core.dashboard.domain.model.dto.SettlementSheetEmployeeList

interface SalaryService {

    suspend fun getSettlementSheetEmployeesResult(period: Int): SettlementSheetEmployeeList?

    fun getSSGPOPersonInfo(period: Int, lang: String): SSGPOEmployeeInfoList?
}