package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import java.io.Serializable;

@Getter
@Setter
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
@Entity
@Table(name = "Term")
public class Term implements Serializable {

    private static final long serialVersionUID = 8386980479757900227L;

    @Id
    @Column(name = "Term_ID")
    private Long id;

    @Column(name = "Term_RU")
    private String termRU;

    @Column(name = "Term_EN")
    private String termEN;

    @Column(name = "Term_KZ")
    private String termKZ;

    @Column(name = "Term_DE")
    private String termDE;

    @Column(name = "Term_FR")
    private String termFR;

    @Column(name = "Term_TR")
    private String termTR;

    @Column(name = "Desc_RU")
    private String descRU;

    @Column(name = "Desc_EN")
    private String descEN;

    @Column(name = "Desc_KZ")
    private String descKZ;

    @Column(name = "Desc_DE")
    private String descDE;

    @Column(name = "Desc_FR")
    private String descFR;

    @Column(name = "Desc_TR")
    private String descTR;
}
