package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PersonStatus {

    private String code;
    private String title;
    private Long term;
    private boolean valid;
}
