package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
public class DepositContract extends GeneralContract implements Serializable {

    private static final long serialVersionUID = 2296987427425448212L;

    private BigDecimal arrestedSum;
    private BigDecimal accruedAmountTotal;
    private BigDecimal accruedAmountForMonth;
    private BigDecimal minBalance;
    private Limits limits;
    boolean allowBalance;
    boolean allowCreateFinDoc;
    boolean allowSubmitFinDoc;
    private BigDecimal balance;
    private boolean agreementAvailable;
    private BigDecimal actualBalance;
    private BigDecimal blockedSum;
    private String contractNo;
}
