package kz.eubank.core.dashboard.domain.model.enums;

import java.util.Arrays;

public enum CreditStatus {

    ACTIVE("ACTV"),
    CLOSED("CLOSED"),
    DRAFT("DRAFT"),
    DELETED("DELETED");

    private final String text;

    CreditStatus(String text) {
        this.text = text;
    }

    public String getText() {
        return this.text;
    }

    public static CreditStatus fromString(String text) {
        return Arrays.stream(CreditStatus.values()).filter(q -> q.getText().equalsIgnoreCase(text))
                .findFirst().orElse(null);
    }
}
