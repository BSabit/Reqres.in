package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "LoanApplicationStatus")
public class LoanApplicationStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "LoanApplicationStatus_ID")
    private String id;

    @Column(name = "LoanApplicationStatus_Title")
    private String title;

    @Column(name = "LoanApplicationStatus_IsFinal")
    private boolean finale;

    @OneToOne
    @JoinColumn(name = "Term_OUTREF")
    private Term term;
}
