package kz.eubank.core.dashboard.domain.model.entity;

import kz.eubank.core.dashboard.domain.model.entity.core.Term;

import javax.persistence.*;

@Entity
@Table(name = "ServiceType")
public class ServiceType {

    @Id
    @Column(name = "ServiceType_ID")
    private Long id;

    @Column(name = "ServiceType_Title")
    private String title;
    
    @Column(name = "Synonyms")
    private String synonyms;

    @OneToOne
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;
    
    @Column(name = "Priority")
    private int priority;
    
    @Column(name = "LogoPath")
    private String logoPath;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Term getTerms() {
        return terms;
    }
    
    public String getSynonyms() {
        return synonyms;
    }

    public int getPriority() {
        return priority;
    }

    public String getLogoPath() {
        return logoPath;
    }

    public void setLogoPath(String logoPath) {
        this.logoPath = logoPath;
    }
}
