package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
public class AccountBalanceInfo {

    private String accountNumber;
    private BigDecimal balance;
    private String currency;
    private BigDecimal actualBalance;
    private BigDecimal blockedSum;
    private BigDecimal availableBalance;
    private List<SubAccountBalance> subAccountBalances;
    private List<SubAccountBalance> subAccountAvailableBalances;
    private AccountGraceInfo accountGraceInfo;
    private boolean isGrace;
    private Integer minBalance;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }
}
