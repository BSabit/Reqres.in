package kz.eubank.core.dashboard.domain.model.converter;

import kz.eubank.core.dashboard.domain.model.dto.AccountLongInfo;
import kz.eubank.core.dashboard.domain.model.dto.AccountStatus;
import kz.eubank.core.dashboard.domain.model.dto.DepositContract;
import kz.eubank.core.dashboard.domain.model.dto.Limits;
import org.dozer.CustomConverter;
import org.springframework.beans.BeanUtils;

public class AccountLongInfoToDepositContractConverter implements CustomConverter {

    @Override
    public Object convert(Object dest, Object source, Class<?> arg2, Class<?> arg3) {
        if (source == null) {
            return null;
        }
        if (source instanceof AccountLongInfo && arg2.equals(DepositContract.class)) {
            AccountLongInfo accountLongInfo = (AccountLongInfo) source;
            DepositContract depositContract = new DepositContract();

            if (accountLongInfo.getStatus() != null) {
                AccountStatus accountStatus = String2AccountStatus_Converter.convert(
                        accountLongInfo.getStatus().getCode());
                depositContract.setStatus(accountStatus == null ? "" : accountStatus.getCode());
            }
            depositContract.setBranchTermId(accountLongInfo.getBranchTermId());
            depositContract.setBranchTitle(accountLongInfo.getBranchTitle());
            depositContract.setLimits(new Limits(accountLongInfo.getLimitCurrency(),
                    accountLongInfo.getLimitDay().intValue(),
                    accountLongInfo.getLimitMonth().intValue(), accountLongInfo.getLimitFinDoc().intValue(),
                    accountLongInfo.getLimitWeek().intValue()));
            depositContract.setActions(accountLongInfo.getActions());
            depositContract.setTitle(accountLongInfo.getTitle());
            depositContract.setCurrency(accountLongInfo.getCurrency());
            depositContract.setNumber(accountLongInfo.getNumber());
            depositContract.setSpriteIndex(accountLongInfo.getSpriteIndex());
            depositContract.setAllowBalance(accountLongInfo.isAllowBalance());
            depositContract.setAllowCreateFinDoc(accountLongInfo.isAllowCreateFinDoc());
            depositContract.setAllowSubmitFinDoc(accountLongInfo.isAllowSubmitFinDoc());
            depositContract.setContractNo(accountLongInfo.getContractNo());

            return depositContract;
        } else if (source instanceof DepositContract && arg2.equals(AccountLongInfo.class)) {//todo remove
            DepositContract depositContract = (DepositContract) source;
            AccountLongInfo accountLongInfo = new AccountLongInfo();
            BeanUtils.copyProperties(depositContract, accountLongInfo);
            return accountLongInfo;
        }
        return null;
    }
}