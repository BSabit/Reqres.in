package kz.eubank.core.dashboard.application.controller

import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.Parameter
import io.swagger.v3.oas.annotations.Parameters
import io.swagger.v3.oas.annotations.security.SecurityRequirement
import io.swagger.v3.oas.annotations.tags.Tag
import kz.eubank.core.dashboard.domain.model.dto.SSGPOEmployeeInfoList
import kz.eubank.core.dashboard.domain.model.dto.SettlementSheetEmployeeList
import kz.eubank.core.dashboard.domain.model.response.APIResponse
import kz.eubank.core.dashboard.domain.service.SalaryService
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestHeader
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/salary")
@SecurityRequirement(name = "Bearer Authentication")
@Tag(name = "Зарплатный листок", description = "SalaryController")
class SalaryController(
    private val salaryService: SalaryService
) {

    @Operation(
        summary = "getSettlementSheetEmployeesResult",
        description = "Получение зарплатного листка по пользователю"
    )
    @Parameters(
        Parameter(name = "size", description = "Количество месяцев", required = true)
    )
    @GetMapping("/sheets")
    suspend fun getSettlementSheetEmployeesResult(
        size: Int,
        @RequestHeader(
            value = "language",
            defaultValue = "ru"
        ) language: String
    ): APIResponse<SettlementSheetEmployeeList?> {
        return APIResponse(salaryService.getSettlementSheetEmployeesResult(size))
    }

    @Operation(
        summary = "getSSGPOPersonInfo",
        description = "Получение зарплатного листка по пользователю SSGPO"
    )
    @Parameters(
        Parameter(name = "size", description = "Количество месяцев", required = true)
    )
    @GetMapping("/ssgpoInfo")
    fun getSSGPOPersonInfo(
        size: Int,
        @RequestHeader(
            value = "language",
            defaultValue = "ru"
        ) language: String
    ): APIResponse<SSGPOEmployeeInfoList?> {
        return APIResponse(salaryService.getSSGPOPersonInfo(size, language))
    }
}