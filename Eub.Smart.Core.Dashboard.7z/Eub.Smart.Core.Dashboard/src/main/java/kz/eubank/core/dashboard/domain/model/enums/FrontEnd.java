package kz.eubank.core.dashboard.domain.model.enums;

public enum FrontEnd {

    MWEB("MOBILE_WEB", "Mobile web application"),
    WEBB("WEB", "Web application"),
    ANDP("MOBILE_ANDROID", "Android application"),
    IPAD("MOBILE_IPAD", "iPad application"),
    IPHN("MOBILE_IPHONE", "Iphone application"),
    WINP("MOBILE_WINDOWS", "Windows mobile application"),
    TRML("TERMINAL", "Terminal application"),
    APTS("TEST_REQUEST", "Test application"),
    USSD("USSD", "USSD Portal"),
    SSZO("SSZO", "SSZO  Self service");

    private final String title;
    private final String code;

    FrontEnd(String code, String title) {
        this.code = code;
        this.title = title;
    }

    public String title() {
        return this.title;
    }

    public String code() {
        return this.code;
    }
}
