package kz.eubank.core.dashboard.domain.model.entity;

import kz.eubank.core.dashboard.domain.model.entity.core.*;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Set;


@Entity
@Table(name = "FinDoc")
public class Order {
    @Id
    @Column(name = "FinDoc_ID")
    private Long id;
    @Column(name = "FinDocType_IDREF")
    private String type;
    @Column(name = "Amount")
    private BigDecimal amount;
    @Column(name = "Currency")
    private String currency;
    @Column(name = "Fee")
    private BigDecimal fee;
    @Column(name = "FeeCurrency")
    private String feeCurrency;
    @Column(name = "DateCreated")
    private Date dateCreated;
    @Column(name = "DateScheduled")
    private Date dateScheduled;
    @Column(name = "DateSigned")
    private Date dateSigned;
    @Column(name = "FinDoc_IDREF")
    private Long parentFinDocId;
    @OneToOne
    @JoinColumn(name = "Account_IDREF")
    private Account account;

    @NotFound(action = NotFoundAction.IGNORE)
    @OneToOne()
    @JoinColumns(
            {@JoinColumn(name = "Account_IDREF", referencedColumnName = "Account_IDREF", insertable = false, updatable = false),
                    @JoinColumn(name = "User_IDREF", referencedColumnName = "User_IDREF", insertable = false, updatable = false)})
    private MapUserAccount mapUserAccount;

    @OneToOne
    @JoinColumn(name = "User_IDREF")
    private User user;
    @OneToOne(mappedBy = "order", cascade = {CascadeType.REMOVE, CascadeType.PERSIST, CascadeType.MERGE})
    private FinDocState state;
    @OneToMany(mappedBy = "order", fetch = FetchType.EAGER)
    private Set<Transfer> transfers;
    @OneToMany(mappedBy = "order", fetch = FetchType.EAGER)
    private Set<PaymentDoc> payments;

    @Column(name = "Details")
    private String details;

    @Column(name = "IsUrgent")
    private boolean urgent;
    @Column(name = "IsTemplate")
    private boolean template;

    public Long getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public String getCurrency() {
        return currency;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public Date getDateScheduled() {
        return dateScheduled;
    }

    public Account getAccount() {
        return account;
    }

    public Transfer getTransfer() {
        return transfers != null && transfers.size() > 0 ? transfers.iterator().next() : null;
    }

    public PaymentDoc getPayment() {
        return payments != null && payments.size() > 0 ? payments.iterator().next() : null;
    }

    public FinDocState getState() {
        return state;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public BigDecimal getFee() {
        return fee;
    }

    public void setFee(BigDecimal fee) {
        this.fee = fee;
    }

    public String getFeeCurrency() {
        return feeCurrency;
    }

    public void setFeeCurrency(String feeCurrency) {
        this.feeCurrency = feeCurrency;
    }

    @Entity
    @Table(name = "PaymentDoc")
    public static class PaymentDoc {
        @Id
        @Column(name = "PaymentDoc_ID")
        Long id;
        @JoinColumn(name = "Service_IDREF")
        @OneToOne
        Service service;
        @ManyToOne
        @JoinColumn(name = "FinDoc_IDREF")
        Order order;

        @OneToMany(mappedBy = "payment", fetch = FetchType.EAGER)
        List<PaymentDetails> paymentDetails;

        public Service getService() {
            return service;
        }

        public Long getId() {
            return id;
        }

        public Order getOrder() {
            return order;
        }

        public List<PaymentDetails> getPaymentDetails() {
            return paymentDetails;
        }

        public void setPaymentDetails(List<PaymentDetails> paymentDetails) {
            this.paymentDetails = paymentDetails;
        }
    }

    @Entity
    @Table(name = "Transfer")
    public static class Transfer {
        @Id
        @Column(name = "Transfer_ID")
        private Long id;
        @Column(name = "Receiver_Name")
        private String receiverName;
        @Column(name = "Receiver_Account")
        private String receiverAccount;
        @JoinColumn(name = "Receiver_BIC")
        @OneToOne
        @NotFound(action = NotFoundAction.IGNORE)
        private Bank receiverBank;
        @Column(name = "Receiver_IsResident")
        private boolean receiverResident;
        @Column(name = "Receiver_IIN")
        private String receiverIIN;
        @Column(name = "SubAccountCurrency")
        private String subAccountCurrency;
        @Column(name = "SenderSubAccountCurrency")
        private String senderSubAccountCurrency;
        @ManyToOne
        @JoinColumn(name = "FinDoc_IDREF")
        private Order order;
        @OneToMany(mappedBy = "transfer", fetch = FetchType.EAGER)
        private Set<IntlTransfer> intlTransfers;

        @Column(name = "SEco_IDREF")
        private String secoId;

        @JoinColumn(name = "TransferType_IDREF")
        @OneToOne
        private TransferType type;

        @Column(name = "Receiver_BIN")
        private String receiverBIN;

        public Long getId() {
            return id;
        }

        public String getReceiverName() {
            return receiverName;
        }

        public String getReceiverAccount() {
            return receiverAccount;
        }

        public Order getOrder() {
            return order;
        }

        public Bank getReceiverBank() {
            return receiverBank;
        }

        public boolean isReceiverResident() {
            return receiverResident;
        }

        public IntlTransfer getIntlTransfer() {
            return intlTransfers != null && intlTransfers.size() > 0 ? intlTransfers.iterator().next() : null;
        }

        public String getReceiverIIN() {
            return receiverIIN;
        }

        public String getSubAccountCurrency() {
            return subAccountCurrency;
        }

        public String getSenderSubAccountCurrency() {
            return senderSubAccountCurrency;
        }

        public String getSecoId() {
            return secoId;
        }

        public void setSecoId(String secoId) {
            this.secoId = secoId;
        }

        public String getReceiverBIN() {
            return receiverBIN;
        }

        public void setReceiverBIN(String receiverBIN) {
            this.receiverBIN = receiverBIN;
        }

        public TransferType getType() {
            return type;
        }

        public void setType(TransferType type) {
            this.type = type;
        }

    }

    @Entity
    @Table(name = "TransferType")
    public static class TransferType {
        @Id
        @Column(name = "TransferType_ID")
        private String id;

        @Column(name = "FinDocType_IDREF")
        private String finDocType;

        @Column(name = "TransferType_Title")
        private String title;

        @OneToOne
        @JoinColumn(name = "Term_OUTREF")
        private Term term;

        @Column(name = "IsUrgent")
        private boolean urgent;

        @Column(name = "SrcCurrency")
        private String srcCurrency;

        @Column(name = "TargetCurrency")
        private String targetCurrency;

        @OneToOne
        @JoinColumn(name = "Operation_IDREF")
        private Operation operation;

        @Column(name = "FeePayer_IDREF")
        private String feePayer;

        @Column(name = "IsCorporate")
        private boolean corporate;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getFinDocType() {
            return finDocType;
        }

        public String getTitle() {
            return title;
        }

        public Term getTerm() {
            return term;
        }

        public boolean isUrgent() {
            return urgent;
        }

        public String getSrcCurrency() {
            return srcCurrency;
        }

        public String getTargetCurrency() {
            return targetCurrency;
        }

        public Operation getOperation() {
            return operation;
        }

        public String getFeePayer() {
            return feePayer;
        }

        public boolean isCorporate() {
            return corporate;
        }

        public void setCorporate(boolean corporate) {
            this.corporate = corporate;
        }
    }

    @Entity
    @Table(name = "IntlTransfer")
    public static class IntlTransfer {
        @Id
        @Column(name = "IntlTransfer_ID")
        Long id;
        @Column(name = "Receiver_Address")
        String receiverAddress;
        @JoinColumn(name = "Correspondent_BIC")
        @OneToOne
        @NotFound(action = NotFoundAction.IGNORE)
        Bank correspondentBank;
        @JoinColumn(name = "Country_IDREF")
        @OneToOne
        Country country;

        @ManyToOne
        @JoinColumn(name = "Transfer_IDREF")
        Transfer transfer;

        public Long getId() {
            return id;
        }

        public String getReceiverAddress() {
            return receiverAddress;
        }

        public Bank getCorrespondentBank() {
            return correspondentBank;
        }

        public Country getCountry() {
            return country;
        }

        public Transfer getTransfer() {
            return transfer;
        }
    }

    @Entity
    @Table(name = "Bank")
    public static class Bank {

        @Id
        @Column(name = "BIC")
        private String bic;

        @Column(name = "Bank_Title")
        private String title;

        @OneToOne()
        @JoinColumn(name = "Term_OUTREF")
        private Term terms;

        public String getBic() {
            return bic;
        }

        public String getTitle() {
            return title;
        }

        public Term getTerms() {
            return terms;
        }
    }


    @Entity
    @Table(name = "Account")
    public static class Account {
        @Id
        @Column(name = "Account_ID")
        Long id;
        @Column(name = "Number")
        String number;
        @JoinColumn(name = "BSystemClient_IDREF")
        @OneToOne
        BSystemClient bsystemClient;
        @Column(name = "Account_Title")
        private String title;

        public Long getId() {
            return id;
        }

        public String getNumber() {
            return number;
        }

        public BSystemClient getBsystemClient() {
            return bsystemClient;
        }

        public String getTitle() {
            return title;
        }
    }

    @Entity
    @Table(name = "FinDocState")
    public static class FinDocState {
        @Id
        @Column(name = "FinDocState_ID")
        Long id;
        @JoinColumn(name = "DocTechStatus_IDREF")
        @OneToOne
        DocTechStatus status;
        @OneToOne
        @JoinColumn(name = "FinDoc_IDREF")
        Order order;
        @Column(name = "StatusDate")
        Date statusDate;
        @Column(name = "UserMessage")
        String statusMessage;

        @Column(name = "isHidden")
        private boolean hidden;

        public Long getId() {
            return id;
        }

        public Order getOrder() {
            return order;
        }

        public DocTechStatus getStatus() {
            return status;
        }

        public Date getStatusDate() {
            return statusDate;
        }

        public boolean isHidden() {
            return hidden;
        }

        public void setHidden(boolean hidden) {
            this.hidden = hidden;
        }

        public String getStatusMessage() {
            return statusMessage;
        }
    }

    @Entity
    @Table(name = "DocTechStatus")
    public static class DocTechStatus {
        @Id
        @Column(name = "DocTechStatus_ID")
        String code;
        @Column(name = "DocTechStatus_Title")
        String title;
        @OneToOne
        @JoinColumn(name = "FinDocStatus_IDREF")
        FinDocStatus finDocStatus;
        @OneToOne()
        @JoinColumn(name = "Term_OUTREF")
        private Term terms;

        public String getCode() {
            return code;
        }

        public String getTitle() {
            return title;
        }

        public FinDocStatus getFinDocStatus() {
            return finDocStatus;
        }

        public Term getTerms() {
            return terms;
        }

        public void setTerms(Term terms) {
            this.terms = terms;
        }
    }

    public Long getParentFinDocId() {
        return parentFinDocId;
    }

    public Date getDateSigned() {
        return dateSigned;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public boolean isUrgent() {
        return urgent;
    }

    public void setUrgent(boolean urgent) {
        this.urgent = urgent;
    }

    public boolean isTemplate() {
        return template;
    }

    public void setTemplate(boolean template) {
        this.template = template;
    }

    public MapUserAccount getMapUserAccount() {
        return mapUserAccount;
    }

}
