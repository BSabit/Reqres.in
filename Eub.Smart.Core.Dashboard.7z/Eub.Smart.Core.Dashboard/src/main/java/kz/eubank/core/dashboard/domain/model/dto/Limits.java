package kz.eubank.core.dashboard.domain.model.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class Limits {

    private String currency;
    private Integer dayLimit;
    private Integer monthLimit;
    private Integer operationLimit;
    private Integer weekLimit;

    @Override
    public String toString() {
        return "Limits [currency=" + this.currency + ", dayLimit=" + this.dayLimit + ", monthLimit="
                + this.monthLimit + ", operationLimit=" + this.operationLimit + ", weekLimit=" + this.weekLimit + "]";
    }
}
