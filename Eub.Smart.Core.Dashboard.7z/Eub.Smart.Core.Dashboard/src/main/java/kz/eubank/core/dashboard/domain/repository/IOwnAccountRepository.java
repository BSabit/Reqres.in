package kz.eubank.core.dashboard.domain.repository;

import kz.eubank.core.dashboard.domain.model.entity.CardAccount;
import kz.eubank.core.dashboard.domain.model.entity.core.Account;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface IOwnAccountRepository extends CrudRepository<Account, Long> {

    Account findByNumber(final String p0);

    @Query(nativeQuery = true, name = "findActions", value = "select Action_ID from GetActionsForProduct(?)")
    List<String> findActions(final Long p0);

    @Query("select c from CardAccount c where c.accountId = ?1 ")
    CardAccount findCardAccount(final Long p0);
}
