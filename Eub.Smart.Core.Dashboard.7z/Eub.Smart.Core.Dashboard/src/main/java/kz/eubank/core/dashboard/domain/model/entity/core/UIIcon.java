package kz.eubank.core.dashboard.domain.model.entity.core;

import javax.persistence.*;

@Entity
@Table(name = "UIIcon")
public class UIIcon {

    @Id
    @Column(name = "UIIcon_ID")
    private Long id;

    @Column(name = "UIIcon_Title")
    private String title;

    @Column(name = "SpriteIndex")
    private int spriteIndex;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;

    public Long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public int getSpriteIndex() {
        return spriteIndex;
    }

    public void setSpriteIndex(int spriteIndex) {
        this.spriteIndex = spriteIndex;
    }

    public Term getTerms() {
        return terms;
    }

    public void setTerms(Term terms) {
        this.terms = terms;
    }

}
