package kz.eubank.core.dashboard.domain.model.dto

data class SettlementSheet(
    var accruals: List<SettlementSheetOperation>? = null,
    var retentions: List<SettlementSheetOperation>? = null,
    var companyRetentions: List<SettlementSheetOperation>? = null,
    var availableWorkDaysPerMonth: Int? = null,
    var healthInsurance: Int? = null,
    var pensionContributions: Int? = null,
    var socialContributions: Int? = null,
    var totalAccrualAmount: Int? = null,
    var totalAmount: Int? = null,
    var totalRetentionAmount: Int? = null,
    var totalDebtAmount: Int? = null,
    var totalCompanyRetentionAmount: Int? = null,
    var currentSalary: Int? = null,
    var currentDepartmentName: String? = null,
    var exportPeriod: String? = null
)