package kz.eubank.core.dashboard.domain.gate.impl;

import kz.eubank.core.dashboard.infrastructure.config.MapperHelper;
import kz.eubank.core.dashboard.domain.gate.ICardGate;
import kz.eubank.core.dashboard.domain.model.entity.MapCardAndCardUsageType;
import kz.eubank.core.dashboard.domain.model.entity.UserCard;
import kz.eubank.core.dashboard.domain.repository.ICardLimitsRepository;
import kz.eubank.core.dashboard.domain.repository.ICardRepository;
import kz.eubank.core.dashboard.domain.repository.IOwnAccountRepository;
import kz.eubank.core.dashboard.domain.repository.IUserCardRepository;
import kz.eubank.core.dashboard.domain.model.dto.CardLimitXml;
import kz.eubank.core.dashboard.domain.model.dto.CardLongInfo;
import kz.eubank.core.dashboard.domain.model.dto.CardShortInfo;
import kz.eubank.core.dashboard.domain.model.entity.core.Account;
import kz.eubank.core.dashboard.domain.model.entity.core.Card;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;

@Service
public class CardGateImpl implements ICardGate {

    @Autowired
    protected ICardRepository cardRepository;

    @Autowired
    protected IOwnAccountRepository accountRepository;

    @Autowired
    private IUserCardRepository userCardRepository;

    @Autowired
    private ICardLimitsRepository cardLimitsRepository;

    @Autowired
    private MapperHelper mapperHelper;

    @Override
    public Collection<CardLongInfo> getCardsLongInfo(final String accountNumber, final boolean valid,
                                                     final boolean closed, final Long userId) {
        if (StringUtils.isEmpty(accountNumber)) {
            throw new IllegalArgumentException("Account number is null or empty!");
        }
        final Account account = accountRepository.findByNumber(accountNumber);
        final Collection<Card> cardsList = cardRepository.findAll(account.getId(), valid, closed);
        return map(cardsList, userId);
    }

    private Collection<CardLongInfo> map(final Collection<Card> cardsList, final Long userId) {
        final List<CardLongInfo> cards = map(cardsList);
        if (cards.isEmpty()) {
            return cards;
        }
        for (final CardLongInfo cardLongInfo : cards) {
            final Long cardId = cardLongInfo.getId();
            final List<MapCardAndCardUsageType> usageTypes = cardLimitsRepository.findByCardId(cardId);
            if (usageTypes == null) {
                continue;
            }
            final Collection<CardLimitXml> cardLimitXmls = (Collection<CardLimitXml>) mapperHelper.map((Object) usageTypes)
                    .toList((Class) CardLimitXml.class);//todo check then
            cardLongInfo.setCardLimitXmls(cardLimitXmls);
        }
        updatePriority(cards, userId);
        sortByPriority(cards);
        return cards;
    }

    private List<CardLongInfo> map(final Collection<Card> sourceCards) {
        final List<CardLongInfo> destinationCards = new ArrayList<>();
        for (final Card sourceCard : sourceCards) {
            final CardLongInfo cardLongInfo = mapperHelper.map(sourceCard).to(CardLongInfo.class);
            final Long productId = sourceCard.getProduct().getId();
            cardLongInfo.setActions(accountRepository.findActions(productId));
            destinationCards.add(cardLongInfo);
        }
        return destinationCards;
    }

    private <T extends CardShortInfo> void updatePriority(final List<T> cards, final Long userId) {
        if (cards.isEmpty()) {
            return;
        }
        final List<Long> cardIDs = getIDs(cards);
        final List<UserCard> userCards = userCardRepository.findUserCards(userId, cardIDs);
        for (final CardShortInfo card : cards) {
            final int priority = getCardPriority(userCards, card.getId());
            card.setPriority(priority);
        }
    }

    int getCardPriority(final List<UserCard> userCards, final Long cardID) {
        for (final UserCard userCard : userCards) {
            if (userCard.getId().getCardId().compareTo(cardID) == 0) {
                return userCard.getCardPriority();
            }
        }
        return Integer.MAX_VALUE;
    }

    <T extends CardShortInfo> List<Long> getIDs(final List<T> cards) {
        final List<Long> cardIDs = new ArrayList<>(cards.size());
        for (final CardShortInfo card : cards) {
            cardIDs.add(card.getId());
        }
        return cardIDs;
    }

    private <T extends CardShortInfo> void sortByPriority(final List<T> cards) {
        Comparator cardComparator = Comparator.comparingInt(CardShortInfo::getPriority);
        cards.sort(cardComparator);//todo check then
    }
}
