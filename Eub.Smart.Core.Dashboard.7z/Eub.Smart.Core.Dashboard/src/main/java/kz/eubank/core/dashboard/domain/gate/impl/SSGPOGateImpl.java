package kz.eubank.core.dashboard.domain.gate.impl;

import kz.eubank.core.dashboard.domain.gate.SSGPOGate;
import kz.eubank.core.dashboard.domain.model.dto.SSGPOEmployeeInfo;
import kz.eubank.core.dashboard.domain.model.dto.SSGPOEmployeeInfoList;
import kz.eubank.core.dashboard.domain.model.dto.SSGPOSettlementInfo;
import kz.eubank.core.dashboard.domain.model.entity.SSGPOEmployeesInfo;
import kz.eubank.core.dashboard.domain.model.entity.SSGPOMutualSettlements;
import kz.eubank.core.dashboard.domain.model.mapper.SSGPOEmployeeInfoMapper;
import kz.eubank.core.dashboard.domain.model.mapper.SSGPOSettlementInfoMapper;
import kz.eubank.core.dashboard.domain.repository.SSGPOEmployeesInfoRepository;
import kz.eubank.core.dashboard.domain.repository.SSGPOMutualSettlementsRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SSGPOGateImpl implements SSGPOGate {

    private final SSGPOEmployeesInfoRepository ssgpoEmployeesInfoRepository;
    private final SSGPOMutualSettlementsRepository ssgpoMutualSettlementsRepository;

    @Override
    public SSGPOEmployeeInfoList getSSGPOEmployeeInfoList(String iin, int size, String lang) {
        List<SSGPOEmployeesInfo> employeesInfoEntity = ssgpoEmployeesInfoRepository.findSSGPOEmployeesInfoByIinAndTop(iin, size);
        List<SSGPOEmployeeInfo> employeesInfoDto = employeesInfoEntity
                .stream()
                .map(el -> SSGPOEmployeeInfoMapper.INSTANCE.toDto(el, lang))
                .collect(Collectors.toList());
        fillSettlements(employeesInfoDto, lang);
        return new SSGPOEmployeeInfoList(employeesInfoDto);
    }

    private void fillSettlements(List<SSGPOEmployeeInfo> ssgpoEmployeeInfos, String lang) {
        ssgpoEmployeeInfos.forEach((ssgpoEmployeesInfo) -> {
            List<SSGPOSettlementInfo> settlementsAccrual = new ArrayList<>();
            List<SSGPOSettlementInfo> settlementsRetension = new ArrayList<>();
            List<SSGPOMutualSettlements> ssgpoMutualSettlements =
                    ssgpoMutualSettlementsRepository.getSSGPOMutualSettlements(ssgpoEmployeesInfo.getId());
            ssgpoMutualSettlements.forEach((ssgpoMutualSettlement) -> {
                SSGPOSettlementInfo ssgpoSettlementInfo = SSGPOSettlementInfoMapper.INSTANCE.toDto(ssgpoMutualSettlement, lang);
                if ("Accrual".equals(ssgpoSettlementInfo.getSettlementType())) {
                    settlementsAccrual.add(ssgpoSettlementInfo);
                } else {
                    settlementsRetension.add(ssgpoSettlementInfo);
                }
            });
            ssgpoEmployeesInfo.setSettlementsAccrual(settlementsAccrual);
            ssgpoEmployeesInfo.setSettlementsRetension(settlementsRetension);
        });
    }
}
