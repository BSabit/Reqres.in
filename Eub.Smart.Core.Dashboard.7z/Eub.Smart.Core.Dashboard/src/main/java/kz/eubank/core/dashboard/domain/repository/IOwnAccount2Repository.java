package kz.eubank.core.dashboard.domain.repository;

import kz.eubank.core.dashboard.domain.model.entity.core.Account2;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IOwnAccount2Repository extends CrudRepository<Account2, Long> {

    @Query(nativeQuery = true, value = "select              acc.Account_ID, " +
            "    Account_Title = COALESCE(usracc.Pseudonym, " +
            "                             case :lang " +
            "                                 when 'ru' then prod_term.Term_RU " +
            "                                 when 'kk' then prod_term.Term_KZ " +
            "                                 when 'de' then prod_term.Term_DE " +
            "                                 when 'fr' then prod_term.Term_FR " +
            "                                 when 'tr' then prod_term.Term_TR " +
            "                                 else prod_term.TERM_EN end, " +
            "                             acc.Account_Title), " +
            "                    acc.Currency, " +
            "                    acc.Number, " +
            "                    acc.AccountStatus_IDREF            as Account_Status, " +
            "                    acc.AccountType_IDREF              as Account_Type, " +
            "                    ISNULL(ico.SpriteIndex, 9)         as Sprite_Index, " +
            "                    ISNULL(usrAcc.Account_Priority, 0) as Account_Priority, " +
            "                    acc.Product_IDREF, " +
            "                    acc.InterestRate, " +
            "                    acc.Branch_IDREF, " +
            "                    acc.IsMultiCurrency, " +
            "                    usage.Currency                     as Limit_Currency, " +
            "                    usage.Limit_FinDoc, " +
            "                    usage.Limit_Day, " +
            "                    usage.Limit_Week, " +
            "                    usage.Limit_Month, " +
            "                    perm.AllowSubmitFinDoc, " +
            "                    perm.AllowBalance, " +
            "                    perm.AllowCreateFinDoc, " +
            "                    acc.ContractNo, " +
            "                    acc.Account_IDREF " +
            "from AccountPermission perm " +
            "         left join map_User_Account usrAcc on usrAcc.Account_IDREF = perm.Account_IDREF " +
            "    and perm.User_IDREF = usrAcc.User_IDREF " +
            "         left join UIIcon ico on ico.UIIcon_ID = usrAcc.UIIcon_IDREF " +
            "         left join Account acc on perm.Account_IDREF = acc.Account_ID " +
            "         left join AccountStatus stat on stat.AccountStatus_ID = acc.AccountStatus_IDREF " +
            "    and stat.IsValid = 'true' " +
            "         left join BSystemClient bsys on acc.BSystemClient_IDREF = bsys.BSystemClient_ID " +
            "         left join Usage usage on usage.Usage_ID = perm.Usage_IDREF " +
            "         left join Product prod on prod.Product_ID = acc.Product_IDREF " +
            "         left join Term prod_term on prod.Term_OUTREF = prod_term.Term_ID " +
            "where stat.IsClosed = :isClosed " +
            "  and bsys.Client_IDREF = :clientId " +
            "  and perm.User_IDREF = :userId " +
            "  and acc.AccountType_IDREF in (:typeList) " +
            "order by usrAcc.Account_Priority")
    List<Account2> findAll(@Param("userId") final Long p0, @Param("clientId") final Long p1,
                           @Param("isClosed") final boolean p2, @Param("typeList") final List<String> p3,
                           @Param("lang") final String p4);

    @Query(nativeQuery = true, value = "select      acc.Account_ID,      Account_Title = COALESCE(usracc.Pseudonym, case :lang when 'ru' then prod_term.Term_RU when 'kk' then prod_term.Term_KZ when 'de' then prod_term.Term_DE when 'fr' then prod_term.Term_FR when 'tr' then prod_term.Term_TR else prod_term.TERM_EN end,     acc.Account_Title),      acc.Currency, acc.Number,      acc.AccountStatus_IDREF as Account_Status,      acc.AccountType_IDREF as Account_Type,      ISNULL(ico.SpriteIndex, 9) as Sprite_Index,      ISNULL(usrAcc.Account_Priority, 0) as Account_Priority,      acc.Product_IDREF,      acc.InterestRate,      acc.Branch_IDREF,      acc.IsMultiCurrency,      usage.Currency as Limit_Currency,      usage.Limit_FinDoc,      usage.Limit_Day,      usage.Limit_Week,      usage.Limit_Month,      perm.AllowSubmitFinDoc,      perm.AllowBalance,      perm.AllowCreateFinDoc,acc.ContractNo,acc.Account_IDREF from AccountPermission perm      left outer join map_User_Account usrAcc on usrAcc.Account_IDREF=perm.Account_IDREF           and perm.User_IDREF=usrAcc.User_IDREF      left outer join UIIcon ico on ico.UIIcon_ID = usrAcc.UIIcon_IDREF,      Account acc, AccountStatus stat, BSystemClient bsys, Usage usage,      Product prod left join Term prod_term on prod.Term_OUTREF=prod_term.Term_ID where perm.Account_IDREF=acc.Account_ID      and acc.BSystemClient_IDREF=bsys.BSystemClient_ID      and bsys.Client_IDREF=:clientId      and perm.User_IDREF=:userId      and acc.Number = :account      and usage.Usage_ID = perm.Usage_IDREF     and stat.AccountStatus_ID=acc.AccountStatus_IDREF      and stat.IsValid='true'     and prod.Product_ID=acc.Product_IDREF ")
    Account2 findOne(@Param("userId") final Long p0, @Param("clientId") final Long p1,
                     @Param("account") final String p2, @Param("lang") final String p3);
}
