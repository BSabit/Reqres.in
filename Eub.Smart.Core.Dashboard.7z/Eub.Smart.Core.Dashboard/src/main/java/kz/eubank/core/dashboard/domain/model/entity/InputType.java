package kz.eubank.core.dashboard.domain.model.entity;

import kz.eubank.core.dashboard.domain.model.entity.core.Term;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

@Entity
@Table(name = "InputType")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class InputType {

    @Id
    @Column(name = "InputType_ID")
    private String code;

    @Column(name = "InputType_Title")
    String title;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;

    @Column(name = "HTMLType")
    String htmlType;

    @Column(name = "Mask")
    String mask;

    @Column(name = "Size")
    Long size;

    @Column(name = "Regex")
    String regEx;
    
    @Column(name = "Preprocessor")
    String preprocessor;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Term getTerms() {
        return terms;
    }

    public void setTerms(Term terms) {
        this.terms = terms;
    }

    public String getHtmlType() {
        return htmlType;
    }

    public void setHtmlType(String htmlType) {
        this.htmlType = htmlType;
    }

    public String getMask() {
        return mask;
    }

    public void setMask(String mask) {
        this.mask = mask;
    }

    public Long getSize() {
        return size;
    }

    public void setSize(Long size) {
        this.size = size;
    }

    public String getRegEx() {
        return regEx;
    }

    public void setRegEx(String regEx) {
        this.regEx = regEx;
    }

    public String getPreprocessor() {
        return preprocessor;
    }
}
