package kz.eubank.core.dashboard.domain.model.entity;

import javax.persistence.*;

@Entity
@Table(name = "CardAccount")
public class CardAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CardAccount_ID")
    private Long id;
    
    @Column(name = "Account_IDREF")
    private Long accountId;
    
    @Column(name = "HasActiveInstallments")
    private boolean hasActiveInstallments;
    
    @Column(name = "IsMultiCurrency")
    private boolean multiCurrency;
    
    @Column(name = "IsInstallment")
    private boolean installment;
    
    
    @Column(name = "IsBonusFood")
    private boolean isBonusFood;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public boolean isHasActiveInstallments() {
        return hasActiveInstallments;
    }

    public void setHasActiveInstallments(boolean hasActiveInstallments) {
        this.hasActiveInstallments = hasActiveInstallments;
    }

    public boolean isMultiCurrency() {
        return multiCurrency;
    }

    public void setMultiCurrency(boolean multiCurrency) {
        this.multiCurrency = multiCurrency;
    }

    public boolean isInstallment() {
        return installment;
    }

    public void setInstallment(boolean installment) {
        this.installment = installment;
    }

    public boolean isBonusFood() {
        return isBonusFood;
    }

    public void setBonusFood(boolean isBonusFood) {
        this.isBonusFood = isBonusFood;
    }
}
