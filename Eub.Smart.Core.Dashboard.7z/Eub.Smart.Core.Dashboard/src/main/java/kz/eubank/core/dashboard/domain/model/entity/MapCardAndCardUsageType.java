package kz.eubank.core.dashboard.domain.model.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name = "map_Card_CardUsageType")
public class MapCardAndCardUsageType {

    @Id
    @Column(name = "Card_IDREF")
    private Long cardId;

    @OneToOne
    @JoinColumn(name = "CardUsageType_IDREF")
    private CardUsageType cardUsageType;

    @Column(name = "Currency")
    private String currency;

    @Column(name = "Phase_Type")
    private String phaseType;

    @Column(name = "Phase_Length")
    private int phaseLength;

    @Column(name = "Amount")
    private BigDecimal amount;
}
