package kz.eubank.core.dashboard.domain.repository;

import kz.eubank.core.dashboard.domain.model.entity.core.Branch;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface IBranchRepository extends CrudRepository<Branch, Long> {

    Optional<Branch> findById(final Long p0);
}
