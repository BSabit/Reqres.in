package kz.eubank.core.dashboard.infrastructure.config;

import org.dozer.DozerBeanMapper;

import java.lang.reflect.Array;
import java.util.*;

public class Mapper<S> {

    private final DozerBeanMapper mapper;
    private final S source;

    public Mapper(final DozerBeanMapper mapper, final S source) {
        this.mapper = mapper;
        this.source = source;
    }

    public <D> List<D> toList(final Class<D> destinationClass) {
        if (this.source == null) {
            return null;
        }
        List<D> destination = Collections.emptyList();
        if (this.source instanceof Collection || this.source instanceof Object[]) {
            Collection<S> source = null;
            if (this.source instanceof Object[]) {
                source = (Collection<S>) Arrays.asList((Object[]) this.source);
            } else {
                source = (Collection<S>) this.source;
            }
            destination = new ArrayList<D>(source.size());
            for (final S s : source) {
                destination.add((D) mapper.map((Object) s, (Class) destinationClass));
            }
        }
        return destination;
    }

    public <D> D[] toArray(final Class<D> destinationClass) {
        if (this.source == null) {
            return null;
        }
        D[] destination = (D[]) Array.newInstance(destinationClass, 0);
        if (this.source instanceof Collection || this.source instanceof Object[]) {
            Collection<S> source;
            if (this.source instanceof Object[]) {
                source = (Collection<S>) Arrays.asList((Object[]) this.source);
            } else {
                source = (Collection<S>) this.source;
            }
            final int size = source.size();
            destination = (D[]) Array.newInstance(destinationClass, size);
            int i = 0;
            for (S obj : source) {
                destination[i++] = this.mapper.map(obj, destinationClass);
            }
        }
        return destination;
    }

    public <D> D to(final Class<D> destinationClass) {
        if (this.source == null) {
            return null;
        }
        return (D) this.mapper.map(this.source, (Class) destinationClass);
    }

    public <D> D to(final Class<D> destinationClass, final String mapId) {
        if (this.source == null) {
            return null;
        }
        return (D) this.mapper.map(this.source, (Class) destinationClass, mapId);
    }

    public <D> void to(final D destinationObject) {
        this.mapper.map(this.source, (Object) destinationObject);
    }

    public <D> void to(final D destinationObject, final String mapId) {
        this.mapper.map(this.source, (Object) destinationObject, mapId);
    }
}
