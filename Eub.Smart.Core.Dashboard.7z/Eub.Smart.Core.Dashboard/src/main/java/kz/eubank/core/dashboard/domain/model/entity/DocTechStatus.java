package kz.eubank.core.dashboard.domain.model.entity;

import kz.eubank.core.dashboard.domain.model.entity.core.Term;

import javax.persistence.*;

@Entity
@Table(name = "DocTechStatus")
public class DocTechStatus {

    @Id
    @Column(name = "DocTechStatus_ID")
    private String id;

    @Column(name = "DocTechStatus_Title")
    private String title;

    @OneToOne()
    @JoinColumn(name = "FinDocStatus_IDREF")
    private FinDocStatus status;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public FinDocStatus getStatus() {
        return status;
    }

    public Term getTerms() {
        return terms;
    }

    public void setTerms(Term terms) {
        this.terms = terms;
    }

    public void setTitle(String title) {
        this.title = title;
    }

}
