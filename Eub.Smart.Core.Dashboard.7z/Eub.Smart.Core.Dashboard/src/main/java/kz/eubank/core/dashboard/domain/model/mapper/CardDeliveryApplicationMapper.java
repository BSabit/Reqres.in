package kz.eubank.core.dashboard.domain.model.mapper;

import kz.eubank.core.dashboard.domain.model.dto.CardDeliveryMethod;
import kz.eubank.core.dashboard.domain.model.entity.CardDeliveryApplication;
import kz.eubank.core.dashboard.domain.model.entity.core.City;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface CardDeliveryApplicationMapper {

    CardDeliveryApplication toCardDeliveryApplicationEntity(kz.eubank.core.dashboard.domain.model.dto.CardDeliveryApplication applicationDto);

    kz.eubank.core.dashboard.domain.model.dto.CardDeliveryApplication toCardDeliveryApplicationDto(CardDeliveryApplication application);

    @Mapping(target = "code", source = "code")
    kz.eubank.core.dashboard.domain.model.entity.CardDeliveryMethod toCardDeliveryMethodEntity(CardDeliveryMethod cardDeliveryMethodDto);

    @Mapping(target = "code", source = "code")
    CardDeliveryMethod toCardDeliveryMethodDto(kz.eubank.core.dashboard.domain.model.entity.CardDeliveryMethod cardDeliveryMethodDto);

    default String cityTitleFromCity(City city) {
        return city != null ? city.getTitle() : null;
    }

    default City cityFromCityTitle(String cityTitle) {
        if (cityTitle != null) {
            City city = new City();
            city.setTitle(cityTitle);
            return city;
        }
        return null;
    }
}
