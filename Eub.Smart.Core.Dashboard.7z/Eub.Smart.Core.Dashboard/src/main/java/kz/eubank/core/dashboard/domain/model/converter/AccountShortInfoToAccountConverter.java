package kz.eubank.core.dashboard.domain.model.converter;


import kz.eubank.core.dashboard.domain.model.dto.AccountLongInfo;
import kz.eubank.core.dashboard.domain.model.dto.AccountShortInfo;
import kz.eubank.core.dashboard.domain.model.dto.CardAccount;
import kz.eubank.core.dashboard.domain.model.dto.Limits;
import kz.eubank.core.dashboard.domain.model.response.Account;
import lombok.extern.slf4j.Slf4j;
import org.dozer.CustomConverter;
import org.springframework.beans.BeanUtils;

import java.math.BigDecimal;

@Slf4j
public class AccountShortInfoToAccountConverter implements CustomConverter {

    @Override
    public Object convert(Object dest, Object source, Class<?> arg2, Class<?> arg3) {
        if (source == null) {
            return null;
        }
        if (arg2.equals(AccountShortInfo.class)) {
            if (source instanceof Account) {
                Account account = (Account) source;
                AccountShortInfo accountShortInfo = new AccountShortInfo();
                BeanUtils.copyProperties(account, accountShortInfo);//todo remove
                return accountShortInfo;
            }
        } else if (arg2.equals(CardAccount.class)) {
            if (source instanceof AccountLongInfo) {
                AccountLongInfo accountLongInfo = (AccountLongInfo) source;
                CardAccount cardAccount = new CardAccount();

                if (accountLongInfo.getStatus() != null) {
                    cardAccount.setStatus(String2AccountStatus_Converter.convert(accountLongInfo.getStatus().getCode())
                            .getCode());
                }

                cardAccount.setActions(accountLongInfo.getActions());
                cardAccount.setCurrency(accountLongInfo.getCurrency());
                cardAccount.setNumber(accountLongInfo.getNumber());
                cardAccount.setPriority(accountLongInfo.getPriority());
                cardAccount.setTitle(accountLongInfo.getTitle());
                cardAccount.setType(accountLongInfo.getType());
                cardAccount.setAllowCreateFinDoc(accountLongInfo.isAllowCreateFinDoc());
                cardAccount.setShowBalance(accountLongInfo.isAllowBalance());
                cardAccount.setAllowTransfer(accountLongInfo.isAllowCreateFinDoc());
                cardAccount.setMultiCurrency(accountLongInfo.isMultiCurrency());
                cardAccount.setContractNo(accountLongInfo.getContractNo());
                cardAccount.setParentAccountId(accountLongInfo.getParentAccountId());
                cardAccount.setId(accountLongInfo.getId());
                cardAccount.setBranchTitle(accountLongInfo.getBranchTitle());

                cardAccount.setOverdraft(accountLongInfo.getOverdraft());
                cardAccount.setCurrentInterest(accountLongInfo.getCurrentInterest());
                cardAccount.setLastMonthInterest(accountLongInfo.getLastMonthInterest());
                cardAccount.setAllPeriodInterest(accountLongInfo.getAllPeriodInterest());
                cardAccount.setCashbackForPeriod(accountLongInfo.getCashbackForPeriod());
                cardAccount.setPeriodOfCashBack(accountLongInfo.getPeriodOfCashBack());
                cardAccount.setTotalCashback(accountLongInfo.getTotalCashback());
                cardAccount.setSubAccountBalances(accountLongInfo.getSubAccountBalances());
                cardAccount.setSubAccountAvailableBalances(accountLongInfo.getSubAccountAvailableBalances());
                cardAccount.setInstallmentAccount(accountLongInfo.getInstallmentAccount());
                cardAccount.setActiveInstallments(accountLongInfo.getActiveInstallments());
                cardAccount.setAccountGraceInfo(accountLongInfo.getAccountGraceInfo());
                cardAccount.setFinBlocking(accountLongInfo.getFinBlocking());
                cardAccount.setGrace(accountLongInfo.isGrace());
                cardAccount.setMultiCurrency(accountLongInfo.isMultiCurrency());
                cardAccount.setAllowBalance(accountLongInfo.isAllowBalance());

                cardAccount.setDateClosed((accountLongInfo.getDateClosed() != null)
                        ? accountLongInfo.getDateClosed().getTime() : 0);
                cardAccount.setDateOpened((accountLongInfo.getDateOpened() != null)
                        ? accountLongInfo.getDateOpened().getTime() : 0);

                cardAccount.setInterestRate(accountLongInfo.getInterestRate() == null ? 0
                        : accountLongInfo.getInterestRate().intValue());
                cardAccount.setMinBalance(accountLongInfo.getMinBalance() == null ? 0
                        : accountLongInfo.getMinBalance());

                cardAccount.setLimits(new Limits(accountLongInfo.getLimitCurrency(),
                        accountLongInfo.getLimitDay().intValue(),
                        accountLongInfo.getLimitMonth().intValue(), accountLongInfo.getLimitFinDoc().intValue(),
                        accountLongInfo.getLimitWeek().intValue()));

                cardAccount.setOverdraft(accountLongInfo.getOverdraft() == null ? BigDecimal.ZERO
                        : accountLongInfo.getOverdraft());
                cardAccount.setCurrentInterest(accountLongInfo.getCurrentInterest() == null ? BigDecimal.ZERO
                        : accountLongInfo.getCurrentInterest());
                cardAccount.setLastMonthInterest(accountLongInfo.getLastMonthInterest() == null ? BigDecimal.ZERO
                        : accountLongInfo.getLastMonthInterest());
                cardAccount.setAllPeriodInterest(accountLongInfo.getAllPeriodInterest() == null ? BigDecimal.ZERO
                        : accountLongInfo.getAllPeriodInterest());
                cardAccount.setCashbackForPeriod(accountLongInfo.getCashbackForPeriod() == null ? BigDecimal.ZERO
                        : accountLongInfo.getCashbackForPeriod());
                cardAccount.setPeriodOfCashBack(accountLongInfo.getPeriodOfCashBack() == null ? BigDecimal.ZERO
                        : accountLongInfo.getPeriodOfCashBack());
                cardAccount.setTotalCashback(accountLongInfo.getTotalCashback() == null ? BigDecimal.ZERO
                        : accountLongInfo.getTotalCashback());
                cardAccount.setFullDebtAmount(accountLongInfo.getFullDebtAmount() == null ? BigDecimal.ZERO
                        : accountLongInfo.getFullDebtAmount());
                cardAccount.setBlockedSum(accountLongInfo.getBlockedSum() == null ? BigDecimal.ZERO
                        : accountLongInfo.getBlockedSum());
                cardAccount.setActualBalance(accountLongInfo.getActualBalance() == null ? BigDecimal.ZERO
                        : accountLongInfo.getActualBalance());
                cardAccount.setBalance(accountLongInfo.getBalance() == null ? BigDecimal.ZERO
                        : accountLongInfo.getBalance());

                return cardAccount;
            }
        } else if (arg2.equals(Account.class)) {//source instanceof AccountShortInfo or AccountLongInfo
            AccountShortInfo accountShortInfo = (AccountShortInfo) source;
            Account account = new Account();
            accountShortInfoToAccount(accountShortInfo, account);
            return account;
        }
        return null;
    }

    private static void accountShortInfoToAccount(AccountShortInfo accountShortInfo, Account account) {
        if (accountShortInfo.getStatus() != null) {
            account.setStatus(accountShortInfo.getStatus().getCode());//todo check
        }

        account.setActions(accountShortInfo.getActions());
        account.setCurrency(accountShortInfo.getCurrency());
        account.setNumber(accountShortInfo.getNumber());
        account.setPriority(accountShortInfo.getPriority());
        account.setTitle(accountShortInfo.getTitle());
        account.setType(accountShortInfo.getType());
        account.setAllowBalance(accountShortInfo.isAllowBalance());
        account.setAllowCreateFinDoc(accountShortInfo.isAllowCreateFinDoc());
        account.setActualBalance(accountShortInfo.getActualBalance());
        account.setBalance(accountShortInfo.getBalance());
        account.setMultiCurrency(accountShortInfo.isMultiCurrency());
        account.setContractNo(accountShortInfo.getContractNo());
        account.setParentAccountId(accountShortInfo.getParentAccountId());
        account.setId(accountShortInfo.getId());
        account.setAllowTransfer(accountShortInfo.isAllowCreateFinDoc());
        account.setShowBalance(accountShortInfo.isAllowBalance());

        account.setBlockedSum(accountShortInfo.getBlockedSum() == null ? BigDecimal.ZERO
                : accountShortInfo.getBlockedSum());
    }
}