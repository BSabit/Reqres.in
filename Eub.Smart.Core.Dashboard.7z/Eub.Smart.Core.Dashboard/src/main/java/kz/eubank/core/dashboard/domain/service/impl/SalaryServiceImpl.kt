package kz.eubank.core.dashboard.domain.service.impl

import kz.eubank.core.dashboard.domain.gate.SSGPOGate
import kz.eubank.core.dashboard.domain.gate.SalaryGate
import kz.eubank.core.dashboard.domain.model.dto.SSGPOEmployeeInfoList
import kz.eubank.core.dashboard.domain.model.dto.SettlementSheetEmployeeList
import kz.eubank.core.dashboard.domain.service.SalaryService
import kz.eubank.core.dashboard.infrastructure.config.ApplicationContext
import org.springframework.stereotype.Service

@Service
class SalaryServiceImpl(
    private val salaryGate: SalaryGate,
    private val ssgpoGate: SSGPOGate,
    private val context: ApplicationContext
) : SalaryService {

    override suspend fun getSettlementSheetEmployeesResult(period: Int): SettlementSheetEmployeeList? {
        val iin = context.currentUser.iin
        return salaryGate.getSettlementSheetEmployeesResult(iin, period)
    }

    override fun getSSGPOPersonInfo(period: Int, lang: String): SSGPOEmployeeInfoList? {
        val iin = context.currentUser.iin
        return ssgpoGate.getSSGPOEmployeeInfoList(iin, period, lang)
    }
}