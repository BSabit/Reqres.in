// 
// Decompiled by Procyon v0.5.36
// 

package kz.eubank.core.dashboard.domain.model.response;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

public class Validator {

    public static final int MAXIMUM_PAGE_SIZE = 50;
    public static final int MINIMUM_SEARCH_LENGTH = 3;
    private final Map<Validation, Map<String, Object>> validate;
    private final Map<String, Validation> errors;

    public Validator() {
        this.validate = new TreeMap<>();
        this.errors = new HashMap<>();
        this.validate.put(Validation.NOT_BLANK, new HashMap<>());
        this.validate.put(Validation.NUMERIC, new HashMap<>());
        this.validate.put(Validation.PAGE_SIZE, new HashMap<>());
        this.validate.put(Validation.SEARCH_LENGTH, new HashMap<>());
    }

    public Map<String, Validation> getErrors() {
        return this.errors;
    }

    public boolean isValid() {
        this.errors.clear();
        final Iterator<Validation> i = this.validate.keySet().iterator();
        Validation v;
        while (i.hasNext() && (v = i.next()) != null) {
            final Map<String, Object> fields = this.validate.get(v);
            if (!fields.isEmpty()) {
                switch (Validator.Validation.values()[v.ordinal()]) {
                    case NOT_BLANK: {
                        this.validateNotBlankFields(fields);
                        continue;
                    }
                    case SEARCH_LENGTH: {
                        this.validateSearchFields(fields);
                        continue;
                    }
                    case NUMERIC: {
                        this.validateNumericFields(fields);
                        continue;
                    }
                    case PAGE_SIZE: {
                        this.validatePageSizeFields(fields);
                    }
                }
            }
        }
        return this.errors.isEmpty();
    }

    public void validate(final String field, final Object value, final Validation validation) {
        final Map<String, Object> fields = this.validate.get(validation);
        fields.put(field, value);
    }

    private void validateNotBlankFields(final Map<String, Object> fields) {
        fields.entrySet().stream().filter(q -> (q.getValue() == null || q.getValue().equals(""))).forEach(q -> {
            errors.put(q.getKey(), Validation.NOT_BLANK);
        });
    }

    private void validateNumericFields(final Map<String, Object> fields) {
        fields.forEach((key, value) -> {
            try {
                new BigDecimal(value.toString());
            } catch (NumberFormatException e) {
                this.errors.put(key, Validation.NUMERIC);
            }
        });
    }

    private void validateSearchFields(final Map<String, Object> fields) {
        fields.entrySet().stream()
                .filter(q -> (q.getValue() == null || q.getValue().equals("") || q.getValue().toString().length() < 3))
                .forEach(q -> errors.put(q.getKey(), Validation.SEARCH_LENGTH));
    }

    private void validatePageSizeFields(final Map<String, Object> fields) {
        for (final Map.Entry<String, Object> entry : fields.entrySet()) {
            try {
                final int size = Integer.parseInt(entry.getValue().toString());
                if (size <= 50) {
                    continue;
                }
                this.errors.put(entry.getKey(), Validation.PAGE_SIZE);
            } catch (NumberFormatException e) {
                this.errors.put(entry.getKey(), Validation.PAGE_SIZE);
            }
        }
    }

    public enum Validation {
        NOT_BLANK,
        NUMERIC,
        PAGE_SIZE,
        SEARCH_LENGTH;
    }
}
