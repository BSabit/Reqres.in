package kz.eubank.core.dashboard.domain.model.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SSGPOEmployeeInfoList {
    private List<SSGPOEmployeeInfo> list;

    public int getSize() {
        return (this.getList() != null) ? this.getList().size() : 0;
    }
}
