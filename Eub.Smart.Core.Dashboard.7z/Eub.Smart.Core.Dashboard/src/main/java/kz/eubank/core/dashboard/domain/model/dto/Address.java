package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Generated;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class Address {
    private Long id;
    private String country;
    private City city;
    private String place;
    private String placeType;
    private String houseNo;
    private String apartmentNo;
    private AddressType type;
    private String title;
    private Country countryFull;
    private Double longitude;
    private Double latitude;
    private String phone;
    private String fax;
    private String workPhone;

    @Generated
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof Address)) {
            return false;
        }
        final Address other = (Address) o;
        if (!other.canEqual(this)) {
            return false;
        }
        final Object this$id = this.getId();
        final Object other$id = other.getId();
        Label_0065:
        {
            if (this$id == null) {
                if (other$id == null) {
                    break Label_0065;
                }
            } else if (this$id.equals(other$id)) {
                break Label_0065;
            }
            return false;
        }
        final Object this$country = this.getCountry();
        final Object other$country = other.getCountry();
        Label_0102:
        {
            if (this$country == null) {
                if (other$country == null) {
                    break Label_0102;
                }
            } else if (this$country.equals(other$country)) {
                break Label_0102;
            }
            return false;
        }
        final Object this$city = this.getCity();
        final Object other$city = other.getCity();
        Label_0139:
        {
            if (this$city == null) {
                if (other$city == null) {
                    break Label_0139;
                }
            } else if (this$city.equals(other$city)) {
                break Label_0139;
            }
            return false;
        }
        final Object this$place = this.getPlace();
        final Object other$place = other.getPlace();
        Label_0176:
        {
            if (this$place == null) {
                if (other$place == null) {
                    break Label_0176;
                }
            } else if (this$place.equals(other$place)) {
                break Label_0176;
            }
            return false;
        }
        final Object this$placeType = this.getPlaceType();
        final Object other$placeType = other.getPlaceType();
        Label_0213:
        {
            if (this$placeType == null) {
                if (other$placeType == null) {
                    break Label_0213;
                }
            } else if (this$placeType.equals(other$placeType)) {
                break Label_0213;
            }
            return false;
        }
        final Object this$houseNo = this.getHouseNo();
        final Object other$houseNo = other.getHouseNo();
        Label_0250:
        {
            if (this$houseNo == null) {
                if (other$houseNo == null) {
                    break Label_0250;
                }
            } else if (this$houseNo.equals(other$houseNo)) {
                break Label_0250;
            }
            return false;
        }
        final Object this$apartmentNo = this.getApartmentNo();
        final Object other$apartmentNo = other.getApartmentNo();
        Label_0287:
        {
            if (this$apartmentNo == null) {
                if (other$apartmentNo == null) {
                    break Label_0287;
                }
            } else if (this$apartmentNo.equals(other$apartmentNo)) {
                break Label_0287;
            }
            return false;
        }
        final Object this$type = this.getType();
        final Object other$type = other.getType();
        Label_0324:
        {
            if (this$type == null) {
                if (other$type == null) {
                    break Label_0324;
                }
            } else if (this$type.equals(other$type)) {
                break Label_0324;
            }
            return false;
        }
        final Object this$title = this.getTitle();
        final Object other$title = other.getTitle();
        Label_0361:
        {
            if (this$title == null) {
                if (other$title == null) {
                    break Label_0361;
                }
            } else if (this$title.equals(other$title)) {
                break Label_0361;
            }
            return false;
        }
        final Object this$countryFull = this.getCountryFull();
        final Object other$countryFull = other.getCountryFull();
        Label_0398:
        {
            if (this$countryFull == null) {
                if (other$countryFull == null) {
                    break Label_0398;
                }
            } else if (this$countryFull.equals(other$countryFull)) {
                break Label_0398;
            }
            return false;
        }
        final Object this$longitude = this.getLongitude();
        final Object other$longitude = other.getLongitude();
        Label_0435:
        {
            if (this$longitude == null) {
                if (other$longitude == null) {
                    break Label_0435;
                }
            } else if (this$longitude.equals(other$longitude)) {
                break Label_0435;
            }
            return false;
        }
        final Object this$latitude = this.getLatitude();
        final Object other$latitude = other.getLatitude();
        Label_0472:
        {
            if (this$latitude == null) {
                if (other$latitude == null) {
                    break Label_0472;
                }
            } else if (this$latitude.equals(other$latitude)) {
                break Label_0472;
            }
            return false;
        }
        final Object this$phone = this.getPhone();
        final Object other$phone = other.getPhone();
        Label_0509:
        {
            if (this$phone == null) {
                if (other$phone == null) {
                    break Label_0509;
                }
            } else if (this$phone.equals(other$phone)) {
                break Label_0509;
            }
            return false;
        }
        final Object this$fax = this.getFax();
        final Object other$fax = other.getFax();
        Label_0546:
        {
            if (this$fax == null) {
                if (other$fax == null) {
                    break Label_0546;
                }
            } else if (this$fax.equals(other$fax)) {
                break Label_0546;
            }
            return false;
        }
        final Object this$workPhone = this.getWorkPhone();
        final Object other$workPhone = other.getWorkPhone();
        if (this$workPhone == null) {
            return other$workPhone == null;
        } else return this$workPhone.equals(other$workPhone);
    }

    @Generated
    protected boolean canEqual(final Object other) {
        return other instanceof Address;
    }

    @Generated
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $id = this.getId();
        result = result * PRIME + (($id == null) ? 43 : $id.hashCode());
        final Object $country = this.getCountry();
        result = result * PRIME + (($country == null) ? 43 : $country.hashCode());
        final Object $city = this.getCity();
        result = result * PRIME + (($city == null) ? 43 : $city.hashCode());
        final Object $place = this.getPlace();
        result = result * PRIME + (($place == null) ? 43 : $place.hashCode());
        final Object $placeType = this.getPlaceType();
        result = result * PRIME + (($placeType == null) ? 43 : $placeType.hashCode());
        final Object $houseNo = this.getHouseNo();
        result = result * PRIME + (($houseNo == null) ? 43 : $houseNo.hashCode());
        final Object $apartmentNo = this.getApartmentNo();
        result = result * PRIME + (($apartmentNo == null) ? 43 : $apartmentNo.hashCode());
        final Object $type = this.getType();
        result = result * PRIME + (($type == null) ? 43 : $type.hashCode());
        final Object $title = this.getTitle();
        result = result * PRIME + (($title == null) ? 43 : $title.hashCode());
        final Object $countryFull = this.getCountryFull();
        result = result * PRIME + (($countryFull == null) ? 43 : $countryFull.hashCode());
        final Object $longitude = this.getLongitude();
        result = result * PRIME + (($longitude == null) ? 43 : $longitude.hashCode());
        final Object $latitude = this.getLatitude();
        result = result * PRIME + (($latitude == null) ? 43 : $latitude.hashCode());
        final Object $phone = this.getPhone();
        result = result * PRIME + (($phone == null) ? 43 : $phone.hashCode());
        final Object $fax = this.getFax();
        result = result * PRIME + (($fax == null) ? 43 : $fax.hashCode());
        final Object $workPhone = this.getWorkPhone();
        result = result * PRIME + (($workPhone == null) ? 43 : $workPhone.hashCode());
        return result;
    }

    @Generated
    @Override
    public String toString() {
        return "Address(id=" + this.getId() + ", country=" + this.getCountry() + ", city=" + this.getCity() + ", place=" + this.getPlace() + ", placeType=" + this.getPlaceType() + ", houseNo=" + this.getHouseNo() + ", apartmentNo=" + this.getApartmentNo() + ", type=" + this.getType() + ", title=" + this.getTitle() + ", countryFull=" + this.getCountryFull() + ", longitude=" + this.getLongitude() + ", latitude=" + this.getLatitude() + ", phone=" + this.getPhone() + ", fax=" + this.getFax() + ", workPhone=" + this.getWorkPhone() + ")";
    }
}
