package kz.eubank.core.dashboard.domain.model.dto

data class SettlementSheetEmployeeList(
    var sheets: MutableCollection<SettlementSheetEmployee> = mutableListOf()
)