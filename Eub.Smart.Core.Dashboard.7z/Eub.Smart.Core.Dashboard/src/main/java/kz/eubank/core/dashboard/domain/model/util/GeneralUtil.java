package kz.eubank.core.dashboard.domain.model.util;

import kz.eubank.core.dashboard.domain.model.enums.ErrorMessages;
import kz.eubank.core.dashboard.infrastructure.exception.ServiceException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Component
public class GeneralUtil {

    public <T> T getAsync(Future<T> asyncInvocation) {
        try {
            return asyncInvocation.get(60L, TimeUnit.SECONDS);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new ServiceException(ErrorMessages.UNABLE_TO_COMPLETE_OPERATION.getErrorMessage(), ex,
                    HttpStatus.INTERNAL_SERVER_ERROR.value());
        } catch (ExecutionException | TimeoutException ex) {
            throw new ServiceException(ErrorMessages.UNABLE_TO_COMPLETE_OPERATION.getErrorMessage(), ex,
                    HttpStatus.INTERNAL_SERVER_ERROR.value());
        }
    }
}
