package kz.eubank.core.dashboard.domain.service.impl;

import kz.eubank.core.dashboard.domain.gate.IAccountGate;
import kz.eubank.core.dashboard.domain.gate.ICardGate;
import kz.eubank.core.dashboard.domain.model.dto.*;
import kz.eubank.core.dashboard.domain.model.entity.core.Account2;
import kz.eubank.core.dashboard.domain.model.entity.core.Branch;
import kz.eubank.core.dashboard.domain.model.response.Account;
import kz.eubank.core.dashboard.domain.model.response.AccountList;
import kz.eubank.core.dashboard.domain.model.util.GeneralUtil;
import kz.eubank.core.dashboard.domain.repository.*;
import kz.eubank.core.dashboard.domain.service.IAccountService;
import kz.eubank.core.dashboard.domain.service.IAllAccService;
import kz.eubank.core.dashboard.infrastructure.config.AppProperties;
import kz.eubank.core.dashboard.infrastructure.config.ApplicationContext;
import kz.eubank.core.dashboard.infrastructure.config.MapperHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.Future;

@Service
public class AllAccServiceImpl implements IAllAccService {

    @Autowired
    private IAccountService accountService;

    @Autowired
    private AppProperties appProperties;

    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    private IAccountGate accountGate;

    @Autowired
    private ICardGate cardGate;

    @Autowired
    private MapperHelper mapperHelper;

    @Autowired
    private IDepositAccountRepository depositAccountRepository;

    @Autowired
    private IBranchRepository branchRepository;

    @Autowired
    private IAccountRepository accountRepository;

    @Autowired
    private IAccount2Repository account2Repository;

    @Autowired
    private IApplicationRepository applicationRepository;

    @Autowired
    private GeneralUtil generalUtil;

    @Override
    public AccountList getCardAccounts(String balanceCurrency, String dateFromStr, String dateTillStr) {
        if (balanceCurrency == null || balanceCurrency.isEmpty()) {
            balanceCurrency = "KZT";
        }
        AccountList accountList = generalUtil.getAsync(getCardAccounts(balanceCurrency, Boolean.FALSE, true));
        List<Account> cardAccountList = new ArrayList<>();
        for (Account account : accountList.getAccounts()) {
            CardAccount val = (CardAccount) account;
            CardAccount cardAccount = getCardAccount(account.getNumber());
            CardList cards = listCards(account.getNumber(), Boolean.TRUE, Boolean.FALSE);
            cardAccount.setCards(cards.getCards());
            cardAccount.setHasStandingOrders(accountService.getHasFutureStandingOrder(account.getNumber(), dateFromStr,
                    dateTillStr));
            cardAccount.setLimits(val.getLimits());
            cardAccountList.add(cardAccount);
        }
        return new AccountList(cardAccountList);
    }

    public Future<AccountList> getCardAccounts(String balanceCurrency, Boolean isClosed, boolean addBalances) {
        String[] accountTypes = {appProperties.getCardAccountType()};
        Collection<AccountLongInfo> accountsInfo = accountService.getAccountsInfo(accountTypes, isClosed, addBalances,
                balanceCurrency, CARD_ACC_ACCOUNT_TYPE, CARD_ACC_ACCOUNT);
        CardAccount[] cardAccounts = mapperHelper.map((Object) accountsInfo).toArray(CardAccount.class);
        return (Future<AccountList>) new AsyncResult(new AccountList(Arrays.asList(cardAccounts)));
    }

    public CardAccount getCardAccount(String accountNr) {
        Long clientId = applicationContext.getCurrentUser().getClientId();
        Long userId = applicationContext.getCurrentUser().getUserId();
        String lang = applicationContext.getLanguage();
        AccountLongInfo accountLongInfo = accountGate.getAccountDetails(userId, clientId, accountNr, lang);
        CardAccount account = (CardAccount) mapperHelper.map((Object) accountLongInfo).to((Class) CardAccount.class);
        account.setShowInstallements((account.getInstallmentAccount() && account.getActiveInstallments())
                || account.getActions().contains("DACC"));
        if (account.getBalance() != null) {
            account.setOwnFunds((account.getBalance().doubleValue() > 0.0) ? account.getBalance() : BigDecimal.valueOf(0L));
        }
        account.setFinBlocking((account.getFinBlocking() != null && account.getFinBlocking().doubleValue() > 0.0)
                ? account.getFinBlocking() : BigDecimal.valueOf(0L));
        CardProductOperation cardProductOperation = accountGate.getCardProductOperation(accountLongInfo.getProductId());
        account.setCardProductOperation(cardProductOperation);
        if (account.isMultiCurrency()) {
            account.setSubAccountActionEUR(appProperties.getSubAccountAction("EUR"));
            account.setSubAccountActionKZT(appProperties.getSubAccountAction("KZT"));
            account.setSubAccountActionUSD(appProperties.getSubAccountAction("USD"));
        }
        return account;
    }

    public CardList listCards(String account, Boolean valid, Boolean closed) {
        CardXml[] cards = getAllCards(account, valid, closed);
        Card[] ret = mapperHelper.map(cards).toArray(Card.class);//todo mapper
        for (Card card : ret) {
            card.setCardTransactionStatus("");
        }
        return new CardList(Arrays.asList(ret));
    }

    private CardXml[] getAllCards(String accountNr, Boolean valid, Boolean closed) {
        Collection<CardLongInfo> cardsLongInfos = cardGate.getCardsLongInfo(accountNr, valid, closed,
                applicationContext.getCurrentUser().getUserId());
        if (cardsLongInfos == null) {
            throw new IllegalArgumentException("cardsLongInfos list is null!");
        }
        return mapperHelper.map(cardsLongInfos).toArray(CardXml.class);
    }

    @Override
    public AccountList getCurrentAccounts(String balanceCurrency) {
        if (balanceCurrency == null || balanceCurrency.isEmpty()) {
            balanceCurrency = "KZT";
        }
        return generalUtil.getAsync(listFutureCurrentAccounts(balanceCurrency));
    }

    private Future<AccountList> listFutureCurrentAccounts(String balanceCurrency) {
        String[] accountTypes = {appProperties.getCurrentAccountType()};
        Collection<AccountLongInfo> accountsInfo = accountService.getAccountsInfo(accountTypes, false, true,
                balanceCurrency, CURR_ACC_ACCOUNT_TYPE, CURR_ACC_ACCOUNT);
        AccountList accountList = convertAccountsInfoToAccountList(accountsInfo);
        return (Future<AccountList>) new AsyncResult(accountList);
    }

    private AccountList convertAccountsInfoToAccountList(Collection<AccountLongInfo> accountsInfo) {
        List<Account> accounts = mapperHelper.map(accountsInfo).toList(Account.class);
        return new AccountList(accounts);
    }

    @Override
    public AccountList getDeposits(String balanceCurrency, String dateFromStr, String dateTillStr) {
        if (balanceCurrency == null || balanceCurrency.isEmpty()) {
            balanceCurrency = "KZT";
        }
        List<DepositAccount> depositAccountList = new ArrayList<>();
        AccountList list = generalUtil.getAsync(getAllDeposits(balanceCurrency, Boolean.FALSE, true));
        for (Account account : list.getAccounts()) {
            DepositAccount depositAccount = getDepositAccount(account);
            account.setHasStandingOrders(accountService.getHasFutureStandingOrder(account.getNumber(), dateFromStr,
                    dateTillStr));
            depositAccountList.add(depositAccount);
        }
        return new AccountList(depositAccountList);
    }

    public Future<AccountList> getAllDeposits(String balanceCurrency, Boolean isClosed, boolean addBalances) {
        String[] accountTypes = {appProperties.getDepositAccountType()};
        Collection<AccountLongInfo> accountsShortInfo = accountService.getAccountsInfo(accountTypes, isClosed,
                addBalances, balanceCurrency, DEPOSIT_ACCOUNT_TYPE, DEPOSIT_ACCOUNT);
        DepositContractInfo[] depositContractInfos = mapDomainToContractInfoDto(accountsShortInfo);
        List<DepositAccount> list = mapperHelper.map(depositContractInfos).toList(DepositAccount.class);
        return (Future<AccountList>) new AsyncResult(new AccountList(list));
    }

    private DepositContractInfo[] mapDomainToContractInfoDto(Collection<AccountLongInfo> srcList) {
        List<DepositContractInfo> dstList = new ArrayList<>();
        for (AccountLongInfo src : srcList) {
            String accountNumber = src.getNumber();
            kz.eubank.core.dashboard.domain.model.entity.core.DepositAccount depositAccount = depositAccountRepository.findOne(accountNumber);
            if (depositAccount == null) {
                throw new IllegalArgumentException("Deposit details is null: (account: " + accountNumber + ")");
            }
            DepositContractInfo dst = convertToDepContrInfo(src, depositAccount);//todo mapper
            dstList.add(dst);
        }
        return dstList.toArray(new DepositContractInfo[0]);
    }

    private DepositContractInfo convertToDepContrInfo(AccountLongInfo src,
                                                      kz.eubank.core.dashboard.domain.model.entity.core.DepositAccount depositAccount) {
        DepositContractInfo depositContractInfo = new DepositContractInfo();

        depositContractInfo.setTitle(src.getTitle());
        depositContractInfo.setCurrency(src.getCurrency());
        depositContractInfo.setNumber(src.getNumber());
        depositContractInfo.setInterestRate(src.getInterestRate());
        depositContractInfo.setSpriteIndex(src.getSpriteIndex());
        depositContractInfo.setTerm(depositAccount.getTermPeriod());
        depositContractInfo.setActions(src.getActions());
        depositContractInfo.setPriority(src.getPriority());
        depositContractInfo.setType(src.getType());
        depositContractInfo.setAllowBalance(src.isAllowBalance());
        depositContractInfo.setAllowCreateFinDoc(src.isAllowCreateFinDoc());
        depositContractInfo.setAllowSubmitFinDoc(src.isAllowSubmitFinDoc());

        depositContractInfo.setActualBalance(src.getActualBalance());
        depositContractInfo.setBalance(src.getBalance());
        depositContractInfo.setBlockedSum(src.getBlockedSum());
        depositContractInfo.setDateOpened(src.getDateOpened());
        depositContractInfo.setDateClosed(src.getDateClosed());
        depositContractInfo.setAccruedAmountForMonth(src.getAccruedAmountForMonth());
        depositContractInfo.setAccruedAmountTotal(src.getAccruedAmountTotal());
        depositContractInfo.setMinBalance(src.getMinBalance());

        depositContractInfo.setEffectiveRate(src.getEffectiveRate());

        return depositContractInfo;
    }

    public DepositAccount getDepositAccount(Account account) {
        DepositAccount depositAccount = (DepositAccount) account;
        String contractNr = depositAccount.getNumber();
        Long userId = applicationContext.getCurrentUser().getUserId();
        Long clientId = applicationContext.getCurrentUser().getClientId();
        String lang = applicationContext.getLanguage();
        AccountLongInfo accountLongInfo = getAccountDetails(userId, clientId, contractNr, lang);
        DepositContract depositContract = mapperHelper.map(accountLongInfo).to(DepositContract.class);
        kz.eubank.core.dashboard.domain.model.entity.core.DepositAccount depositAccountEnt = depositAccountRepository.findOne(contractNr);
        DepositDetails depositDetails = mapperHelper.map(depositAccountEnt).to(DepositDetails.class);
        depositContract.setExpiration(depositDetails.getExpiration());
        byte[] agreement = applicationRepository.findAgreement(contractNr, userId, clientId);
        depositContract.setAgreementAvailable(agreement != null && agreement.length > 0);
        mixData(depositContract, depositAccount);
        kz.eubank.core.dashboard.domain.model.entity.core.Account acc = accountRepository.findByNumber(contractNr);
        if (acc != null) {
            depositAccount.setDateClosed(acc.getDateClosed() == null ? 0 : acc.getDateClosed().getTime());
            depositAccount.setDateOpened(acc.getDateOpened() == null ? 0 : acc.getDateOpened().getTime());
        }
        return depositAccount;
    }

    private void mixData(DepositContract contract, DepositAccount depositAccount) {
        depositAccount.setAccountNumber(depositAccount.getNumber());
        depositAccount.setStatus(contract.getStatus());
        depositAccount.setExpiration(contract.getExpiration().getTime());
        depositAccount.setBranchTitle(contract.getBranchTitle());
        depositAccount.setBranchTermId(contract.getBranchTermId());
        depositAccount.setContractNo(contract.getContractNo());
        depositAccount.setShowBalance(contract.isAllowBalance());
        depositAccount.setAllowTransfer(true);//todo change then
        depositAccount.setLimits(contract.getLimits());
    }

    private AccountLongInfo getAccountDetails(Long userId, Long clientId, String accountNr, String lang) {
        Account2 account = account2Repository.findOne(userId, clientId, accountNr, lang);
        AccountLongInfo accountDetails = accountService.getAggregateAccountBalance(accountNr,
                IAllAccService.DEPOSIT_ACCOUNT_TYPE);
        BigDecimal interestRate = accountDetails.getInterestRate();

        Optional<Branch> optionalBranch = branchRepository.findById(account.getBranchId());
        if (optionalBranch.isPresent()) {
            Branch branch = optionalBranch.get();
            if (branch.getTerms() != null) {
                accountDetails.setBranchTermId(branch.getTerms().getId().toString());
            }
            accountDetails.setBranchTitle(branch.getTitle());
        }

        accountDetails.setActions(accountService.findActions(accountNr));
        convertAccountToAccountDetails(account, accountDetails);//todo mapper
        if (appProperties.getDepositAccountType().equals(account.getType())) {
            accountDetails.setInterestRate(interestRate);
        }
        if (appProperties.getCardAccountType().equals(account.getType())) {
            accountDetails.setInterestRate(interestRate);
            kz.eubank.core.dashboard.domain.model.entity.CardAccount card = accountRepository.findCardAccount(account.getId());
            if (card != null) {
                accountDetails.setActiveInstallments(card.isHasActiveInstallments());
                accountDetails.setInstallmentAccount(card.isInstallment());
            }
        }
        return accountDetails;
    }

    private void convertAccountToAccountDetails(Account2 account, AccountLongInfo accountDetails) {
        accountDetails.setId(account.getId());
        accountDetails.setTitle(account.getTitle());
        accountDetails.setCurrency(account.getCurrency());
        accountDetails.setNumber(account.getNumber());
        accountDetails.setStatus(new AccountStatus(account.getStatus(), account.getStatus()));
        accountDetails.setType(account.getType());
        accountDetails.setSpriteIndex(account.getSpriteIndex());
        accountDetails.setPriority(account.getPriority());
        accountDetails.setProductId(account.getProductId());
        accountDetails.setInterestRate(account.getInterestRate());
        accountDetails.setLimitCurrency(account.getLimitCurrency());
        accountDetails.setLimitFinDoc(account.getLimitFinDoc());
        accountDetails.setLimitDay(account.getLimitDay());
        accountDetails.setLimitWeek(account.getLimitWeek());
        accountDetails.setLimitMonth(account.getLimitMonth());
        accountDetails.setAllowBalance(account.isAllowBalance());
        accountDetails.setAllowCreateFinDoc(account.isAllowCreateFinDoc());
        accountDetails.setAllowSubmitFinDoc(account.isAllowSubmitFinDoc());
        accountDetails.setMultiCurrency(account.isMultiCurrency());
        accountDetails.setContractNo(account.getContractNo());
    }
}
