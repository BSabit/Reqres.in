package kz.eubank.core.dashboard.domain.model.entity

import kz.eubank.core.dashboard.domain.model.dto.SettlementOperationName
import javax.persistence.*

@Entity
@Table(name = "SettlementSheetCompanyRetention")
data class SettlementSheetCompanyRetention(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SettlementSheetCompanyRetention_ID")
    var id: Long? = null
) : SettlementSheetOperation() {

    fun toSettlementSheetOperationDto() =
        kz.eubank.core.dashboard.domain.model.dto.SettlementSheetOperation(
            amount = amount?.toInt(),
            count = count,
            price = price?.toInt() ?: 0,
            rowNameEn = SettlementOperationName(fullNameEn, shortNameEn),
            rowNameKz = SettlementOperationName(fullNameKz, shortNameKz),
            rowNameRu = SettlementOperationName(fullNameRu, shortNameRu),
            type = type
        )

}