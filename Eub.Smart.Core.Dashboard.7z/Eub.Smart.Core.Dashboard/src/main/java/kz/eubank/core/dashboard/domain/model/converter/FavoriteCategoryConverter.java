package kz.eubank.core.dashboard.domain.model.converter;

import kz.eubank.core.dashboard.domain.model.entity.core.FavoriteCategory;
import kz.eubank.core.dashboard.domain.model.response.FavoriteCategoryDetails;
import org.dozer.CustomConverter;
import org.springframework.beans.BeanUtils;

import java.util.List;
import java.util.stream.Collectors;

public class FavoriteCategoryConverter implements CustomConverter {

    @Override
    public Object convert(Object dest, Object source, Class<?> arg2, Class<?> arg3) {
        if (source == null) {
            return null;
        } else if (source instanceof FavoriteCategory) {
            FavoriteCategory favoriteCategoryEntity = (FavoriteCategory)source;
            kz.eubank.core.dashboard.domain.model.response.FavoriteCategory favoriteCategory
                    = new kz.eubank.core.dashboard.domain.model.response.FavoriteCategory();
            favoriteCategory.setId(favoriteCategoryEntity.getId());
            favoriteCategory.setTitle(favoriteCategoryEntity.getTitle());
            favoriteCategory.setMcc(favoriteCategoryEntity.getMcc());
            favoriteCategory.setVisible(favoriteCategoryEntity.isVisible());
            favoriteCategory.setImagePath(favoriteCategoryEntity.getImagePath());
            favoriteCategory.setDescription(favoriteCategoryEntity.getDescription());
            favoriteCategory.setColor(favoriteCategoryEntity.getColor());

            favoriteCategory.setDetails(favoriteCategoryEntity.getDetails().stream().map(q -> {
                FavoriteCategoryDetails favoriteCategoryDetails =
                        new FavoriteCategoryDetails();
                favoriteCategoryDetails.setId(q.getId());
                favoriteCategoryDetails.setTitle(q.getTerms().getTermEN());
                favoriteCategoryDetails.setDescription("");//todo
                favoriteCategoryDetails.setImageAddress(q.getImageAddress());
                favoriteCategoryDetails.setMaxPercent(q.getMaxPercent());
                return favoriteCategoryDetails;
            }).collect(Collectors.toList()));

            favoriteCategory.setAdditionalDescription(favoriteCategoryEntity.getAdditionalDescriptionTerms().getTermRU());
            return favoriteCategory;
        } else if (source instanceof kz.eubank.core.dashboard.domain.model.response.FavoriteCategory) {
            kz.eubank.core.dashboard.domain.model.response.FavoriteCategory favoriteCategory = (kz.eubank.core.dashboard.domain.model.response.FavoriteCategory)source;
            FavoriteCategory favoriteCategoryEntity = new FavoriteCategory();
            BeanUtils.copyProperties(favoriteCategory, favoriteCategoryEntity);
            return favoriteCategoryEntity;
        } else {
            return null;
        }
    }
}