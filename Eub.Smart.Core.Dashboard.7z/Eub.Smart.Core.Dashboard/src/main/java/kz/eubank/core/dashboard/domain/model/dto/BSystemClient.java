package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BSystemClient {

    private Long id;
    private BSystem bsystem;
    private Branch branch;
    private BSystemClientStatus status;
    private String title;
    private String outRef;
}
