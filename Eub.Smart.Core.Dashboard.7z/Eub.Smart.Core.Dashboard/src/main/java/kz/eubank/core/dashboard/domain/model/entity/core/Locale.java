package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Setter
@Getter
@Entity
@Table(name = "Locale")
public class Locale {

    @Id
    @Column(name = "Locale_ID")
    private String code;

    @Column(name = "Locale_Title")
    private String title;
}
