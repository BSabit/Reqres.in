package kz.eubank.core.dashboard.domain.repository;

import kz.eubank.core.dashboard.domain.model.entity.core.FavoriteCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface IFavoriteCategoryRepository extends JpaRepository<FavoriteCategory, String> {

    @Query("select f from FavoriteCategory f where f.visible=true")
    List<FavoriteCategory> findAllCategories();

    FavoriteCategory findByOutRef(String outRef);
}