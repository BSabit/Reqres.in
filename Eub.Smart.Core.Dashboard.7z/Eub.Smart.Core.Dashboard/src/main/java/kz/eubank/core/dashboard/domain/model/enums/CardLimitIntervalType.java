package kz.eubank.core.dashboard.domain.model.enums;

public enum CardLimitIntervalType {
    DAY, MONTH
}
