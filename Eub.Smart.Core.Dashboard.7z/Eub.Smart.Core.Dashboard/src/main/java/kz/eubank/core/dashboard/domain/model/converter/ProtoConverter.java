package kz.eubank.core.dashboard.domain.model.converter;

import com.google.protobuf.Timestamp;
import kz.eubank.core.dashboard.domain.model.dto.SubAccountBalance;
import kz.eubank.core.dashboard.domain.model.enums.ErrorMessages;
import kz.eubank.core.dashboard.domain.model.grpc.CustomTypes;
import kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard;
import kz.eubank.core.dashboard.infrastructure.exception.ServiceException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class ProtoConverter {

    public BigDecimal convertMoneyToBigDecimal(EubAggregatorCoreDashboard.Money money) {
        return convertDecimalValueToBigDecimal(money.getAmount());
    }

    public String moneyToCurrency(EubAggregatorCoreDashboard.Money q) {
        return q.getCurrency().getValueDescriptor().getName();
    }

    public Date timestampToDate(Timestamp ts) {
        if (ts.getSeconds() < 0) {//todo change then
            return null;
        }
        LocalDate localDate = Instant
                .ofEpochSecond(ts.getSeconds(), ts.getNanos())
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
        return Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
    }

    public List<SubAccountBalance> moneyListToSubAccountBalanceList(List<EubAggregatorCoreDashboard.Money> list) {
        return list.stream().map(q -> {
            SubAccountBalance subAccountBalance = new SubAccountBalance();
            subAccountBalance.setAmount(convertMoneyToBigDecimal(q));
            subAccountBalance.setCurrency(moneyToCurrency(q));
            return subAccountBalance;
        }).collect(Collectors.toList());
    }

    public BigDecimal convertDecimalValueToBigDecimal(CustomTypes.DecimalValue decimalValue) {
//        if (decimalValue.getSerializedSize() == 0) {
//            return null;
//        }
        return BigDecimal.valueOf(decimalValue.getUnits() + decimalValue.getNanos() * Math.pow(10, -9)).setScale(2, RoundingMode.FLOOR);
    }

    public BigDecimal convertDecimalValueToBigDecimalCurrencyRate(CustomTypes.DecimalValue decimalValue) {
        BigDecimal bgValue = convertDecimalValueToBigDecimal(decimalValue);
        return bgValue != null ? bgValue : BigDecimal.ZERO;
    }

    public Date convertStringDateToDate(String strDate) {
        try {
            return new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(strDate + " 06:00");
        } catch (ParseException e) {
            throw new ServiceException(ErrorMessages.UNABLE_TO_PARSE_DATE.getErrorMessage(), e,
                    HttpStatus.INTERNAL_SERVER_ERROR.value());
        }
    }
}
