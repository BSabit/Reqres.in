package kz.eubank.core.dashboard.domain.service;

import kz.eubank.core.dashboard.domain.model.dto.CurrencyRateList;

public interface IExchangeRateService {

    CurrencyRateList getAllRates(Boolean isCardRates);
}
