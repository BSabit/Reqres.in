package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "AddressStatus")
public class AddressStatus {

    @Id
    @Column(name = "AddressStatus_ID")
    private String code;

    @Column(name = "AddressStatus_Title")
    private String title;

    @Column(name = "IsValid")
    private boolean valid;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;
}
