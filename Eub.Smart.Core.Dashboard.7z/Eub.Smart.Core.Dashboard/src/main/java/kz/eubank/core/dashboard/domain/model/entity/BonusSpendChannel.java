package kz.eubank.core.dashboard.domain.model.entity;

import kz.eubank.core.dashboard.domain.model.entity.core.Term;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Setter
@Getter
@Entity
@Table(name = "BonusSpendChannel")
public class BonusSpendChannel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "BonusSpendChannel_ID")
    private String id;

    @Column(name = "BonusSpendChannel_Title")
    private boolean title;

    @OneToOne
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;
}
