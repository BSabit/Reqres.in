package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class SubAccountBalance {

    private BigDecimal amount;
    private String currency;

    @Override
    public String toString() {
        return "SubAccountBalance [amount=" + this.amount + ", currency=" + this.currency + "]";
    }
}
