package kz.eubank.core.dashboard.domain.model.dto;

import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class DepositAccount extends ContractAccount {

    private BigDecimal interestRate;
    private BigDecimal balance;
    private BigDecimal actualBalance;
    private String accountNumber;
    private Long dateClosed;
    private String status;
    private BigDecimal accruedAmountForMonth;
    private BigDecimal accruedAmountTotal;
    private Limits limits;
    private Integer minBalance;
    private Long expiration;
    private BigDecimal effectiveRate;

    public DepositAccount() {
        this.setType("SAVE");
    }

    @JsonSetter(nulls = Nulls.AS_EMPTY)
    public void setLimits(final Limits limits) {
        this.limits = limits;
    }

    public Long getTerm() {
        return this.expiration;
    }
}
