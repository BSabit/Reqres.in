package kz.eubank.core.dashboard.domain.model.dto;

import kz.eubank.core.dashboard.domain.model.enums.CreditStatus;
import kz.eubank.core.dashboard.domain.model.enums.TermPeriod;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Getter
@Setter
public class CreditShortInfo {

    private String title;
    private String currency;
    private String number;
    private BigDecimal interestRate;
    private BigDecimal amount;
    private Date expiration;
    private int spriteIndex;
    private Integer term;
    private TermPeriod termPeriod;
    private CreditStatus status;
    private BigDecimal balance;
    private String balanceCurrency;
    private BigDecimal actualBalance;
    private BigDecimal blockedSum;
    private List<String> actions;
}
