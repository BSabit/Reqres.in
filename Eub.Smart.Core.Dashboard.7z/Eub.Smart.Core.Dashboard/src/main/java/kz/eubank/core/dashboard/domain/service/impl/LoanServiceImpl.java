package kz.eubank.core.dashboard.domain.service.impl;

import kz.eubank.core.dashboard.domain.model.dto.CreditContractAccount;
import kz.eubank.core.dashboard.domain.model.response.AccountList;
import kz.eubank.core.dashboard.infrastructure.config.ApplicationContext;
import kz.eubank.core.dashboard.infrastructure.config.MapperHelper;
import kz.eubank.core.dashboard.domain.model.dto.ListCreditResponse;
import kz.eubank.core.dashboard.domain.model.response.LoanApplicationList;
import kz.eubank.core.dashboard.domain.repository.ICreditRequestRepository;
import kz.eubank.core.dashboard.domain.service.IAccountService;
import kz.eubank.core.dashboard.domain.service.ILoanService;
import kz.eubank.core.dashboard.domain.model.entity.core.LoanApplication;
import kz.eubank.core.dashboard.domain.model.response.LoanApplicationResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class LoanServiceImpl implements ILoanService {

    @Autowired
    private MapperHelper mapperHelper;

    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    private ICreditRequestRepository creditRequestRepository;

    @Autowired
    private IAccountService accountService;

    @Override
    public AccountList getListCredits() {
        String iinPayer = applicationContext.getCurrentUser().getIin();
        ListCreditResponse listCreditResponse = accountService.listCreditsInfo(iinPayer);
        List<CreditContractAccount> creditContracts = mapperHelper.map(listCreditResponse.getLoan().getItems()).toList(CreditContractAccount.class);
        return new AccountList(creditContracts);
    }

    public LoanApplicationList getRequestsList(Date dateFrom, Date dateTo, int page, int pageSize, String language) {
        List<LoanApplication> list = loadLoanApplicationList(dateFrom, dateTo,
                applicationContext.getCurrentUser().getUserId(),
                page, pageSize)
                .stream().peek(o -> o.getApplication().getState().getTechStatus().getStatus().changeTitleLanguage(language))
                .collect(Collectors.toList());
        List<LoanApplicationResponse> responses = mapperHelper.map(list).toList(LoanApplicationResponse.class);
        return new LoanApplicationList(responses);
    }

    public List<LoanApplication> loadLoanApplicationList(Date dateFrom, Date dateTo, Long userId, int page,
                                                         int pageSize) {
        Pageable pageable = PageRequest.of(page, pageSize);
        Page<LoanApplication> result = creditRequestRepository.findByUserIdAndDates(pageable, dateFrom, dateTo,
                userId);
        return result.getContent();
    }
}