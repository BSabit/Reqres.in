package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;

@Getter
@Setter
@Entity
@Table(name = "DepositApplication")
public class DepositApplication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DepositApplication_ID")
    private Long id;

    @OneToOne
    @JoinColumn(name = "DepositProduct_IDREF")
    private DepositProduct depositProduct;

    @OneToOne
    @JoinColumn(name = "Application_IDREF", insertable = false, updatable = false)
    private Application application;

    @OneToOne
    @JoinColumn(name = "Operation_IDREF")
    private Operation operation;

    @Column(name = "Fee")
    private BigDecimal fee;

    @Column(name = "Currency")
    private String currency;

    @OneToOne
    @JoinColumn(name = "Branch_IDREF")
    private Branch branch;

    @Column(name = "Amount")
    private BigDecimal amount;

    @OneToOne
    @JoinColumn(name = " Account_IDREF")
    private Account account;

    @Column(name = "FeeCurrency")
    private String feeCurrency;

    @Column(name = "Period_Months")
    private Integer periodMonths;

    @Column(name = "InterestRate")
    private BigDecimal interestRate;

    @Column(name = "Prolongations")
    private Integer prolongations;

    @Column(name = "Agreement")
    private byte[] agreement;

    @Column(name = "IBAN")
    private String IBAN;

    @Column(name = "ContractNo")
    private String contractNo;

    @Column(name = "EffectiveRate")
    private BigDecimal effectiveRate;

    @Column(name = "InterestIBAN")
    private String interestIBAN;
}
