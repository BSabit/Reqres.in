package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "AcceptanceIncomingTransferApplication")
public class MoneyTransferApplication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "AcceptanceIncomingTransferApplication_ID")
    private Long id;

    @OneToOne
    @JoinColumn(name = "Application_IDREF", insertable = false, updatable = false)
    private Application application;

    @Column(name = "ReceiptDate")
    @Temporal(TemporalType.DATE)
    private Date receiptDate;

    @Column(name = "Transfer_outref")
    private int transferOutref;

    @Column(name = "KBE")
    private int kbe;

    @Column(name = "ReceiverAccount")
    private String receiverAccount;

    @Column(name = "SenderData")
    private String senderData;

    @OneToOne
    @JoinColumn(name = "SenderCountry_idref")
    private Country senderCountry;

    @Column(name = "SenderIsResident")
    private boolean senderResident;

    @Column(name = "Amount")
    private BigDecimal amount;

    @Column(name = "CurrencyAmount")
    private String currency;

    @OneToOne
    @JoinColumn(name = "KNP_IDREF")
    private KNP knp;

    @Column(name = "TransferPurpose")
    private String transferPurpose;

    @Column(name = "ReceiverIIN")
    private String ReceiverIIN;
}
