package kz.eubank.core.dashboard.infrastructure.config;

import kz.eubank.core.dashboard.domain.model.authorization.UserDetails;

public interface ApplicationContext {

    String getLanguage();

    UserDetails getCurrentUser();
}
