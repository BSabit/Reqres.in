package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "LoanApplicationState")
public class LoanApplicationState {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "LoanApplicationState_ID")
    private Long id;

    @OneToOne
    @JoinColumn(name = "LoanApplication_IDREF")
    private LoanApplication loanApplication;

    @Column(name = "StatusDate")
    private Date statusDate;

    @OneToOne
    @JoinColumn(name = "LoanApplicationStatus_IDREF")
    private LoanApplicationStatus loanApplicationStatus;

    @Column(name = "LoanApplicationStatusComment")
    private String loanApplicationStatusComment;

    @Column(name = "UserMessage")
    private String userMessage;

    @Column(name = "IsCheckStatus")
    private boolean checkStatus;
}
