package kz.eubank.core.dashboard.domain.model.enums;

public enum DutyStatus {
    ACTIVE, CLOSED, DELETED
}
