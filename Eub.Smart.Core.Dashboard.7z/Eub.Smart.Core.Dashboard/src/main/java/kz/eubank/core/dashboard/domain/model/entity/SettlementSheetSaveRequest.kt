package kz.eubank.core.dashboard.domain.model.entity

import java.util.Date
import javax.persistence.*

@Entity
@Table(name = "SettlementSheetSaveRequest")
data class SettlementSheetSaveRequest(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SettlementSheetSaveRequest_ID")
    var id: Long? = null,
    var exportDate: Date? = null,
    var exportPeriod: String? = null
)