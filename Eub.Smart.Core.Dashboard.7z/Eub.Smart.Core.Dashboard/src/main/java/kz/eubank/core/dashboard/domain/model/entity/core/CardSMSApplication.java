package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "CardSMSApplication")
public class CardSMSApplication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CardSMSApplication_ID")
    private Long id;

    @Column(name = "CardSMSApplication_GUID", insertable = false, updatable = false)
    private String guid;

    @OneToOne
    @JoinColumn(name = "Card_IDREF")
    private Card card;

    @Column(name = "Phone")
    private String phone;

    @OneToOne
    @JoinColumn(name = "NewPhone_IDREF")
    private MobilePhone newPhone;

    @JoinColumn(name = "Comment")
    private String comment;

    @OneToOne
    @JoinColumn(name = "CardSMSReason_IDREF")
    private CardSMSReason reason;
}
