package kz.eubank.core.dashboard.domain.model.entity.core;

import javax.persistence.*;

@Entity
@Table(name = "DutyStatus")
public class DutyStatus {

    @Id
    @Column(name = "DutyStatus_ID")
    private String code;

    @Column(name = "DutyStatus_Title")
    private String title;

    @Column(name = "IsValid")
    private boolean valid;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;

    public String getCode() {
        return this.code;
    }

    public String getTitle() {
        return title;
    }

    public boolean isValid() {
        return valid;
    }

    public Term getTerms() {
        return terms;
    }

    public void setTerms(Term terms) {
        this.terms = terms;
    }
}
