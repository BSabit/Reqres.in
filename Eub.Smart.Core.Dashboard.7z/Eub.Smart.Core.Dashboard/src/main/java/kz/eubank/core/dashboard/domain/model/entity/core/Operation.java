package kz.eubank.core.dashboard.domain.model.entity.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Operation")
public class Operation {

    @Id
    @Column(name = "Operation_ID")
    private Long id;

    @Column(name = "Operation_Title")
    private String title;
    
    @Column(name = "Action_IDREF")
    private String action;

    public Long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

	public void setId(Long id) {
		this.id = id;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public void setTitle(String title) {
		this.title = title;
	}
    
}
