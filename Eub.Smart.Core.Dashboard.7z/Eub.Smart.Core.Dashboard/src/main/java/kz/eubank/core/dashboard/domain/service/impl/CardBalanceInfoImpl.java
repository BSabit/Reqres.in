package kz.eubank.core.dashboard.domain.service.impl;

import kz.eubank.core.dashboard.domain.model.converter.ProtoConverter;
import kz.eubank.core.dashboard.domain.model.dto.AccountBalanceInfo;
import kz.eubank.core.dashboard.domain.model.dto.CardBalanceInfo;
import kz.eubank.core.dashboard.domain.model.dto.AccountGraceInfo;
import kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard;
import kz.eubank.core.dashboard.domain.service.IAccountBalanceInfo;
import kz.eubank.core.dashboard.domain.service.IAllAccService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class CardBalanceInfoImpl implements IAccountBalanceInfo {

    @Autowired
    private ProtoConverter protoConverter;

    @Override
    public String getType() {
        return IAllAccService.CARD_ACC_ACCOUNT;
    }

    @Override
    public List<? extends AccountBalanceInfo> getAccountBalances(List<EubAggregatorCoreDashboard.Account> esbAccounts) {
        List<CardBalanceInfo> accountBalances = new ArrayList<>();
        for (EubAggregatorCoreDashboard.Account account : esbAccounts) {
            CardBalanceInfo cardBalanceInfo = new CardBalanceInfo();

            cardBalanceInfo.setAccountNumber(account.getNumber());
            cardBalanceInfo.setBalance(protoConverter.convertMoneyToBigDecimal(account.getBalance()));
            cardBalanceInfo.setCurrency(protoConverter.moneyToCurrency(account.getBalance()));
            cardBalanceInfo.setBlockedSum(protoConverter.convertMoneyToBigDecimal(account.getBlockedSum()));
            cardBalanceInfo.setAvailableBalance(protoConverter.convertMoneyToBigDecimal(account.getAvailableBalance()));
            cardBalanceInfo.setActualBalance(protoConverter.convertMoneyToBigDecimal(account.getAvailableBalance()));
            cardBalanceInfo.setGrace(account.getIsGrace());

            AccountGraceInfo accountGraceInfo = new AccountGraceInfo();
            accountGraceInfo.setUnusedCreditLimit(protoConverter.convertMoneyToBigDecimal(account.getUnusedCreditLimit()));
            accountGraceInfo.setTotalLoan(protoConverter.convertMoneyToBigDecimal(account.getTotalLoan()));
            accountGraceInfo.setMinimalPayment(protoConverter.convertMoneyToBigDecimal(account.getMinimalPayment()));

            Date nextBillingDate = protoConverter.timestampToDate(account.getNextBillingDate());
            accountGraceInfo.setNextBillingDate(nextBillingDate == null ? null : nextBillingDate.getTime());

            Date nextDueDate = protoConverter.timestampToDate(account.getNextDueDate());
            accountGraceInfo.setNextDueDate(nextDueDate == null ? null : nextDueDate.getTime());
            
            accountGraceInfo.setOwn(protoConverter.convertMoneyToBigDecimal(account.getOwn()));
            accountGraceInfo.setOverdue(protoConverter.convertMoneyToBigDecimal(account.getOverdue()));
            accountGraceInfo.setOverlimit(protoConverter.convertMoneyToBigDecimal(account.getOverlimit()));
            accountGraceInfo.setPenalty(protoConverter.convertMoneyToBigDecimal(account.getPenalty()));
            accountGraceInfo.setCreditLimit(protoConverter.convertMoneyToBigDecimal(account.getCreditLimit()));
            accountGraceInfo.setGraceFailedFee(protoConverter.convertMoneyToBigDecimal(account.getGraceFailedFee()));
            accountGraceInfo.setGracePaymentAmount(protoConverter.convertMoneyToBigDecimal(account.getGracePaymentAmount()));
            cardBalanceInfo.setAccountGraceInfo(accountGraceInfo);

            cardBalanceInfo.setSubAccountBalances(protoConverter.moneyListToSubAccountBalanceList(account.getSubAccountBalances()
                    .getSubAccountBalanceList()));
            cardBalanceInfo.setSubAccountAvailableBalances(protoConverter.moneyListToSubAccountBalanceList(
                    account.getSubAccountAvailableBalances().getSubAccountAvailableBalanceList()));

            BigDecimal minBalance = protoConverter.convertMoneyToBigDecimal(account.getMinBalance());
            if (minBalance != null) {
                cardBalanceInfo.setMinBalance(minBalance.intValue());
            }

            accountBalances.add(cardBalanceInfo);
        }
        return accountBalances;
    }
}
