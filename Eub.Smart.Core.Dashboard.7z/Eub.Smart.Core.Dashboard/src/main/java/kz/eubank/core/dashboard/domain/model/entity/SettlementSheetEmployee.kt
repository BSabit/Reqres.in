package kz.eubank.core.dashboard.domain.model.entity

import java.math.BigDecimal
import javax.persistence.*

@Entity
@Table(name = "SettlementSheetEmployee")
data class SettlementSheetEmployee(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SettlementSheetEmployee_ID")
    var id: Long? = null,
    var number: String? = null,
    var departmentName: String? = null,
    var departmentNumber: String? = null,
    var iin: String? = null,
    var fullName: String? = null,
    var salary: BigDecimal? = null,
    @OneToMany(cascade = [CascadeType.ALL])
    @JoinColumn(name = "SettlementSheetEmployee_IDREF")
    var sheets: List<SettlementSheet> = emptyList()
) {

    fun toSettlementSheetEmployeeDto() =
        kz.eubank.core.dashboard.domain.model.dto.SettlementSheetEmployee(
            departmentName = departmentName,
            departmentNumber = departmentNumber,
            fullName = fullName,
            iin = iin,
            number = number,
            salary = salary?.toInt()
        )

}
