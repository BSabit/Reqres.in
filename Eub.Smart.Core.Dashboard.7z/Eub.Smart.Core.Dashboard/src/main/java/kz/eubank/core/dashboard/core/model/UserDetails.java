package kz.eubank.core.dashboard.core.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import static kz.eubank.core.dashboard.core.util.JsonUtil.toObject;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDetails {

    @JsonProperty("user_id")
    private Long userId;
    @JsonProperty("birth_date")
    private String birthDate;
    @JsonProperty("name")
    private String name;
    @JsonProperty("preferred_username")
    private String preferredUsername;
    @JsonProperty("middle_name")
    private String middleName;
    @JsonProperty("given_name")
    private String givenName;
    @JsonProperty("family_name")
    private String familyName;
    @JsonProperty("client_id")
    private Long clientId;
    @JsonProperty("iin")
    private String iin;
    @JsonProperty("person_id")
    private Long personId;


    public static UserDetails build(String payload) {
        return toObject(payload, UserDetails.class)
                .orElseThrow(() -> new RuntimeException("NOT FETCHED USER DETAILS INFO"));
    }
}
