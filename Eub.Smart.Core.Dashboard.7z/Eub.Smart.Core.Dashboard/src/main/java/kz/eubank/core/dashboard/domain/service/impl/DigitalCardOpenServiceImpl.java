package kz.eubank.core.dashboard.domain.service.impl;

import kz.eubank.core.dashboard.domain.gate.DigitalCardOpenGate;
import kz.eubank.core.dashboard.domain.model.dto.TempDigitalCardList;
import kz.eubank.core.dashboard.domain.service.DigitalCardOpenService;
import kz.eubank.core.dashboard.infrastructure.config.ApplicationContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DigitalCardOpenServiceImpl implements DigitalCardOpenService {

    @Autowired
    private ApplicationContext context;
    @Autowired
    private DigitalCardOpenGate digitalCardOpenGate;

    @Override
    public TempDigitalCardList getTempCards() {
        Long userId = context.getCurrentUser().getUserId();
        return new TempDigitalCardList(digitalCardOpenGate.getTempCards(userId));
    }
}
