package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "PlaceType")
public class AddressPlaceType {

    @Id
    @Column(name = "PlaceType_ID")
    private String code;

    @Column(name = "PlaceType_Title")
    private String title;

    @OneToOne
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;
}
