package kz.eubank.core.dashboard.domain.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ServiceFormType")
public class ServiceFormType {

    @Id
    @Column(name = "ServiceFormType_ID")
    private Long id;

    @Column(name = "ServiceFormType_Code")
    private String code;
    
    @Column(name = "ServiceFormType_Title")
    private String title;

    public Long getId() {
        return id;
    }

    public String getCode() {
        return code;
    }

    public String getTitle() {
        return title;
    }
}
