package kz.eubank.core.dashboard.domain.model.dto;

import java.util.Arrays;
import java.util.Collection;

public abstract class AbstractList<T> {

    private final Collection<T> items;

    public AbstractList(Collection<T> items) {
        this.items = items;
    }

    public AbstractList(T[] items) {
        this.items = Arrays.asList(items);
    }

    public Collection<T> getItems() {
        return (Collection<T>)this.items;
    }

    public int getSize() {
        return (this.items != null) ? this.items.size() : 0;
    }
}
