package kz.eubank.core.dashboard.domain.repository;

import kz.eubank.core.dashboard.domain.model.entity.core.ClientPermission;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IClientPermissionRepository extends CrudRepository<ClientPermission, Long> {

    ClientPermission findByUserIdAndClientId(final Long p0, final Long p1);
}
