package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name = "Card")
public class Card {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Card_ID")
    private Long id;

    @Column(name = "Card_OUTREF")
    private Long outref;

    @OneToOne
    @JoinColumn(name = "Product_IDREF")
    private Product product;

    @OneToOne
    @JoinColumn(name = "Account_IDREF")
    private Account account;

    @Column(name = "NameEmbossed")
    private String nameEmbossed;

    @Column(name = "MaskedNumber")
    private String maskedNumber;

    @Column(name = "ProductCompound_OUTREF")
    private String productCompoundOutref;

    @OneToOne
    @JoinColumn(name = "CardType_IDREF")
    private CardType type;

    @Column(name = "Expiration")
    private Date expiration;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CardStatus_IDREF")
    private CardStatus status;

    @Column(name = "AllowCNP")
    private boolean allowCNP;

    @Column(name = "`Hash`")
    private String hash;

    @Column(name = "IsIVR")
    private Boolean isIVR;

    @Column(name = "IsPINSet")
    private Boolean isPINSet;

    @Column(name = "IsDigital")
    private Boolean isDigital;
}
