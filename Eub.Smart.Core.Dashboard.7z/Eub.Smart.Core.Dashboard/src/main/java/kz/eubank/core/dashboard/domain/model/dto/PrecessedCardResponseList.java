package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.Collection;

@Getter
@Setter
public class PrecessedCardResponseList {

    private Collection<PrecessedCardResponse> cardDeliveryApplications;

    public PrecessedCardResponseList(Collection<PrecessedCardResponse> cardDeliveryApplications) {
        this.cardDeliveryApplications = cardDeliveryApplications;
    }
}
