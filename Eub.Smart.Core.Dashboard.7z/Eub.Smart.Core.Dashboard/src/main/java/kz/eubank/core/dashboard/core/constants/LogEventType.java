package kz.eubank.core.dashboard.core.constants;

public interface LogEventType {

    String REST = "REST";
    String EXTERNAL_CALL_gRPC = "External_Call_Grpc";
}
