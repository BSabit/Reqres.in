package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@Entity
@Table(name = "MobilePhoneStatus")
public class MobilePhoneStatus {

    @Id
    @Column(name = "MobilePhoneStatus_ID")
    private String code;

    @Column(name = "IsValid")
    private boolean valid;
}
