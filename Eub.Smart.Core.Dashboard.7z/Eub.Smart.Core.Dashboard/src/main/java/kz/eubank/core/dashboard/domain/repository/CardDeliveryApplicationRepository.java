package kz.eubank.core.dashboard.domain.repository;

import kz.eubank.core.dashboard.domain.model.entity.CardDeliveryApplication;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CardDeliveryApplicationRepository extends CrudRepository<CardDeliveryApplication, Long> {

    @Query("select c from CardDeliveryApplication c " +
            "where c.application.userId=?1 and c.application.state.techStatus.status.code=?2")
    List<CardDeliveryApplication> getProcessedCard(Long userId, String status);
}
