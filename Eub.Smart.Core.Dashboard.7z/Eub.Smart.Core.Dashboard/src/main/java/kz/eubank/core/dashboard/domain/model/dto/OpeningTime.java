package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Generated;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OpeningTime {

    private String startTime;
    private String finishTime;

    @Generated
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof OpeningTime)) {
            return false;
        }
        final OpeningTime other = (OpeningTime) o;
        if (!other.canEqual(this)) {
            return false;
        }
        final Object this$startTime = this.getStartTime();
        final Object other$startTime = other.getStartTime();
        Label_0065:
        {
            if (this$startTime == null) {
                if (other$startTime == null) {
                    break Label_0065;
                }
            } else if (this$startTime.equals(other$startTime)) {
                break Label_0065;
            }
            return false;
        }
        final Object this$finishTime = this.getFinishTime();
        final Object other$finishTime = other.getFinishTime();
        if (this$finishTime == null) {
            return other$finishTime == null;
        } else return this$finishTime.equals(other$finishTime);
    }

    @Generated
    protected boolean canEqual(final Object other) {
        return other instanceof OpeningTime;
    }

    @Generated
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $startTime = this.getStartTime();
        result = result * 59 + (($startTime == null) ? 43 : $startTime.hashCode());
        final Object $finishTime = this.getFinishTime();
        result = result * 59 + (($finishTime == null) ? 43 : $finishTime.hashCode());
        return result;
    }

    @Generated
    @Override
    public String toString() {
        return "OpeningTime(startTime=" + this.getStartTime() + ", finishTime=" + this.getFinishTime() + ")";
    }
}
