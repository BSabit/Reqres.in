package kz.eubank.core.dashboard.domain.repository;

import kz.eubank.core.dashboard.domain.model.entity.SmbkAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface SmbkAccountRepository extends JpaRepository<SmbkAccount, String> {

    @Query(nativeQuery = true,
            value = "select p.IIN as Iin," +
                    "       convert(varchar(10), p.BirthDate, 120) as DateOfBirth," +
                    "       ap.Product_OUTREF as ProgramCode," +
                    "       acc.Currency as Unit," +
                    "       acc.Number as SmbkAccountNumber," +
                    "       c.Client_ID as SmbkClientId," +
                    "       acc.Account_ID as SmbkAccountId" +
                    "  from Account acc" +
                    "  join map_User_Account muacc on muacc.Account_IDREF = acc.Account_ID" +
                    "  join [User] u on u.[User_ID] = muacc.User_IDREF" +
                    "  join Person p on p.Person_ID = u.Person_IDREF" +
                    "  join Client c on c.Person_IDREF = p.Person_ID" +
                    "  join AccountType acct on acct.AccountType_ID = acc.AccountType_IDREF" +
                    "  join AccountProduct ap on ap.Product_IDREF = acc.Product_IDREF" +
                    " where acct.BSystem_IDREF = :bSystem" +
                    "   and acc.Number = :accountNumber")
    List<SmbkAccount> getAllByBSystemAndAccountOutref(String accountNumber, String bSystem);
}
