package kz.eubank.core.dashboard.domain.model.entity;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "FinDocState")
public class FinDocState {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "FinDocState_ID")
    private Long id;

    @OneToOne()
    @JoinColumn(name = "FinDoc_IDREF")
    private FinDoc finDoc;

    @Column(name = "Attempts")
    private int attempts;

    @Column(name = "StatusDate")
    private Date statusDate;

    @Column(name = "TechScheduled")
    private Date techScheduled;

    @OneToOne()
    @JoinColumn(name = "DocTechStatus_IDREF")
    private DocTechStatus docTechStatus;

    @Column(name = "DocTechStatusComment")
    private String docTechStatusComment;

    @Column(name = "Process_ID")
    private String processId;
    
    @Column(name="isHidden")
    private boolean hidden;
    

    public Long getId() {
        return id;
    }

    public FinDoc getFinDoc() {
        return finDoc;
    }

    public int getAttempts() {
        return attempts;
    }

    public Date getStatusDate() {
        return statusDate;
    }

    public Date getTechScheduled() {
        return techScheduled;
    }

    public DocTechStatus getDocTechStatus() {
        return docTechStatus;
    }

    public void setDocTechStatus(DocTechStatus docTechStatus) {
        this.docTechStatus = docTechStatus;
    }

    public String getDocTechStatusComment() {
        return docTechStatusComment;
    }

    public String getProcessId() {
        return processId;
    }

    public void setFinDoc(FinDoc finDoc) {
        this.finDoc = finDoc;
    }

    public void setStatusDate(Date statusDate) {
        this.statusDate = statusDate;
    }

    public void setTechScheduled(Date techScheduled) {
        this.techScheduled = techScheduled;
    }
    
    public boolean isHidden() {
		return hidden;
	}

	public void setHidden(boolean hidden) {
		this.hidden = hidden;
	}

}
