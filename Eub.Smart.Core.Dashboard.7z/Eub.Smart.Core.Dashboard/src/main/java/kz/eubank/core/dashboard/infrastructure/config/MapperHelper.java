package kz.eubank.core.dashboard.infrastructure.config;

import org.dozer.DozerBeanMapper;
import org.springframework.stereotype.Service;

@Service
public class MapperHelper {

    private final DozerBeanMapper dozerMapper;

    public MapperHelper(final DozerBeanMapper dozerMapper) {
        this.dozerMapper = dozerMapper;
    }

    public <S> Mapper<S> map(final S source) {
        return (Mapper<S>) new Mapper(this.dozerMapper, source);
    }
}
