package kz.eubank.core.dashboard.domain.model.response;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CarPledgeInfo {

    private String iin;
    private String vin;
    private String brand;
    private String model;
    private Integer year;
    private String plateNumber;
    private String applicationNB;
    private Integer status;
    private String statusInfo;
    private Long mvdPledgeId;
}
