package kz.eubank.core.dashboard.domain.repository

import kz.eubank.core.dashboard.domain.model.entity.SettlementSheetEmployee
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface SettlementSheetEmployeeRepository : JpaRepository<SettlementSheetEmployee, Long> {
    fun findByIin(iin: String): List<SettlementSheetEmployee>
}