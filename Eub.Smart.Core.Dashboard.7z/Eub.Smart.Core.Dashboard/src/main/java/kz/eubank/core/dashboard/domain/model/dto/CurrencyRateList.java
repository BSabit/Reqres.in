package kz.eubank.core.dashboard.domain.model.dto;

import java.util.Collection;

public class CurrencyRateList {

    private final Collection<CurrencyRate> rates;

    public CurrencyRateList(final Collection<CurrencyRate> rates) {
        this.rates = rates;
    }

    public Collection<CurrencyRate> getRates() {
        return this.rates;
    }

    public int getSize() {
        return (this.rates != null) ? this.rates.size() : 0;
    }

    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("CurrencyRateList [rates=");
        builder.append(this.rates);
        builder.append("]");
        return builder.toString();
    }
}
