package kz.eubank.core.dashboard.domain.model.converter;

import kz.eubank.core.dashboard.domain.model.dto.AccountStatus;
import org.apache.commons.lang3.StringUtils;

public class String2AccountStatus_Converter {

    public static AccountStatus convert(String source) {
        if (source == null) return null;//
        if (StringUtils.isEmpty(source)) return null;
        if ("ACTV".equals(source) || "ACTIVE".equals(source)) return new AccountStatus("ACTIVE", "ACTIVE");
        if ("BLOC".equals(source) || "BLOCKED".equals(source)) return new AccountStatus("BLOCKED", "BLOCKED");
        if ("CLOS".equals(source) || "CLOSED".equals(source)) return new AccountStatus("CLOSED", "CLOSED");
        if ("COLL".equals(source) || "TRANSFERED_TO_COLLECTORS".equals(source)) return new AccountStatus("TRANSFERED_TO_COLLECTORS", "TRANSFERED_TO_COLLECTORS");
        if ("PRBL".equals(source) || "PARTIALLY_BLOCKED".equals(source)) return new AccountStatus("PARTIALLY_BLOCKED", "PARTIALLY_BLOCKED");
        if ("DLTD".equals(source) || "DELETED".equals(source)) return new AccountStatus("DELETED", "DELETED");
        if ("CRBA".equals(source)) return new AccountStatus("CRBA", "CRBA");
        if ("SUSP".equals(source) || "SUSPENDED".equals(source)) return new AccountStatus("SUSPENDED", "SUSPENDED");
        if ("UNCL".equals(source) || "UNDER_COLLECTION".equals(source)) return new AccountStatus("UNDER_COLLECTION", "UNDER_COLLECTION");
        if ("UNKN".equals(source)) return new AccountStatus("UNKN", "UNKN");
        throw new IllegalArgumentException("Unknown account status code: " + source);
    }
}