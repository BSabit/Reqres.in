package kz.eubank.core.dashboard.domain.model.entity.core;

import kz.eubank.core.dashboard.domain.model.enums.FrontEnd;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Set;

@Getter
@Setter
@Entity
@Table(name = "Application")
public class Application {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Application_ID")
    private Long id;

    @OneToOne
    @JoinColumn(name = "ApplicationType_IDREF")
    private ApplicationType type;

    @Column(name = "Client_IDREF")
    private Long clientId;

    @Column(name = "User_IDREF")
    private Long userId;

    @Column(name = "DateCreated", updatable = false)
    private Date created;

    @Column(name = "BLOB")
    private byte[] blob;

    @Column(name = "FrontEnd_IDREF")
    @Enumerated(EnumType.STRING)
    private FrontEnd frontEnd;

    @OneToOne
    @JoinColumn(name = "User_IDREF", insertable = false, updatable = false)
    private User user;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "Application_IDREF", referencedColumnName = "Application_ID", insertable = false,
            updatable = false, nullable = false)
    private Set<CardBlockApplication> cardBlockApplications;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "Application_IDREF", referencedColumnName = "Application_ID", insertable = false,
            updatable = false, nullable = false)
    private Set<DepositApplication> depositApplications;

    @OneToMany(cascade = CascadeType.REMOVE)
    @JoinColumn(name = "Application_IDREF", referencedColumnName = "Application_ID", nullable = false)
    private List<ApplicationStateHistory> stateHistory;

    @OneToOne(mappedBy = "application", cascade = {CascadeType.REMOVE, CascadeType.PERSIST, CascadeType.MERGE})
    private ApplicationState state;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "Application_IDREF", referencedColumnName = "Application_ID", insertable = false,
            updatable = false, nullable = false)
    private Set<CNPBlockApplication> cnpBlockApplications;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "Application_IDREF", referencedColumnName = "Application_ID", insertable = false,
            updatable = false, nullable = false)
    private Set<ForexApplication> forexApplications;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "Application_IDREF", referencedColumnName = "Application_ID", insertable = false,
            updatable = false, nullable = false)
    private Set<CardSMSApplication> cardSMSApplications;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "Application_IDREF", referencedColumnName = "Application_ID", insertable = false,
            updatable = false, nullable = false)
    private Set<PINSetApplication> pinSetApplications;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "Application_IDREF", referencedColumnName = "Application_ID", insertable = false,
            updatable = false, nullable = false)
    private Set<BonusApplication> bonusApplications;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "Application_IDREF", referencedColumnName = "Application_ID", insertable = false,
            updatable = false, nullable = false)
    private Set<MoneyTransferApplication> moneyTransferPickupApplications;

    @Column(name = "PreferredPhone")
    private String preferredPhone;

    @Column(name = "FeeCurrency")
    private String feeCurrency = "KZT";

    @Column(name = "Fee")
    private BigDecimal fee = new BigDecimal(0);

    @Column(name = "DateScheduled")
    private Date dateScheduled;

    @Column(name = "DateSigned")
    private Date dateSigned;
}
