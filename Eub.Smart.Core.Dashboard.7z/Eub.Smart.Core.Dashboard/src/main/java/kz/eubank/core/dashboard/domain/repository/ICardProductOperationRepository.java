package kz.eubank.core.dashboard.domain.repository;

import kz.eubank.core.dashboard.domain.model.entity.CardProductOperation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ICardProductOperationRepository extends JpaRepository<CardProductOperation, Long> {

    CardProductOperation findByProductId(Long productId);
}
