package kz.eubank.core.dashboard.domain.model.dto;

import kz.eubank.core.dashboard.domain.model.enums.CardStatus;
import kz.eubank.core.dashboard.domain.model.enums.CardTransactionStatus;
import kz.eubank.core.dashboard.domain.model.enums.SMSNotificationStatus;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import java.util.List;

@Getter
@Setter
//@Entity//todo
@XmlRootElement
public class CardXml implements Serializable {

    private static final long serialVersionUID = -6072057323105685238L;

    private Long id;
    private String number;
    private Date expiration;
    private CardStatus status;
    private String type;
    private String nameEmbossed;
    private Collection<CardLimitXml> cardLimitXmls;
    private int priority;
    boolean allowCNP;
    private CardTransactionStatus cardTransactionStatus = CardTransactionStatus.CVV_2;
    private SMSNotificationStatus smsNotificationStatus = SMSNotificationStatus.UNKN;
    private List<String> actions;
    private String hash;
    private Boolean isPINSet;
    private Boolean isIVR;
    private Boolean isDigital;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }
}
