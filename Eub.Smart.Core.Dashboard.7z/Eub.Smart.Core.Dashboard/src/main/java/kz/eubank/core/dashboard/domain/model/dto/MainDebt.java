package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Setter
@Getter
public class MainDebt {

    private BigDecimal amountBySchedule;
    private BigDecimal amountOverdue;
    private BigDecimal balanceBySchedule;
    private BigDecimal total;
}
