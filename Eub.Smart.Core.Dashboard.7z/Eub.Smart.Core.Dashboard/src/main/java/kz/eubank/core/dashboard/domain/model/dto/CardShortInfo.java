package kz.eubank.core.dashboard.domain.model.dto;

import kz.eubank.core.dashboard.domain.model.response.Account;
import lombok.Generated;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class CardShortInfo {

    private Long id;
    private String number;
    private String nameEmbossed;
    private String type;
    private String typeTitle;
    private CardStatus status;
    private Date expiration;
    private int priority;
    private Account account;
    private List<String> actions;

    @Generated
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof CardShortInfo)) {
            return false;
        }
        final CardShortInfo other = (CardShortInfo) o;
        if (!other.canEqual(this)) {
            return false;
        }
        final Object this$id = this.getId();
        final Object other$id = other.getId();
        Label_0065:
        {
            if (this$id == null) {
                if (other$id == null) {
                    break Label_0065;
                }
            } else if (this$id.equals(other$id)) {
                break Label_0065;
            }
            return false;
        }
        final Object this$number = this.getNumber();
        final Object other$number = other.getNumber();
        Label_0102:
        {
            if (this$number == null) {
                if (other$number == null) {
                    break Label_0102;
                }
            } else if (this$number.equals(other$number)) {
                break Label_0102;
            }
            return false;
        }
        final Object this$nameEmbossed = this.getNameEmbossed();
        final Object other$nameEmbossed = other.getNameEmbossed();
        Label_0139:
        {
            if (this$nameEmbossed == null) {
                if (other$nameEmbossed == null) {
                    break Label_0139;
                }
            } else if (this$nameEmbossed.equals(other$nameEmbossed)) {
                break Label_0139;
            }
            return false;
        }
        final Object this$type = this.getType();
        final Object other$type = other.getType();
        Label_0176:
        {
            if (this$type == null) {
                if (other$type == null) {
                    break Label_0176;
                }
            } else if (this$type.equals(other$type)) {
                break Label_0176;
            }
            return false;
        }
        final Object this$typeTitle = this.getTypeTitle();
        final Object other$typeTitle = other.getTypeTitle();
        Label_0213:
        {
            if (this$typeTitle == null) {
                if (other$typeTitle == null) {
                    break Label_0213;
                }
            } else if (this$typeTitle.equals(other$typeTitle)) {
                break Label_0213;
            }
            return false;
        }
        final Object this$status = this.getStatus();
        final Object other$status = other.getStatus();
        Label_0250:
        {
            if (this$status == null) {
                if (other$status == null) {
                    break Label_0250;
                }
            } else if (this$status.equals(other$status)) {
                break Label_0250;
            }
            return false;
        }
        final Object this$expiration = this.getExpiration();
        final Object other$expiration = other.getExpiration();
        Label_0287:
        {
            if (this$expiration == null) {
                if (other$expiration == null) {
                    break Label_0287;
                }
            } else if (this$expiration.equals(other$expiration)) {
                break Label_0287;
            }
            return false;
        }
        if (this.getPriority() != other.getPriority()) {
            return false;
        }
        final Object this$account = this.getAccount();
        final Object other$account = other.getAccount();
        Label_0337:
        {
            if (this$account == null) {
                if (other$account == null) {
                    break Label_0337;
                }
            } else if (this$account.equals(other$account)) {
                break Label_0337;
            }
            return false;
        }
        final Object this$actions = this.getActions();
        final Object other$actions = other.getActions();
        if (this$actions == null) {
            return other$actions == null;
        } else return this$actions.equals(other$actions);
    }

    @Generated
    protected boolean canEqual(final Object other) {
        return other instanceof CardShortInfo;
    }

    @Generated
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $id = this.getId();
        result = result * 59 + (($id == null) ? 43 : $id.hashCode());
        final Object $number = this.getNumber();
        result = result * 59 + (($number == null) ? 43 : $number.hashCode());
        final Object $nameEmbossed = this.getNameEmbossed();
        result = result * 59 + (($nameEmbossed == null) ? 43 : $nameEmbossed.hashCode());
        final Object $type = this.getType();
        result = result * 59 + (($type == null) ? 43 : $type.hashCode());
        final Object $typeTitle = this.getTypeTitle();
        result = result * 59 + (($typeTitle == null) ? 43 : $typeTitle.hashCode());
        final Object $status = this.getStatus();
        result = result * 59 + (($status == null) ? 43 : $status.hashCode());
        final Object $expiration = this.getExpiration();
        result = result * 59 + (($expiration == null) ? 43 : $expiration.hashCode());
        result = result * 59 + this.getPriority();
        final Object $account = this.getAccount();
        result = result * 59 + (($account == null) ? 43 : $account.hashCode());
        final Object $actions = this.getActions();
        result = result * 59 + (($actions == null) ? 43 : $actions.hashCode());
        return result;
    }

    @Generated
    @Override
    public String toString() {
        return "CardShortInfo(id=" + this.getId() + ", number=" + this.getNumber() + ", nameEmbossed="
                + this.getNameEmbossed() + ", type=" + this.getType() + ", typeTitle=" + this.getTypeTitle()
                + ", status=" + this.getStatus() + ", expiration=" + this.getExpiration() + ", priority="
                + this.getPriority() + ", account=" + this.getAccount() + ", actions=" + this.getActions() + ")";
    }
}
