package kz.eubank.core.dashboard.domain.model.entity;

import kz.eubank.core.dashboard.domain.model.entity.core.Term;

import javax.persistence.*;

@Entity
@Table(name = "Provider")
public class Provider {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Provider_ID")
    private Long id;

    @Column(name = "Provider_Title")
    private String title;
    
    @Column(name = "Synonyms")
    private String synonyms;

    @OneToOne
    @JoinColumn(name = "Term_OUTREF")
    private Term term;

    public Long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public Term getTerm() {
        return term;
    }

    public String getSynonyms() {
        return synonyms;
    }

}
