package kz.eubank.core.dashboard.domain.model.enums;

public enum ApplicationMode {
    PAYMENT
}
