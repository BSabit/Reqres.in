package kz.eubank.core.dashboard.infrastructure.config;

import kz.eubank.core.dashboard.domain.model.enums.FrontEnd;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import java.net.URLDecoder;

@Service
public class CookiesManager {

    private static Logger log;
    public static final String DEFAULT_APPID = "smartbank-common";
    public static final String DEFAULT_IP = "unknown-ip";
    public static final String DEFAULT_FRONT_SID = "unknown-front-sid";
    public static final String DEFAULT_SID = "unknown-sid";
    public static final String DEFAULT_LANGUAGE = "ru";
    public static final String DEFAULT_LOGIN = "unknown-login";
    public static final String DEFAULT_CREF = "unknown-cref";
    public static final String DEFAULT_PLATFORM = "unknown-platform";
    public static final String DEFAULT_VERSION = "unknown-version";
    public static final String DEFAULT_TIME_ZONE = "+06:00";
    public static final String COOKIE_APPID = "smartbank.appid";
    public static final String COOKIE_IP = "smartbank.ip";
    public static final String COOKIE_CREF = "smartbank.cref";
    public static final String COOKIE_LOGIN = "smartbank.login";
    public static final String COOKIE_FRONT_SID = "smartbank.front.sid";
    public static final String COOKIE_LANG = "lang";
    public static final String COOKIE_PLATFORM = "smartbank.platform";
    public static final String COOKIE_VERSION = "smartbank.version";
    public static final String COOKIE_TIME_ZONE = "smartbank.time.zone";
    public static final String COOKIE_REQUEST_ID = "smartbank.requestid";
    public static final String COOKIE_DEVICE_ID = "smartbank.deviceid";
    public static final String COOKIE_MESSAGE_SENDER = "smartbank.message.sender";

    public FrontEnd getAppID() {
        final String appId = this.getCookie("smartbank.appid", "smartbank-common");
        try {
            return FrontEnd.valueOf(appId);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    public String getIp() {
        return this.getCookie("smartbank.ip", "unknown-ip");
    }

    public String getFrontSid() {
        return this.getCookie("smartbank.front.sid", "unknown-front-sid");
    }

    public String getLanguage() {
        return this.getCookie("lang", "ru");
    }

    public String getLogin() {
        return this.getCookie("smartbank.login", "unknown-login");
    }

    public String getCref() {
        return this.getCookie("smartbank.cref", "unknown-cref");
    }

    public Long getClientId() {
        final String cref = this.getCref();
        if (StringUtils.isEmpty(cref)) {
            return -1L;
        }
        return Long.valueOf(StringUtils.isNumeric(cref) ? cref : "0");
    }

    public String getPlatform() {
        return this.getCookie("smartbank.platform", "unknown-platform");
    }

    public String getMessageSender() {
        return this.getCookie("smartbank.message.sender", null);
    }

    public String getVersion() {
        return this.getCookie("smartbank.version", "unknown-version");
    }

    public String getRequestId() {
        return this.getCookie("smartbank.requestid", "");
    }

    protected String getCookie(final String name, final String defaultValue) {
        try {
            final ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder
                    .currentRequestAttributes();
            final HttpServletRequest request = requestAttributes.getRequest();
            final Cookie[] cookies = request.getCookies();
            if (cookies == null) {
                return defaultValue;
            }
            for (final Cookie cookie : cookies) {
                if (name.equals(cookie.getName())) {
                    return URLDecoder.decode(cookie.getValue(), "UTF-8");
                }
            }
        } catch (Exception e) {
            CookiesManager.log.error(e.getMessage(), (Throwable) e);
        }
        return defaultValue;
    }

    public String getTimeZone() {
        return this.getCookie("smartbank.time.zone", "+06:00");
    }

    public String getDeviceId() {
        return this.getCookie("smartbank.deviceid", null);
    }

    static {
        CookiesManager.log = LoggerFactory.getLogger((Class) CookiesManager.class);
    }
}
