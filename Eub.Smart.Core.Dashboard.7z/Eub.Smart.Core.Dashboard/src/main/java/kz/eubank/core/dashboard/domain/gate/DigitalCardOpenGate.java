package kz.eubank.core.dashboard.domain.gate;

import kz.eubank.core.dashboard.domain.model.dto.TempDigitalCard;

import java.util.List;

public interface DigitalCardOpenGate {

    List<TempDigitalCard> getTempCards(Long userId);
}
