package kz.eubank.core.dashboard.domain.model.enums;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public enum CardType {

    VISA_ELECTRON(Collections.singletonList("Visa Electron")),
    VISA_CLASSIC(Collections.singletonList("Visa Classic")),
    VISA_GOLD(Collections.singletonList("Visa Gold")),
    VISA_PLATINUM(Collections.singletonList("Visa Platinum")),
    VISA_INFINITY(Collections.singletonList("Visa Infinite")),
    VISA_BUSINESS(Collections.singletonList("VISA BUSINESS")),
    MC_GOLD(Collections.singletonList("MasterCard Gold")),
    MC_STANDARD(Collections.singletonList("MasterCard Standard")),
    MC_STANDARD_PAY_PASS(Collections.singletonList("MasterCard Standard PayPass")),
    MC_GOLD_PAY_PASS(Collections.singletonList("MasterCard Gold PayPass")),
    MC_BLACK(Arrays.asList("MasterCard Auto Card",
            "Mastercard Black Edition PayPass",
            "MC WORLD ELITE METAL BLUE",
            "MC WORLD ELITE METAL RED")),
    VISA_AUVS(Collections.singletonList("VISA Auto Card")),
    VISA_GMTL(Collections.singletonList("VISA GREY METAL PRIVATE")),
    MC_MGSC(Collections.singletonList("MC Smart Card PayPass Digital")),
    VISA_PMTL(Collections.singletonList("VISA PINK METAL PRIVATE")),
    MC_CBDC_PAY_PASS(Collections.singletonList("MC CBDC Card"));

    private final List<String> cardTypes;

    CardType(List<String> cardTypes) {
        this.cardTypes = cardTypes;
    }

    public List<String> getCardTypes() {
        return cardTypes;
    }

    public static CardType fromString(String text) {
        return Arrays.stream(CardType.values())
                .filter(e -> e.getCardTypes().stream()
                        .anyMatch(s -> s.equalsIgnoreCase(text)))
                .findFirst().orElse(null);
    }
}
