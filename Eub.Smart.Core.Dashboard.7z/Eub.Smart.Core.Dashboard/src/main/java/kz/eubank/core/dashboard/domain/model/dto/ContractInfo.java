package kz.eubank.core.dashboard.domain.model.dto;

import kz.eubank.core.dashboard.domain.model.enums.TermPeriod;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Getter
@Setter
public class ContractInfo implements Serializable {

    private static final long serialVersionUID = 3694708786726161226L;

    private String title;
    private String currency;
    private BigDecimal amount;
    private Date expiration;
    private String number;
    private BigDecimal interestRate;
    private int spriteIndex;
    private Integer term;
    private TermPeriod termPeriod;
    private List<String> actions;
    private int priority;
    private String type;

    private BigDecimal balance;
    private String balanceCurrency;
    private BigDecimal actualBalance;
    private BigDecimal blockedSum;

    private BigDecimal effectiveRate;
}
