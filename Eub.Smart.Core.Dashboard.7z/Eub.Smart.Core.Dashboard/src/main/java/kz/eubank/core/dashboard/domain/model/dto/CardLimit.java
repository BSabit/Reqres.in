package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class CardLimit {

    private BigDecimal amount;
    private String currency;
    private Integer interval;
    private String intervalType;
    private String type;

    @Override
    public String toString() {
        return "CardLimit [amount=" + this.amount + ", currency=" + this.currency + ", interval=" + this.interval
                + ", intervalType=" + this.intervalType + ", type=" + this.type + "]";
    }
}
