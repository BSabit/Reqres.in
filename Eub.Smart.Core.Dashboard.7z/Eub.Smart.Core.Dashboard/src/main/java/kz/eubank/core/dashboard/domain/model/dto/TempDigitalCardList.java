package kz.eubank.core.dashboard.domain.model.dto;

import java.util.Collection;

public class TempDigitalCardList extends AbstractList<TempDigitalCard> {

    public TempDigitalCardList(Collection<TempDigitalCard> items) {
        super(items);
    }
}
