package kz.eubank.core.dashboard.domain.repository;

import kz.eubank.core.dashboard.domain.model.entity.MapCardAndCardUsageType;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ICardLimitsRepository extends CrudRepository<MapCardAndCardUsageType, Long> {

    @Query("select m from MapCardAndCardUsageType m where m.cardId=?1")
    List<MapCardAndCardUsageType> findByCardId(final Long p0);
}
