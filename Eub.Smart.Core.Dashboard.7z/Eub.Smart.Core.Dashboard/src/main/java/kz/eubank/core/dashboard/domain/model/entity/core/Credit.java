package kz.eubank.core.dashboard.domain.model.entity.core;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;

@Entity
@Table(name = "Credit")
public class Credit {

    @Id
    @Column(name = "Credit_ID")
    private Long id;

    @Column(name = "Credit_OUTREF")
    private String outref;

    @Column(name = "Credit_Title")
    private String title;

    @Column(name = "Number")
    private String number;

    @Column(name = "Currency")
    private String currency;

    @Column(name = "Amount")
    private BigDecimal amount;

    @Column(name = "DateOpened")
    private Date dateStart;

    @Column(name = "DateClosed")
    private Date dateEnd;

    @Column(name = "ProductCompound_OUTREF")
    private String productCompoundOutref;

    @Column(name = "Product_IDREF")
    private Long productId;

    @OneToOne
    @JoinColumn(name = "CreditPayType_IDREF")
    private CreditPayType payType;

    @Column(name = "InterestRate")
    private BigDecimal interestRate;

    @OneToOne
    @JoinColumn(name = "CreditStatus_IDREF")
    private CreditStatus status;

    @OneToOne()
    @JoinColumn(name = "BSystemClient_IDREF")
    private BSystemClient bsystemClient;

    @OneToOne
    @JoinColumn(name = "Branch_IDREF")
    private Branch branch;

    @OneToMany(mappedBy = "credit")
    private Collection<Duty> duties;

    @OneToOne
    @JoinColumn(name = "UIIcon_IDREF")
    private UIIcon uiIcon;

    @Column(name = "Term")
    private Integer term;

    @Column(name = "Guarantee")
    private String guarantee;


    @Column(name = "TermPeriod")
    private String termPeriod;

    public Long getId() {
        return id;
    }

    public String getNumber() {
        return number;
    }

    public String getCurrency() {
        return currency;
    }

    public String getOutref() {
        return outref;
    }

    public String getTitle() {
        return title;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public Date getDateStart() {
        return dateStart;
    }

    public Date getDateEnd() {
        return dateEnd;
    }

    public CreditPayType getPayType() {
        return payType;
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public CreditStatus getStatus() {
        return status;
    }

    public Branch getBranch() {
        return branch;
    }

    public Collection<Duty> getDuties() {
        return duties;
    }

    public BSystemClient getBsystemClient() {
        return bsystemClient;
    }

    public UIIcon getUiIcon() {
        return uiIcon;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setUiIcon(UIIcon uiIcon) {
        this.uiIcon = uiIcon;
    }

    public Long getProductId() {
        return productId;
    }

    public Integer getTerm() {
        return term;
    }

    public String getTermPeriod() {
        return termPeriod;
    }

    public String getProductCompoundOutref() {
        return productCompoundOutref;
    }

    public void setProductCompoundOutref(String productCompoundOutref) {
        this.productCompoundOutref = productCompoundOutref;
    }

    public String getGuarantee() {
        return guarantee;
    }

    public void setGuarantee(String guarantee) {
        this.guarantee = guarantee;
    }
}
