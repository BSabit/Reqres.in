package kz.eubank.core.dashboard.domain.model.converter;

import kz.eubank.core.dashboard.domain.model.dto.Item;
import kz.eubank.core.dashboard.domain.model.dto.CreditContractAccount;
import kz.eubank.core.dashboard.domain.model.dto.Debt;
import kz.eubank.core.dashboard.domain.model.dto.Duty;
import lombok.extern.log4j.Log4j2;
import org.dozer.CustomConverter;
import org.springframework.beans.BeanUtils;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Objects;

@Log4j2
public class ItemToCreditContractConverter implements CustomConverter {

    @Override
    public Object convert(Object dest, Object source, Class<?> arg2, Class<?> arg3) {
        if (source == null) {
            return null;
        }
        if (source instanceof Item) {
            Item item = (Item) source;
            CreditContractAccount creditContract = new CreditContractAccount();
            setCreditContractStaticFields(creditContract);

            creditContract.setNumber(item.getGeneralInfo().getContractNumber());
            creditContract.setTitle(item.getGeneralInfo().getContractNumber());
            creditContract.setBalance(nullSafeBG(item.getGeneralInfo().getTotalCreditBalance()));
            creditContract.setDateOpened(dateToLong(item.getGeneralInfo().getDateOpen()));
            creditContract.setAmount(nullSafeBG(item.getGeneralInfo().getAmount()));
            creditContract.setInterestRate(nullSafeBG(item.getGeneralInfo().getRateMin()));
            creditContract.setValidityDate(0L);
            creditContract.setTerm(item.getGeneralInfo().getTerm());
            creditContract.setExpiration(0L);
            creditContract.setSourceSystem(item.getSourceSystem());
            creditContract.setGuarantee("");
            creditContract.setRepaymentAccounts(Collections.emptyList());

            String productType = item.getGeneralInfo().getProductType();
            log.info("productType: " + productType);
            creditContract.setType(productType);

            BigDecimal totalFullRepaymentBalance = item.getGeneralInfo().getTotalFullRepaymentBalance();
            log.info("totalFullRepaymentBalance: " + totalFullRepaymentBalance);
            creditContract.setTotalFullRepaymentBalance(totalFullRepaymentBalance);

            Duty duty = new Duty();
            duty.setNextPaymentAmount(nullSafeBG(item.getGeneralInfo().getRepaymentBySchedule()));
            duty.setAmount(nullSafeBG(item.getGeneralInfo().getAmount()));
            duty.setNextPaymentDate(dateToLong(item.getGeneralInfo().getRepaymentDateBySchedule()));
            duty.setDateOpened(dateToLong(item.getGeneralInfo().getDateOpen()));
            duty.setDateClosed(dateToLong(item.getGeneralInfo().getDateClose()));
            duty.setOverpayment(nullSafeBG(item.getGeneralInfo().getTotalOverpayment()));
            duty.setId(0L);
            duty.setInterestRate(nullSafeBG(BigDecimal.ZERO));
            duty.setStatus("");
            duty.setType("");
            duty.setNumber("");

            Debt debt = new Debt();
            debt.setMain(nullSafeBG(item.getMainDebt().getBalanceBySchedule()));
            debt.setPercentage(nullSafeBG(item.getInterest().getBalanceBySchedule()));
            debt.setCommission(nullSafeBG(item.getFeePeriodic().getBalanceBySchedule()));
            debt.setTotal(nullSafeBG(add(item.getMainDebt().getBalanceBySchedule(),
                    item.getInterest().getBalanceBySchedule(),
                    item.getFeePeriodic().getBalanceBySchedule())));
            debt.setOverDueInterestCommission(BigDecimal.ZERO);
            debt.setFine(BigDecimal.ZERO);

            Debt delayedDebt = new Debt();
            delayedDebt.setMain(nullSafeBG(item.getMainDebt().getAmountOverdue()));
            delayedDebt.setPercentage(nullSafeBG(item.getInterest().getAmountOverdue()));
            delayedDebt.setCommission(nullSafeBG(item.getFeePeriodic().getAmountOverdue()));
            delayedDebt.setTotal(nullSafeBG(item.getGeneralInfo().getTotalOverdue()));
            delayedDebt.setOverDueInterestCommission(BigDecimal.ZERO);
            delayedDebt.setFine(BigDecimal.ZERO);

            Debt delayedDebtFine = new Debt();
            delayedDebtFine.setMain(nullSafeBG(add(item.getFine().getMainDebt(), item.getFine().getMainDebtOverdue())));
            delayedDebtFine.setPercentage(BigDecimal.ZERO);
            delayedDebtFine.setCommission(BigDecimal.ZERO);
            delayedDebtFine.setTotal(nullSafeBG(item.getFine().getTotal()));
            delayedDebtFine.setOverDueInterestCommission(BigDecimal.ZERO);
            delayedDebtFine.setFine(nullSafeBG(item.getFine().getInterest()));

            duty.setDebt(debt);
            duty.setDelayedDebt(delayedDebt);
            duty.setDelayedDebtFine(delayedDebtFine);

            creditContract.setDuties(Collections.singletonList(duty));
            return creditContract;
        } else if (source instanceof CreditContractAccount) {
            CreditContractAccount creditContract = (CreditContractAccount) source;
            Item item = new Item();
            BeanUtils.copyProperties(creditContract, item);
            return item;
        }
        return null;
    }

    private static void setCreditContractStaticFields(CreditContractAccount creditContract) {
        creditContract.setActions(Arrays.asList("INST", "SMTI", "STMT"));
        creditContract.setCurrency("KZT");
//        creditContract.setType("CRED");
        creditContract.setAllowBalance(true);
        creditContract.setShowBalance(true);
        creditContract.setAllowCreateFinDoc(false);
        creditContract.setAllowTransfer(false);
        creditContract.setStatus("ACTIVE");
        creditContract.setContractNo("");
        creditContract.setBranchTitle("");
        creditContract.setTermPeriod("MONTH");
        creditContract.setBranchTermId("");
        creditContract.setCreditType("CRED");
        creditContract.setServicingBranch("");
    }

    private static Long dateToLong(Date date) {
        return (date != null) ? date.getTime() : null;
    }

    private static BigDecimal add(BigDecimal... addends) {
        if (addends == null) {
            return BigDecimal.ZERO;
        }
        return Arrays.stream(addends)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private static BigDecimal nullSafeBG(BigDecimal source) {
        if (source == null) {
            return BigDecimal.ZERO;
        }
        return new BigDecimal(source.stripTrailingZeros().toPlainString());
    }
}
