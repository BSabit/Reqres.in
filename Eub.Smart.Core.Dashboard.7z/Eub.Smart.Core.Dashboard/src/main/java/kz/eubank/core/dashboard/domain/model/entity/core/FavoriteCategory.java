package kz.eubank.core.dashboard.domain.model.entity.core;

import javax.persistence.*;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "FavoriteCategory")
public class FavoriteCategory {

    @Id
    @Column(name = "FavoriteCategory_ID", nullable = false)
    private String id;

    @Column(name = "FavoriteCategory_Title")
    private String title;

    @Column(name = "FavoriteCategory_OUTREF")
    private String outRef;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF", nullable = true)
    private Term terms;

    @Column(name = "MCC")
    private String mcc;

    @Column(name = "IsVisible")
    private boolean visible;

    @OneToMany(mappedBy = "category")
    private List<FavoriteCategoryDetails> details;

    @OneToOne()
    @JoinColumn(name = "AdditionalDescription_Term_OUTREF")
    private Term additionalDescriptionTerms;


    @Column(name = "Color")
    private String color;

    @Column(name = "ImagePath")
    private String imagePath;

    @Transient
    private String description;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMcc() {
        return mcc;
    }

    public void setMcc(String mcc) {
        this.mcc = mcc;
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public Term getTerms() {
        return terms;
    }

    public void setTerms(Term terms) {
        this.terms = terms;
    }

    public List<FavoriteCategoryDetails> getDetails() {
        return details;
    }

    public void setDetails(List<FavoriteCategoryDetails> details) {
        this.details = details;
    }

    public Term getAdditionalDescriptionTerms() {
        return additionalDescriptionTerms;
    }

    public void setAdditionalDescriptionTerms(Term additionalDescriptionTerms) {
        this.additionalDescriptionTerms = additionalDescriptionTerms;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public String getOutRef() {
        return outRef;
    }

    public void setOutRef(String outRef) {
        this.outRef = outRef;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
