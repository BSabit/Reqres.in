package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

@Setter
@Getter
@Entity
public class Account2 {

    @Id
    @Column(name = "Account_ID")
    private Long id;

    @Column(name = "Account_Title")
    private String title;

    @Column(name = "Currency")
    private String currency;

    @Column(name = "Number")
    private String number;

    @Column(name = "Account_Status")
    private String status;

    @Column(name = "Account_Type")
    private String type;

    @Column(name = "Sprite_Index")
    private int spriteIndex;

    @Column(name = "Account_Priority")
    private int priority;

    @Column(name = "Product_IDREF")
    private Long productId;

    @Column(name = "InterestRate")
    private BigDecimal interestRate;

    @Column(name = "Limit_Currency")
    private String limitCurrency;

    @Column(name = "Limit_FinDoc")
    private BigDecimal limitFinDoc;

    @Column(name = "Limit_Day")
    private BigDecimal limitDay;

    @Column(name = "Limit_Week")
    private BigDecimal limitWeek;

    @Column(name = "Limit_Month")
    private BigDecimal limitMonth;

    @Column(name = "Branch_IDREF")
    private Long branchId;

    @Column(name = "AllowBalance")
    private boolean allowBalance;

    @Column(name = "AllowCreateFinDoc")
    private boolean allowCreateFinDoc;

    @Column(name = "AllowSubmitFinDoc")
    private boolean allowSubmitFinDoc;

    @Column(name = "IsMultiCurrency")
    private boolean multiCurrency;

    @Column(name = "ContractNo")
    private String contractNo;

    @Column(name = "Account_IDREF")
    private Long parentAccountId;

    @Column(name = "EffectiveRate")
    private BigDecimal effectiveRate;
}
