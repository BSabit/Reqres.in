package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class Branch extends Facility {

    private Long id;
    private Address address;
    private String bicCode;
    private String binCode;
    private String title;
    private String rnn;
    private String termId;
    private String openingHours;
    private List<BranchQueue> queues;
    private String queueCash;
    private String queueCustomerService;
    private List<WorkingHours> hours;
    private String[] services;
    private Integer number;
    private String type;
    private boolean active;
}
