package kz.eubank.core.dashboard.domain.model.mapper;

import kz.eubank.core.dashboard.domain.model.dto.SSGPOSettlementInfo;
import kz.eubank.core.dashboard.domain.model.entity.SSGPOMutualSettlements;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface SSGPOSettlementInfoMapper {

    SSGPOSettlementInfoMapper INSTANCE = Mappers.getMapper(SSGPOSettlementInfoMapper.class);

    @Mappings({
            @Mapping(target = "accrualRate", expression = "java(ssgpoMutualSettlements.getAccrualRate())"),
            @Mapping(target = "amount", expression = "java(ssgpoMutualSettlements.getAmount())"),
            @Mapping(target = "code", expression = "java(ssgpoMutualSettlements.getSsgpoCodeDictionary().getCode())"),
            @Mapping(target = "settlementMonth", expression = "java(ssgpoMutualSettlements.getMutualSettlementPeriod())"),
            @Mapping(target = "settlementType", expression =
                    "java(ssgpoMutualSettlements.getSsgpoCodeDictionary().getSsgpoCodeType().getType().equals(\"ACCR\")" +
                            " ? \"Accrual\" : \"Retention\")"),
            @Mapping(target = "codeDesc", expression = "java(\"ru\".equals(lang) " +
                    "? ssgpoMutualSettlements.getSsgpoCodeDictionary().getCodeDescRu()" +
                    ": ssgpoMutualSettlements.getSsgpoCodeDictionary().getCodeDescKz())"),
            @Mapping(target = "codeDescShort", expression = "java(\"ru\".equals(lang) " +
                    "? ssgpoMutualSettlements.getSsgpoCodeDictionary().getCodeDescShortRu()" +
                    ": ssgpoMutualSettlements.getSsgpoCodeDictionary().getCodeDescShortKz())")
    })
    SSGPOSettlementInfo toDto(SSGPOMutualSettlements ssgpoMutualSettlements, String lang);
}
