package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

@Setter
@Getter
public class GeneralInfo {

    private BigDecimal amount;
    private String clientFullName;
    private String currency;
    private BigDecimal currentAmount;
    private Date dateOpen;
    private Date dateClose;
    private Long term;
    private String contractNumber;
    private String branch;
    private Date currentPaymentDate;
    private BigDecimal rateMin;
    private BigDecimal rateEffective;
    private Integer countOverdueDays;
    private BigDecimal repaymentBySchedule;
    private Date repaymentDateBySchedule;
    private BigDecimal totalOverdue;
    private BigDecimal totalFine;
    private BigDecimal totalOverpayment;
    private BigDecimal totalCreditBalance;
    private BigDecimal totalFullRepaymentBalance;
    private String productType;
}
