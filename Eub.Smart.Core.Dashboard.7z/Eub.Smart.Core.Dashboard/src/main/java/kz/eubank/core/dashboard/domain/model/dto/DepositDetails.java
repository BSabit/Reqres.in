// 
// Decompiled by Procyon v0.5.36
// 

package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

@Setter
@Getter
public class DepositDetails {

    private String termCode;
    private Integer termPeriod;
    private BigDecimal effectiveRate;
    private Date expiration;
}
