package kz.eubank.core.dashboard.domain.model.response;

import lombok.Generated;

import java.math.BigDecimal;
import java.util.Date;

public class LoanApplicationScoring {
    private Long id;
    private Long created;
    private LoanApplicationScoringStatus status;
    private String statusComment;
    private String credilogicStatus;
    private BigDecimal fullLoanAmount;
    private BigDecimal loanAmount;
    private BigDecimal commissionAmount;
    private BigDecimal feeAmount;
    private BigDecimal insuranceAmount;
    private Integer period;
    private Double apr;
    private BigDecimal totalInstallment;
    private Long fileStorageId;

    @Generated
    public LoanApplicationScoring() {
    }

    @Generated
    public Long getId() {
        return this.id;
    }

    @Generated
    public Long getCreated() {
        return this.created;
    }

    @Generated
    public LoanApplicationScoringStatus getStatus() {
        return this.status;
    }

    @Generated
    public String getStatusComment() {
        return this.statusComment;
    }

    @Generated
    public String getCredilogicStatus() {
        return this.credilogicStatus;
    }

    @Generated
    public BigDecimal getFullLoanAmount() {
        return this.fullLoanAmount;
    }

    @Generated
    public BigDecimal getLoanAmount() {
        return this.loanAmount;
    }

    @Generated
    public BigDecimal getCommissionAmount() {
        return this.commissionAmount;
    }

    @Generated
    public BigDecimal getFeeAmount() {
        return this.feeAmount;
    }

    @Generated
    public BigDecimal getInsuranceAmount() {
        return this.insuranceAmount;
    }

    @Generated
    public Integer getPeriod() {
        return this.period;
    }

    @Generated
    public Double getApr() {
        return this.apr;
    }

    @Generated
    public BigDecimal getTotalInstallment() {
        return this.totalInstallment;
    }

    @Generated
    public Long getFileStorageId() {
        return this.fileStorageId;
    }

    @Generated
    public void setId(final Long id) {
        this.id = id;
    }

    @Generated
    public void setCreated(final Long created) {
        this.created = created;
    }

    @Generated
    public void setStatus(final LoanApplicationScoringStatus status) {
        this.status = status;
    }

    @Generated
    public void setStatusComment(final String statusComment) {
        this.statusComment = statusComment;
    }

    @Generated
    public void setCredilogicStatus(final String credilogicStatus) {
        this.credilogicStatus = credilogicStatus;
    }

    @Generated
    public void setFullLoanAmount(final BigDecimal fullLoanAmount) {
        this.fullLoanAmount = fullLoanAmount;
    }

    @Generated
    public void setLoanAmount(final BigDecimal loanAmount) {
        this.loanAmount = loanAmount;
    }

    @Generated
    public void setCommissionAmount(final BigDecimal commissionAmount) {
        this.commissionAmount = commissionAmount;
    }

    @Generated
    public void setFeeAmount(final BigDecimal feeAmount) {
        this.feeAmount = feeAmount;
    }

    @Generated
    public void setInsuranceAmount(final BigDecimal insuranceAmount) {
        this.insuranceAmount = insuranceAmount;
    }

    @Generated
    public void setPeriod(final Integer period) {
        this.period = period;
    }

    @Generated
    public void setApr(final Double apr) {
        this.apr = apr;
    }

    @Generated
    public void setTotalInstallment(final BigDecimal totalInstallment) {
        this.totalInstallment = totalInstallment;
    }

    @Generated
    public void setFileStorageId(final Long fileStorageId) {
        this.fileStorageId = fileStorageId;
    }

    @Generated
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof LoanApplicationScoring)) {
            return false;
        }
        final LoanApplicationScoring other = (LoanApplicationScoring) o;
        if (!other.canEqual(this)) {
            return false;
        }
        final Object this$id = this.getId();
        final Object other$id = other.getId();
        Label_0065:
        {
            if (this$id == null) {
                if (other$id == null) {
                    break Label_0065;
                }
            } else if (this$id.equals(other$id)) {
                break Label_0065;
            }
            return false;
        }
        final Object this$created = this.getCreated();
        final Object other$created = other.getCreated();
        Label_0102:
        {
            if (this$created == null) {
                if (other$created == null) {
                    break Label_0102;
                }
            } else if (this$created.equals(other$created)) {
                break Label_0102;
            }
            return false;
        }
        final Object this$status = this.getStatus();
        final Object other$status = other.getStatus();
        Label_0139:
        {
            if (this$status == null) {
                if (other$status == null) {
                    break Label_0139;
                }
            } else if (this$status.equals(other$status)) {
                break Label_0139;
            }
            return false;
        }
        final Object this$statusComment = this.getStatusComment();
        final Object other$statusComment = other.getStatusComment();
        Label_0176:
        {
            if (this$statusComment == null) {
                if (other$statusComment == null) {
                    break Label_0176;
                }
            } else if (this$statusComment.equals(other$statusComment)) {
                break Label_0176;
            }
            return false;
        }
        final Object this$credilogicStatus = this.getCredilogicStatus();
        final Object other$credilogicStatus = other.getCredilogicStatus();
        Label_0213:
        {
            if (this$credilogicStatus == null) {
                if (other$credilogicStatus == null) {
                    break Label_0213;
                }
            } else if (this$credilogicStatus.equals(other$credilogicStatus)) {
                break Label_0213;
            }
            return false;
        }
        final Object this$fullLoanAmount = this.getFullLoanAmount();
        final Object other$fullLoanAmount = other.getFullLoanAmount();
        Label_0250:
        {
            if (this$fullLoanAmount == null) {
                if (other$fullLoanAmount == null) {
                    break Label_0250;
                }
            } else if (this$fullLoanAmount.equals(other$fullLoanAmount)) {
                break Label_0250;
            }
            return false;
        }
        final Object this$loanAmount = this.getLoanAmount();
        final Object other$loanAmount = other.getLoanAmount();
        Label_0287:
        {
            if (this$loanAmount == null) {
                if (other$loanAmount == null) {
                    break Label_0287;
                }
            } else if (this$loanAmount.equals(other$loanAmount)) {
                break Label_0287;
            }
            return false;
        }
        final Object this$commissionAmount = this.getCommissionAmount();
        final Object other$commissionAmount = other.getCommissionAmount();
        Label_0324:
        {
            if (this$commissionAmount == null) {
                if (other$commissionAmount == null) {
                    break Label_0324;
                }
            } else if (this$commissionAmount.equals(other$commissionAmount)) {
                break Label_0324;
            }
            return false;
        }
        final Object this$feeAmount = this.getFeeAmount();
        final Object other$feeAmount = other.getFeeAmount();
        Label_0361:
        {
            if (this$feeAmount == null) {
                if (other$feeAmount == null) {
                    break Label_0361;
                }
            } else if (this$feeAmount.equals(other$feeAmount)) {
                break Label_0361;
            }
            return false;
        }
        final Object this$insuranceAmount = this.getInsuranceAmount();
        final Object other$insuranceAmount = other.getInsuranceAmount();
        Label_0398:
        {
            if (this$insuranceAmount == null) {
                if (other$insuranceAmount == null) {
                    break Label_0398;
                }
            } else if (this$insuranceAmount.equals(other$insuranceAmount)) {
                break Label_0398;
            }
            return false;
        }
        final Object this$period = this.getPeriod();
        final Object other$period = other.getPeriod();
        Label_0435:
        {
            if (this$period == null) {
                if (other$period == null) {
                    break Label_0435;
                }
            } else if (this$period.equals(other$period)) {
                break Label_0435;
            }
            return false;
        }
        final Object this$apr = this.getApr();
        final Object other$apr = other.getApr();
        Label_0472:
        {
            if (this$apr == null) {
                if (other$apr == null) {
                    break Label_0472;
                }
            } else if (this$apr.equals(other$apr)) {
                break Label_0472;
            }
            return false;
        }
        final Object this$totalInstallment = this.getTotalInstallment();
        final Object other$totalInstallment = other.getTotalInstallment();
        Label_0509:
        {
            if (this$totalInstallment == null) {
                if (other$totalInstallment == null) {
                    break Label_0509;
                }
            } else if (this$totalInstallment.equals(other$totalInstallment)) {
                break Label_0509;
            }
            return false;
        }
        final Object this$fileStorageId = this.getFileStorageId();
        final Object other$fileStorageId = other.getFileStorageId();
        if (this$fileStorageId == null) {
            return other$fileStorageId == null;
        } else return this$fileStorageId.equals(other$fileStorageId);
    }

    @Generated
    protected boolean canEqual(final Object other) {
        return other instanceof LoanApplicationScoring;
    }

    @Generated
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $id = this.getId();
        result = result * 59 + (($id == null) ? 43 : $id.hashCode());
        final Object $created = this.getCreated();
        result = result * 59 + (($created == null) ? 43 : $created.hashCode());
        final Object $status = this.getStatus();
        result = result * 59 + (($status == null) ? 43 : $status.hashCode());
        final Object $statusComment = this.getStatusComment();
        result = result * 59 + (($statusComment == null) ? 43 : $statusComment.hashCode());
        final Object $credilogicStatus = this.getCredilogicStatus();
        result = result * 59 + (($credilogicStatus == null) ? 43 : $credilogicStatus.hashCode());
        final Object $fullLoanAmount = this.getFullLoanAmount();
        result = result * 59 + (($fullLoanAmount == null) ? 43 : $fullLoanAmount.hashCode());
        final Object $loanAmount = this.getLoanAmount();
        result = result * 59 + (($loanAmount == null) ? 43 : $loanAmount.hashCode());
        final Object $commissionAmount = this.getCommissionAmount();
        result = result * 59 + (($commissionAmount == null) ? 43 : $commissionAmount.hashCode());
        final Object $feeAmount = this.getFeeAmount();
        result = result * 59 + (($feeAmount == null) ? 43 : $feeAmount.hashCode());
        final Object $insuranceAmount = this.getInsuranceAmount();
        result = result * 59 + (($insuranceAmount == null) ? 43 : $insuranceAmount.hashCode());
        final Object $period = this.getPeriod();
        result = result * 59 + (($period == null) ? 43 : $period.hashCode());
        final Object $apr = this.getApr();
        result = result * 59 + (($apr == null) ? 43 : $apr.hashCode());
        final Object $totalInstallment = this.getTotalInstallment();
        result = result * 59 + (($totalInstallment == null) ? 43 : $totalInstallment.hashCode());
        final Object $fileStorageId = this.getFileStorageId();
        result = result * 59 + (($fileStorageId == null) ? 43 : $fileStorageId.hashCode());
        return result;
    }

    @Generated
    @Override
    public String toString() {
        return "LoanApplicationScoring(id=" + this.getId() + ", created=" + this.getCreated() + ", status=" + this.getStatus() + ", statusComment=" + this.getStatusComment() + ", credilogicStatus=" + this.getCredilogicStatus() + ", fullLoanAmount=" + this.getFullLoanAmount() + ", loanAmount=" + this.getLoanAmount() + ", commissionAmount=" + this.getCommissionAmount() + ", feeAmount=" + this.getFeeAmount() + ", insuranceAmount=" + this.getInsuranceAmount() + ", period=" + this.getPeriod() + ", apr=" + this.getApr() + ", totalInstallment=" + this.getTotalInstallment() + ", fileStorageId=" + this.getFileStorageId() + ")";
    }
}
