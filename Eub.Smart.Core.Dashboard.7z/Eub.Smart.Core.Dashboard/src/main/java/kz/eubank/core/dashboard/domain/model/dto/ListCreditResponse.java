package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ListCreditResponse {

    private String activityId;
    private String iin;
    private Loan loan;
    private Error error;
}
