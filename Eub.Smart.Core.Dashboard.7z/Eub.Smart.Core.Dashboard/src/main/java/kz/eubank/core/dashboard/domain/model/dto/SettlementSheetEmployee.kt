package kz.eubank.core.dashboard.domain.model.dto

data class SettlementSheetEmployee(
    var departmentName: String? = null,
    var departmentNumber: String? = null,
    var fullName: String? = null,
    var iin: String? = null,
    var number: String? = null,
    var salary: Int? = null,
    var sheets: List<SettlementSheet>? = null
)