package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "Client")
public class Client {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Client_ID")
    private Long id;

    @OneToOne
    @JoinColumn(name = "Person_IDREF")
    private Person person;

    @OneToOne
    @JoinColumn(name = "Corporation_IDREF")
    private Corporation corporation;

    @OneToOne
    @JoinColumn(name = "ClientStatus_IDREF")
    private ClientStatus status;

    @Column(name = "TypeCode")
    private String typeCode;

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "Client_IDREF", nullable = false)
    private List<BSystemClient> BSystemClientsList;

}
