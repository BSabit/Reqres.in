package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Country {

    private String code;
    private String title;
    private String isoCode;
    private boolean oecdMember;
}
