package kz.eubank.core.dashboard.domain.model.entity;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="map_User_Account")
public class MapUserAccount {
	
	@EmbeddedId
	MapUserAccount_PK pk;

	@Column(name="Pseudonym")
	String pseudonym;
	
	@Column(name="Account_Priority")
    int priority;

    public MapUserAccount_PK getPk() {
        return pk;
    }

    public String getPseudonym() {
        return pseudonym;
    }

    public int getPriority() {
        return priority;
    }
}
