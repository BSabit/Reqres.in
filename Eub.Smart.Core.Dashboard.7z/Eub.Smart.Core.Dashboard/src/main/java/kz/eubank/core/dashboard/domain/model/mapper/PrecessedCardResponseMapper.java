package kz.eubank.core.dashboard.domain.model.mapper;

import kz.eubank.core.dashboard.domain.model.dto.CardDeliveryApplication;
import kz.eubank.core.dashboard.domain.model.dto.PrecessedCardResponse;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface PrecessedCardResponseMapper {

    List<PrecessedCardResponse> toPrecessedCardResponseList(List<CardDeliveryApplication> source);
}
