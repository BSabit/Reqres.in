package kz.eubank.core.dashboard.domain.repository;

import kz.eubank.core.dashboard.domain.model.entity.TempDigitalCard;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TempDigitalCardRepository extends CrudRepository<TempDigitalCard, Long> {

    @Query("select a from TempDigitalCard a where  a.userId=?1")
    List<TempDigitalCard> findAllTempCardsForUser(Long userId);
}
