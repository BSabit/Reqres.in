package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class AccountGraceInfo {

    private BigDecimal unusedCreditLimit;
    private BigDecimal totalLoan;
    private BigDecimal minimalPayment;
    private Long nextBillingDate;
    private Long nextDueDate;
    private BigDecimal own;
    private BigDecimal overdue;
    private BigDecimal overlimit;
    private BigDecimal penalty;
    private BigDecimal creditLimit;
    private BigDecimal graceFailedFee;
    private BigDecimal gracePaymentAmount;
}
