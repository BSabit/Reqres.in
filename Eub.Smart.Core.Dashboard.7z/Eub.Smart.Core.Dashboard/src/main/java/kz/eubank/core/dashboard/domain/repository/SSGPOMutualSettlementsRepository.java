package kz.eubank.core.dashboard.domain.repository;

import kz.eubank.core.dashboard.domain.model.entity.SSGPOMutualSettlements;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface SSGPOMutualSettlementsRepository extends JpaRepository<SSGPOMutualSettlements, String> {

    @Query(nativeQuery = true,
            value = "SELECT sms.*" +
                    "  FROM SSGPOEmployeesInfo sei" +
                    " INNER JOIN SSGPOMutualSettlements sms ON sei.SSGPOEmployeesInfo_ID = sms.SSGPOEmployeesInfo_IDREF" +
                    " INNER JOIN SSGPOCodeDictionary scd ON scd.SSGPOCodeDictionary_ID = sms.SSGPOCodeDictionary_IDREF" +
                    " INNER JOIN SSGPOCodeType sct ON sct.SSGPOCodeType_ID = scd.SSGPOCodeType_IDREF" +
                    " WHERE sct.Type IN ('ACCR', 'RETN')" +
                    "   AND sei.SSGPOEmployeesInfo_ID = :ssgpoEmployeesInfo")
    List<SSGPOMutualSettlements> getSSGPOMutualSettlements(String ssgpoEmployeesInfo);
}
