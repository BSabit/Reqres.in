package kz.eubank.core.dashboard.domain.gate.impl

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kz.eubank.core.dashboard.domain.gate.SalaryGate
import kz.eubank.core.dashboard.domain.model.dto.SettlementSheetEmployeeList
import kz.eubank.core.dashboard.domain.repository.*
import org.springframework.stereotype.Service

@Service
class SalaryGateService(
    private val settlementSheetRepository: SettlementSheetRepository,
    private val settlementSheetEmployeeRepository: SettlementSheetEmployeeRepository,
    private val settlementSheetAccrualRepository: SettlementSheetAccrualRepository,
    private val settlementSheetRetentionRepository: SettlementSheetRetentionRepository,
    private val settlementSheetCompanyRetentionRepository: SettlementSheetCompanyRetentionRepository
) : SalaryGate {

    override suspend fun getSettlementSheetEmployeesResult(
        iin: String,
        size: Int
    ): SettlementSheetEmployeeList {
        val settlementSheetEmployeeList = SettlementSheetEmployeeList()
        val employees = settlementSheetEmployeeRepository.findByIin(iin)
        employees.forEach { employee ->
            val settlementSheetEmployee = employee.toSettlementSheetEmployeeDto()
            val settlementSheets: MutableList<kz.eubank.core.dashboard.domain.model.dto.SettlementSheet> =
                mutableListOf()
            val sheets = settlementSheetRepository.findAllByEmployeeIinAndIdTop(iin, employee.id!!, size)

            sheets.forEach { sheet ->
                val sheetDto = sheet.toSettlementSheetDto()
                CoroutineScope(Dispatchers.IO).launch {
                    launch {
                        val accruals = settlementSheetAccrualRepository.findBySheetId(sheet.id!!)
                        sheetDto.accruals = accruals.map { o -> o.toSettlementSheetOperationDto() }
                    }
                    launch {
                        val retentions = settlementSheetRetentionRepository.findBySheetId(sheet.id!!)
                        sheetDto.retentions = retentions.map { o -> o.toSettlementSheetOperationDto() }
                    }
                    launch {
                        val companyRetentions = settlementSheetCompanyRetentionRepository.findBySheetId(sheet.id!!)
                        sheetDto.companyRetentions = companyRetentions.map { o -> o.toSettlementSheetOperationDto() }
                    }
                }.join()
                sheetDto.exportPeriod = sheet.settlementSheetSaveRequest?.exportPeriod
                settlementSheets.add(sheetDto)
            }
            settlementSheetEmployee.sheets = settlementSheets
            settlementSheetEmployeeList.sheets.add(settlementSheetEmployee)
        }
        return settlementSheetEmployeeList
    }

}