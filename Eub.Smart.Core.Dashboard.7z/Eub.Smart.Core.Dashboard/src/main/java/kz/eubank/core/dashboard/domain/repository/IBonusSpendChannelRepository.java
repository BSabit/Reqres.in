package kz.eubank.core.dashboard.domain.repository;

import kz.eubank.core.dashboard.domain.model.entity.BonusSpendChannel;
import org.springframework.data.repository.CrudRepository;

public interface IBonusSpendChannelRepository extends CrudRepository<BonusSpendChannel, String> {
}
