package kz.eubank.core.dashboard.domain.model.authorization;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDetails {

    private Long userId;
    private String birthDate;
    private String name;
    private String preferredUsername;
    private String middleName;
    private String givenName;
    private String familyName;
    private Long clientId;
    public String iin;
    private Long personId;
}
