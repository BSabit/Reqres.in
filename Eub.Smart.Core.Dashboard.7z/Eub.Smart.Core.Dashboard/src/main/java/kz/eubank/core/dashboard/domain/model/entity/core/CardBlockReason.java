package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "CardBlockReason")
public class CardBlockReason {

    @Id
    @Column(name = "CardBlockReason_ID")
    private String code;

    @Column(name = "CardBlockReason_Title")
    private String title;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;
}
