package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BranchQueue {

    private String id;
    private String title;
    private Integer serving;
    private Integer waiting;
    private Integer avgTimePerClient;
    private boolean cash;
}
