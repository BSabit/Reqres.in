package kz.eubank.core.dashboard.domain.service.impl;

import kz.eubank.core.dashboard.domain.model.dto.CurrencyRate;
import kz.eubank.core.dashboard.domain.model.dto.CurrencyRateList;
import kz.eubank.core.dashboard.domain.service.IAccountService;
import kz.eubank.core.dashboard.domain.service.IExchangeRateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ExchangeRateServiceImpl implements IExchangeRateService {

    @Autowired
    private IAccountService accountService;

    @Override
    public CurrencyRateList getAllRates(Boolean isCardRates) {
        List<CurrencyRate> currencyRates = Arrays.stream(accountService.getCurrencyRates(isCardRates))
                .filter(c -> !"KZT".equals(c.getCurrency().getCode())).collect(Collectors.toList());
        return new CurrencyRateList(currencyRates);
    }
}
