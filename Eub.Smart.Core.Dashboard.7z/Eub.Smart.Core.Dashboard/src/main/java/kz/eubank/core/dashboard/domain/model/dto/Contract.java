package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Getter
@Setter
public class Contract implements HasActionList, Serializable {

    private static final long serialVersionUID = -1297667892185817117L;

    private String title;
    private BigDecimal interestRate;
    private Date expiration;
    private Date dateOpened;
    private BigDecimal amount;
    private String currency;
    private String number;
    private String branchTermId;
    private String branchTitle;
    private int spriteIndex;
    private List<String> actions;

    @Override
    public List<String> getActions() {
        return actions;
    }
}
