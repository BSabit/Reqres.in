package kz.eubank.core.dashboard.domain.model.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CardDeliveryApplication {

    private Long cardId;
    private CardDeliveryMethod cardDeliveryMethod;
    private Long applicationId;
    private Long branchId;
    private String street;
    private String houseNum;
    private String flatNum;
    private String contactNum;
    private String city;
    private Long orderDate;
}
