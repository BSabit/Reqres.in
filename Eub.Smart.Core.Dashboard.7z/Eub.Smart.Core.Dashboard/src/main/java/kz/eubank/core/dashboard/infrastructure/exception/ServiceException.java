package kz.eubank.core.dashboard.infrastructure.exception;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ServiceException extends RuntimeException {

    @Getter
    private final Integer code;

    public ServiceException(String errorMessage, Integer code) {
        super(errorMessage);
        this.code = code;
        log.error(errorMessage, this);
    }

    public ServiceException(String errorMessage, Exception e, Integer code) {
        super(errorMessage);
        this.code = code;
        log.error(errorMessage, e);
    }
}