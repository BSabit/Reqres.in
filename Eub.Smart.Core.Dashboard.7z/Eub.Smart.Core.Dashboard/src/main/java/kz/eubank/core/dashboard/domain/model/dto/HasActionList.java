package kz.eubank.core.dashboard.domain.model.dto;

import java.util.List;

public interface HasActionList {

    List<String> getActions();
}
