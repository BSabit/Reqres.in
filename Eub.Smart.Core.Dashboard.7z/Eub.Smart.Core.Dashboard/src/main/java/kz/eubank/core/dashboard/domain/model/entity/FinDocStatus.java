package kz.eubank.core.dashboard.domain.model.entity;

import kz.eubank.core.dashboard.domain.model.entity.core.Term;

import javax.persistence.*;

@Entity
@Table(name = "FinDocStatus")
public class FinDocStatus {
    @Id
    @Column(name = "FinDocStatus_ID")
    private String code;

    @Column(name = "FinDocStatus_Title")
    private String title;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term term;

    @Column(name = "IsFinal")
    private boolean isFinal;

    public String getCode() {
        return code;
    }

    public String getTitle() {
        return title;
    }

    public Term getTerm() {
        return term;
    }

    public boolean isFinal() {
        return isFinal;
    }
}
