package kz.eubank.core.dashboard.domain.model.dto;

import java.util.Collection;

public class CardList {

    private final Collection<Card> cards;

    public CardList(final Collection<Card> cards) {
        this.cards = cards;
    }

    public Collection<Card> getCards() {
        return this.cards;
    }

    public int getSize() {
        return (this.cards != null) ? this.cards.size() : 0;
    }

    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("CardList [cards=");
        builder.append(this.cards);
        builder.append("]");
        return builder.toString();
    }
}
