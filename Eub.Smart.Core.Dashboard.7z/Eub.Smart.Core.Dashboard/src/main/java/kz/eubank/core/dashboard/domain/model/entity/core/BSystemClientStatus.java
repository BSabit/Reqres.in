package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

/**
 * Created with IntelliJ IDEA.
 * User: alexander
 * Date: 10/11/13
 * Time: 11:36 AM
 */

@Getter
@Setter
@Entity
@Table(name = "BSystemClientStatus")
public class BSystemClientStatus {

    @Id
    @Column(name = "BSystemClientStatus_ID")
    private String code;

    @Column(name = "BSystemClientStatus_Title")
    private String title;

    @Column(name = "IsValid")
    private boolean valid;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;

}
