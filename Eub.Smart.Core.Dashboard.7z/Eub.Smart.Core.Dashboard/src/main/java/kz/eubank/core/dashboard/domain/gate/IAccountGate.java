package kz.eubank.core.dashboard.domain.gate;

import kz.eubank.core.dashboard.domain.model.dto.AccountLongInfo;
import kz.eubank.core.dashboard.domain.model.dto.CardProductOperation;

public interface IAccountGate {

    AccountLongInfo getAccountDetails(final Long p0, final Long p1, final String p2, final String p3);

    CardProductOperation getCardProductOperation(final Long p0);

    AccountLongInfo getAccountDetails(final String accountNr, AccountLongInfo accountLongInfo);
}
