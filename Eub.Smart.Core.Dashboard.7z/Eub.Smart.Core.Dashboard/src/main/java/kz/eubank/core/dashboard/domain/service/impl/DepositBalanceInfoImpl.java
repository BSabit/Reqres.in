package kz.eubank.core.dashboard.domain.service.impl;

import kz.eubank.core.dashboard.domain.model.converter.ProtoConverter;
import kz.eubank.core.dashboard.domain.model.dto.AccountBalanceInfo;
import kz.eubank.core.dashboard.domain.model.dto.DepositBalanceInfo;
import kz.eubank.core.dashboard.domain.model.dto.AccountGraceInfo;
import kz.eubank.core.dashboard.domain.model.grpc.EubAggregatorCoreDashboard;
import kz.eubank.core.dashboard.domain.service.IAccountBalanceInfo;
import kz.eubank.core.dashboard.domain.service.IAllAccService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class DepositBalanceInfoImpl implements IAccountBalanceInfo {

    @Autowired
    private ProtoConverter protoConverter;

    @Override
    public String getType() {
        return IAllAccService.DEPOSIT_ACCOUNT;
    }

    @Override
    public List<? extends AccountBalanceInfo> getAccountBalances(List<EubAggregatorCoreDashboard.Account> esbAccounts) {
        List<DepositBalanceInfo> accountBalances = new ArrayList<>();
        for (EubAggregatorCoreDashboard.Account account : esbAccounts) {
            DepositBalanceInfo depositBalanceInfo = new DepositBalanceInfo();

            depositBalanceInfo.setAccountNumber(account.getNumber());
            depositBalanceInfo.setBalance(protoConverter.convertMoneyToBigDecimal(account.getBalance()));
            depositBalanceInfo.setCurrency(protoConverter.moneyToCurrency(account.getBalance()));
            depositBalanceInfo.setBlockedSum(protoConverter.convertMoneyToBigDecimal(account.getBlockedSum()));
            depositBalanceInfo.setAvailableBalance(protoConverter.convertMoneyToBigDecimal(account.getAvailableBalance()));
            depositBalanceInfo.setActualBalance(protoConverter.convertMoneyToBigDecimal(account.getAvailableBalance())
                    .subtract(protoConverter.convertMoneyToBigDecimal(account.getMinBalance())));
            depositBalanceInfo.setGrace(account.getIsGrace());

            AccountGraceInfo accountGraceInfo = new AccountGraceInfo();
            accountGraceInfo.setUnusedCreditLimit(protoConverter.convertMoneyToBigDecimal(account.getUnusedCreditLimit()));
            accountGraceInfo.setTotalLoan(protoConverter.convertMoneyToBigDecimal(account.getTotalLoan()));
            accountGraceInfo.setMinimalPayment(protoConverter.convertMoneyToBigDecimal(account.getMinimalPayment()));

            Date nextBillingDate = protoConverter.timestampToDate(account.getNextBillingDate());
            accountGraceInfo.setNextBillingDate(nextBillingDate == null ? null : nextBillingDate.getTime());

            Date nextDueDate = protoConverter.timestampToDate(account.getNextDueDate());
            accountGraceInfo.setNextDueDate(nextDueDate == null ? null : nextDueDate.getTime());

            accountGraceInfo.setOwn(protoConverter.convertMoneyToBigDecimal(account.getOwn()));
            accountGraceInfo.setOverdue(protoConverter.convertMoneyToBigDecimal(account.getOverdue()));
            accountGraceInfo.setOverlimit(protoConverter.convertMoneyToBigDecimal(account.getOverlimit()));
            accountGraceInfo.setPenalty(protoConverter.convertMoneyToBigDecimal(account.getPenalty()));
            accountGraceInfo.setCreditLimit(protoConverter.convertMoneyToBigDecimal(account.getCreditLimit()));
            accountGraceInfo.setGraceFailedFee(protoConverter.convertMoneyToBigDecimal(account.getGraceFailedFee()));
            accountGraceInfo.setGracePaymentAmount(protoConverter.convertMoneyToBigDecimal(account.getGracePaymentAmount()));
            depositBalanceInfo.setAccountGraceInfo(accountGraceInfo);

            depositBalanceInfo.setSubAccountBalances(protoConverter.moneyListToSubAccountBalanceList(account.getSubAccountBalances()
                    .getSubAccountBalanceList()));
            depositBalanceInfo.setSubAccountAvailableBalances(protoConverter.moneyListToSubAccountBalanceList(
                    account.getSubAccountAvailableBalances().getSubAccountAvailableBalanceList()));

            depositBalanceInfo.setDateOpened(protoConverter.timestampToDate(account.getDateOpened()));
            depositBalanceInfo.setInterestRate(protoConverter.convertDecimalValueToBigDecimal(account.getRate()));
            depositBalanceInfo.setDateClosed(protoConverter.timestampToDate(account.getDateClosed()));
            depositBalanceInfo.setAccruedAmountForMonth(BigDecimal.ZERO);//todo change then
            depositBalanceInfo.setAccruedAmountTotal(protoConverter.convertMoneyToBigDecimal(account.getAccruedPositiveInterest()));

            BigDecimal minBalance = protoConverter.convertMoneyToBigDecimal(account.getMinBalance());
            if (minBalance != null) {
                depositBalanceInfo.setMinBalance(minBalance.intValue());
            }

            accountBalances.add(depositBalanceInfo);
        }
        return accountBalances;
    }
}
