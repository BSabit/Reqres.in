package kz.eubank.core.dashboard.domain.gate.impl;

import kz.eubank.core.dashboard.domain.gate.CardDeliveryApplicationGate;
import kz.eubank.core.dashboard.domain.model.dto.CardDeliveryApplication;
import kz.eubank.core.dashboard.domain.model.mapper.CardDeliveryApplicationMapper;
import kz.eubank.core.dashboard.domain.repository.CardDeliveryApplicationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class CardDeliveryApplicationGateService implements CardDeliveryApplicationGate {

    @Autowired
    private CardDeliveryApplicationRepository cardDeliveryApplicationRepository;
    @Autowired
    private CardDeliveryApplicationMapper cardDeliveryApplicationMapper;

    @Override
    @Transactional
    public List<CardDeliveryApplication> getProcessedCard(Long userId) {
        List<CardDeliveryApplication> ret = new ArrayList<>();
        List<kz.eubank.core.dashboard.domain.model.entity.CardDeliveryApplication> processed =
                cardDeliveryApplicationRepository.getProcessedCard(userId, "PROC");
        for (kz.eubank.core.dashboard.domain.model.entity.CardDeliveryApplication entity : processed) {
            CardDeliveryApplication application = cardDeliveryApplicationMapper.toCardDeliveryApplicationDto(entity);
            application.setApplicationId(entity.getApplication().getId());
            application.setBranchId(entity.getBranch().getId());
            application.setCardId(entity.getCard().getId());
            application.setCardDeliveryMethod(cardDeliveryApplicationMapper.toCardDeliveryMethodDto(entity.getCardDeliveryMethod()));
            if ("DLBR".equals(application.getCardDeliveryMethod().getCode())) {
                application.setStreet(entity.getBranch().getAddress().getPlace());
                application.setHouseNum((entity.getBranch().getAddress().getHouseNo() != null)
                        ? entity.getBranch().getAddress().getHouseNo() : "");
                application.setFlatNum((entity.getBranch().getAddress().getApartmentNo() != null)
                        ? entity.getBranch().getAddress().getApartmentNo() : "");
            } else {
                application.setStreet(entity.getStreet());
                application.setHouseNum((entity.getHouseNum() != null) ? entity.getHouseNum() : "");
                application.setFlatNum((entity.getFlatNum() != null) ? entity.getFlatNum() : "");
            }
            application.setOrderDate(entity.getApplication().getCreated().getTime());
            application.setContactNum((entity.getContactNum() != null) ? entity.getContactNum() : "");
            application.setCity((entity.getCity() != null) ? entity.getCity().getTitle() : "");
            ret.add(application);
        }
        return ret;
    }
}
