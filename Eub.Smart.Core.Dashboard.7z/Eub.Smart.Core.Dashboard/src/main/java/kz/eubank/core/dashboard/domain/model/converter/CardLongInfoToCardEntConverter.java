package kz.eubank.core.dashboard.domain.model.converter;

import kz.eubank.core.dashboard.domain.model.dto.CardLongInfo;
import kz.eubank.core.dashboard.domain.model.dto.CardStatus;
import kz.eubank.core.dashboard.domain.model.entity.core.Card;
import org.dozer.CustomConverter;
import org.springframework.beans.BeanUtils;

public class CardLongInfoToCardEntConverter implements CustomConverter {

    @Override
    public Object convert(Object dest, Object source, Class<?> arg2, Class<?> arg3) {
        if (source == null) {
            return null;
        }
        if (source instanceof CardLongInfo && arg2.equals(Card.class)) {//todo
            CardLongInfo cardLongInfo = (CardLongInfo) source;
            Card card = new Card();
            BeanUtils.copyProperties(cardLongInfo, card);
            return card;
        } else if (source instanceof Card && arg2.equals(CardLongInfo.class)) {
            Card card = (Card) source;
            CardLongInfo cardLongInfo = new CardLongInfo();
            cardLongInfo.setAllowCNP(card.isAllowCNP());
            cardLongInfo.setHash(card.getHash());
            cardLongInfo.setIsPINSet(card.getIsPINSet());
            cardLongInfo.setIsIVR(card.getIsIVR());
            cardLongInfo.setId(card.getId());
            cardLongInfo.setNumber(card.getMaskedNumber());
            cardLongInfo.setNameEmbossed(card.getNameEmbossed());
            cardLongInfo.setType(card.getType().getCode());
            cardLongInfo.setTypeTitle(card.getType().getTitle());
            cardLongInfo.setStatus(new CardStatus(card.getStatus().getCode(), card.getStatus().getTitle()));
            cardLongInfo.setExpiration(card.getExpiration());
            cardLongInfo.setIsDigital(card.getIsDigital());
//            cardLongInfo.setCardLimits();//todo
//            cardLongInfo.setCardTransactionStatus();
//            cardLongInfo.setIsDigital();
//            cardLongInfo.setPriority();
//            cardLongInfo.setAccount();
//            cardLongInfo.setActions();
            return cardLongInfo;
        }
        return null;
    }
}