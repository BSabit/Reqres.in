package kz.eubank.core.dashboard.domain.repository;

import kz.eubank.core.dashboard.domain.model.entity.core.Card;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ICardRepository extends CrudRepository<Card, Long> {

    @Query("select c from Card c where c.account.id=?1 and c.status.valid=?2 and c.status.closed=?3 ")
    List<Card> findAll(final Long p0, final boolean p1, final boolean p2);
}
