package kz.eubank.core.dashboard.domain.model.entity.core;


import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "BSystemClient")
public class BSystemClient {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "BSystemClient_ID")
    private Long id;

    @OneToOne()
    @JoinColumn(name = "BSystem_IDREF")
    private BSystem bsystem;

    @OneToOne()
    @JoinColumn(name = "Branch_IDREF")
    private Branch branch;

    @OneToOne()
    @JoinColumn(name = "BSystemClientStatus_IDREF")
    private BSystemClientStatus status;

    @Column(name = "BSystemClient_Title")
    private String title;

    @Column(name = "BSystemClient_OUTREF")
    private String outRef;

    @Column(insertable = false, updatable = false, name = "Client_IDREF")
    private Long clientId;
}
