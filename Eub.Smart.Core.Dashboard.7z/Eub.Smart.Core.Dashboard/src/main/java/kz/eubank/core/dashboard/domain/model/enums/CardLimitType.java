package kz.eubank.core.dashboard.domain.model.enums;

public enum CardLimitType {
    ATM, BANK, OUTLET, OPERATIONS_WITHOUT_CARD, MAX_TOTAL 
}
