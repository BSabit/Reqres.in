package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.springframework.cache.annotation.Cacheable;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@Entity
@Table(name = "ClientPermission")
public class ClientPermission {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ClientPermission_ID")
    private Long id;

    @Column(name = "User_IDREF")
    private Long userId;

    @JoinColumn(name = "Client_IDREF")
    @OneToOne
    private Client client;

    @Column(name = "DateValid")
    private Date dateValid;

    @Column(name = "SignatureLevel")
    private int signatureLevel;

    @Column(name = "FinDocFilter")
    private String finDocFilter;

    @Column(name = "OverrideFilter")
    private boolean overrideFilter;

    @Column(name = "IsDefault")
    private boolean defaultClient;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "Usage_IDREF")
    private Usage usage;
}
