package kz.eubank.core.dashboard.domain.model.dto

data class SettlementSheetOperation(
    var amount: Int? = null,
    var count: Int? = null,
    var price: Int? = null,
    var rowNameEn: SettlementOperationName? = null,
    var rowNameKz: SettlementOperationName? = null,
    var rowNameRu: SettlementOperationName? = null,
    var type: String? = null
)