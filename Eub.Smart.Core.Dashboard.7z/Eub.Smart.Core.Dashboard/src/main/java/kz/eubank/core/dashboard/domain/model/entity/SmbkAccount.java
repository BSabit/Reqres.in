package kz.eubank.core.dashboard.domain.model.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Getter
@Setter
@Entity
public class SmbkAccount {

    @Id
    @Column(name = "SmbkAccountId")
    private Long smbkAccountId;

    @Column(name = "Iin")
    private String iin;

    @Column(name = "DateOfBirth")
    private String dateOfBirth;

    @Column(name = "ProgramCode")
    private String programCode;

    @Column(name = "Unit")
    private String unit;

    @Column(name = "SmbkAccountNumber")
    private String smbkAccountNumber;

    @Column(name = "SmbkClientId")
    private Long smbkClientId;

    public String getUniqueValues() {
        return getIin() + getProgramCode() + getUnit();
    }
}
