package kz.eubank.core.dashboard.domain.model.enums;

public enum CardTransactionStatus {
    CVV_2,
    BLOC,
    WCV_2,
    UNKN,
    ERRR,
    ALLT,
    FULL,
    PART,

    MC_AUMC,
    VISA_AUVS,
    VISA_CLASSIC,
    VISA_ELECTRON,
    VISA_GMTL,
    VISA_GOLD,
    VISA_INFINITY,
    MC_BLACK,
    MC_GOLD,
    MC_GOLD_PAY_PASS,
    MC_MGSC,
    MC_STANDARD_PAY_PASS,
    MC_STANDARD,
    VISA_PLATINUM,
    VISA_PMTL,
    VISA_BUSINESS,
}
