package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Getter
@Setter
public class AccountLongInfo extends AccountShortInfo {

    private Date dateOpened;
    private Date dateClosed;
    private String branchTermId;
    private String branchTitle;
    private BigDecimal limitFinDoc;
    private BigDecimal limitDay;
    private BigDecimal limitWeek;
    private BigDecimal limitMonth;
    private String limitCurrency;
    private BigDecimal overdraft;
    private Integer minBalance;
    private BigDecimal accruedAmountTotal;
    private BigDecimal accruedAmountForMonth;
    private BigDecimal availBalance;
    private BigDecimal finBlocking;
    private int termLength;
    private BigDecimal openBalance;
    private String name;
    private List<String> actions;
    private BigDecimal currentInterest;
    private BigDecimal lastMonthInterest;
    private BigDecimal allPeriodInterest;
    private List<SubAccountBalance> subAccountBalances;
    private List<SubAccountBalance> subAccountAvailableBalances;
    private BigDecimal creditLimitForInstallment;
    private BigDecimal creditLimitForInstallmentAvailable;
    private BigDecimal maxCreditLimitPayment;
    private BigDecimal minCreditLimitPayment;
    private Date minCreditLimitPaymentDate;
    private BigDecimal periodOfCashBack;
    private BigDecimal cashbackForPeriod;
    private BigDecimal totalCashback;
    private BigDecimal fullDebtAmount;
    private Boolean installmentAccount;
    private Boolean activeInstallments;
    private AccountGraceInfo accountGraceInfo;
    private Long parentAccountId;
    private boolean isGrace;
}
