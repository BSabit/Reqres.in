package kz.eubank.core.dashboard.domain.service;

import kz.eubank.core.dashboard.domain.model.response.CarPledgeInfo;

public interface ICarPledgeService {

    CarPledgeInfo getCarPledgeInfo();
}
