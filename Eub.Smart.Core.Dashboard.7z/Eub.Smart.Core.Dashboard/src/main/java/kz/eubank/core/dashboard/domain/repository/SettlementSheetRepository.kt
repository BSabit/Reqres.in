package kz.eubank.core.dashboard.domain.repository

import kz.eubank.core.dashboard.domain.model.entity.SettlementSheet
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query
import org.springframework.stereotype.Repository

@Repository
interface SettlementSheetRepository : JpaRepository<SettlementSheet, Long> {

    @Query(
        nativeQuery = true,
        value = """select ss.*
              from SettlementSheetEmployee sse
              join SettlementSheet ss on sse.SettlementSheetEmployee_ID = ss.SettlementSheetEmployee_IDREF
              join SettlementSheetSaveRequest sssr on ss.SettlementSheetSaveRequest_IDREF = sssr.SettlementSheetSaveRequest_ID
                    and sssr.ExportPeriod in 
                       (select top (:size) sssr2.ExportPeriod
                          from SettlementSheetEmployee sse2
                          join SettlementSheet ss2 on sse2.SettlementSheetEmployee_ID = ss2.SettlementSheetEmployee_IDREF
                          join SettlementSheetSaveRequest sssr2 on ss2.SettlementSheetSaveRequest_IDREF = sssr2.SettlementSheetSaveRequest_ID
                         where sse2.iin = sse.Iin
                           and sse2.SettlementSheetEmployee_ID = sse.SettlementSheetEmployee_ID
                      group by sssr2.ExportPeriod
                      order by substring(sssr2.ExportPeriod, 4, 2) desc, substring(sssr2.ExportPeriod, 1, 2) desc)
              where sse.iin = :iin
                and sse.SettlementSheetEmployee_ID = :employeeId
              order by substring(sssr.ExportPeriod, 4, 2) desc, substring(sssr.ExportPeriod, 1, 2) desc"""
    )
    fun findAllByEmployeeIinAndIdTop(iin: String, employeeId: Long, size: Int): List<SettlementSheet>
}