package kz.eubank.core.dashboard.application.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import kz.eubank.core.dashboard.domain.model.dto.CurrencyRateList;
import kz.eubank.core.dashboard.domain.model.response.APIResponse;
import kz.eubank.core.dashboard.domain.service.IExchangeRateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("exchange-rate")
@SecurityRequirement(name = "Bearer Authentication")
@Tag(name = "Курс валют", description = "ExchangeRateController")
public class ExchangeRateController {

    @Autowired
    private IExchangeRateService referenceService;

    @Operation(summary = "getAllRates", description = "Курс валют")
    @Parameters({
            @Parameter(name = "cashed", description = "cashed")
    })
    @GetMapping("getAllRates")
    public APIResponse<CurrencyRateList> getAllRates(@RequestParam(value = "cashed", required = false) String cashed,
                                                     @RequestHeader(value = "language", defaultValue = "ru") String language) {
        Boolean isCardRates = Boolean.FALSE;
        if (cashed != null) {
            cashed = cashed.toLowerCase();
            if (cashed.equals("true") || cashed.equals("yes")) {
                isCardRates = true;
            }
        }
        final CurrencyRateList list = referenceService.getAllRates(isCardRates);
        list.getRates().removeIf(currencyRate -> "BNS".equals(currencyRate.getCurrency().getCode()));
        return (APIResponse<CurrencyRateList>) new APIResponse(list);
    }
}
