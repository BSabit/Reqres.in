package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class CurrencyRate {

    private Currency currency;
    private BigDecimal buyRate;
    private BigDecimal sellRate;
    private BigDecimal centralBankRate;
}
