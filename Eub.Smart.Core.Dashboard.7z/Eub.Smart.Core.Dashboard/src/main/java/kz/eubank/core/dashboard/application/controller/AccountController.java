package kz.eubank.core.dashboard.application.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import kz.eubank.core.dashboard.domain.model.response.APIResponse;
import kz.eubank.core.dashboard.domain.model.response.AccountList;
import kz.eubank.core.dashboard.domain.service.IAllAccService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("account")
@SecurityRequirement(name = "Bearer Authentication")
@Tag(name = "Счета", description = "AccountController")
public class AccountController {

    @Autowired
    private IAllAccService allAccService;

    @Operation(summary = "getCardAccounts",
            description = "Карточные счета")
    @Parameters({
            @Parameter(name = "currency", description = "currency"),
            @Parameter(name = "dateFrom", description = "dateFrom"),
            @Parameter(name = "dateTill", description = "dateTill")
    })
    @GetMapping("getCardAccounts")
    public APIResponse<AccountList> getCards(@RequestParam(value = "currency", required = false) String currency,
                                             @RequestParam(value = "dateFrom", required = false) String dateFrom,
                                             @RequestParam(value = "dateTill", required = false) String dateTill,
                                             @RequestHeader(value = "language", defaultValue = "ru") String language) {
        return (APIResponse<AccountList>) new APIResponse(allAccService.getCardAccounts(currency, dateFrom, dateTill));
    }

    @Operation(summary = "getCurrentAccounts",
            description = "Текущие счета")
    @Parameters({
            @Parameter(name = "currency", description = "currency")
    })
    @GetMapping("getCurrentAccounts")
    public APIResponse<AccountList> getCurAccs(@RequestParam(value = "currency", required = false) String currency,
                                               @RequestHeader(value = "language", defaultValue = "ru") String language) {
        return (APIResponse<AccountList>) new APIResponse(allAccService.getCurrentAccounts(currency));
    }

    @Operation(summary = "getDeposits",
            description = "Депозиты")
    @Parameters({
            @Parameter(name = "currency", description = "currency"),
            @Parameter(name = "dateFrom", description = "dateFrom"),
            @Parameter(name = "dateTill", description = "dateTill")
    })
    @GetMapping("getDeposits")
    public APIResponse<AccountList> getDeposits(@RequestParam(value = "currency", required = false) String currency,
                                                @RequestParam(value = "dateFrom", required = false) String dateFrom,
                                                @RequestParam(value = "dateTill", required = false) String dateTill,
                                                @RequestHeader(value = "language", defaultValue = "ru") String language) {
        return (APIResponse<AccountList>) new APIResponse(allAccService.getDeposits(currency, dateFrom, dateTill));
    }
}