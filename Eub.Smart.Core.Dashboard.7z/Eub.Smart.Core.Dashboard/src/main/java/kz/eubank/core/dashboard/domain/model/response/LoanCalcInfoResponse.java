package kz.eubank.core.dashboard.domain.model.response;

import lombok.Generated;

import java.io.Serializable;

public class LoanCalcInfoResponse implements Serializable {
    private Long id;
    private Long created;
    private Integer fullAmount;
    private Integer period;
    private Integer paymentAmountSum;
    private Integer paymentDay;
    private Long fileStorageId;
    private String tariffCode;
    private String insurancePackageCode;
    private String insurancePackageType;
    private Integer amount;

    @Generated
    public LoanCalcInfoResponse() {
    }

    @Generated
    public Long getId() {
        return this.id;
    }

    @Generated
    public Long getCreated() {
        return this.created;
    }

    @Generated
    public Integer getFullAmount() {
        return this.fullAmount;
    }

    @Generated
    public Integer getPeriod() {
        return this.period;
    }

    @Generated
    public Integer getPaymentAmountSum() {
        return this.paymentAmountSum;
    }

    @Generated
    public Integer getPaymentDay() {
        return this.paymentDay;
    }

    @Generated
    public Long getFileStorageId() {
        return this.fileStorageId;
    }

    @Generated
    public String getTariffCode() {
        return this.tariffCode;
    }

    @Generated
    public String getInsurancePackageCode() {
        return this.insurancePackageCode;
    }

    @Generated
    public String getInsurancePackageType() {
        return this.insurancePackageType;
    }

    @Generated
    public Integer getAmount() {
        return this.amount;
    }

    @Generated
    public void setId(final Long id) {
        this.id = id;
    }

    @Generated
    public void setCreated(final Long created) {
        this.created = created;
    }

    @Generated
    public void setFullAmount(final Integer fullAmount) {
        this.fullAmount = fullAmount;
    }

    @Generated
    public void setPeriod(final Integer period) {
        this.period = period;
    }

    @Generated
    public void setPaymentAmountSum(final Integer paymentAmountSum) {
        this.paymentAmountSum = paymentAmountSum;
    }

    @Generated
    public void setPaymentDay(final Integer paymentDay) {
        this.paymentDay = paymentDay;
    }

    @Generated
    public void setFileStorageId(final Long fileStorageId) {
        this.fileStorageId = fileStorageId;
    }

    @Generated
    public void setTariffCode(final String tariffCode) {
        this.tariffCode = tariffCode;
    }

    @Generated
    public void setInsurancePackageCode(final String insurancePackageCode) {
        this.insurancePackageCode = insurancePackageCode;
    }

    @Generated
    public void setInsurancePackageType(final String insurancePackageType) {
        this.insurancePackageType = insurancePackageType;
    }

    @Generated
    public void setAmount(final Integer amount) {
        this.amount = amount;
    }

    @Generated
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof LoanCalcInfoResponse)) {
            return false;
        }
        final LoanCalcInfoResponse other = (LoanCalcInfoResponse) o;
        if (!other.canEqual(this)) {
            return false;
        }
        final Object this$id = this.getId();
        final Object other$id = other.getId();
        Label_0065:
        {
            if (this$id == null) {
                if (other$id == null) {
                    break Label_0065;
                }
            } else if (this$id.equals(other$id)) {
                break Label_0065;
            }
            return false;
        }
        final Object this$created = this.getCreated();
        final Object other$created = other.getCreated();
        Label_0102:
        {
            if (this$created == null) {
                if (other$created == null) {
                    break Label_0102;
                }
            } else if (this$created.equals(other$created)) {
                break Label_0102;
            }
            return false;
        }
        final Object this$fullAmount = this.getFullAmount();
        final Object other$fullAmount = other.getFullAmount();
        Label_0139:
        {
            if (this$fullAmount == null) {
                if (other$fullAmount == null) {
                    break Label_0139;
                }
            } else if (this$fullAmount.equals(other$fullAmount)) {
                break Label_0139;
            }
            return false;
        }
        final Object this$period = this.getPeriod();
        final Object other$period = other.getPeriod();
        Label_0176:
        {
            if (this$period == null) {
                if (other$period == null) {
                    break Label_0176;
                }
            } else if (this$period.equals(other$period)) {
                break Label_0176;
            }
            return false;
        }
        final Object this$paymentAmountSum = this.getPaymentAmountSum();
        final Object other$paymentAmountSum = other.getPaymentAmountSum();
        Label_0213:
        {
            if (this$paymentAmountSum == null) {
                if (other$paymentAmountSum == null) {
                    break Label_0213;
                }
            } else if (this$paymentAmountSum.equals(other$paymentAmountSum)) {
                break Label_0213;
            }
            return false;
        }
        final Object this$paymentDay = this.getPaymentDay();
        final Object other$paymentDay = other.getPaymentDay();
        Label_0250:
        {
            if (this$paymentDay == null) {
                if (other$paymentDay == null) {
                    break Label_0250;
                }
            } else if (this$paymentDay.equals(other$paymentDay)) {
                break Label_0250;
            }
            return false;
        }
        final Object this$fileStorageId = this.getFileStorageId();
        final Object other$fileStorageId = other.getFileStorageId();
        Label_0287:
        {
            if (this$fileStorageId == null) {
                if (other$fileStorageId == null) {
                    break Label_0287;
                }
            } else if (this$fileStorageId.equals(other$fileStorageId)) {
                break Label_0287;
            }
            return false;
        }
        final Object this$tariffCode = this.getTariffCode();
        final Object other$tariffCode = other.getTariffCode();
        Label_0324:
        {
            if (this$tariffCode == null) {
                if (other$tariffCode == null) {
                    break Label_0324;
                }
            } else if (this$tariffCode.equals(other$tariffCode)) {
                break Label_0324;
            }
            return false;
        }
        final Object this$insurancePackageCode = this.getInsurancePackageCode();
        final Object other$insurancePackageCode = other.getInsurancePackageCode();
        Label_0361:
        {
            if (this$insurancePackageCode == null) {
                if (other$insurancePackageCode == null) {
                    break Label_0361;
                }
            } else if (this$insurancePackageCode.equals(other$insurancePackageCode)) {
                break Label_0361;
            }
            return false;
        }
        final Object this$insurancePackageType = this.getInsurancePackageType();
        final Object other$insurancePackageType = other.getInsurancePackageType();
        Label_0398:
        {
            if (this$insurancePackageType == null) {
                if (other$insurancePackageType == null) {
                    break Label_0398;
                }
            } else if (this$insurancePackageType.equals(other$insurancePackageType)) {
                break Label_0398;
            }
            return false;
        }
        final Object this$amount = this.getAmount();
        final Object other$amount = other.getAmount();
        if (this$amount == null) {
            return other$amount == null;
        } else return this$amount.equals(other$amount);
    }

    @Generated
    protected boolean canEqual(final Object other) {
        return other instanceof LoanCalcInfoResponse;
    }

    @Generated
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $id = this.getId();
        result = result * 59 + (($id == null) ? 43 : $id.hashCode());
        final Object $created = this.getCreated();
        result = result * 59 + (($created == null) ? 43 : $created.hashCode());
        final Object $fullAmount = this.getFullAmount();
        result = result * 59 + (($fullAmount == null) ? 43 : $fullAmount.hashCode());
        final Object $period = this.getPeriod();
        result = result * 59 + (($period == null) ? 43 : $period.hashCode());
        final Object $paymentAmountSum = this.getPaymentAmountSum();
        result = result * 59 + (($paymentAmountSum == null) ? 43 : $paymentAmountSum.hashCode());
        final Object $paymentDay = this.getPaymentDay();
        result = result * 59 + (($paymentDay == null) ? 43 : $paymentDay.hashCode());
        final Object $fileStorageId = this.getFileStorageId();
        result = result * 59 + (($fileStorageId == null) ? 43 : $fileStorageId.hashCode());
        final Object $tariffCode = this.getTariffCode();
        result = result * 59 + (($tariffCode == null) ? 43 : $tariffCode.hashCode());
        final Object $insurancePackageCode = this.getInsurancePackageCode();
        result = result * 59 + (($insurancePackageCode == null) ? 43 : $insurancePackageCode.hashCode());
        final Object $insurancePackageType = this.getInsurancePackageType();
        result = result * 59 + (($insurancePackageType == null) ? 43 : $insurancePackageType.hashCode());
        final Object $amount = this.getAmount();
        result = result * 59 + (($amount == null) ? 43 : $amount.hashCode());
        return result;
    }

    @Generated
    @Override
    public String toString() {
        return "LoanCalcInfo(id=" + this.getId() + ", created=" + this.getCreated() + ", fullAmount=" + this.getFullAmount() + ", period=" + this.getPeriod() + ", paymentAmountSum=" + this.getPaymentAmountSum() + ", paymentDay=" + this.getPaymentDay() + ", fileStorageId=" + this.getFileStorageId() + ", tariffCode=" + this.getTariffCode() + ", insurancePackageCode=" + this.getInsurancePackageCode() + ", insurancePackageType=" + this.getInsurancePackageType() + ", amount=" + this.getAmount() + ")";
    }
}
