package kz.eubank.core.dashboard.domain.gate.impl;

import kz.eubank.core.dashboard.domain.model.entity.core.Term;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

@Service
public class TermGateService {

    private static final String RU = "ru";
    private static final String KZ = "kz";
    private static final String DE = "de";
    private static final String FR = "fr";
    private static final String TR = "tr";

    public String getTitle(Term term, String defaultTitle, String lang) {
        if (term == null) {
            return defaultTitle;
        }

        String title;
        if (StringUtils.equalsIgnoreCase(lang, RU)) {
            title = term.getTermRU();
        } else if (StringUtils.equalsIgnoreCase(lang, KZ)) {
            title = term.getTermKZ();
        } else if (StringUtils.equalsIgnoreCase(lang, DE)) {
            title = term.getTermDE();
        } else if (StringUtils.equalsIgnoreCase(lang, FR)) {
            title = term.getTermFR();
        } else if (StringUtils.equalsIgnoreCase(lang, TR)) {
            title = term.getTermTR();
        } else {
            title = term.getTermEN();
        }

        return !StringUtils.isEmpty(title) ? title : defaultTitle;
    }

    public String getDescription(Term term, String defaultDescription, String lang) {
        if (term == null) {
            return defaultDescription;
        }

        String title;
        if (StringUtils.equalsIgnoreCase(lang, RU)) {
            title = term.getDescRU();
        } else if (StringUtils.equalsIgnoreCase(lang, KZ)) {
            title = term.getDescKZ();
        } else if (StringUtils.equalsIgnoreCase(lang, DE)) {
            title = term.getDescDE();
        } else if (StringUtils.equalsIgnoreCase(lang, FR)) {
            title = term.getDescFR();
        } else if (StringUtils.equalsIgnoreCase(lang, TR)) {
            title = term.getDescTR();
        } else {
            title = term.getDescEN();
        }

        return !StringUtils.isEmpty(title) ? title : defaultDescription;
    }
}
