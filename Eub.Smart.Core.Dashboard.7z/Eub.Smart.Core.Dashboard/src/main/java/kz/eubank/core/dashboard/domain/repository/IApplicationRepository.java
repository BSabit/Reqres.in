package kz.eubank.core.dashboard.domain.repository;

import kz.eubank.core.dashboard.domain.model.entity.core.Application;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface IApplicationRepository extends CrudRepository<Application, Long> {

    @Query("select d.agreement from Application a, DepositApplication d" +
            " where d.application=a and a.clientId=?3 and a.userId=?2 and d.IBAN=?1")
    byte[] findAgreement(final String p0, final Long p1, final Long p2);
}
