package kz.eubank.core.dashboard.domain.model.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TempDigitalCard {

    private Long id;
    private String iban;
    private String maskedNumber;
    private Long userId;
    private Long created;
    private Long applicationId;
}
