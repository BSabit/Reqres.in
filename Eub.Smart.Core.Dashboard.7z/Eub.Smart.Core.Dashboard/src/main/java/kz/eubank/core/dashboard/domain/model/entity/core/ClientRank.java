package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "ClientRank")
public class ClientRank {

    @Id
    @Column(name = "ClientRank_ID")
    private String code;

    @Column(name = "ClientRank_Title")
    private String title;

    @Column(name = "Rank")
    private Integer rank;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;
}
