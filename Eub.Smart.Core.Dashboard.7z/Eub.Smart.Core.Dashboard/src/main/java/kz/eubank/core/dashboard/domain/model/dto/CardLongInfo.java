package kz.eubank.core.dashboard.domain.model.dto;

import kz.eubank.core.dashboard.domain.model.enums.CardTransactionStatus;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Collection;

@Getter
@Setter
@NoArgsConstructor
public class CardLongInfo extends CardShortInfo {

    private Collection<CardLimitXml> cardLimitXmls;
    private boolean allowCNP;
    private CardTransactionStatus cardTransactionStatus;
    private String hash;
    private Boolean isPINSet;
    private Boolean isIVR;
    private Boolean isDigital;
}
