package kz.eubank.core.dashboard.domain.model.entity;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "PaymentDoc")
public class PaymentDoc {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PaymentDoc_ID")
    private Long id;

    @OneToOne
    @JoinColumn(name = "FinDoc_IDREF")
    private FinDoc finDoc;

    @OneToOne
    @JoinColumn(name = "Service_IDREF")
    private Service service;

    @OneToMany(fetch= FetchType.EAGER, cascade = {CascadeType.ALL}, orphanRemoval=true)
    @JoinColumn(name = "PaymentDoc_IDREF", nullable=false)
    private List<PaymentDetails> paymentDetails;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public FinDoc getFinDoc() {
        return finDoc;
    }

    public void setFinDoc(FinDoc finDoc) {
        this.finDoc = finDoc;
    }

    public Service getService() {
        return service;
    }

    public void setService(Service service) {
        this.service = service;
    }

    public List<PaymentDetails> getPaymentDetails() {
        return paymentDetails;
    }

    public void setPaymentDetails(List<PaymentDetails> paymentDetails) {
        this.paymentDetails = paymentDetails;
    }

}
