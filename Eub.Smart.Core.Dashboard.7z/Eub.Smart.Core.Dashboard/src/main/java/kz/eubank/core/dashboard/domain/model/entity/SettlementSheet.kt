package kz.eubank.core.dashboard.domain.model.entity

import java.math.BigDecimal
import javax.persistence.*

@Entity
@Table(name = "SettlementSheet")
data class SettlementSheet(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SettlementSheet_ID")
    var id: Long? = null,
    var currentSalary: BigDecimal? = null,
    var currentDepartmentName: String? = null,
    var totalAccrualAmount: BigDecimal? = null,
    var totalRetentionAmount: BigDecimal? = null,
    var totalCompanyRetentionAmount: BigDecimal? = null,
    var totalAmount: BigDecimal? = null,
    var totalDebtAmount: BigDecimal? = null,
    @OneToOne
    @JoinColumn(name = "SettlementSheetSaveRequest_IDREF")
    var settlementSheetSaveRequest: SettlementSheetSaveRequest? = null
) {

    fun toSettlementSheetDto() = kz.eubank.core.dashboard.domain.model.dto.SettlementSheet(
        totalAmount = totalAmount?.toInt(),
        totalDebtAmount = totalDebtAmount?.toInt(),
        totalAccrualAmount = totalAccrualAmount?.toInt(),
        totalRetentionAmount = totalRetentionAmount?.toInt(),
        totalCompanyRetentionAmount = totalCompanyRetentionAmount?.toInt(),
        currentSalary = currentSalary?.toInt(),
        currentDepartmentName = currentDepartmentName
    )

}

