package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Currency {

    private String code;
    private String name;
}
