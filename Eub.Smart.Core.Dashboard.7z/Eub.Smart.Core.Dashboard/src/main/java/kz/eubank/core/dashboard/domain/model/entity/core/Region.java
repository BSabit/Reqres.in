package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "Region")
public class Region {

    @Id
    @Column(name = "Region_ID")
    private Long id;

    @Column(name = "Region_Title")
    private String title;

    @OneToOne
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;

    /**
     * Time offset relative to Astana timezone (in hours)
     */
    @Column(name = "AstanaTimeOffset")
    private int timeOffset;

    @Column(name = "Priority")
    private Integer priority;

    @Column(name = "Latitude")
    private Float latitude;

    @Column(name = "Longtitude")
    private Float longtitude;

    @Column(name = "IndexCode")
    private String indexCode;
}
