package kz.eubank.core.dashboard.domain.model.response;

public class FavoriteCategoryDetails {
    private Long id;
    private String title;
    private String description;
    private String imageAddress;
    private Double maxPercent;

    public Long getId() {
        return this.id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(final String title) {
        this.title = title;
    }

    public String getImageAddress() {
        return this.imageAddress;
    }

    public void setImageAddress(final String imageAddress) {
        this.imageAddress = imageAddress;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    public Double getMaxPercent() {
        return this.maxPercent;
    }

    public void setMaxPercent(final Double maxPercent) {
        this.maxPercent = maxPercent;
    }
}
