package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "PreApprovedLoans")
public class PreApprovedLoans {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PreApprovedLoans_ID")
    private Long id;

    @Column(name = "IIN")
    private String iin;

    @Column(name = "LoanAmount")
    private BigDecimal loanAmount;

    @Column(name = "DurationMonth")
    private int durationMonth;

    @Column(name = "PaymentAmount")
    private BigDecimal paymentAmount;

    @Column(name = "DateCreated")
    private Date dateCreated;

    @Column(name = "Hidden")
    private boolean hidden;

    @Column(name = "SubProductName")
    private String subProductName;

    @Column(name = "SubProductCode")
    private String subProductCode;

    @Column(name = "ClientName")
    private String clientName;
}
