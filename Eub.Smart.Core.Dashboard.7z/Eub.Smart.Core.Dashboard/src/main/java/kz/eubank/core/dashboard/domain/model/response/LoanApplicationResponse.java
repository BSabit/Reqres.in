package kz.eubank.core.dashboard.domain.model.response;

import lombok.Generated;

import java.io.Serializable;
import java.util.List;

public class LoanApplicationResponse implements Serializable {
    private Long id;
    private Application application;
    private List<LoanApplicationScoring> loanApplicationScoring;
    private LoanCalcInfoResponse loanCalcInfoResponse;
    private LoanApplicationState loanApplicationState;
    private Integer amount;
    private Integer period;
    private boolean pensioner;
    private boolean individualEntrepreneur;
    private boolean hasNotIncome;
    private String employerBinFromBS;
    private String employerNameFromBS;
    private String partnerCode;
    private String partnerId;
    private String subProductName;
    private String subProductCode;
    private Boolean insuranceDefaultValueOn;
    private String insuranceOrgName;
    private String insurancePackage;
    private Integer officialIncomeAmount;
    private Integer additionalIncomeAmount;
    private Integer anotherLoanAmount;
    private String employerName;
    private String employerPhoneNumber;
    private String contactPerson;
    private String contactPersonPhone;
    private String staff;
    private String loanContractNumber;
    private String branchCode;
    private String maritalStatus;
    private int childCount;

    @Generated
    public LoanApplicationResponse() {
    }

    @Generated
    public Long getId() {
        return this.id;
    }

    @Generated
    public Application getApplication() {
        return this.application;
    }

    @Generated
    public List<LoanApplicationScoring> getLoanApplicationScoring() {
        return (List<LoanApplicationScoring>) this.loanApplicationScoring;
    }

    @Generated
    public LoanCalcInfoResponse getLoanCalcInfo() {
        return this.loanCalcInfoResponse;
    }

    @Generated
    public LoanApplicationState getLoanApplicationState() {
        return this.loanApplicationState;
    }

    @Generated
    public Integer getAmount() {
        return this.amount;
    }

    @Generated
    public Integer getPeriod() {
        return this.period;
    }

    @Generated
    public boolean isPensioner() {
        return this.pensioner;
    }

    @Generated
    public boolean isIndividualEntrepreneur() {
        return this.individualEntrepreneur;
    }

    @Generated
    public boolean isHasNotIncome() {
        return this.hasNotIncome;
    }

    @Generated
    public String getEmployerBinFromBS() {
        return this.employerBinFromBS;
    }

    @Generated
    public String getEmployerNameFromBS() {
        return this.employerNameFromBS;
    }

    @Generated
    public String getPartnerCode() {
        return this.partnerCode;
    }

    @Generated
    public String getPartnerId() {
        return this.partnerId;
    }

    @Generated
    public String getSubProductName() {
        return this.subProductName;
    }

    @Generated
    public String getSubProductCode() {
        return this.subProductCode;
    }

    @Generated
    public Boolean getInsuranceDefaultValueOn() {
        return this.insuranceDefaultValueOn;
    }

    @Generated
    public String getInsuranceOrgName() {
        return this.insuranceOrgName;
    }

    @Generated
    public String getInsurancePackage() {
        return this.insurancePackage;
    }

    @Generated
    public Integer getOfficialIncomeAmount() {
        return this.officialIncomeAmount;
    }

    @Generated
    public Integer getAdditionalIncomeAmount() {
        return this.additionalIncomeAmount;
    }

    @Generated
    public Integer getAnotherLoanAmount() {
        return this.anotherLoanAmount;
    }

    @Generated
    public String getEmployerName() {
        return this.employerName;
    }

    @Generated
    public String getEmployerPhoneNumber() {
        return this.employerPhoneNumber;
    }

    @Generated
    public String getContactPerson() {
        return this.contactPerson;
    }

    @Generated
    public String getContactPersonPhone() {
        return this.contactPersonPhone;
    }

    @Generated
    public String getStaff() {
        return this.staff;
    }

    @Generated
    public String getLoanContractNumber() {
        return this.loanContractNumber;
    }

    @Generated
    public String getBranchCode() {
        return this.branchCode;
    }

    @Generated
    public String getMaritalStatus() {
        return this.maritalStatus;
    }

    @Generated
    public int getChildCount() {
        return this.childCount;
    }

    @Generated
    public void setId(final Long id) {
        this.id = id;
    }

    @Generated
    public void setApplication(final Application application) {
        this.application = application;
    }

    @Generated
    public void setLoanApplicationScoring(final List<LoanApplicationScoring> loanApplicationScoring) {
        this.loanApplicationScoring = loanApplicationScoring;
    }

    @Generated
    public void setLoanCalcInfo(final LoanCalcInfoResponse loanCalcInfoResponse) {
        this.loanCalcInfoResponse = loanCalcInfoResponse;
    }

    @Generated
    public void setLoanApplicationState(final LoanApplicationState loanApplicationState) {
        this.loanApplicationState = loanApplicationState;
    }

    @Generated
    public void setAmount(final Integer amount) {
        this.amount = amount;
    }

    @Generated
    public void setPeriod(final Integer period) {
        this.period = period;
    }

    @Generated
    public void setPensioner(final boolean pensioner) {
        this.pensioner = pensioner;
    }

    @Generated
    public void setIndividualEntrepreneur(final boolean individualEntrepreneur) {
        this.individualEntrepreneur = individualEntrepreneur;
    }

    @Generated
    public void setHasNotIncome(final boolean hasNotIncome) {
        this.hasNotIncome = hasNotIncome;
    }

    @Generated
    public void setEmployerBinFromBS(final String employerBinFromBS) {
        this.employerBinFromBS = employerBinFromBS;
    }

    @Generated
    public void setEmployerNameFromBS(final String employerNameFromBS) {
        this.employerNameFromBS = employerNameFromBS;
    }

    @Generated
    public void setPartnerCode(final String partnerCode) {
        this.partnerCode = partnerCode;
    }

    @Generated
    public void setPartnerId(final String partnerId) {
        this.partnerId = partnerId;
    }

    @Generated
    public void setSubProductName(final String subProductName) {
        this.subProductName = subProductName;
    }

    @Generated
    public void setSubProductCode(final String subProductCode) {
        this.subProductCode = subProductCode;
    }

    @Generated
    public void setInsuranceDefaultValueOn(final Boolean insuranceDefaultValueOn) {
        this.insuranceDefaultValueOn = insuranceDefaultValueOn;
    }

    @Generated
    public void setInsuranceOrgName(final String insuranceOrgName) {
        this.insuranceOrgName = insuranceOrgName;
    }

    @Generated
    public void setInsurancePackage(final String insurancePackage) {
        this.insurancePackage = insurancePackage;
    }

    @Generated
    public void setOfficialIncomeAmount(final Integer officialIncomeAmount) {
        this.officialIncomeAmount = officialIncomeAmount;
    }

    @Generated
    public void setAdditionalIncomeAmount(final Integer additionalIncomeAmount) {
        this.additionalIncomeAmount = additionalIncomeAmount;
    }

    @Generated
    public void setAnotherLoanAmount(final Integer anotherLoanAmount) {
        this.anotherLoanAmount = anotherLoanAmount;
    }

    @Generated
    public void setEmployerName(final String employerName) {
        this.employerName = employerName;
    }

    @Generated
    public void setEmployerPhoneNumber(final String employerPhoneNumber) {
        this.employerPhoneNumber = employerPhoneNumber;
    }

    @Generated
    public void setContactPerson(final String contactPerson) {
        this.contactPerson = contactPerson;
    }

    @Generated
    public void setContactPersonPhone(final String contactPersonPhone) {
        this.contactPersonPhone = contactPersonPhone;
    }

    @Generated
    public void setStaff(final String staff) {
        this.staff = staff;
    }

    @Generated
    public void setLoanContractNumber(final String loanContractNumber) {
        this.loanContractNumber = loanContractNumber;
    }

    @Generated
    public void setBranchCode(final String branchCode) {
        this.branchCode = branchCode;
    }

    @Generated
    public void setMaritalStatus(final String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    @Generated
    public void setChildCount(final int childCount) {
        this.childCount = childCount;
    }

    @Generated
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof LoanApplicationResponse)) {
            return false;
        }
        final LoanApplicationResponse other = (LoanApplicationResponse) o;
        if (!other.canEqual((Object) this)) {
            return false;
        }
        final Object this$id = this.getId();
        final Object other$id = other.getId();
        Label_0065:
        {
            if (this$id == null) {
                if (other$id == null) {
                    break Label_0065;
                }
            } else if (this$id.equals(other$id)) {
                break Label_0065;
            }
            return false;
        }
        final Object this$application = this.getApplication();
        final Object other$application = other.getApplication();
        Label_0102:
        {
            if (this$application == null) {
                if (other$application == null) {
                    break Label_0102;
                }
            } else if (this$application.equals(other$application)) {
                break Label_0102;
            }
            return false;
        }
        final Object this$loanApplicationScoring = this.getLoanApplicationScoring();
        final Object other$loanApplicationScoring = other.getLoanApplicationScoring();
        Label_0139:
        {
            if (this$loanApplicationScoring == null) {
                if (other$loanApplicationScoring == null) {
                    break Label_0139;
                }
            } else if (this$loanApplicationScoring.equals(other$loanApplicationScoring)) {
                break Label_0139;
            }
            return false;
        }
        final Object this$loanCalcInfo = this.getLoanCalcInfo();
        final Object other$loanCalcInfo = other.getLoanCalcInfo();
        Label_0176:
        {
            if (this$loanCalcInfo == null) {
                if (other$loanCalcInfo == null) {
                    break Label_0176;
                }
            } else if (this$loanCalcInfo.equals(other$loanCalcInfo)) {
                break Label_0176;
            }
            return false;
        }
        final Object this$loanApplicationState = this.getLoanApplicationState();
        final Object other$loanApplicationState = other.getLoanApplicationState();
        Label_0213:
        {
            if (this$loanApplicationState == null) {
                if (other$loanApplicationState == null) {
                    break Label_0213;
                }
            } else if (this$loanApplicationState.equals(other$loanApplicationState)) {
                break Label_0213;
            }
            return false;
        }
        final Object this$amount = this.getAmount();
        final Object other$amount = other.getAmount();
        Label_0250:
        {
            if (this$amount == null) {
                if (other$amount == null) {
                    break Label_0250;
                }
            } else if (this$amount.equals(other$amount)) {
                break Label_0250;
            }
            return false;
        }
        final Object this$period = this.getPeriod();
        final Object other$period = other.getPeriod();
        Label_0287:
        {
            if (this$period == null) {
                if (other$period == null) {
                    break Label_0287;
                }
            } else if (this$period.equals(other$period)) {
                break Label_0287;
            }
            return false;
        }
        if (this.isPensioner() != other.isPensioner()) {
            return false;
        }
        if (this.isIndividualEntrepreneur() != other.isIndividualEntrepreneur()) {
            return false;
        }
        if (this.isHasNotIncome() != other.isHasNotIncome()) {
            return false;
        }
        final Object this$employerBinFromBS = this.getEmployerBinFromBS();
        final Object other$employerBinFromBS = other.getEmployerBinFromBS();
        Label_0363:
        {
            if (this$employerBinFromBS == null) {
                if (other$employerBinFromBS == null) {
                    break Label_0363;
                }
            } else if (this$employerBinFromBS.equals(other$employerBinFromBS)) {
                break Label_0363;
            }
            return false;
        }
        final Object this$employerNameFromBS = this.getEmployerNameFromBS();
        final Object other$employerNameFromBS = other.getEmployerNameFromBS();
        Label_0400:
        {
            if (this$employerNameFromBS == null) {
                if (other$employerNameFromBS == null) {
                    break Label_0400;
                }
            } else if (this$employerNameFromBS.equals(other$employerNameFromBS)) {
                break Label_0400;
            }
            return false;
        }
        final Object this$partnerCode = this.getPartnerCode();
        final Object other$partnerCode = other.getPartnerCode();
        Label_0437:
        {
            if (this$partnerCode == null) {
                if (other$partnerCode == null) {
                    break Label_0437;
                }
            } else if (this$partnerCode.equals(other$partnerCode)) {
                break Label_0437;
            }
            return false;
        }
        final Object this$partnerId = this.getPartnerId();
        final Object other$partnerId = other.getPartnerId();
        Label_0474:
        {
            if (this$partnerId == null) {
                if (other$partnerId == null) {
                    break Label_0474;
                }
            } else if (this$partnerId.equals(other$partnerId)) {
                break Label_0474;
            }
            return false;
        }
        final Object this$subProductName = this.getSubProductName();
        final Object other$subProductName = other.getSubProductName();
        Label_0511:
        {
            if (this$subProductName == null) {
                if (other$subProductName == null) {
                    break Label_0511;
                }
            } else if (this$subProductName.equals(other$subProductName)) {
                break Label_0511;
            }
            return false;
        }
        final Object this$subProductCode = this.getSubProductCode();
        final Object other$subProductCode = other.getSubProductCode();
        Label_0548:
        {
            if (this$subProductCode == null) {
                if (other$subProductCode == null) {
                    break Label_0548;
                }
            } else if (this$subProductCode.equals(other$subProductCode)) {
                break Label_0548;
            }
            return false;
        }
        final Object this$insuranceDefaultValueOn = this.getInsuranceDefaultValueOn();
        final Object other$insuranceDefaultValueOn = other.getInsuranceDefaultValueOn();
        Label_0585:
        {
            if (this$insuranceDefaultValueOn == null) {
                if (other$insuranceDefaultValueOn == null) {
                    break Label_0585;
                }
            } else if (this$insuranceDefaultValueOn.equals(other$insuranceDefaultValueOn)) {
                break Label_0585;
            }
            return false;
        }
        final Object this$insuranceOrgName = this.getInsuranceOrgName();
        final Object other$insuranceOrgName = other.getInsuranceOrgName();
        Label_0622:
        {
            if (this$insuranceOrgName == null) {
                if (other$insuranceOrgName == null) {
                    break Label_0622;
                }
            } else if (this$insuranceOrgName.equals(other$insuranceOrgName)) {
                break Label_0622;
            }
            return false;
        }
        final Object this$insurancePackage = this.getInsurancePackage();
        final Object other$insurancePackage = other.getInsurancePackage();
        Label_0659:
        {
            if (this$insurancePackage == null) {
                if (other$insurancePackage == null) {
                    break Label_0659;
                }
            } else if (this$insurancePackage.equals(other$insurancePackage)) {
                break Label_0659;
            }
            return false;
        }
        final Object this$officialIncomeAmount = this.getOfficialIncomeAmount();
        final Object other$officialIncomeAmount = other.getOfficialIncomeAmount();
        Label_0696:
        {
            if (this$officialIncomeAmount == null) {
                if (other$officialIncomeAmount == null) {
                    break Label_0696;
                }
            } else if (this$officialIncomeAmount.equals(other$officialIncomeAmount)) {
                break Label_0696;
            }
            return false;
        }
        final Object this$additionalIncomeAmount = this.getAdditionalIncomeAmount();
        final Object other$additionalIncomeAmount = other.getAdditionalIncomeAmount();
        Label_0733:
        {
            if (this$additionalIncomeAmount == null) {
                if (other$additionalIncomeAmount == null) {
                    break Label_0733;
                }
            } else if (this$additionalIncomeAmount.equals(other$additionalIncomeAmount)) {
                break Label_0733;
            }
            return false;
        }
        final Object this$anotherLoanAmount = this.getAnotherLoanAmount();
        final Object other$anotherLoanAmount = other.getAnotherLoanAmount();
        Label_0770:
        {
            if (this$anotherLoanAmount == null) {
                if (other$anotherLoanAmount == null) {
                    break Label_0770;
                }
            } else if (this$anotherLoanAmount.equals(other$anotherLoanAmount)) {
                break Label_0770;
            }
            return false;
        }
        final Object this$employerName = this.getEmployerName();
        final Object other$employerName = other.getEmployerName();
        Label_0807:
        {
            if (this$employerName == null) {
                if (other$employerName == null) {
                    break Label_0807;
                }
            } else if (this$employerName.equals(other$employerName)) {
                break Label_0807;
            }
            return false;
        }
        final Object this$employerPhoneNumber = this.getEmployerPhoneNumber();
        final Object other$employerPhoneNumber = other.getEmployerPhoneNumber();
        Label_0844:
        {
            if (this$employerPhoneNumber == null) {
                if (other$employerPhoneNumber == null) {
                    break Label_0844;
                }
            } else if (this$employerPhoneNumber.equals(other$employerPhoneNumber)) {
                break Label_0844;
            }
            return false;
        }
        final Object this$contactPerson = this.getContactPerson();
        final Object other$contactPerson = other.getContactPerson();
        Label_0881:
        {
            if (this$contactPerson == null) {
                if (other$contactPerson == null) {
                    break Label_0881;
                }
            } else if (this$contactPerson.equals(other$contactPerson)) {
                break Label_0881;
            }
            return false;
        }
        final Object this$contactPersonPhone = this.getContactPersonPhone();
        final Object other$contactPersonPhone = other.getContactPersonPhone();
        Label_0918:
        {
            if (this$contactPersonPhone == null) {
                if (other$contactPersonPhone == null) {
                    break Label_0918;
                }
            } else if (this$contactPersonPhone.equals(other$contactPersonPhone)) {
                break Label_0918;
            }
            return false;
        }
        final Object this$staff = this.getStaff();
        final Object other$staff = other.getStaff();
        Label_0955:
        {
            if (this$staff == null) {
                if (other$staff == null) {
                    break Label_0955;
                }
            } else if (this$staff.equals(other$staff)) {
                break Label_0955;
            }
            return false;
        }
        final Object this$loanContractNumber = this.getLoanContractNumber();
        final Object other$loanContractNumber = other.getLoanContractNumber();
        Label_0992:
        {
            if (this$loanContractNumber == null) {
                if (other$loanContractNumber == null) {
                    break Label_0992;
                }
            } else if (this$loanContractNumber.equals(other$loanContractNumber)) {
                break Label_0992;
            }
            return false;
        }
        final Object this$branchCode = this.getBranchCode();
        final Object other$branchCode = other.getBranchCode();
        Label_1029:
        {
            if (this$branchCode == null) {
                if (other$branchCode == null) {
                    break Label_1029;
                }
            } else if (this$branchCode.equals(other$branchCode)) {
                break Label_1029;
            }
            return false;
        }
        final Object this$maritalStatus = this.getMaritalStatus();
        final Object other$maritalStatus = other.getMaritalStatus();
        if (this$maritalStatus == null) {
            if (other$maritalStatus == null) {
                return this.getChildCount() == other.getChildCount();
            }
        } else if (this$maritalStatus.equals(other$maritalStatus)) {
            return this.getChildCount() == other.getChildCount();
        }
        return false;
    }

    @Generated
    protected boolean canEqual(final Object other) {
        return other instanceof LoanApplicationResponse;
    }

    @Generated
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $id = this.getId();
        result = result * 59 + (($id == null) ? 43 : $id.hashCode());
        final Object $application = this.getApplication();
        result = result * 59 + (($application == null) ? 43 : $application.hashCode());
        final Object $loanApplicationScoring = this.getLoanApplicationScoring();
        result = result * 59 + (($loanApplicationScoring == null) ? 43 : $loanApplicationScoring.hashCode());
        final Object $loanCalcInfo = this.getLoanCalcInfo();
        result = result * 59 + (($loanCalcInfo == null) ? 43 : $loanCalcInfo.hashCode());
        final Object $loanApplicationState = this.getLoanApplicationState();
        result = result * 59 + (($loanApplicationState == null) ? 43 : $loanApplicationState.hashCode());
        final Object $amount = this.getAmount();
        result = result * 59 + (($amount == null) ? 43 : $amount.hashCode());
        final Object $period = this.getPeriod();
        result = result * 59 + (($period == null) ? 43 : $period.hashCode());
        result = result * 59 + (this.isPensioner() ? 79 : 97);
        result = result * 59 + (this.isIndividualEntrepreneur() ? 79 : 97);
        result = result * 59 + (this.isHasNotIncome() ? 79 : 97);
        final Object $employerBinFromBS = this.getEmployerBinFromBS();
        result = result * 59 + (($employerBinFromBS == null) ? 43 : $employerBinFromBS.hashCode());
        final Object $employerNameFromBS = this.getEmployerNameFromBS();
        result = result * 59 + (($employerNameFromBS == null) ? 43 : $employerNameFromBS.hashCode());
        final Object $partnerCode = this.getPartnerCode();
        result = result * 59 + (($partnerCode == null) ? 43 : $partnerCode.hashCode());
        final Object $partnerId = this.getPartnerId();
        result = result * 59 + (($partnerId == null) ? 43 : $partnerId.hashCode());
        final Object $subProductName = this.getSubProductName();
        result = result * 59 + (($subProductName == null) ? 43 : $subProductName.hashCode());
        final Object $subProductCode = this.getSubProductCode();
        result = result * 59 + (($subProductCode == null) ? 43 : $subProductCode.hashCode());
        final Object $insuranceDefaultValueOn = this.getInsuranceDefaultValueOn();
        result = result * 59 + (($insuranceDefaultValueOn == null) ? 43 : $insuranceDefaultValueOn.hashCode());
        final Object $insuranceOrgName = this.getInsuranceOrgName();
        result = result * 59 + (($insuranceOrgName == null) ? 43 : $insuranceOrgName.hashCode());
        final Object $insurancePackage = this.getInsurancePackage();
        result = result * 59 + (($insurancePackage == null) ? 43 : $insurancePackage.hashCode());
        final Object $officialIncomeAmount = this.getOfficialIncomeAmount();
        result = result * 59 + (($officialIncomeAmount == null) ? 43 : $officialIncomeAmount.hashCode());
        final Object $additionalIncomeAmount = this.getAdditionalIncomeAmount();
        result = result * 59 + (($additionalIncomeAmount == null) ? 43 : $additionalIncomeAmount.hashCode());
        final Object $anotherLoanAmount = this.getAnotherLoanAmount();
        result = result * 59 + (($anotherLoanAmount == null) ? 43 : $anotherLoanAmount.hashCode());
        final Object $employerName = this.getEmployerName();
        result = result * 59 + (($employerName == null) ? 43 : $employerName.hashCode());
        final Object $employerPhoneNumber = this.getEmployerPhoneNumber();
        result = result * 59 + (($employerPhoneNumber == null) ? 43 : $employerPhoneNumber.hashCode());
        final Object $contactPerson = this.getContactPerson();
        result = result * 59 + (($contactPerson == null) ? 43 : $contactPerson.hashCode());
        final Object $contactPersonPhone = this.getContactPersonPhone();
        result = result * 59 + (($contactPersonPhone == null) ? 43 : $contactPersonPhone.hashCode());
        final Object $staff = this.getStaff();
        result = result * 59 + (($staff == null) ? 43 : $staff.hashCode());
        final Object $loanContractNumber = this.getLoanContractNumber();
        result = result * 59 + (($loanContractNumber == null) ? 43 : $loanContractNumber.hashCode());
        final Object $branchCode = this.getBranchCode();
        result = result * 59 + (($branchCode == null) ? 43 : $branchCode.hashCode());
        final Object $maritalStatus = this.getMaritalStatus();
        result = result * 59 + (($maritalStatus == null) ? 43 : $maritalStatus.hashCode());
        result = result * 59 + this.getChildCount();
        return result;
    }

    @Generated
    @Override
    public String toString() {
        return "LoanApplication(id=" + this.getId() + ", application=" + this.getApplication() + ", loanApplicationScoring=" + this.getLoanApplicationScoring() + ", loanCalcInfo=" + this.getLoanCalcInfo() + ", loanApplicationState=" + this.getLoanApplicationState() + ", amount=" + this.getAmount() + ", period=" + this.getPeriod() + ", pensioner=" + this.isPensioner() + ", individualEntrepreneur=" + this.isIndividualEntrepreneur() + ", hasNotIncome=" + this.isHasNotIncome() + ", employerBinFromBS=" + this.getEmployerBinFromBS() + ", employerNameFromBS=" + this.getEmployerNameFromBS() + ", partnerCode=" + this.getPartnerCode() + ", partnerId=" + this.getPartnerId() + ", subProductName=" + this.getSubProductName() + ", subProductCode=" + this.getSubProductCode() + ", insuranceDefaultValueOn=" + this.getInsuranceDefaultValueOn() + ", insuranceOrgName=" + this.getInsuranceOrgName() + ", insurancePackage=" + this.getInsurancePackage() + ", officialIncomeAmount=" + this.getOfficialIncomeAmount() + ", additionalIncomeAmount=" + this.getAdditionalIncomeAmount() + ", anotherLoanAmount=" + this.getAnotherLoanAmount() + ", employerName=" + this.getEmployerName() + ", employerPhoneNumber=" + this.getEmployerPhoneNumber() + ", contactPerson=" + this.getContactPerson() + ", contactPersonPhone=" + this.getContactPersonPhone() + ", staff=" + this.getStaff() + ", loanContractNumber=" + this.getLoanContractNumber() + ", branchCode=" + this.getBranchCode() + ", maritalStatus=" + this.getMaritalStatus() + ", childCount=" + this.getChildCount() + ")";
    }
}
