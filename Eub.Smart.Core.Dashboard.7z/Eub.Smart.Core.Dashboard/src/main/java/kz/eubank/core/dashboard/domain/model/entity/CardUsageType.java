package kz.eubank.core.dashboard.domain.model.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@Entity
@Table(name = "CardUsageType")
public class CardUsageType {

    @Id
    @Column(name = "CardUsageType_ID")
    private String code;

    @Column(name = "CardUsageType_Title")
    private String title;
}
