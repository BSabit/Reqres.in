package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
public class CreditContractAccount extends ContractAccount {

    private BigDecimal amount;
    private BigDecimal available;
    private BigDecimal interestRate;
    private String balanceCurrency;
    private List<Duty> duties;
    private String guarantee;
    private List<String> repaymentAccounts;
    private Long validityDate;
    private String type;
    private Long term;
    private Long expiration;
    private String sourceSystem;
    private String creditType;
    private String servicingBranch;
    private BigDecimal totalFullRepaymentBalance;
}
