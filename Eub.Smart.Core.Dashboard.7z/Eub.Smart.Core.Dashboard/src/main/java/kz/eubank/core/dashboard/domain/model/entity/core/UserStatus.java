package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Setter
@Getter
@Entity
@Table(name = "UserStatus")
public class UserStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "UserStatus_ID")
    private String code;

    @Column(name = "UserStatus_Title")
    private String title;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;

    @Column(name = "IsValid")
    private boolean valid;
}
