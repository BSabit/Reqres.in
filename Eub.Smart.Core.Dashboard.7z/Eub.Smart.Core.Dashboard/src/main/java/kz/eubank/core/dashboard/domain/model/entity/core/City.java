package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "City")
public class City {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "City_ID")
    private Long id;

    @Column(name = "City_Title")
    private String title;

    @OneToOne()
    @JoinColumn(name = "Region_IDREF")
    private Region region;

    @Column(name = "Area")
    private String area;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;
}
