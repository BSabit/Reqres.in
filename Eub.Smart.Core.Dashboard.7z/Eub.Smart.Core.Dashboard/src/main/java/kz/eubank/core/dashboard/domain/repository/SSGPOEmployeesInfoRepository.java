package kz.eubank.core.dashboard.domain.repository;

import kz.eubank.core.dashboard.domain.model.entity.SSGPOEmployeesInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface SSGPOEmployeesInfoRepository extends JpaRepository<SSGPOEmployeesInfo, String> {

    @Query(nativeQuery = true,
            value = "SELECT sei.*" +
                    " FROM SSGPOTickets st" +
                    " INNER JOIN SSGPOEmployeesInfo sei ON st.SSGPOTickets_ID = sei.SSGPOTickets_IDREF" +
                    " INNER JOIN SSGPOCodeDictionary scd ON scd.SSGPOCodeDictionary_ID = sei.SSGPOCodeDictionary_IDREF" +
                    " INNER JOIN SSGPOCodeType sct ON sct.SSGPOCodeType_ID = scd.SSGPOCodeType_IDREF" +
                    " WHERE sct.Type = 'SUBD'" +
                    "   AND sei.PersonIIN = :iin" +
                    "   AND st.ExportPeriod IN " +
                    "       (select TOP (:size) st1.exportPeriod" +
                    "          from SSGPOTickets st1" +
                    "          join SSGPOEmployeesInfo sei1 ON st1.SSGPOTickets_ID = sei1.SSGPOTickets_IDREF" +
                    "         where sei1.PersonIIN = :iin" +
                    "         group by st1.ExportPeriod" +
                    "         order by substring(st1.ExportPeriod, 4, 4) desc, substring(st1.ExportPeriod, 1, 2) desc)")
    List<SSGPOEmployeesInfo> findSSGPOEmployeesInfoByIinAndTop(String iin, int size);
}
