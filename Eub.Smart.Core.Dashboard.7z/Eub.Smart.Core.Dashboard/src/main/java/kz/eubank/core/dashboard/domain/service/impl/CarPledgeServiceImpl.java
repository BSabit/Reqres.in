package kz.eubank.core.dashboard.domain.service.impl;

import kz.eubank.core.dashboard.domain.model.response.CarPledgeInfo;
import kz.eubank.core.dashboard.domain.service.ICarPledgeService;
import kz.eubank.core.dashboard.infrastructure.config.ApplicationContext;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class CarPledgeServiceImpl implements ICarPledgeService {

    private final ApplicationContext context;
    private static final Map<String, CarPledgeInfo> carPledges;

    static {
        carPledges = new HashMap<>();

        carPledges.put("950201300406", CarPledgeInfo.builder()
                .iin("950201300406")
                .vin(null)
                .brand("HYUNDAI")
                .model("SONATA")
                .year(2023)
                .plateNumber("851AYI01")
                .applicationNB("L223197006832")
                .status(5)
                .statusInfo("ожидает снятия с залога")
                .mvdPledgeId(172393L)
                .build());
        carPledges.put("990507400700", CarPledgeInfo.builder()
                .iin("990507400700")
                .vin(null)
                .brand("HYUNDAI")
                .model("SONATA")
                .year(2024)
                .plateNumber("851AYI02")
                .applicationNB("L223197006832")
                .status(1)
                .statusInfo("стоит на учете")
                .mvdPledgeId(172393L)
                .build());
        carPledges.put("940218300843", CarPledgeInfo.builder()
                .iin("940218300843")
                .vin(null)
                .brand("HYUNDAI")
                .model("SONATA")
                .year(2025)
                .plateNumber("851AYI03")
                .applicationNB("L223197006832")
                .status(5)
                .statusInfo("ожидает снятия с залога")
                .mvdPledgeId(172393L)
                .build());
        carPledges.put("011130500391", CarPledgeInfo.builder()
                .iin("011130500391")
                .vin(null)
                .brand("HYUNDAI")
                .model("SONATA")
                .year(2026)
                .plateNumber("851AYI04")
                .applicationNB("L223197006832")
                .status(2)
                .statusInfo("снят с учета")
                .mvdPledgeId(172393L)
                .build());
    }

    @Override
    public CarPledgeInfo getCarPledgeInfo() {
        String iin = context.getCurrentUser().getIin();
        return Optional.ofNullable(carPledges.get(iin))
                .orElse(new CarPledgeInfo());
    }
}
