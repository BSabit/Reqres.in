package kz.eubank.core.dashboard.domain.model.enums;

import java.util.Arrays;

public enum AccountStatus {

    ACTIVE("ACTV"),
    CLOSED(""),
    BLOCKED(""),
    TRANSFERED_TO_COLLECTORS(""),
    PARTIALLY_BLOCKED(""),
    DELETED(""),
    CRBA(""),
    SUSPENDED(""),
    UNDER_COLLECTION("");

    private final String text;

    AccountStatus(String text) {
        this.text = text;
    }

    public String getText() {
        return this.text;
    }

    public static AccountStatus fromString(String text) {
        return Arrays.stream(AccountStatus.values()).filter(q -> q.getText().equalsIgnoreCase(text))
                .findFirst().orElse(null);
    }
}
