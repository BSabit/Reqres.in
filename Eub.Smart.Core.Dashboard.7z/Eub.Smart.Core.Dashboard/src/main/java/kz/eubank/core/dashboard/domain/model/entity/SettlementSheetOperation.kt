package kz.eubank.core.dashboard.domain.model.entity

import java.math.BigDecimal
import javax.persistence.Column
import javax.persistence.JoinColumn
import javax.persistence.ManyToOne
import javax.persistence.MappedSuperclass

@MappedSuperclass
open class SettlementSheetOperation (
    @ManyToOne
    @JoinColumn(name = "SettlementSheet_IDREF", nullable = false)
    var sheet: SettlementSheet? = null,
    @Column(name = "ShortNameKz")
    var shortNameKz: String? = null,
    @Column(name = "FullNameKz")
    var fullNameKz: String? = null,
    @Column(name = "ShortNameRu")
    var shortNameRu: String? = null,
    @Column(name = "FullNameRu")
    var fullNameRu: String? = null,
    @Column(name = "ShortNameEn")
    var shortNameEn: String? = null,
    @Column(name = "FullNameEn")
    var fullNameEn: String? = null,
    @Column(name = "Amount")
    var amount: BigDecimal? = null,
    @Column(name = "RateCount")
    var count: Int? = null,
    @Column(name = "RatePrice")
    var price: BigDecimal? = null,
    @Column(name = "RateType")
    var type: String? = null
)