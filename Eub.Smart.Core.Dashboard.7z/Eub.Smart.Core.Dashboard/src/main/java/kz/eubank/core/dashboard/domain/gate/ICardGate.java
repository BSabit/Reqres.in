package kz.eubank.core.dashboard.domain.gate;

import kz.eubank.core.dashboard.domain.model.dto.CardLongInfo;

import java.util.Collection;

public interface ICardGate {

    Collection<CardLongInfo> getCardsLongInfo(final String p0, final boolean p1, final boolean p2, final Long p3);
}
