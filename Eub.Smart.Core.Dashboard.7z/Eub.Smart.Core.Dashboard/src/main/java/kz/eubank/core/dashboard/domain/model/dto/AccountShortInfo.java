package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class AccountShortInfo {

    private Long id;
    private String title;
    private String currency;
    private String number;
    private BigDecimal interestRate;
    private String type;
    private Long productId;
    private AccountStatus status;
    private int spriteIndex;
    private int priority;
    boolean allowBalance;
    boolean allowCreateFinDoc;
    boolean allowSubmitFinDoc;
    private BigDecimal balance;
    private String balanceCurrency;
    private BigDecimal actualBalance;
    private BigDecimal blockedSum;
    private List<String> actions;
    private boolean multiCurrency;
    private Long outref;
    private String contractNo;
    private Date dateOpened;
    private Long parentAccountId;
    private BigDecimal effectiveRate;
}
