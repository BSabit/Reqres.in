package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "PINSetApplication")
public class PINSetApplication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PINSetApplication_ID")
    private Long id;

    @Column(name = "PINSetRequest_ID")
    private String requestGUID;

    @OneToOne
    @JoinColumn(name = "Card_IDREF")
    private Card card;
}
