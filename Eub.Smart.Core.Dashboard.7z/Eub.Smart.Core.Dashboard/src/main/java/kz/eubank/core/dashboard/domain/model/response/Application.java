package kz.eubank.core.dashboard.domain.model.response;

import lombok.Generated;

import java.io.Serializable;

public class Application implements Serializable {
    private static final long serialVersionUID = -2311492506508880633L;
    private Long id;
    private String type;
    private String typeTitle;
    private String compositeType;
    private byte[] blob;
    private String status;
    private String statusTitle;
    private String statusMessage;
    private boolean statusIsFinal;
    private Long created;
    private Long dateScheduled;
    private Long dateSigned;
    private Integer fee;
    private String feeCurrency;
    private String commissionAccount;

    @Generated
    public Long getId() {
        return this.id;
    }

    @Generated
    public String getType() {
        return this.type;
    }

    @Generated
    public String getTypeTitle() {
        return this.typeTitle;
    }

    @Generated
    public String getCompositeType() {
        return this.compositeType;
    }

    @Generated
    public byte[] getBlob() {
        return this.blob;
    }

    @Generated
    public String getStatus() {
        return this.status;
    }

    @Generated
    public String getStatusTitle() {
        return this.statusTitle;
    }

    @Generated
    public String getStatusMessage() {
        return this.statusMessage;
    }

    @Generated
    public boolean isStatusIsFinal() {
        return this.statusIsFinal;
    }

    @Generated
    public Long getCreated() {
        return this.created;
    }

    @Generated
    public Long getDateScheduled() {
        return this.dateScheduled;
    }

    @Generated
    public Long getDateSigned() {
        return this.dateSigned;
    }

    @Generated
    public Integer getFee() {
        return this.fee;
    }

    @Generated
    public String getFeeCurrency() {
        return this.feeCurrency;
    }

    @Generated
    public String getCommissionAccount() {
        return this.commissionAccount;
    }

    @Generated
    public void setId(final Long id) {
        this.id = id;
    }

    @Generated
    public void setType(final String type) {
        this.type = type;
    }

    @Generated
    public void setTypeTitle(final String typeTitle) {
        this.typeTitle = typeTitle;
    }

    @Generated
    public void setCompositeType(final String compositeType) {
        this.compositeType = compositeType;
    }

    @Generated
    public void setBlob(final byte[] blob) {
        this.blob = blob;
    }

    @Generated
    public void setStatus(final String status) {
        this.status = status;
    }

    @Generated
    public void setStatusTitle(final String statusTitle) {
        this.statusTitle = statusTitle;
    }

    @Generated
    public void setStatusMessage(final String statusMessage) {
        this.statusMessage = statusMessage;
    }

    @Generated
    public void setStatusIsFinal(final boolean statusIsFinal) {
        this.statusIsFinal = statusIsFinal;
    }

    @Generated
    public void setCreated(final Long created) {
        this.created = created;
    }

    @Generated
    public void setDateScheduled(final Long dateScheduled) {
        this.dateScheduled = dateScheduled;
    }

    @Generated
    public void setDateSigned(final Long dateSigned) {
        this.dateSigned = dateSigned;
    }

    @Generated
    public void setFee(final Integer fee) {
        this.fee = fee;
    }

    @Generated
    public void setFeeCurrency(final String feeCurrency) {
        this.feeCurrency = feeCurrency;
    }

    @Generated
    public void setCommissionAccount(final String commissionAccount) {
        this.commissionAccount = commissionAccount;
    }
}
