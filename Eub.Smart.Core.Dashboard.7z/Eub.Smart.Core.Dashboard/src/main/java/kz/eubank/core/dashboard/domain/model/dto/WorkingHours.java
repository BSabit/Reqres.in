package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Generated;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Arrays;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class WorkingHours {

    private int[] weekDay;
    private List<OpeningTime> openingTime;

    @Generated
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof WorkingHours)) {
            return false;
        }
        final WorkingHours other = (WorkingHours) o;
        if (!other.canEqual(this)) {
            return false;
        }
        if (!Arrays.equals(this.getWeekDay(), other.getWeekDay())) {
            return false;
        }
        final Object this$openingTime = this.getOpeningTime();
        final Object other$openingTime = other.getOpeningTime();
        if (this$openingTime == null) {
            return other$openingTime == null;
        } else return this$openingTime.equals(other$openingTime);
    }

    @Generated
    protected boolean canEqual(final Object other) {
        return other instanceof WorkingHours;
    }

    @Generated
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        result = result * 59 + Arrays.hashCode(this.getWeekDay());
        final Object $openingTime = this.getOpeningTime();
        result = result * 59 + (($openingTime == null) ? 43 : $openingTime.hashCode());
        return result;
    }

    @Generated
    @Override
    public String toString() {
        return "WorkingHours(weekDay=" + Arrays.toString(this.getWeekDay()) + ", openingTime=" + this.getOpeningTime() + ")";
    }
}
