package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Getter
@Setter
@Entity
@Table(name = "ApplicationType")
public class ApplicationType implements Serializable {

    private static final long serialVersionUID = -3031863819151871703L;

    @Id
    @Column(name = "ApplicationType_ID")
    private String code;

    @Column(name = "ApplicationGroup_IDREF")
    private String groupCode;

    @Column(name = "ApplicationType_Title")
    private String title;

    @OneToOne
    @JoinColumn(name = "ApplicationFormType_IDREF")
    private ApplicationFormType formType;

    @OneToOne
    @PrimaryKeyJoinColumn
    private ReferenceProperty referenceProperty;

    @Column(name = "Knp_IDREF")
    private String knpId;

    @Column(name = "KnpText")
    private String knpText;

    @OneToOne
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;

    @Column(name = "IsActive")
    private boolean active;

    @Column(name = "LogoPath")
    private String logoPath;
}