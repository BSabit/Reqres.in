package kz.eubank.core.dashboard.domain.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Getter
@Setter
public class CardAccount extends CurrentAccount implements Serializable {

    private Collection<Card> cards;
    private BigDecimal overdraft;
    private BigDecimal ownFunds;
    private BigDecimal currentInterest;
    private BigDecimal lastMonthInterest;
    private BigDecimal allPeriodInterest;
    private BigDecimal cashbackForPeriod;
    private BigDecimal periodOfCashBack;
    private BigDecimal totalCashback;
    private Collection<SubAccountBalance> subAccountBalances;
    private Collection<SubAccountBalance> subAccountAvailableBalances;
    private Collection<SubAccountBalance> subAccountBlockedSumBalances;
    private List<String> subAccountActionKZT = new ArrayList<>();
    private List<String> subAccountActionUSD = new ArrayList<>();
    private List<String> subAccountActionEUR = new ArrayList<>();
    private Boolean installmentAccount;
    private Boolean activeInstallments;
    private AccountGraceInfo accountGraceInfo;
    private BigDecimal finBlocking;
    @JsonProperty("isGrace")
    private boolean grace;
    private BigDecimal fullDebtAmount;
    @JsonSetter(nulls = Nulls.SET)
    private CardProductOperation cardProductOperation;
    private Boolean showInstallements;
    private boolean multiCurrency;

    public CardAccount() {
        this.setType("CARD");
    }

    public String getType() {
        return "CARD";
    }
}
