package kz.eubank.core.dashboard.infrastructure.config;

import lombok.AllArgsConstructor;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
@AllArgsConstructor
public class AppProperties {

    private Environment environment;

    public String getCardAccountType() {
        return environment.getProperty("account.type.CARD");
    }

    private String[] toArray(final String key) {
        final String list = environment.getProperty(key, "");
        return list.split(",");
    }

    public String getDepositAccountType() {
        return environment.getProperty("account.type.DEPOSIT");
    }

    public List<String> getSubAccountAction(final String currency) {
        String str = environment.getProperty("sub.account.action." + currency, "CRED;TSLF;TLOC;PAYM;TOUT");
        str = str.replaceAll(" ", "");
        return Arrays.asList(str.split(";"));
    }

    public String getCurrentAccountType() {
        return environment.getProperty("account.type.CURRENT");
    }

    public String getBonusAccountType() {
        return environment.getProperty("account.type.BONUS");
    }
}
