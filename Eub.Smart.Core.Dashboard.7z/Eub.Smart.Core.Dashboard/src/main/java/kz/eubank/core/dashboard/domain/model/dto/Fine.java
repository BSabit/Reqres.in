package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Setter
@Getter
public class Fine {

    private BigDecimal interest;
    private BigDecimal mainDebt;
    private BigDecimal mainDebtOverdue;
    private BigDecimal total;
}
