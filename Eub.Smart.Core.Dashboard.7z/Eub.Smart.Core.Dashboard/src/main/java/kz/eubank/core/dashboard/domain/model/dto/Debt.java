package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class Debt {

    private BigDecimal main;
    private BigDecimal percentage;
    private BigDecimal commission;
    private BigDecimal total;
    private BigDecimal overDueInterestCommission;
    private BigDecimal fine;
}
