package kz.eubank.core.dashboard.domain.service;

import kz.eubank.core.dashboard.domain.model.response.AccountList;
import kz.eubank.core.dashboard.domain.model.response.BonusSettings;
import kz.eubank.core.dashboard.domain.model.response.FavoriteCategoryList;

public interface IBonusesService {

    AccountList listBonusAccounts(String balanceCurrency, String dateFrom, String dateTill);

    FavoriteCategoryList getCategories(String language);

    BonusSettings getBonusSettingsByAccount(String account);
}
