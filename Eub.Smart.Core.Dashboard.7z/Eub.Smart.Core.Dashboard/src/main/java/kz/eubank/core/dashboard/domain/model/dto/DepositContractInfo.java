package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
public class DepositContractInfo extends ContractInfo {

    private static final long serialVersionUID = 4265487107951688436L;

    boolean allowBalance;
    boolean allowCreateFinDoc;
    boolean allowSubmitFinDoc;
    private AccountStatus status;

    private Date dateOpened;
    private Date dateClosed;
    private BigDecimal accruedAmountForMonth;
    private BigDecimal accruedAmountTotal;
    private Integer minBalance;
}
