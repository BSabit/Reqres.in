package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "KNP")
public class KNP {

    @Id
    @Column(name = "KNP_ID")
    private String code;

    @Column(name = "KNP_Title")
    private String title;

    @OneToOne
    @JoinColumn(name = "Term_OUTREF")
    private Term term;

    @Column(name = "IsPrivate")
    private boolean isPrivate;

    @Column(name = "IsLocal")
    private boolean isLocal;

    @Column(name = "IsCorporate")
    private boolean isCorporate;

    @Column(name = "IsInShortList")
    private boolean isInShortList;

    @Column(name = "IsXBorder")
    private boolean isXBorder;

    @Column(name = "IsAid")
    private boolean isAid;

    @Column(name = "RequireDocFields")
    private boolean requireDocFields;

    @Column(name = "IsActive")
    private boolean active;
}
