package kz.eubank.core.dashboard.domain.model.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
public class SSGPOEmployeeInfo {

    @JsonIgnore
    private String id;
    private BigDecimal accrualAmount;
    private String departmentCode;
    private String departmentCodeDesc;
    private String departmentCodeDescShort;
    private List<SSGPOSettlementInfo> settlementsAccrual;
    private List<SSGPOSettlementInfo> settlementsRetension;
    private BigDecimal oppvAmount;
    private BigDecimal osmsAmount;
    private String period;
    private String iin;
    private String personNumber;
    private BigDecimal retentionAmount;
    private BigDecimal salary;
    private BigDecimal socialRetentionAmount;
    private BigDecimal totalAmount;
}
