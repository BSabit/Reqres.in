package kz.eubank.core.dashboard.domain.model.response;

import java.util.List;

public class FavoriteCategory {
    private String id;
    private String title;
    private String mcc;
    private boolean visible;
    private String description;
    private List<FavoriteCategoryDetails> details;
    private String additionalDescription;
    private String color;
    private String imagePath;

    public String getId() {
        return this.id;
    }

    public void setId(final String id) {
        this.id = id;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(final String title) {
        this.title = title;
    }

    public String getMcc() {
        return this.mcc;
    }

    public void setMcc(final String mcc) {
        this.mcc = mcc;
    }

    public boolean isVisible() {
        return this.visible;
    }

    public void setVisible(final boolean visible) {
        this.visible = visible;
    }

    public List<FavoriteCategoryDetails> getDetails() {
        return (List<FavoriteCategoryDetails>) this.details;
    }

    public void setDetails(final List<FavoriteCategoryDetails> details) {
        this.details = details;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    public String getColor() {
        return this.color;
    }

    public void setColor(final String color) {
        this.color = color;
    }

    public String getImagePath() {
        return this.imagePath;
    }

    public void setImagePath(final String imagePath) {
        this.imagePath = imagePath;
    }

    public String getAdditionalDescription() {
        return this.additionalDescription;
    }

    public void setAdditionalDescription(final String additionalDescription) {
        this.additionalDescription = additionalDescription;
    }
}
