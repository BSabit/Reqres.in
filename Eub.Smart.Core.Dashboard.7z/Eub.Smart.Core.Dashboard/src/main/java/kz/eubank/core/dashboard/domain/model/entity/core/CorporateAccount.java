package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "CorporateAccount")
public class CorporateAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CorporateAccount_ID")
    private Long id;

    @Column(name = "Commentary")
    private String commentary;

    @OneToOne
    @JoinColumn(name = "Account_IDREF")
    private Account account;
}
