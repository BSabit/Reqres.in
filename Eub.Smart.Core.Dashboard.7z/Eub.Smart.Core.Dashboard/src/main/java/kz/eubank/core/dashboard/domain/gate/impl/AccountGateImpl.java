package kz.eubank.core.dashboard.domain.gate.impl;

import kz.eubank.core.dashboard.domain.gate.IAccountGate;
import kz.eubank.core.dashboard.domain.gate.WebServiceGate;
import kz.eubank.core.dashboard.domain.model.dto.AccountLongInfo;
import kz.eubank.core.dashboard.domain.model.dto.CardProductOperation;
import kz.eubank.core.dashboard.domain.model.entity.CardAccount;
import kz.eubank.core.dashboard.domain.model.entity.core.Account;
import kz.eubank.core.dashboard.domain.model.entity.core.Account2;
import kz.eubank.core.dashboard.domain.model.entity.core.Branch;
import kz.eubank.core.dashboard.domain.repository.IBranchRepository;
import kz.eubank.core.dashboard.domain.repository.ICardProductOperationRepository;
import kz.eubank.core.dashboard.domain.repository.IOwnAccount2Repository;
import kz.eubank.core.dashboard.domain.repository.IOwnAccountRepository;
import kz.eubank.core.dashboard.infrastructure.config.AppProperties;
import kz.eubank.core.dashboard.infrastructure.config.MapperHelper;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Log4j2
@Service
public class AccountGateImpl implements IAccountGate {

    @Autowired
    private IOwnAccount2Repository account2Repository;

    @Autowired
    private IOwnAccountRepository accountRepository;

    @Autowired
    private WebServiceGate webServiceGate;

    @Autowired
    private AppProperties appProperties;

    @Autowired
    private IBranchRepository branchRepository;

    @Autowired
    private ICardProductOperationRepository cardProductOperationRepository;

    @Autowired
    private MapperHelper mapperHelper;

    private List<String> findActions(final String accountNr) {
        final Account account = accountRepository.findByNumber(accountNr);
        if (account == null) {
            throw new IllegalArgumentException("Account: " + accountNr + " not found!");
        }
        return accountRepository.findActions(account.getProductId());
    }

    @Override
    public AccountLongInfo getAccountDetails(final Long userId, final Long clientId, final String accountNr,
                                             final String lang) {
        final Account2 account = account2Repository.findOne(userId, clientId, accountNr, lang);
        AccountLongInfo accountLongInfo = mapperHelper.map(account).to(AccountLongInfo.class);
        final AccountLongInfo accountDetails = getAccountDetails(accountNr, accountLongInfo);
        final BigDecimal interestRate = accountDetails.getInterestRate();
        branchRepository.findById(account.getBranchId())
                .ifPresent(q -> setBranchDetails(accountDetails, q));
        accountDetails.setActions(findActions(accountNr));
        if (appProperties.getDepositAccountType().equals(account.getType())) {
            accountDetails.setInterestRate(interestRate);
        }
        if (appProperties.getCardAccountType().equals(account.getType())) {
            accountDetails.setInterestRate(interestRate);
            final CardAccount card = accountRepository.findCardAccount(account.getId());
            if (card != null) {
                accountDetails.setActiveInstallments(card.isHasActiveInstallments());
                accountDetails.setInstallmentAccount(card.isInstallment());
            }
        }
        Account acc = accountRepository.findByNumber(accountNr);
        if (acc != null) {
            accountDetails.setDateClosed(acc.getDateClosed());
            accountDetails.setDateOpened(acc.getDateOpened());
            log.info("dateOpened: " + acc.getDateOpened());
            log.info("current date: " + new Date());
        }
        return accountDetails;
    }

    private void setBranchDetails(AccountLongInfo accountDetails, Branch q) {
        if (q.getTerms() != null) {
            accountDetails.setBranchTermId(q.getTerms().getId().toString());
        }
        accountDetails.setBranchTitle(q.getTitle());
    }

    @Override
    public AccountLongInfo getAccountDetails(final String accountNr, AccountLongInfo accountLongInfo) {
        return webServiceGate.getAccountDetails(accountNr, accountLongInfo);
    }

    @Override
    public CardProductOperation getCardProductOperation(final Long productId) {
        kz.eubank.core.dashboard.domain.model.entity.CardProductOperation product = cardProductOperationRepository
                .findByProductId(productId);
        if (product != null) {
            return mapperHelper.map(product).to(CardProductOperation.class);
        }
        return null;
    }
}
