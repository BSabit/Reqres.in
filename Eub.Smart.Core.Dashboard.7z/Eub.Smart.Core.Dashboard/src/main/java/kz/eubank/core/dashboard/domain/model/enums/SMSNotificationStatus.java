package kz.eubank.core.dashboard.domain.model.enums;

public enum SMSNotificationStatus {
    ACTV, NCTV, UNKN
}
