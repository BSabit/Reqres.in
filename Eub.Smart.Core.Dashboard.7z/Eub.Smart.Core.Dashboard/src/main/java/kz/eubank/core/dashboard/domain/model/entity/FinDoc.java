package kz.eubank.core.dashboard.domain.model.entity;

import kz.eubank.core.dashboard.domain.model.entity.core.Account;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "FinDoc")
public class FinDoc {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "FinDoc_ID")
    private Long id;

    @Column(name = "FinDocType_IDREF")
    private String docType;

    @OneToOne(mappedBy = "finDoc")
    private FinDocState state;

    @Column(name = "User_IDREF")
    private Long userId;

    @Column(name = "BLOB")
    private byte[] blob;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "Account_IDREF")
    private Account account;

    @Column(name = "Currency")
    private String currency;

    @Column(name = "Amount")
    private BigDecimal amount;

    @Column(name = "Fee")
    private BigDecimal feeAmount;

    @Column(name = "Details")
    private String details;

    @Column(name = "DateCreated")
    private Date dateCreated;
    
    @Column(name = "DateSigned")
    private Date dateSigned;

    @Column(name = "DateScheduled")
    private Date dateScheduled;

    @Column(name = "IsUrgent")
    private boolean urgent;
    
    @Column(name = "IsTemplate")
    private boolean template;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDocType() {
        return docType;
    }

    public void setDocType(String docType) {
        this.docType = docType;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public byte[] getBlob() {
        return blob;
    }

    public void setBlob(byte[] blob) {
        this.blob = blob;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateScheduled() {
        return dateScheduled;
    }

    public void setDateScheduled(Date dateScheduled) {
        this.dateScheduled = dateScheduled;
    }

    public boolean isUrgent() {
        return urgent;
    }

    public void setUrgent(boolean urgent) {
        this.urgent = urgent;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public BigDecimal getFeeAmount() {
        return feeAmount;
    }

    public void setFeeAmount(BigDecimal feeAmount) {
        this.feeAmount = feeAmount;
    }

    public FinDocState getState() {
        return state;
    }

    public boolean isTemplate() {
        return template;
    }

    public void setTemplate(boolean template) {
        this.template = template;
    }

    public Date getDateSigned() {
        return dateSigned;
    }

    public void setDateSigned(Date dateSigned) {
        this.dateSigned = dateSigned;
    }
}
