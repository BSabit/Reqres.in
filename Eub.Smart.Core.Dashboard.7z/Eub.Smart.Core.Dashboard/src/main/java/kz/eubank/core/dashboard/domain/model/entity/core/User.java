package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

import javax.persistence.*;
import java.util.Date;

@Setter
@Getter
@Entity
@Table(name = "`User`")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "User_ID")
    private Long id;

    @Column(name = "Username")
    private String username;

    @Column(name = "LoginHourStart")
    private int loginHourStart;

    @Column(name = "LoginHourEnd")
    private int loginHourEnd;

    @Column(name = "FailedLogins")
    private int failedLogins;

    @Column(name = "CodeWord")
    private String codeWord;

    @OneToOne
    @JoinColumn(name = "UserStatus_IDREF")
    private UserStatus status;

    @OneToOne
    @JoinColumn(name = "Person_IDREF")
    private Person person;

    @OneToOne
    @JoinColumn(name = "Locale_IDREF")
    private Locale locale;

    @Column(name = "UILayout_IDREF")
    private long layout;

    @Column(name = "UITheme_IDREF")
    private long theme;

    @Column(name = "PasswordAge")
    private Integer passwordAge;

    @Column(name = "SessionTimeout")
    private Integer sessionTimeout;

    @Column(name = "DateCreated")
    private Date dateCreated;

    @Column(name = "RegFinishDate")
    private Date regFinishDate;

    @Column(name = "UIUseSmallCards")
    private Boolean useSmallCards;

    @OneToOne
    @JoinColumn(name = "Branch_IDREF")
    private Branch branch;

    @Column(name = "DateRegistered")
    private Date dateRegistered;

    @Column(name = "RegisteredBy")
    private String registeredBy;

    @Column(name = "RegChannel_IDREF")
    private String regChannelId;

    @Column(name="RegisteredBy_Override")
    private String registeredByOverride;

    @Column(name="RegFinishDate_FPHM")
    private Date regFinishDateFPHM;

    @Column(name="UnlimitedPassword")
    private Integer unlimitedPassword;

    @Column(name="IsForcedVerifyRequired")
    private Boolean isForcedVerifyRequired;

    @Column(name="HideContact")
    private Boolean hideContact;

    @OneToOne
    @JoinColumn(name = "Region_IDREF")
    private Region region;

    public String getName() {
        String firstName = getPerson().getFirstName();
        String lastName = getPerson().getLastName();
        String fathersName = getPerson().getFathersName();
        return StringUtils.join(lastName, " ", firstName, " ", fathersName);
    }
}
