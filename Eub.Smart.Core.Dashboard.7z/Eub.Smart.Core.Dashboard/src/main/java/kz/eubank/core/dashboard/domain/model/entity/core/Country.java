package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "Country")
public class Country {

    @Id
    @Column(name = "Country_ID")
    private String code;

    @Column(name = "Country_ISO")
    private String isoCode;

    @Column(name = "Country_Title")
    private String title;

    @OneToOne
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;
}
