package kz.eubank.core.dashboard.domain.model.dto;

import kz.eubank.core.dashboard.domain.model.response.Account;
import lombok.Generated;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ContractAccount extends Account {

    private String branchTitle;
    private Long dateOpened;
    private String termPeriod;
    private String branchTermId;

    @Generated
    public String toString() {
        return "Contract(branchTitle=" + this.getBranchTitle() + ", dateOpened=" + this.getDateOpened()
                + ", termPeriod=" + this.getTermPeriod() + ", branchTermId=" + this.getBranchTermId() + ")";
    }
}
