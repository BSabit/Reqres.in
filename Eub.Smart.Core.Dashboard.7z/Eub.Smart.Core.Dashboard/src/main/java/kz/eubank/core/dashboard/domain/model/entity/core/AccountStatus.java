package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Setter
@Getter
@Entity
@Table(name = "AccountStatus")
public class AccountStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "AccountStatus_ID")
    private String code;

    @Column(name = "AccountStatus_Title")
    private String title;

    @Column(name = "IsValid")
    private boolean isValid;

    @Column(name = "CanWithdraw")
    private boolean canWithdraw;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;
}
