package kz.eubank.core.dashboard.domain.model.entity;

import kz.eubank.core.dashboard.domain.model.entity.core.Term;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "ServiceField")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
@BatchSize(size = 100)
public class ServiceField {

    @Id
    @Column(name = "ServiceField_ID")
    private long id;

    @Column(name = "Service_IDREF")
    private long service;

    @Column(name = "Name")
    private String name;

    @Column(name = "ServiceField_Title")
    private String title;
    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;

    @OneToOne()
    @JoinColumn(name = "InputType_IDREF")
    private InputType inputType;

    @Column(name = "Priority")
    private int priority;

    @Column(name = "Mask")
    private String mask;
    @Column(name = "Regex")
    private String regex;
    @Column(name = "Size")
    private Long size;


    @Column(name = "IsMandatory")
    private boolean mandatory;
    @Column(name = "IsVisible")
    private boolean visible;
    @Column(name = "IsReadOnly")
    private boolean readOnly;

    @Column(name = "MinValue")
    private BigDecimal minValue;
    @Column(name = "MaxValue")
    private BigDecimal maxValue;

    @Column(name = "DefaultValue")
    private String defaultValue;

    @Column(name = "AllowedValues")
    private String allowedValues;

    @Column(name = "Interchange")
    private String interchange;

    @Column(name = "Preprocessor")
    private String preprocessor;

    @Column(name = "IsServiceDefining")
    private boolean serviceDefining;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getService() {
        return service;
    }

    public void setService(long service) {
        this.service = service;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Term getTerms() {
        return terms;
    }

    public void setTerms(Term terms) {
        this.terms = terms;
    }

    public InputType getInputType() {
        return inputType;
    }

    public void setInputType(InputType inputType) {
        this.inputType = inputType;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public String getMask() {
        return mask;
    }

    public void setMask(String mask) {
        this.mask = mask;
    }

    public String getRegex() {
        return regex;
    }

    public void setRegex(String regex) {
        this.regex = regex;
    }

    public Long getSize() {
        return size;
    }

    public void setSize(Long size) {
        this.size = size;
    }

    public boolean isMandatory() {
        return mandatory;
    }

    public void setMandatory(boolean mandatory) {
        this.mandatory = mandatory;
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public boolean isReadOnly() {
        return readOnly;
    }

    public void setReadOnly(boolean readOnly) {
        this.readOnly = readOnly;
    }

    public String getDefaultValue() {
        return defaultValue;
    }

    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }

    public BigDecimal getMinValue() {
        return minValue;
    }

    public BigDecimal getMaxValue() {
        return maxValue;
    }

    public void setMinValue(BigDecimal minValue) {
        this.minValue = minValue;
    }

    public void setMaxValue(BigDecimal maxValue) {
        this.maxValue = maxValue;
    }

    public String getInterchange() {
        return interchange;
    }

    public void setInterchange(String interchange) {
        this.interchange = interchange;
    }

    public String getAllowedValues() {
        return allowedValues;
    }

    public String getPreprocessor() {
        return preprocessor;
    }

    public void setPreprocessor(String preprocessor) {
        this.preprocessor = preprocessor;
    }

    public boolean isServiceDefining() {
        return serviceDefining;
    }

    public void setServiceDefining(boolean serviceDefining) {
        this.serviceDefining = serviceDefining;
    }

}
