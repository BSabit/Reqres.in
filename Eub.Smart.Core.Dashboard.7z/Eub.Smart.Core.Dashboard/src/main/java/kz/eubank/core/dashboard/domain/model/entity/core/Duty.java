package kz.eubank.core.dashboard.domain.model.entity.core;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "Duty")
public class Duty {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Duty_ID")
    private Long id;

    @Column(name = "Duty_OUTREF")
    private String outref;

    @Column(name = "DateStart")
    private Date dateStart;

    @Column(name = "DateEnd")
    private Date dateEnd;

    @Column(name = "Amount")
    private BigDecimal amount;

    @Column(name = "InterestRate")
    private BigDecimal interestRate;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "Credit_IDREF")
    private Credit credit;

    @OneToOne()
    @JoinColumn(name = "DutyStatus_IDREF")
    private DutyStatus status;

    public Long getId() {
        return id;
    }

    public String getOutref() {
        return outref;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public Date getDateStart() {
        return dateStart;
    }

    public Date getDateEnd() {
        return dateEnd;
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public DutyStatus getStatus() {
        return status;
    }

    public Credit getCredit() {
        return credit;
    }
}
