package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "CardSMSReason")
public class CardSMSReason {

    @Id
    @Column(name = "CardSMSReason_ID")
    private String code;

    @Column(name = "CardSMSReason_Title")
    private String title;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;
}
