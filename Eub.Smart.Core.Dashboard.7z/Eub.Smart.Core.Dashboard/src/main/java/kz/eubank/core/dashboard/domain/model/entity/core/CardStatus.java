package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "CardStatus")
public class CardStatus {

    @Id
    @Column(name = "CardStatus_ID")
    private String code;

    @Column(name = "CardStatus_Title")
    private String title;

    @Column(name = "IsValid")
    private boolean valid;

    @Column(name = "IsClosed")
    private boolean closed;

    @OneToOne
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;

    @Column(name = "IsBlocked")
    private boolean blocked;

    @Column(name = "IsPINSetAllowed")
    private boolean pinSetAllowed;
}
