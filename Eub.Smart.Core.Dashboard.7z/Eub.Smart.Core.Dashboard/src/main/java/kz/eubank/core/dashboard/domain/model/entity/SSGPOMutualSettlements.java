package kz.eubank.core.dashboard.domain.model.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;

@Getter
@Setter
@Entity
@Table(name = "SSGPOMutualSettlements")
public class SSGPOMutualSettlements {

    @Id
    @Column(name = "SSGPOMutualSettlements_ID")
    private String id;

    @OneToOne
    @JoinColumn(name = "SSGPOEmployeesInfo_IDREF")
    private SSGPOEmployeesInfo ssgpoEmployeesInfo;

    @OneToOne
    @JoinColumn(name = "SSGPOCodeDictionary_IDREF")
    private SSGPOCodeDictionary ssgpoCodeDictionary;

    @Column(name = "MutualSettlementPeriod")
    private String mutualSettlementPeriod;

    @Column(name = "AccrualRate")
    private BigDecimal accrualRate;

    @Column(name = "Amount")
    private BigDecimal amount;
}
