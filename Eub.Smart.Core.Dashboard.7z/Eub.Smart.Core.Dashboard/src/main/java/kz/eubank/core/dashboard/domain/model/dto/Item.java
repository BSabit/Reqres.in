package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Item {

    private GeneralInfo generalInfo;
    private MainDebt mainDebt;
    private Interest interest;
    private FeePeriodic feePeriodic;
    private Fine fine;
    private Receivables receivables;
    private Overpayment overpayment;
    private String sourceSystem;
}
