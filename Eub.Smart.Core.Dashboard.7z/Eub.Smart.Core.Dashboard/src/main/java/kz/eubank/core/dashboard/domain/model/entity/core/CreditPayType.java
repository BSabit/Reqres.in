package kz.eubank.core.dashboard.domain.model.entity.core;

import javax.persistence.*;

@Entity
@Table(name = "CreditPayType")
public class CreditPayType {

    @Id
    @Column(name = "CreditPayType_ID")
    private String code;

    @Column(name = "CreditPayType_Title")
    private String title;
    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;

    public String getCode() {
        return this.code;
    }

    public String getTitle() {
        return title;
    }

    public Term getTerms() {
        return terms;
    }

    public void setTerms(Term terms) {
        this.terms = terms;
    }
}
