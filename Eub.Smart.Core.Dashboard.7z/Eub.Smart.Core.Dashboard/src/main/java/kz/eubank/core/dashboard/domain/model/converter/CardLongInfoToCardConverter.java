package kz.eubank.core.dashboard.domain.model.converter;

import kz.eubank.core.dashboard.domain.model.dto.CardLongInfo;
import kz.eubank.core.dashboard.domain.model.dto.CardXml;
import kz.eubank.core.dashboard.domain.model.enums.CardStatus;
import kz.eubank.core.dashboard.domain.model.enums.CardType;
import org.dozer.CustomConverter;
import org.springframework.beans.BeanUtils;

import java.util.Collections;
import java.util.Objects;

public class CardLongInfoToCardConverter implements CustomConverter {

    @Override
    public Object convert(Object dest, Object source, Class<?> arg2, Class<?> arg3) {
        if (source == null) {
            return null;
        }
        if (source instanceof CardLongInfo && arg2.equals(CardXml.class)) {
            CardLongInfo cardLongInfo = (CardLongInfo) source;

            CardXml card = new CardXml();
            card.setId(cardLongInfo.getId());
            card.setNumber(cardLongInfo.getNumber());
            card.setExpiration(cardLongInfo.getExpiration());
            card.setStatus(CardStatus.getValue(cardLongInfo.getStatus().getCode()));
            card.setNameEmbossed(cardLongInfo.getNameEmbossed());
            card.setCardLimitXmls((cardLongInfo.getCardLimitXmls() != null)
                    ? cardLongInfo.getCardLimitXmls() : Collections.emptyList());
            card.setPriority(cardLongInfo.getPriority());
            card.setAllowCNP(cardLongInfo.isAllowCNP());
            card.setCardTransactionStatus(cardLongInfo.getCardTransactionStatus());
            card.setActions(cardLongInfo.getActions());
            card.setHash(cardLongInfo.getHash());
            card.setIsPINSet(cardLongInfo.getIsPINSet());
            card.setIsIVR(cardLongInfo.getIsIVR());
            card.setIsDigital(cardLongInfo.getIsDigital());
            card.setType(Objects.toString(CardType.fromString(cardLongInfo.getTypeTitle()), "0"));//todo check
//            card.setSmsNotificationStatus();//todo fill later
            return card;
        } else if (source instanceof CardXml && arg2.equals(CardLongInfo.class)) {//todo
            CardXml card = (CardXml) source;
            CardLongInfo cardLongInfo = new CardLongInfo();
            BeanUtils.copyProperties(card, cardLongInfo);
            return cardLongInfo;
        }
        return null;
    }
}