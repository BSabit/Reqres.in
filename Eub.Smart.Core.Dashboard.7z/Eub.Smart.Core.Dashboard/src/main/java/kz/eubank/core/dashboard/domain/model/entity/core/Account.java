package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Setter
@Getter
@Entity
@Table(name = "Account")
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Account_ID")
    private Long id;

    @Column(name = "Account_OUTREF")
    private Long outref;

    @Column(name = "Number")
    private String number;

    @OneToOne()
    @JoinColumn(name = "BSystemClient_IDREF")
    private BSystemClient bsystemClient;

    @Column(name = "Account_Title")
    private String title;

    @Column(name = "Currency")
    private String currency;

    @Column(name = "DateOpened")
    private Date dateOpened;

    @Column(name = "DateClosed")
    private Date dateClosed;

    @OneToOne
    @JoinColumn(name = "AccountStatus_IDREF")
    private AccountStatus status;

    @OneToOne()
    @JoinColumn(name = "AccountType_IDREF")
    private AccountType type;

    @Column(name = "Branch_IDREF")
    private Long branchId;

    @Column(name = "IsStaff")
    private boolean staff;

    @Column(name = "IsResident")
    private boolean resident;

    @Column(name = "MinBalance")
    private BigDecimal minBalance;

    @Column(name = "CreditLimit")
    private BigDecimal creditLimit;

    @OneToOne(mappedBy = "account")
    private CorporateAccount corporateAccount;

    @Column(name = "InterestRate")
    private BigDecimal interestRate;

    @Column(name = "Product_IDREF")
    private Long productId;

    @Column(name = "ProductCompound_OUTREF")
    private String productCompoundOutref;

    @Column(name = "IsMultiCurrency")
    private boolean multiCurrency;
}
