package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Setter
@Getter
@Entity
@Table(name = "AccountType")
public class AccountType {

    @Id
    @Column(name = "AccountType_ID")
    private String code;

    @Column(name = "AccountType_Title")
    private String title;

    @Column(name = "UIIcon_IDREF")
    private Long uiIconID;

    @Column(name = "BSystem_IDREF")
    private String bSystemID;

    @OneToOne()
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;
}
