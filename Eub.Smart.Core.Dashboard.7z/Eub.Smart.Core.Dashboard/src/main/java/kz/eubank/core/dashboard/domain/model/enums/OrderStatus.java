package kz.eubank.core.dashboard.domain.model.enums;

public enum OrderStatus {
    DRAFT, ERROR, NEW, IN_PROCESS, DONE, REJECTED, TEMPLATE, STANDING_ORDER, CANCELED
}
