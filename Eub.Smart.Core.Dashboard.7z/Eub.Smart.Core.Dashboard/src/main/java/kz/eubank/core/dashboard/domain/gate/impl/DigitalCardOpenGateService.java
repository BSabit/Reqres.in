package kz.eubank.core.dashboard.domain.gate.impl;

import kz.eubank.core.dashboard.domain.gate.DigitalCardOpenGate;
import kz.eubank.core.dashboard.domain.model.dto.TempDigitalCard;
import kz.eubank.core.dashboard.domain.model.mapper.TempDigitalCardMapper;
import kz.eubank.core.dashboard.domain.repository.TempDigitalCardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DigitalCardOpenGateService implements DigitalCardOpenGate {

    @Autowired
    private TempDigitalCardRepository tempDigitalCardRepository;
    @Autowired
    private TempDigitalCardMapper tempDigitalCardMapper;

    @Override
    public List<TempDigitalCard> getTempCards(Long userId) {
        List<kz.eubank.core.dashboard.domain.model.entity.TempDigitalCard> tempCards = tempDigitalCardRepository.findAllTempCardsForUser(userId);
        return tempDigitalCardMapper.toTempDigitalCardDtoList(tempCards);
    }
}
