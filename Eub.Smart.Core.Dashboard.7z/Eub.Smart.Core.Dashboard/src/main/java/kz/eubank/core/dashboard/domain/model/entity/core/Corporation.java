package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name = "Corporation")
public class Corporation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Corporation_ID")
    private Long id;

    @Column(name = "Corporation_Title")
    private String title;

    @Column(name = "RegistrationDate")
    private Date registrationDate;

    @Column(name = "IsResident")
    private boolean resident;

    @Column(name = "IsAffiliated")
    private boolean affiliated;

    @Column(name = "RNN")
    private String rnn;

    @Column(name = "BIN")
    private String bin;

    @OneToOne()
    @JoinColumn(name = "CorporationStatus_IDREF")
    private CorporationStatus status;
}
