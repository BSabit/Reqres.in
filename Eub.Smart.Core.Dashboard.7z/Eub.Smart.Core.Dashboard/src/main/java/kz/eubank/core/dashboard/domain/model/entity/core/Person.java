package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;
import org.apache.logging.log4j.util.Strings;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "Person")
public class Person {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "Person_ID")
    private Long id;

    @Column(name = "FirstName")
    private String firstName;

    @Column(name = "LastName")
    private String lastName;

    @Column(name = "FathersName")
    private String fathersName;

    @Column(name = "BirthDate")
    private Date birthDate;

    @Column(name = "IsResident")
    private boolean resident;

    @Column(name = "IsAffiliated")
    private boolean affiliated;

    @Column(name = "HasSalaryAccount")
    private boolean salaryAccount;

    @Column(name = "IsEmployee")
    private boolean employee;

    @Column(name = "IIN")
    private String iin;

    @Column(name = "RNN")
    private String rnn;

    @OneToOne
    @JoinColumn(name = "PersonStatus_IDREF")
    private PersonStatus status;

    @OneToOne
    @JoinColumn(name = "Gender_IDREF")
    private Gender gender;

    @OneToOne
    @JoinColumn(name = "ClientRank_IDREF")
    private ClientRank clientRank;

    @Column(name = "BirthPlace")
    private String birthPlace;

    @Column(name = "IsSSGPO")
    private boolean ssgpo;

    public String getFIO(){
        return Strings.trimToNull(this.lastName + " " + this.firstName + " " + this.fathersName);
    }
}
