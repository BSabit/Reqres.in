package kz.eubank.core.dashboard.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class Corporation {

    private Long id;
    private String title;
    private Date registrationDate;
    private boolean resident;
    private boolean affiliated;
    private String rnn;
    private String bin;
}
