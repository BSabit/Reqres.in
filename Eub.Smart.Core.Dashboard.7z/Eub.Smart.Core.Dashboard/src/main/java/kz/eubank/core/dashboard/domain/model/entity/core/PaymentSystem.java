package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "PaymentSystem")
public class PaymentSystem {

    @Id
    @Column(name = "PaymentSystem_ID")
    private String code;

    @Column(name = "PaymentSystem_Title")
    private String title;

    @OneToOne
    @JoinColumn(name = "Term_OUTREF")
    private Term terms;
}
