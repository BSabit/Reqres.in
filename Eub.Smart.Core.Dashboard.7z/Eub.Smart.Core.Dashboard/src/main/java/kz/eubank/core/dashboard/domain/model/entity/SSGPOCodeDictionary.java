package kz.eubank.core.dashboard.domain.model.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "SSGPOCodeDictionary")
public class SSGPOCodeDictionary {

    @Id
    @Column(name = "SSGPOCodeDictionary_ID")
    private String id;

    @Column(name = "Code")
    private String code;

    @Column(name = "CodeDescKz")
    private String codeDescKz;

    @Column(name = "CodeDescRu")
    private String codeDescRu;

    @Column(name = "CodeDescShortKz")
    private String codeDescShortKz;

    @Column(name = "CodeDescShortRu")
    private String codeDescShortRu;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "SSGPOCodeType_IDREF")
    private SSGPOCodeType ssgpoCodeType;
}
