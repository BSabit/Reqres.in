package kz.eubank.core.dashboard.domain.model.entity.core;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "LoanCalcInfo")
public class LoanCalcInfo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "LoanCalcInfo_ID")
    private Long id;

    @Column(name = "DateCreated")
    private Date dateCreated;

    @Column(name = "FullAmount")
    private BigDecimal fullAmount;

    @Column(name = "Period")
    private int period;

    @Column(name = "PaymentAmountSum")
    private BigDecimal paymentAmountSum;

    @Column(name = "PaymentDay")
    private int paymentDay;

    @Column(name = "TarifCode")
    private String tarifCode;

    @Column(name = "InsurancePackageCode")
    private String insurancePackageCode;

    @Column(name = "InsurancePackageType")
    private String insurancePackageType;

    @Column(name = "Amount")
    private BigDecimal amount;

    @Column(name = "FileStorage_OUTREF")
    private Integer fileStorage;
}