package kz.eubank.core.dashboard.infrastructure.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@Configuration
@ConfigurationProperties(prefix = "kz.eubank")
@ComponentScan("kz.eubank.core.dashboard.infrastructure.config")
@EnableJpaRepositories("kz.eubank.core.dashboard.domain.repository")
@EntityScan("kz.eubank.core.dashboard.domain.model")
public class CoreConfig {
}
