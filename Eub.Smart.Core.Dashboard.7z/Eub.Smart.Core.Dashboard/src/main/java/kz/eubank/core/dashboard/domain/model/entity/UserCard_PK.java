package kz.eubank.core.dashboard.domain.model.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Getter
@Setter
@Embeddable
public class UserCard_PK implements Serializable {

    private static final long serialVersionUID = -4863122316010468191L;

    @Column(name = "User_IDREF")
    private Long userId;

    @Column(name = "Card_IDREF")
    private Long cardId;

    @Override
    public int hashCode() {
        return userId.hashCode() + cardId.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this)
            return true;
        if (!(obj instanceof UserCard_PK))
            return false;
        UserCard_PK pk = (UserCard_PK) obj;
        return pk.userId.equals(userId);
    }
}
