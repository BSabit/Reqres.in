package eub.smart.cardproduct.transfer.self;

import eub.smart.cardproduct.transfer.self.domain.model.limit.SpentAmount;
import eub.smart.cardproduct.transfer.self.domain.repository.LimitAccountDayRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.LimitUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.impl.LimitAccountDayUseCaseImpl;
import eub.smart.cardproduct.transfer.self.domain.use_case.impl.LimitFinDocUseCaseImpl;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

public class LimitAccountDayTest {
    LimitAccountDayRepository limitAccountDayRepository = Mockito.mock(LimitAccountDayRepository.class);
    LimitUseCase limitUseCase = Mockito.mock(LimitUseCase.class);
    LimitFinDocUseCaseImpl finDocUseCase = Mockito.mock(LimitFinDocUseCaseImpl.class);
    LimitAccountDayUseCaseImpl useCase = new LimitAccountDayUseCaseImpl(limitAccountDayRepository, finDocUseCase, limitUseCase);

    @Test
    public void whenEmptySpentAmountExpectValueLimitUseCaseInvokeFail() {
        BigDecimal limitDay = BigDecimal.valueOf(1000);
        String accountNumber = "123456";
        String correlationId = "correlation123";
        BigDecimal amount = BigDecimal.valueOf(500);
        String currency = "USD";

        when(limitAccountDayRepository.findByAccountNumber(any(), eq(accountNumber))).thenReturn(new ArrayList<>());
        finDocUseCase.invoke(limitDay, amount, currency, correlationId);
        useCase.invoke(limitDay, accountNumber, correlationId, amount, currency);
    }

    @Test
    public void whenNonEmptySpentAmountExpectValueLimitUseCaseInvoke() {
        BigDecimal limitDay = BigDecimal.valueOf(1000);
        String accountNumber = "123456";
        String correlationId = "correlation123";
        BigDecimal amount = BigDecimal.valueOf(1500);
        String currency = "USD";

        LocalDate currentDate  = LocalDate.now();
        List<SpentAmount> spentAmountGroupByCurrency = new ArrayList<>();
        spentAmountGroupByCurrency.add(new SpentAmount("USD", "USD", new BigDecimal("500")));

        when(limitAccountDayRepository.findByAccountNumber(currentDate, accountNumber)).thenReturn(spentAmountGroupByCurrency);
        useCase.invoke(limitDay, accountNumber, correlationId, amount, currency);
        verify(limitUseCase).invoke(eq(limitDay), eq(correlationId), eq(amount), eq(currency), eq(false), eq(spentAmountGroupByCurrency));
    }
}
