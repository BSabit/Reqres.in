package eub.smart.cardproduct.transfer.self;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SelfApplicationTests {
}
