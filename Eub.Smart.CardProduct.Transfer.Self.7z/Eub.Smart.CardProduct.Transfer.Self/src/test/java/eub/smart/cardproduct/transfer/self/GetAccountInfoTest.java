//package eub.smart.cardproduct.transfer.self;
//
//import eub.smart.cardproduct.transfer.self.domain.model.AccountInfo;
//import eub.smart.cardproduct.transfer.self.domain.model.NewTransferAccount;
//import eub.smart.cardproduct.transfer.self.domain.repository.AccountRepository;
//import eub.smart.cardproduct.transfer.self.domain.use_case.impl.GetAccountInfoUseCaseImpl;
//import org.junit.Test;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.Mockito.mock;
//import static org.mockito.Mockito.when;
//
//public class GetAccountInfoTest {
//    AccountRepository accountRepository = mock(AccountRepository.class);
//    GetAccountInfoUseCaseImpl useCase = new GetAccountInfoUseCaseImpl(accountRepository);
//
//    @Test
//    public void whenIsOldMultiCurrencyExpectValueShortText() {
//        String accountNumber = "12345";
//        String currency = "USD";
//        AccountInfo mockAccountInfo = new AccountInfo();
//        mockAccountInfo.setNumber(accountNumber);
//        mockAccountInfo.setCurrency(currency);
//
//        when(accountRepository.findByNumberOrException(accountNumber)).thenReturn(mockAccountInfo);
//        NewTransferAccount result = useCase.invoke(accountNumber, currency);
//
//        assertEquals(result.getNumber(), accountNumber);
//        assertEquals(result.getCurrency(), currency);
//    }
//}
