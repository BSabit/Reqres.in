package eub.smart.cardproduct.transfer.self;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.use_case.impl.GetSelfMultiTypeUseCaseImpl;
import org.junit.jupiter.api.Test;


import static eub.smart.cardproduct.transfer.self.core.constant.SelfMultiType.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class GetSelfMultiTypeTest {
    GetSelfMultiTypeUseCaseImpl useCase = new GetSelfMultiTypeUseCaseImpl();

    @Test
    public void whenBothMultiFlagTrueAndBothIdRefEqualExpectValueNewMulti() {
        AccountData sender = mock(AccountData.class);
        AccountData receiver = mock(AccountData.class);
        when(sender.getFlagMulti()).thenReturn(true);
        when(receiver.getFlagMulti()).thenReturn(true);

        String result = useCase.invoke(sender, receiver);
        assertEquals(NEW_MULTI, result);
    }

    @Test
    public void whenBothMultiFlagTrueAndIdRefDifferentButAccountNumberEqualExpectValueOldMulti() {
        AccountData sender = mock(AccountData.class);
        AccountData receiver = mock(AccountData.class);
        when(sender.getFlagMulti()).thenReturn(true);
        when(receiver.getFlagMulti()).thenReturn(true);
        when(sender.getAccountIdRef()).thenReturn(1L);
        when(receiver.getAccountIdRef()).thenReturn(2L);
        when(sender.getAccountNumber()).thenReturn("12345");
        when(receiver.getAccountNumber()).thenReturn("12345");

        String result = useCase.invoke(sender, receiver);
        assertEquals(OLD_MULTI, result);
    }

    @Test
    public void whenOneMultiFlagFalseAndBothIdRefEqualExpectValueNonSelf() {
        AccountData sender = mock(AccountData.class);
        AccountData receiver = mock(AccountData.class);
        when(sender.getFlagMulti()).thenReturn(false);
        when(receiver.getFlagMulti()).thenReturn(false);

        String result = useCase.invoke(sender, receiver);
        assertEquals(NON_SELF, result);
    }
}
