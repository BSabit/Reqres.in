package eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc;

import TransferSelf.EubAggregatorCardProductTransferSelf;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.UfxResponse;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.UfxTransferRequest;
import eub.smart.cardproduct.transfer.self.core.util.GrpcUtil;

import static eub.smart.cardproduct.transfer.self.core.util.GrpcUtil.toAggregatorCurrencyCode;

public class TransferSelfMapper {

    public static TransferSelf.EubAggregatorCardProductTransferSelf.UfxTransferRq toProtoModel(UfxTransferRequest requestModel) {
        return EubAggregatorCardProductTransferSelf.UfxTransferRq
                .newBuilder()
                .setFindoc(requestModel.getFindoc())
                .setRrn(requestModel.getRrn())
                .setBrrn(requestModel.getBrrn())
                .setStan(requestModel.getStan())
                .setOperationAccount(requestModel.getOperationAccount())
                .setOperationSum(GrpcUtil.toDecimalValue(requestModel.getOperationSum()))
                .setOperationCurrency(toAggregatorCurrencyCode(requestModel.getOperationCurrency()))
                .setLinkedOperationAccount(requestModel.getLinkedOperationAccount())
                .setIsDeposit(requestModel.getDeposit())
                .setDetails(requestModel.getDetails())
                .build();
    }

    public static UfxResponse toDomainModel(TransferSelf.EubAggregatorCardProductTransferSelf.UfxResponse response) {
        UfxResponse domainModel = new UfxResponse();
        domainModel.setStatus(response.getStatus());
        domainModel.setErrorMessage(response.getErrorMessage());
        return domainModel;
    }
}
