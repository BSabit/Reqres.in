package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4ToWay4Credit;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.scanner.MapResultScanner;

import java.util.Map;

public class TransferWay4ToWay4CreditMapper {

    public static TransferWay4ToWay4Credit toDomainModel(Map<String, Object> row, Long finDocId, String stun, RrnBrrn rrnBrrn) {
        MapResultScanner scanner = new MapResultScanner(row);

        TransferWay4ToWay4Credit request = new TransferWay4ToWay4Credit();
        request.setFindoc(finDocId.toString());
        request.setRrn(rrnBrrn.getBrrn());
        request.setBrrn(rrnBrrn.getRrn());
        request.setStan(stun);
        request.setOperationAccount(scanner.getString("receiverAccountNumber"));
        request.setLinkedOperationAccount(scanner.getString("senderAccountNumber"));
        request.setSenderAmount(scanner.getBigDecimal("senderAmount"));
        request.setReceiverAmount(scanner.getBigDecimal("receiverAmount"));
        request.setSenderCurrency(scanner.getString("senderCurrency"));
        request.setReceiverCurrency(scanner.getString("receiverCurrency"));
        request.setReceiverFlagMultiCurrency(scanner.getBoolean("receiverFlagMultiCurrency"));
        request.setReceiverAccountIdRef(scanner.getLong("receiverAccountIdRef"));
        request.setSenderFlagMultiCurrency(scanner.getBoolean("senderFlagMultiCurrency"));
        request.setDeposit(false);
        request.setDetails(createDetails(scanner));
        return request;
    }

    private static String createDetails(MapResultScanner scanner) {
        String fullname = scanner.getString("receiverFullname");
        String accountNumber = scanner.getString("receiverAccountNumber");
        return String.format("%s; %s", fullname, accountNumber);
    }
}
