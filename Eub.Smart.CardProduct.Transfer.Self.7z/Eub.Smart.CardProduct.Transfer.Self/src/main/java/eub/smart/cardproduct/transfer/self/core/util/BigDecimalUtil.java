package eub.smart.cardproduct.transfer.self.core.util;

import java.math.BigDecimal;

public class BigDecimalUtil {

    public static boolean isNullOrZero(BigDecimal decimal){
        return decimal == null || decimal.compareTo(new BigDecimal("0")) == 0;
    }
}
