package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.repository.LimitClientNightRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.LimitClientNightUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.LimitFinDocUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.LimitUseCase;

import java.math.BigDecimal;
import java.time.LocalDate;

import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isEmpty;

public class LimitClientNightUseCaseImpl implements LimitClientNightUseCase {

    private final LimitClientNightRepository limitClientNightRepository;
    private final LimitFinDocUseCase finDocUseCase;
    private final LimitUseCase limitUseCase;

    public LimitClientNightUseCaseImpl(LimitClientNightRepository limitClientNightRepository,
                                       LimitFinDocUseCase finDocUseCase,
                                       LimitUseCase limitUseCase) {
        this.limitClientNightRepository = limitClientNightRepository;
        this.finDocUseCase = finDocUseCase;
        this.limitUseCase = limitUseCase;
    }

    @Override
    public void invoke(BigDecimal limitNight, Long clientId, Long userId, BigDecimal amount, String currency, String correlationId, Boolean convert) {
        var currentDate = LocalDate.now();
        var spentAmountGroupByCurrency = limitClientNightRepository.findByClientIdAndUserId(currentDate, clientId, userId);
        if (isEmpty(spentAmountGroupByCurrency)) finDocUseCase.invoke(limitNight, amount, currency, correlationId);
        limitUseCase.invoke(limitNight, correlationId, amount, currency, convert, spentAmountGroupByCurrency);
    }

}
