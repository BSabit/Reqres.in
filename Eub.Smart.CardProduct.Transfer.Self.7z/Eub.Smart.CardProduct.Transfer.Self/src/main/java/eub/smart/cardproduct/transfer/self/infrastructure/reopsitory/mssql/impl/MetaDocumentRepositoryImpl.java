package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.out.MetaDocumentOut;
import eub.smart.cardproduct.transfer.self.domain.repository.MetaDocumentRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.MetaDocumentMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isOneResult;

@Repository
public class MetaDocumentRepositoryImpl implements MetaDocumentRepository {

    private final NamedParameterJdbcTemplate template;
    private final String s3Url;

    public MetaDocumentRepositoryImpl(NamedParameterJdbcTemplate template,
                                      @Value("${app.s3-download-address}") String s3Url) {
        this.template = template;
        this.s3Url = s3Url;
    }

    @Override
    public Optional<MetaDocumentOut> find(Long targetId, String targetTable, String docType) {
        Map<String, Object> map = Map.of(
                "targetId", targetId,
                "targetTable", targetTable,
                "docType", docType);

        String sql = """ 
                select MD.FileUid   as uid,
                       DT.Extension as format
                from MetaDocument MD
                         join DocumentType DT on MD.DocumentType_IDREF = DT.DocumentType_ID
                where MD.Target_ID = :targetId
                  and MD.Target_Table = :targetTable
                  and MD.DocumentType_IDREF = :docType;
                """;

        List<MetaDocumentOut> queryResult = template.query(sql, map, (resultSet, i) -> MetaDocumentMapper.toDomain(resultSet, s3Url));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": MetaDocumentRepository find");
        }
    }

    @Override
    public MetaDocumentOut findOrException(Long targetId, String targetTable, String docType) {
        return find(targetId, targetTable, docType)
                .orElseThrow(() -> new SelfException(E_DB_600, ": MetaDocumentRepository findOrException"));
    }
}
