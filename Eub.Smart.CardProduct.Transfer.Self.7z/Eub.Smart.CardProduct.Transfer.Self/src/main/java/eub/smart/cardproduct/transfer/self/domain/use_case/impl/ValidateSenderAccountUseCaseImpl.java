package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.core.util.LangUtil;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.repository.MessageSourceRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.ValidateSenderAccountUseCase;

import static eub.smart.cardproduct.transfer.self.core.constant.BundleCode.ERROR_MESSAGE_VLSS;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_LG_800_VLSS;
import static eub.smart.cardproduct.transfer.self.core.constant.AccountStatus.ACTV;

public class ValidateSenderAccountUseCaseImpl extends AbstractValidateAccountUseCase implements ValidateSenderAccountUseCase {

    private final MessageSourceRepository messageSourceRepository;

    public ValidateSenderAccountUseCaseImpl(MessageSourceRepository messageSourceRepository) {
        this.messageSourceRepository = messageSourceRepository;
    }

    @Override
    public void invoke(AccountData accountData, LangKey lang) {
        var bSystemType = accountData.getbSystem();
        var accountStatus = accountData.getAccountStatus();
        invoke(accountStatus, bSystemType, lang);
    }

    @Override
    public void validateWay4Acc(String accountStatus, LangKey lang) {
        if (!ACTV.equals(accountStatus)) {
            var locale = LangUtil.get(lang);
            var message = messageSourceRepository.getMessage(ERROR_MESSAGE_VLSS, locale);
            throw new SelfException(
                    E_LG_800_VLSS,
                    ": Way4 sender acc status " + accountStatus,
                    message);
        }
    }

    @Override
    public void validateRsbkAcc(String accountStatus, LangKey lang) {
        if (!RSBK_ACC_VALID_STATUS.contains(accountStatus)) {
            var locale = LangUtil.get(lang);
            var message = messageSourceRepository.getMessage(ERROR_MESSAGE_VLSS, locale);
            throw new SelfException(
                    E_LG_800_VLSS,
                    ": RSBK sender acc status " + accountStatus,
                    message);
        }
    }
}
