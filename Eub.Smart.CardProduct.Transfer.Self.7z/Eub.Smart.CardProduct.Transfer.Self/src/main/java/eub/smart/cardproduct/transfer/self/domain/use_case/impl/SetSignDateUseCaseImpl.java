package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.FinDoc;
import eub.smart.cardproduct.transfer.self.domain.repository.FinDocRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.SetSignDateUseCase;

import java.util.Date;

public class SetSignDateUseCaseImpl implements SetSignDateUseCase {

    private final FinDocRepository finDocRepository;

    public SetSignDateUseCaseImpl(FinDocRepository finDocRepository) {
        this.finDocRepository = finDocRepository;
    }

    @Override
    public Date invoke(Long finDocId) {
        var dateSigned = new Date();
        FinDoc finDoc = finDocRepository.findByIdOrException(finDocId);
        finDoc.setDateSigned(dateSigned);
        finDocRepository.save(finDoc);
        return dateSigned;
    }
}
