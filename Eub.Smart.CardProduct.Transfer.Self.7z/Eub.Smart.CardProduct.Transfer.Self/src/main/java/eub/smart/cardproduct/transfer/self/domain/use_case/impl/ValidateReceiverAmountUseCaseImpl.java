package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.use_case.GetConvertingInfoUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.ValidateReceiverAmountUseCase;
import org.slf4j.MDC;

import java.math.BigDecimal;
import java.math.RoundingMode;

import static eub.smart.cardproduct.transfer.self.core.constant.HeaderName.CORRELATION_ID;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_VD_400;

public class ValidateReceiverAmountUseCaseImpl implements ValidateReceiverAmountUseCase {

    private final GetConvertingInfoUseCase getConvertingInfoUseCase;

    public ValidateReceiverAmountUseCaseImpl(GetConvertingInfoUseCase getConvertingInfoUseCase) {
        this.getConvertingInfoUseCase = getConvertingInfoUseCase;
    }

    @Override
    public void invoke(BigDecimal senderAmount, BigDecimal receiverAmount, String senderAccountCurrency, String receiverAccountCurrency) {
        BigDecimal receiverAmountScaled = receiverAmount.setScale(2, RoundingMode.HALF_DOWN);
        var convertingInfo = getConvertingInfoUseCase.invoke(senderAmount, senderAccountCurrency, receiverAccountCurrency, MDC.get(CORRELATION_ID));
        if (isNotEqual(receiverAmountScaled, convertingInfo.getReceiverAmount())) {
            throw new SelfException(E_VD_400, ": request receiver amount is not correct, request amount: "
                    + receiverAmountScaled + ", calculated amount: " + convertingInfo.getReceiverAmount());
        }
    }

    private boolean isNotEqual(BigDecimal requestAmount, BigDecimal calculatedAmount) {
        return requestAmount.compareTo(calculatedAmount) != 0;
    }
}
