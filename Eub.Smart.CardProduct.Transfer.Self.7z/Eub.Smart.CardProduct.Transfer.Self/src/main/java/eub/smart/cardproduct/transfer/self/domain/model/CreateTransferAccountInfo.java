package eub.smart.cardproduct.transfer.self.domain.model;

public class CreateTransferAccountInfo {

    private Long id;
    private String type;
    private String currency;
    private String number;
    private Long clientIdRef;
    private Boolean residentFlag;

    public CreateTransferAccountInfo() {
    }

    public CreateTransferAccountInfo(AccountInfo accountInfo) {
        this.id = accountInfo.getId();
        this.type = accountInfo.getType();
        this.currency = accountInfo.getCurrency();
        this.number = accountInfo.getNumber();
        this.clientIdRef = accountInfo.getClientIdRef();
        this.residentFlag = accountInfo.getResidentFlag();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Long getClientIdRef() {
        return clientIdRef;
    }

    public void setClientIdRef(Long clientIdRef) {
        this.clientIdRef = clientIdRef;
    }

    public Boolean getResidentFlag() {
        return residentFlag;
    }

    public void setResidentFlag(Boolean residentFlag) {
        this.residentFlag = residentFlag;
    }

    @Override
    public String toString() {
        return "NewTransferAccount{" +
                "id=" + id +
                ", type=" + type +
                ", currency=" + currency +
                ", number=" + number +
                ", clientIdRef=" + clientIdRef +
                ", residentFlag=" + residentFlag +
                '}';
    }
}
