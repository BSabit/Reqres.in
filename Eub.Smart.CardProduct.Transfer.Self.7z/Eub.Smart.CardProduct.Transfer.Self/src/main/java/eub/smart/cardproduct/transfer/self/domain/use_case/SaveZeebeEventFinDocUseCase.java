package eub.smart.cardproduct.transfer.self.domain.use_case;

public interface SaveZeebeEventFinDocUseCase {

    void invoke(Long finDocId);
}
