package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.UfxTransferRequest;

import java.util.Optional;

public interface TransferRsbkToWay4DebitTransitRepository {

    Optional<UfxTransferRequest> findByFinDocId(Long finDocId, String stun, RrnBrrn rrnBrrn, String operationAccount);

    UfxTransferRequest findByFinDocIdOrException(Long finDocId, String stun, RrnBrrn rrnBrrn, String operationAccount);
}
