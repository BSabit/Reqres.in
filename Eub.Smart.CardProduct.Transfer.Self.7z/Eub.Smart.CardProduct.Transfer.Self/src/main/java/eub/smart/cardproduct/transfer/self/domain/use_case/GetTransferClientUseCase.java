package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.NewTransferClient;

public interface GetTransferClientUseCase {

    NewTransferClient invoke(String accountNumber);
}
