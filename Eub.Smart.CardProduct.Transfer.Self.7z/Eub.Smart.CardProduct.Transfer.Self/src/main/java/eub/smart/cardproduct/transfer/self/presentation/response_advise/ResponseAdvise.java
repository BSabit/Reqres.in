package eub.smart.cardproduct.transfer.self.presentation.response_advise;

import eub.smart.cardproduct.transfer.self.presentation.model.ServiceResponse;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.MethodParameter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_VD_401;
import static org.springframework.http.HttpStatus.*;

@ControllerAdvice
public class ResponseAdvise extends ResponseEntityExceptionHandler implements ResponseBodyAdvice<Object> {

    private final Logger log = LogManager.getLogger(getClass());

    @Override
    public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
        return true;
    }

    @Override
    public Object beforeBodyWrite(Object o, MethodParameter methodParameter, MediaType mediaType, Class aClass, ServerHttpRequest serverHttpRequest, ServerHttpResponse serverHttpResponse) {
        if (methodParameter.getContainingClass().isAnnotationPresent(ResponseBinding.class) &&
                methodParameter.getContainingClass().isAnnotationPresent(RestController.class)) {
            ServiceResponse<Object> responseBody = new ServiceResponse<>();
            if (o instanceof String s) return responseBody.successResponse(s).json();
            return responseBody.successResponse(o);
        }
        return o;
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        List<String> errors = new ArrayList<>();
        ex.getBindingResult().getFieldErrors().forEach(fieldError -> {
            String defaultMessage = fieldError.getDefaultMessage();
            String fieldName = fieldError.getField();
            errors.add(String.format("Field: %s %s", fieldName, defaultMessage));
        });
        log.error("Request validate error: {}", errors);
        ServiceResponse<Object> responseBody = new ServiceResponse<>();
        responseBody.errorResponse(new SelfException(E_VD_401, ": " + errors));
        return new ResponseEntity<>(responseBody, BAD_REQUEST);
    }

    @ExceptionHandler(value = RuntimeException.class)
    protected ResponseEntity<Object> handleConflict(RuntimeException exception) {

        if (exception instanceof SelfException) {
            ServiceResponse<Object> responseBody = new ServiceResponse<>();
            responseBody.errorResponse((SelfException) exception);
            log.error("Event-Type=REST, Error: [code={}, message={}, stackTrace={}]",
                    ((SelfException) exception).getCode(),
                    exception.getMessage(),
                    exception.getStackTrace());

            switch (((SelfException) exception).getCode()) {
                case E_DB_605:
                    Page<Object> emptyPage = new PageImpl<>(Collections.emptyList(), Pageable.ofSize(20), 0);
                    responseBody.setBody(emptyPage);
                    return new ResponseEntity<>(responseBody , OK);
                case E_EX_701:
                    return new ResponseEntity<>(responseBody, SERVICE_UNAVAILABLE);
                default:
                    return new ResponseEntity<>(responseBody, INTERNAL_SERVER_ERROR);
            }
        } else {
            log.error("Event-Type=REST, Error: [code={}, message={}, stackTrace={}]",
                    -1,
                    exception.getMessage(),
                    exception.getStackTrace());

            return new ResponseEntity<>(exception, INTERNAL_SERVER_ERROR);
        }
    }
}
