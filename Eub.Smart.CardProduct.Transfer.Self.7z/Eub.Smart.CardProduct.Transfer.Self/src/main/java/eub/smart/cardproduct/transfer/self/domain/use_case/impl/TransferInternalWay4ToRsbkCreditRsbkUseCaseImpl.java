package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4ToRsbkCreditRsbk;
import eub.smart.cardproduct.transfer.self.domain.repository.RsbkTransactionalProtoRepository;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferWay4ToRsbkCreditRsbkRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.TransferInternalWay4ToRsbkCreditRsbkUseCase;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.TransferWay4ToRsbkRequestMapper;

public class TransferInternalWay4ToRsbkCreditRsbkUseCaseImpl implements TransferInternalWay4ToRsbkCreditRsbkUseCase {

    private final RsbkTransactionalProtoRepository rsbkTransactionalProtoRepository;
    private final String dboIdPrefix;

    public TransferInternalWay4ToRsbkCreditRsbkUseCaseImpl(RsbkTransactionalProtoRepository rsbkTransactionalProtoRepository,
                                                           String dboIdPrefix) {
        this.rsbkTransactionalProtoRepository = rsbkTransactionalProtoRepository;
        this.dboIdPrefix = dboIdPrefix;
    }

    @Override
    public TransferWay4ToRsbkCreditRsbk invoke(FinDocData finDocData, AccountData senderData, AccountData receiverData) {
        var request = TransferWay4ToRsbkRequestMapper.createRequest(finDocData, senderData, receiverData, dboIdPrefix);
        var response = rsbkTransactionalProtoRepository.transferWay4ToRsbkCreditRsbk(request);
        return new TransferWay4ToRsbkCreditRsbk(request, response);
    }
}
