package eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc;

import DashboardInfo.V1.EubAggregatorCoreDashboard;
import eub.smart.cardproduct.transfer.self.domain.model.out.infrastructure.ValidateAccountAmountOut;

public class GetAggregateAccountsMapper {

    public static EubAggregatorCoreDashboard.AggregateAccountsRequest buildRequest(ValidateAccountAmountOut accountData) {
        var bSystemType = EubAggregatorCoreDashboard.BSystemType
                .valueOf(accountData.bSystem());
        var entityId = EubAggregatorCoreDashboard.EntityId
                .newBuilder()
                .setBSystem(bSystemType)
                .setType("")
                .setValue(String.valueOf(accountData.accountOutRef()))
                .build();
        return EubAggregatorCoreDashboard.AggregateAccountsRequest
                .newBuilder()
                .addAccountId(entityId)
                .setTotalBalanceCurrency(EubAggregatorCoreDashboard.CurrencyCode.KZT)
                .build();
    }
}
