package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToRsbk;

public interface RsbkToRsbkSaveResultUseCase {

    void invoke(Long finDocId, TransferRsbkToRsbk transferRsbkToRsbk);
}
