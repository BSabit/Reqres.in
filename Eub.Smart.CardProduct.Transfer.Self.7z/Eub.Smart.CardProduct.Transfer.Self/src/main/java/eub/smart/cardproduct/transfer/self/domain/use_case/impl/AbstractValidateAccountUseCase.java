package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;

import java.util.Set;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_LG_802;
import static eub.smart.cardproduct.transfer.self.core.constant.AccountStatus.*;
import static eub.smart.cardproduct.transfer.self.core.constant.AccountStatus.CRBA;
import static eub.smart.cardproduct.transfer.self.core.constant.BSystemType.RSBK;
import static eub.smart.cardproduct.transfer.self.core.constant.BSystemType.WAY4;

public abstract class AbstractValidateAccountUseCase {

    public final Set<String> RSBK_ACC_VALID_STATUS = Set.of(ACTV, PRBL);
    public final Set<String> WAY4_RECEIVER_ACC_VALID_STATUS = Set.of(ACTV, SUSP, CRBA);

    public abstract void validateWay4Acc(String accountStatus, LangKey lang);

    public abstract void validateRsbkAcc(String accountStatus, LangKey lang);

    public void invoke(String accountStatus, String bSystemType, LangKey lang) {
        if (WAY4.equals(bSystemType)) validateWay4Acc(accountStatus, lang);
        else if (RSBK.equals(bSystemType)) validateRsbkAcc(accountStatus, lang);
        else throw new SelfException(E_LG_802, ": for BSystem type " + bSystemType);
    }
}
