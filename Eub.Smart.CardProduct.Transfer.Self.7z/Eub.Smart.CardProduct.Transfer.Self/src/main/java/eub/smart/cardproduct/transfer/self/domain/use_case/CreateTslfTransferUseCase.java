package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.in.presentation.CreateTransferTslfPIn;

public interface CreateTslfTransferUseCase {

    Long invoke(CreateTransferTslfPIn in);
}
