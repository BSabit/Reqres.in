package eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.CurrencyRate;
import rsbkinfo.V1.EubAdapterRsbkInfo;

import java.math.BigDecimal;

import static eub.smart.cardproduct.transfer.self.core.util.GrpcUtil.toAdapterCurrencyCode;
import static eub.smart.cardproduct.transfer.self.core.util.GrpcUtil.toBigDecimal;

public class GetCurrencyRatesListMapper {

    public static EubAdapterRsbkInfo.RsbkGetCurrencyRatesRequest toGrpcModel(String currency) {
        return EubAdapterRsbkInfo.RsbkGetCurrencyRatesRequest
                .newBuilder()
                .addCurrencyCodes(toAdapterCurrencyCode(currency))
                .build();
    }

    public static CurrencyRate toDomainModel(EubAdapterRsbkInfo.RsbkGetCurrencyRatesReply response) {
        EubAdapterRsbkInfo.CurrencyRate currencyRate = response.getCurrencyRates(0);
        BigDecimal buyRate = toBigDecimal(currencyRate.getBuyRate());
        BigDecimal sellRate = toBigDecimal(currencyRate.getSellRate());
        return new CurrencyRate(buyRate, sellRate);
    }
}
