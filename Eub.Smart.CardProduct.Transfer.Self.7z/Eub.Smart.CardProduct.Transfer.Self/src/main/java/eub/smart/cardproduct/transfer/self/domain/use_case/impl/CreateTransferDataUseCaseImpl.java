package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.in.presentation.CreateTransferDataPIn;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.DomainMapper;
import eub.smart.cardproduct.transfer.self.domain.model.Transfer;
import eub.smart.cardproduct.transfer.self.domain.model.create_transfer.CreateTransfer;
import eub.smart.cardproduct.transfer.self.domain.model.CreateTransferAccountInfo;
import eub.smart.cardproduct.transfer.self.domain.repository.FinDocStatusRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.*;
import org.springframework.transaction.annotation.Transactional;


import static eub.smart.cardproduct.transfer.self.core.constant.DocTechStatus.DRFT;

public class CreateTransferDataUseCaseImpl implements CreateTransferDataUseCase {

    private final CreateFinDocUseCase createFinDocUseCase;
    private final CreateTransferUseCase createTransferUseCase;
    private final FinDocStatusRepository finDocStatusRepository;
    private final DomainMapper modelMapper;

    public CreateTransferDataUseCaseImpl(CreateFinDocUseCase createFinDocUseCase,
                                         CreateTransferUseCase createTransferUseCase,
                                         FinDocStatusRepository finDocStatusRepository,
                                         DomainMapper modelMapper) {
        this.createFinDocUseCase = createFinDocUseCase;
        this.createTransferUseCase = createTransferUseCase;
        this.finDocStatusRepository = finDocStatusRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    @Transactional
    public CreateTransfer invoke(CreateTransferDataPIn in,
                                 CreateTransferAccountInfo senderAccount,
                                 CreateTransferAccountInfo receiverAccount) {
        var savedTransfer = saveTransfer(in, senderAccount, receiverAccount);

        var transfer = modelMapper.toCreateTransfer(savedTransfer);
        var finDocStatus = finDocStatusRepository.findByIdOrException(DRFT);
        return new CreateTransfer(transfer, senderAccount, finDocStatus);
    }

    private Transfer saveTransfer(CreateTransferDataPIn in,
                                  CreateTransferAccountInfo senderAccount,
                                  CreateTransferAccountInfo receiverAccount) {
        var finDoc = createFinDocUseCase.invoke(
                in.finDocType(),
                in.senderAmount(),
                in.finDocIdRef(),
                senderAccount,
                receiverAccount);
        return createTransferUseCase.invoke(
                finDoc,
                senderAccount,
                receiverAccount,
                in.knpCode(),
                in.receiverAmount(),
                in.currencyRates(),
                in.receiverCurrency());
    }

}
