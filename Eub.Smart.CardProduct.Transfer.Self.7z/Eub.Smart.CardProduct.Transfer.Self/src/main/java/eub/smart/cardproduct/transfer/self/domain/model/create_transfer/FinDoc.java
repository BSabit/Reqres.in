package eub.smart.cardproduct.transfer.self.domain.model.create_transfer;

import java.math.BigDecimal;
import java.util.Date;

public class FinDoc {

    private Long id;
    private String docType;
    private Long userId;
    private String currency;
    private BigDecimal amount;
    private BigDecimal feeAmount;
    private String feeCurrency;
    private Date dateCreated;
    private Date dateScheduled;
    private Boolean flagUrgent;
    private Boolean flagTemplate;
    private String frontEnd;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDocType() {
        return docType;
    }

    public void setDocType(String docType) {
        this.docType = docType;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getFeeAmount() {
        return feeAmount;
    }

    public void setFeeAmount(BigDecimal feeAmount) {
        this.feeAmount = feeAmount;
    }

    public String getFeeCurrency() {
        return feeCurrency;
    }

    public void setFeeCurrency(String feeCurrency) {
        this.feeCurrency = feeCurrency;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateScheduled() {
        return dateScheduled;
    }

    public void setDateScheduled(Date dateScheduled) {
        this.dateScheduled = dateScheduled;
    }

    public Boolean getFlagUrgent() {
        return flagUrgent;
    }

    public void setFlagUrgent(Boolean flagUrgent) {
        this.flagUrgent = flagUrgent;
    }

    public Boolean getFlagTemplate() {
        return flagTemplate;
    }

    public void setFlagTemplate(Boolean flagTemplate) {
        this.flagTemplate = flagTemplate;
    }

    public String getFrontEnd() {
        return frontEnd;
    }

    public void setFrontEnd(String frontEnd) {
        this.frontEnd = frontEnd;
    }

    @Override
    public String toString() {
        return "FinDoc{" +
                "id=" + id +
                ", docType=" + docType +
                ", userId=" + userId +
                ", currency=" + currency +
                ", amount=" + amount +
                ", feeAmount=" + feeAmount +
                ", feeCurrency=" + feeCurrency +
                ", dateCreated=" + dateCreated +
                ", dateScheduled=" + dateScheduled +
                ", flagUrgent=" + flagUrgent +
                ", flagTemplate=" + flagTemplate +
                ", frontEnd=" + frontEnd +
                '}';
    }
}
