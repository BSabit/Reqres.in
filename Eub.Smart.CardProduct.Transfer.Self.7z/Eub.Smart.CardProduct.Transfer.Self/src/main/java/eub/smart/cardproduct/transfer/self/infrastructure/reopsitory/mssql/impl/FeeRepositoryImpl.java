package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.Fee;
import eub.smart.cardproduct.transfer.self.domain.repository.FeeRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.InfrastructureMapper;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.FeeHiberRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;

@Primary
@Component
public class FeeRepositoryImpl implements FeeRepository {

    private final FeeHiberRepository feeHiberRepository;
    private final InfrastructureMapper mapper;

    public FeeRepositoryImpl(FeeHiberRepository feeHiberRepository,
                             InfrastructureMapper mapper) {
        this.feeHiberRepository = feeHiberRepository;
        this.mapper = mapper;
    }

    @Override
    public Optional<Fee> findById(Long id) {
        return feeHiberRepository.findById(id)
                .map(mapper::toDomain);
    }

    @Override
    public Fee findByIdOrException(Long id) {
        return findById(id)
                .orElseThrow(() -> new SelfException(E_DB_600, ": FeeRepository findByIdOrException"));
    }
}
