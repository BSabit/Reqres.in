package eub.smart.cardproduct.transfer.self.core.component;

import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.util.Base64;

@Component
public class AuthToken {

    private final HttpServletRequest request;

    public AuthToken(HttpServletRequest request) {
        this.request = request;
    }

    public String getToken() {
        return request.getHeader("Authorization")
                .replace("Bearer", "")
                .trim();
    }

    public String getPayload() {
        return getToken().split("\\.")[1];
    }

    public String getDecodedPayload() {
        String token = getPayload();
        return new String (Base64.getUrlDecoder().decode(token));
    }
}
