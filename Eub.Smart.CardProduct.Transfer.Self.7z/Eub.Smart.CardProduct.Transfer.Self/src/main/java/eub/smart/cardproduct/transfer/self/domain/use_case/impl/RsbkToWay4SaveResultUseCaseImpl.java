package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToWay4;
import eub.smart.cardproduct.transfer.self.domain.repository.ZeebeEventFinDocRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.RsbkToWay4SaveResultUseCase;

import static java.util.Objects.isNull;

public class RsbkToWay4SaveResultUseCaseImpl extends ZeebeEventFinDocSaveResult implements RsbkToWay4SaveResultUseCase {

    public RsbkToWay4SaveResultUseCaseImpl(ZeebeEventFinDocRepository zeebeEventFinDocRepository) {
        super(zeebeEventFinDocRepository);
    }

    @Override
    public void invoke(Long finDocId, RrnBrrn rrnBrrn, TransferRsbkToWay4 transferRsbkToWay4) {
        if (isNull(transferRsbkToWay4)) {
            saveResult(finDocId);
        } else if (isNull(rrnBrrn))  {
            var collectorId = getCollectorId(transferRsbkToWay4);
            saveResult(finDocId, collectorId);
        } else {
            var collectorId = getCollectorId(transferRsbkToWay4);
            saveResult(finDocId, rrnBrrn, collectorId);
        }
    }

    private String getCollectorId(TransferRsbkToWay4 transferRsbkToWay4) {
        return transferRsbkToWay4.getTransferRsbkToWay4Response().getCollectorId();
    }
}
