package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.FinDocStatus;
import eub.smart.cardproduct.transfer.self.domain.repository.FinDocStatusRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.InfrastructureMapper;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.FinDocStatusHiberRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;

@Primary
@Component
public class FinDocStatusRepositoryImpl implements FinDocStatusRepository {

    private final FinDocStatusHiberRepository finDocStatusHiberRepository;
    private final InfrastructureMapper mapper;

    public FinDocStatusRepositoryImpl(FinDocStatusHiberRepository finDocStatusHiberRepository,
                                      InfrastructureMapper mapper) {
        this.finDocStatusHiberRepository = finDocStatusHiberRepository;
        this.mapper = mapper;
    }

    @Override
    public Optional<FinDocStatus> findByFinIdDoc(Long finDocId) {
        return finDocStatusHiberRepository.findByFinDocId(finDocId)
                .map(mapper::toDomain);
    }

    @Override
    public Optional<FinDocStatus> findById(String id) {
        return finDocStatusHiberRepository.findById(id)
                .map(mapper::toDomain);
    }

    @Override
    public FinDocStatus findByIdOrException(String id) {
        return findById(id)
                .orElseThrow(() -> new SelfException(E_DB_600, ": FinDocStatusRepository findByIdOrException"));
    }

}
