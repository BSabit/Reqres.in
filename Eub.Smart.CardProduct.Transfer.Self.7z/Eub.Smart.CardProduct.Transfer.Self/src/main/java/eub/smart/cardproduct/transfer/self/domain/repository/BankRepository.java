package eub.smart.cardproduct.transfer.self.domain.repository;

import java.util.Optional;

public interface BankRepository {

    Optional<Long> findTargetIdByBic(String bic);

    Long findTargetIdByBicOrException(String bic);
}
