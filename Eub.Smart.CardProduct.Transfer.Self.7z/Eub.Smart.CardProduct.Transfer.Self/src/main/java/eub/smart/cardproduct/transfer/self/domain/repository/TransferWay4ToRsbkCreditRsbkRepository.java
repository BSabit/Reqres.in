package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4ToRsbkRequest;

import java.util.Optional;

public interface TransferWay4ToRsbkCreditRsbkRepository {

    Optional<TransferWay4ToRsbkRequest> findByFinDocId(Long finDocId, String dboIdPrefix);

    TransferWay4ToRsbkRequest findByFinDocIdOrException(Long finDocId, String dboIdPrefix);
}
