package eub.smart.cardproduct.transfer.self.core.constant;

public interface DocTechStatus {

    String DRFT = "DRFT";
    String RJCT = "RJCT";
    String DONE = "DONE";
    String VLAL = "VLAL";
    String VLDA = "VLDA";
    String VLDL = "VLDL";
    String VLMA = "VLMA";
    String VLML = "VLML";
    String VLPS = "VLPS";
    String DCCF = "DCCF";
    String ENBS = "ENBS";
    String VLBS = "VLBS";
    String VLCP = "VLCP";
    String VLSS = "VLSS";
    String VLSU = "VLSU";
    String MTNT = "MTNT";
    String RTRN = "RTRN";
    String NEWW = "NEWW";
}
