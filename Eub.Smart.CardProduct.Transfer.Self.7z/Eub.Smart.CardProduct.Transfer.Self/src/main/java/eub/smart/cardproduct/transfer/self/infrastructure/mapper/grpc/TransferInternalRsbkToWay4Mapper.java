package eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc;

import custom_types.CustomTypes;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToWay4Request;
import rsbktransactional.V1.EubAdapterRsbkTransactional;


import static eub.smart.cardproduct.transfer.self.core.util.GrpcUtil.toTimestamp;
import static eub.smart.cardproduct.transfer.self.core.util.GrpcUtil.toDecimalValue;

public class TransferInternalRsbkToWay4Mapper {

    public static EubAdapterRsbkTransactional.TransferRsbkToWay4Request toGrpcModel(TransferRsbkToWay4Request requestModel) {
        return EubAdapterRsbkTransactional.TransferRsbkToWay4Request
                .newBuilder()
                .setPayerAccount(requestModel.getPayerAccount())
                .setReceiverAccount(requestModel.getReceiverAccount())
                .setOperSum(toDecimalValue(requestModel.getOperSum()))
                .setKnp(requestModel.getKnp())
                .setReceiverAccountCurr(requestModel.getReceiverAccountCurr())
                .setIsSelf(requestModel.getSelf())
                .setReceiverNameFull(requestModel.getReceiverNameFull())
                .setReceiverNameLast(requestModel.getReceiverNameLast())
                .setReceiverNameFirst(requestModel.getReceiverNameFirst())
                .setReceiverNameMiddle(requestModel.getReceiverNameMiddle())
                .setReceiverIin(requestModel.getReceiverIin())
                .setReceiverIsNotRez(requestModel.getReceiverIsNotRez())
                .setSumInReceiverAccCurr(toDecimalValue(requestModel.getSumInReceiverAccCurr()))
                .setDboId(requestModel.getDboId())
                .setDateSign(toTimestamp(requestModel.getDateSign()))
                .setComissTarif(CustomTypes.DecimalValue.getDefaultInstance())
                .setComissSummTg(toDecimalValue(requestModel.getComissSummTg()))
                .setIsSpecRate(1)
                .setRate(CustomTypes.DecimalValue.newBuilder().setUnits(0).setNanos(0).build())
                .setCoverRate(CustomTypes.DecimalValue.newBuilder().setUnits(0).setNanos(0).build())
                .setProcVersion(3)
                .build();
    }
}
