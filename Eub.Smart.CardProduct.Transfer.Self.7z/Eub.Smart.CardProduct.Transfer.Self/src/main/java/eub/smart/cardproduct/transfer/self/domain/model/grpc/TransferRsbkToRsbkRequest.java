package eub.smart.cardproduct.transfer.self.domain.model.grpc;

import com.fasterxml.jackson.annotation.JsonFormat;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;

import static eub.smart.cardproduct.transfer.self.core.constant.FinDocType.SELF;

public class TransferRsbkToRsbkRequest {
    @NotNull
    private String payerAccount;
    @NotNull
    private String receiverAccount;
    @NotNull
    private BigDecimal operSum;
    @NotNull
    private String kpn;
    @NotNull
    private BigDecimal vicalcSumm;
    @NotNull
    private BigDecimal comissSummTg;
    @NotNull
    private String iin;
    @NotNull
    private String dboId;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private Date dateSign;
    @NotNull
    private Boolean self;

    public TransferRsbkToRsbkRequest() {
    }

    public TransferRsbkToRsbkRequest(FinDocData finDocData, AccountData senderData, AccountData receiverData) {
        this.payerAccount = senderData.getAccountNumber();
        this.receiverAccount = receiverData.getAccountNumber();
        this.operSum = senderData.getAmount();
        this.kpn = finDocData.getKnpCode();
        this.vicalcSumm = receiverData.getAmount();
        this.comissSummTg = finDocData.getFeeAmount();
        this.iin = senderData.getIin();
        this.dboId = String.valueOf(finDocData.getId());
        this.dateSign = finDocData.getDateSigned();
        this.self = SELF.equals(finDocData.getType());
    }

    public String getPayerAccount() {
        return payerAccount;
    }

    public void setPayerAccount(String payerAccount) {
        this.payerAccount = payerAccount;
    }

    public String getReceiverAccount() {
        return receiverAccount;
    }

    public void setReceiverAccount(String receiverAccount) {
        this.receiverAccount = receiverAccount;
    }

    public BigDecimal getOperSum() {
        return operSum;
    }

    public void setOperSum(BigDecimal operSum) {
        this.operSum = operSum;
    }

    public String getKpn() {
        return kpn;
    }

    public void setKpn(String kpn) {
        this.kpn = kpn;
    }

    public String getIin() {
        return iin;
    }

    public void setIin(String iin) {
        this.iin = iin;
    }

    public BigDecimal getVicalcSumm() {
        return vicalcSumm;
    }

    public void setVicalcSumm(BigDecimal vicalcSumm) {
        this.vicalcSumm = vicalcSumm;
    }

    public BigDecimal getComissSummTg() {
        return comissSummTg;
    }

    public void setComissSummTg(BigDecimal comissSummTg) {
        this.comissSummTg = comissSummTg;
    }

    public String getDboId() {
        return dboId;
    }

    public void setDboId(String dboId) {
        this.dboId = dboId;
    }

    public Date getDateSign() {
        return dateSign;
    }

    public void setDateSign(Date dateSign) {
        this.dateSign = dateSign;
    }

    public void setSelf(Boolean self) {
        this.self = self;
    }

    public Boolean isSelf() {
        return self;
    }

    @Override
    public String toString() {
        return "TransferRsbkToRsbkRequest{" +
                "payerAccount=" + payerAccount +
                ", receiverAccount=" + receiverAccount +
                ", operSum=" + operSum +
                ", kpn=" + kpn +
                ", vicalcSumm=" + vicalcSumm +
                ", comissSummTg=" + comissSummTg +
                ", iin=" + iin +
                ", dboId=" + dboId +
                ", dateSign=" + dateSign +
                ", self=" + self +
                '}';
    }
}
