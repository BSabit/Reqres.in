package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToWay4;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToWay4Request;
import eub.smart.cardproduct.transfer.self.domain.repository.RsbkTransactionalProtoRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.TransferRsbkToWay4UseCase;

public class TransferRsbkToWay4UseCaseImpl implements TransferRsbkToWay4UseCase {

    private final RsbkTransactionalProtoRepository rsbkTransactionalProtoRepository;

    public TransferRsbkToWay4UseCaseImpl(RsbkTransactionalProtoRepository rsbkTransactionalProtoRepository) {
        this.rsbkTransactionalProtoRepository = rsbkTransactionalProtoRepository;
    }

    @Override
    public TransferRsbkToWay4 invoke(FinDocData finDocData, AccountData senderData, AccountData receiverData) {
        var request = new TransferRsbkToWay4Request(finDocData, senderData, receiverData);
        var response = rsbkTransactionalProtoRepository.transferRsbkToWay4(request, finDocData.getCorrelationId());
        return new TransferRsbkToWay4(request, response);
    }
}
