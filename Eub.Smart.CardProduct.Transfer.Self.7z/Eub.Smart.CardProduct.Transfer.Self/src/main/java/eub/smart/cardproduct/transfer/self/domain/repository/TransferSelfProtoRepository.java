package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.*;

public interface TransferSelfProtoRepository {

    TransferTcResponse transferTcRsbk(TransferTcRequest requestModel, String correlationId);

    TransferTcResponse transferTcWay4(TransferTcRequest requestModel, String correlationId);

    UfxResponse transferRsbkToWay4DebitTransit(UfxTransferRequest requestModel);

    UfxResponse transferRsbkToWay4Credit(UfxTransferRequest requestModel);

    UfxResponse transferRsbkToWay4ReverseTransit(UfxTransferRequest requestModel);

    UfxResponse transferWay4ToRsbkCreditTransit(UfxTransferRequest requestModel);

    UfxResponse transferWay4ToRsbkDebit(UfxTransferRequest requestModel);

    UfxResponse transferWay4ToRsbkReverseDebit(UfxTransferRequest requestModel);

    UfxResponse transferWay4ToRsbkReverseTransit(UfxTransferRequest requestModel);

    UfxResponse transferWay4ToWay4Credit(UfxTransferRequest requestModel);

    UfxResponse transferWay4ToWay4Debit(UfxTransferRequest requestModel);

    UfxResponse transferWay4ToWay4ReverseDebit(UfxTransferRequest requestModel);

    UfxResponse transferWay4Convert(TransferWay4ConvertRequest requestModel);

    UfxResponse transferIbanToIban(TransferIbanToIbanRequest requestModel);
}
