package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.ConvertingInfo;
import eub.smart.cardproduct.transfer.self.domain.repository.RsbkInfoProtoRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.GetConvertingInfoUseCase;

import java.math.BigDecimal;
import java.math.RoundingMode;

import static eub.smart.cardproduct.transfer.self.core.constant.CurrencyCode.KZT;

public class GetConvertingInfoUseCaseImpl implements GetConvertingInfoUseCase {

    private final RsbkInfoProtoRepository rsbkInfoProtoRepository;
    private final static String LOWEST_VALUE = "0.01";
    public GetConvertingInfoUseCaseImpl(RsbkInfoProtoRepository rsbkInfoProtoRepository) {
        this.rsbkInfoProtoRepository = rsbkInfoProtoRepository;
    }

    @Override
    public ConvertingInfo invoke(BigDecimal amount,
                                 String senderAccountCurrency,
                                 String receiverAccountCurrency,
                                 String correlationId) {
        if (isSameCurrency(senderAccountCurrency, receiverAccountCurrency)) {
            return new ConvertingInfo(amount, amount);
        } else if (isStraight(senderAccountCurrency, receiverAccountCurrency)) {
            return calcStraightConversion(amount, senderAccountCurrency, receiverAccountCurrency, new BigDecimal(LOWEST_VALUE), correlationId);
        } else {
            return calcCrossConversion(amount, senderAccountCurrency, receiverAccountCurrency, correlationId);
        }
    }

    private ConvertingInfo calcStraightConversion(BigDecimal amount,
                                                  String senderAccountCurrency,
                                                  String receiverAccountCurrency,
                                                  BigDecimal senderSellRate,
                                                  String correlationId) {
        if (KZT.equals(senderAccountCurrency)) {
            return calcSenderAccCurrencyKzt(amount, receiverAccountCurrency, correlationId, senderSellRate);
        } else {
            return calcReceiverAccCurrencyKzt(amount, senderAccountCurrency, correlationId);
        }
    }

    private ConvertingInfo calcSenderAccCurrencyKzt(BigDecimal amount, String receiverAccountCurrency, String correlationId, BigDecimal senderSellRate) {
        var receiverAccCurrencyRate = rsbkInfoProtoRepository.getCurrencyRate(receiverAccountCurrency, correlationId);
        var receiverSellRate = receiverAccCurrencyRate.getSellRate();
        var resDivideToReceiverSellRate = amount.divide(receiverSellRate, 2, RoundingMode.HALF_UP);
        if (isEqualZero(resDivideToReceiverSellRate)) resDivideToReceiverSellRate = new BigDecimal(LOWEST_VALUE);
        if (isReceiverSellRateGreater(senderSellRate, receiverSellRate)) {
            amount = resDivideToReceiverSellRate.multiply(receiverSellRate).setScale(2, RoundingMode.HALF_UP);
        }
        return new ConvertingInfo(amount, resDivideToReceiverSellRate, receiverAccCurrencyRate);
    }

    private ConvertingInfo calcReceiverAccCurrencyKzt(BigDecimal amount, String senderAccCurrency, String correlationId) {
        var senderAccCurrencyRate = rsbkInfoProtoRepository.getCurrencyRate(senderAccCurrency, correlationId);
        var senderBuyRate = senderAccCurrencyRate.getBuyRate();
        var correctAmount = amount.setScale(2, RoundingMode.HALF_DOWN);
        var receiverAmount = correctAmount.multiply(senderBuyRate).setScale(2, RoundingMode.HALF_DOWN);
        return new ConvertingInfo(correctAmount, receiverAmount, senderAccCurrencyRate);
    }

    private ConvertingInfo calcCrossConversion(BigDecimal amount, String senderAccountCurrency, String receiverAccountCurrency, String correlationId) {
        if (amount.compareTo(new BigDecimal("1")) < 0) {
            amount = new BigDecimal("1");
        }
        var senderConvertingInfo = calcStraightConversion(amount, senderAccountCurrency, KZT, new BigDecimal(LOWEST_VALUE), correlationId);
        var amountKzt = senderConvertingInfo.getReceiverAmount();
        var senderSellRate = senderConvertingInfo.getCurrencyRates().get(0).getSellRate();
        var senderBuyRate = senderConvertingInfo.getCurrencyRates().get(0).getBuyRate();

        var receiverConvertingInfo = calcStraightConversion(amountKzt, KZT, receiverAccountCurrency, senderSellRate, correlationId);
        var correctAmountKzt = receiverConvertingInfo.getCorrectAmount();
        var correctAmount = correctAmountKzt.divide(senderBuyRate, 2, RoundingMode.HALF_UP);

        senderConvertingInfo.getCurrencyRates().addAll(receiverConvertingInfo.getCurrencyRates());
        return new ConvertingInfo(correctAmount, receiverConvertingInfo.getReceiverAmount(), senderConvertingInfo.getCurrencyRates());
    }

    private boolean isEqualZero(BigDecimal resMultiplyToHundred) {
        resMultiplyToHundred = resMultiplyToHundred.setScale(2, RoundingMode.HALF_DOWN);
        var zero = new BigDecimal(0);
        return resMultiplyToHundred.compareTo(zero) <= 0;
    }

    private boolean isStraight(String senderAccountCurrency, String receiverAccountCurrency) {
        return KZT.equals(senderAccountCurrency) || KZT.equals(receiverAccountCurrency);
    }

    private boolean isReceiverSellRateGreater(BigDecimal senderSellRate, BigDecimal receiverSellRate) {
        return senderSellRate.compareTo(receiverSellRate) < 0;
    }

    private boolean isSameCurrency(String senderAccountCurrency, String receiverAccountCurrency) {
        return senderAccountCurrency.equals(receiverAccountCurrency);
    }
}
