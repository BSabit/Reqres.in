package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.domain.model.FullName;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4ToRsbkRequest;
import eub.smart.cardproduct.transfer.self.core.util.NameUtil;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.scanner.MapResultScanner;

import java.util.Map;
import java.util.Objects;

import static eub.smart.cardproduct.transfer.self.core.constant.FinDocType.SELF;

public class TransferWay4ToRsbkRequestMapper {

    public static TransferWay4ToRsbkRequest toDomainModel(Map<String, Object> row, Long finDocId, String dboIdPrefix) {
        MapResultScanner scanner = new MapResultScanner(row);

        String senderFullname = scanner.getString("senderFullname");
        FullName name = NameUtil.getPersonFullName(senderFullname);

        TransferWay4ToRsbkRequest request = new TransferWay4ToRsbkRequest();
        request.setPayerAccount(scanner.getString("senderAccountNumber"));
        request.setReceiverAccount(scanner.getString("receiverAccountNumber"));
        request.setOperSum(scanner.getBigDecimal("senderAmount"));
        request.setViCardIso(scanner.getString("senderCurrency"));
        request.setIsSelf(SELF.equals(scanner.getString("finDocType")) ? 1 : 0);
        request.setViCardHolderName(senderFullname);
        request.setViCardHolderName1(name.getLastname());
        request.setViCardHolderName2(name.getFirstname());
        request.setViCardHolderName3(name.getMiddlename());
        request.setViIin(scanner.getString("senderIin"));
        request.setViNotRez(Boolean.getBoolean(scanner.getString("senderIsResident")) ? "x" : "");
        request.setViCalcSumm(scanner.getBigDecimal("receiverAmount"));
        request.setDboId(finDocId.toString());
        request.setDateSign(scanner.getDate("finDocSignDate"));
        request.setDboIdPrefix(dboIdPrefix);
        request.setProcVersion(3);
        return request;
    }

    private static Boolean isConverted(String senderCurrency, String receiverCurrency) {
        return !Objects.equals(senderCurrency, receiverCurrency);
    }

    private static String createGround(AccountData receiverData) {
        String fullname = receiverData.getFullName();
        String accountNumber = receiverData.getAccountNumber();
        return String.format("To RS; %s; %s", fullname, accountNumber);
    }

    public static TransferWay4ToRsbkRequest createRequest(FinDocData finDocData, AccountData senderData, AccountData receiverData, String dboIdPrefix) {
        String senderFullname = senderData.getFullName();
        FullName name = NameUtil.getPersonFullName(senderFullname);

        TransferWay4ToRsbkRequest request = new TransferWay4ToRsbkRequest();
        request.setPayerAccount(senderData.getAccountNumber());
        request.setReceiverAccount(receiverData.getAccountNumber());
        request.setOperSum(senderData.getAmount());
        request.setKnp(isConverted(senderData.getCurrency(), receiverData.getCurrency()) ? "0" : finDocData.getKnpCode());
        request.setViCardIso(senderData.getCurrency());
        request.setIsSelf(SELF.equals(finDocData.getType()) ? 1 : 0);
        request.setViCardHolderName(senderFullname);
        request.setViCardHolderName1(name.getLastname());
        request.setViCardHolderName2(name.getFirstname());
        request.setViCardHolderName3(name.getMiddlename());
        request.setViIin(senderData.getIin());
        request.setViNotRez(senderData.getFlagResident() ? "x" : "");
        request.setViCalcSumm(receiverData.getAmount());
        request.setGround(createGround(receiverData));
        request.setDboId(String.valueOf(finDocData.getId()));
        request.setDateSign(finDocData.getDateSigned());
        request.setIsSpecRate(isConverted(senderData.getCurrency(), receiverData.getCurrency()) ? 1 : 0);
        request.setDboIdPrefix(dboIdPrefix);
        request.setProcVersion(3);
        return request;
    }
}
