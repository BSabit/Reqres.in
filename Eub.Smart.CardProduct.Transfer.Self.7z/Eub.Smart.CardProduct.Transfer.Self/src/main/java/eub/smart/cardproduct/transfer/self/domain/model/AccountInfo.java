package eub.smart.cardproduct.transfer.self.domain.model;

public class AccountInfo {

    private Long id;
    private String type;
    private String currency;
    private String number;
    private Boolean flagMultiCurrency;
    private Long idRef;
    private Long clientIdRef;
    private Boolean residentFlag;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Boolean getFlagMultiCurrency() {
        return flagMultiCurrency;
    }

    public void setFlagMultiCurrency(Boolean flagMultiCurrency) {
        this.flagMultiCurrency = flagMultiCurrency;
    }

    public Long getIdRef() {
        return idRef;
    }

    public void setIdRef(Long idRef) {
        this.idRef = idRef;
    }

    public void setClientIdRef(Long clientIdRef) {
        this.clientIdRef = clientIdRef;
    }

    public Long getClientIdRef() {
        return clientIdRef;
    }

    public void setResidentFlag(Boolean residentFlag) {
        this.residentFlag = residentFlag;
    }

    public Boolean getResidentFlag() {
        return residentFlag;
    }

    @Override
    public String toString() {
        return "AccountInfo{" +
                "id=" + id +
                ", type=" + type +
                ", currency=" + currency +
                ", number=" + number +
                ", flagMultiCurrency=" + flagMultiCurrency +
                ", idRef=" + idRef +
                ", clientIdRef=" + clientIdRef +
                ", residentFlag=" + residentFlag +
                '}';
    }
}
