package eub.smart.cardproduct.transfer.self.domain.model;

import java.math.BigDecimal;

public class FeeResponse {

    private BigDecimal amount;
    private String currency;

    public FeeResponse() {
    }

    public FeeResponse(BigDecimal amount, String currency) {
        this.amount = amount;
        this.currency = currency;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @Override
    public String toString() {
        return "FeeResponse{" +
                "amount=" + amount +
                ", currency=" + currency +
                "}";
    }
}
