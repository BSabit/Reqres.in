package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql;

import eub.smart.cardproduct.transfer.self.infrastructure.entity.FinDocEntity;
import eub.smart.cardproduct.transfer.self.infrastructure.model.TransferStory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;

@Repository
public interface FinDocHiberRepository extends JpaRepository<FinDocEntity, Long> {

    @Query(value = """
                        select fd.FinDoc_ID                                                                   as finDocId,
                               fdt.FinDocType_ID                                                              as finDocType,
                               fd.DateCreated                                                                 as createdDate,
                               fd.Amount                                                                      as amount,
                               fd.Currency                                                                    as currency,
                               dts.FinDocStatus_IDREF                                                         as status,
                               trm_fdt.Term_RU                                                                as transferTypeRu,
                               trm_fdt.Term_EN                                                                as transferTypeEn,
                               trm_fdt.Term_kz                                                                as transferTypeKk,
                               case
                                   when map_user_account.Pseudonym is not null then (map_user_account.Pseudonym + ' • ' +
                                                                                     left(a.Number, 2) + right(a.Number, 4))
                                   else (trm_at.Term_EN + ' • ' + left(a.Number, 2) + right(a.Number, 4)) end as 'senderEn',
                               case
                                   when map_user_account.Pseudonym is not null then (map_user_account.Pseudonym + ' • ' +
                                                                                     left(a.Number, 2) + right(a.Number, 4))
                                   else (trm_at.Term_KZ + ' • ' + left(a.Number, 2) + right(a.Number, 4)) end as 'senderKk',
                               case
                                   when map_user_account.Pseudonym is not null then (map_user_account.Pseudonym + ' • ' +
                                                                                     left(a.Number, 2) + right(a.Number, 4))
                                   else (trm_at.Term_RU + ' • ' + left(a.Number, 2) + right(a.Number, 4)) end as 'senderRu',
                               right(ipst.USER_ReceiverPhone, 10)                                             as 'receiverEn',
                               right(ipst.USER_ReceiverPhone, 10)                                             as 'receiverKk',
                               right(ipst.USER_ReceiverPhone, 10)                                             as 'receiverRu',
                               ipst.BANK_ReceiverBic                                                          as imageDefinition
                        from FinDoc fd
                                 join FinDocState fds on fd.FinDoc_ID = fds.FinDoc_IDREF
                                 join DocTechStatus dts on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF and
                                                           dts.FinDocStatus_IDREF in ('DONE', 'PROC', 'EROR', 'RJCT')
                                 join FinDocType fdt on fdt.FinDocType_ID = fd.FinDocType_IDREF
                                 left join Term trm_fdt on trm_fdt.Term_ID = fdt.Term_OUTREF
                                 left join Account a on a.Account_ID = fd.Account_IDREF
                                 left join AccountType at on a.AccountType_IDREF = at.AccountType_ID
                                 left join Term trm_at on at.Term_OUTREF = trm_at.Term_ID
                                 join IPSTransfer ipst on fd.FinDoc_ID = ipst.FinDoc_IDREF and ipst.TransferType not in  ('IPSP', 'IPSI')
                                 left join map_User_Account on map_User_Account.User_IDREF = fd.User_IDREF and
                                                               map_User_Account.Account_IDREF = fd.Account_IDREF
                        where FinDocType_ID in ('OIPS', 'IIPS')
                          and fd.DateCreated >= :dateFrom
                          and fd.DateCreated <= :dateTill
                          and fd.User_IDREF = :userId
                        union
                        select fd.FinDoc_ID                                                                   as finDocId,
                               fdt.FinDocType_ID                                                              as finDocType,
                               fd.DateCreated                                                                 as createdDate,
                               fd.Amount                                                                      as amount,
                               fd.Currency                                                                    as currency,
                               dts.FinDocStatus_IDREF                                                         as status,
                               trm_fdt.Term_RU                                                                as transferTypeRu,
                               trm_fdt.Term_EN                                                                as transferTypeEn,
                               trm_fdt.Term_kz                                                                as transferTypeKk,
                               case
                                   when map_user_account.Pseudonym is not null then (map_user_account.Pseudonym + ' • ' +
                                                                                     left(a.Number, 2) + right(a.Number, 4))
                                   else (trm_at.Term_EN + ' • ' + left(a.Number, 2) + right(a.Number, 4)) end as 'senderEn',
                               case
                                   when map_user_account.Pseudonym is not null then (map_user_account.Pseudonym + ' • ' +
                                                                                     left(a.Number, 2) + right(a.Number, 4))
                                   else (trm_at.Term_KZ + ' • ' + left(a.Number, 2) + right(a.Number, 4)) end as 'senderKk',
                               case
                                   when map_user_account.Pseudonym is not null then (map_user_account.Pseudonym + ' • ' +
                                                                                     left(a.Number, 2) + right(a.Number, 4))
                                   else (trm_at.Term_RU + ' • ' + left(a.Number, 2) + right(a.Number, 4)) end as 'senderRu',
                               case
                                   when bank.Bank_ID is not null then
                                       case
                                           when bank.Term_OUTREF is not null then
                                               case
                                                   when t.MaskedNumber is not null
                                                       then (trm_bank.Term_EN + ' • ' + right(t.MaskedNumber, 4))
                                                   else (trm_bank.Term_EN + ' • ' + left(t.Receiver_Account, 2) +
                                                         right(t.Receiver_Account, 4)) end
                                           else case
                                                    when t.MaskedNumber is not null
                                                        then (bank.Bank_Title + ' • ' + right(t.MaskedNumber, 4))
                                                    else (bank.Bank_Title + ' • ' + left(t.Receiver_Account, 2) +
                                                          right(t.Receiver_Account, 4)) end
                                           end
                                   else case
                                            when t.MaskedNumber is not null then (' • ' + right(t.MaskedNumber, 4))
                                            else (' • ' + left(t.Receiver_Account, 2) + right(t.Receiver_Account, 4)) end
                                   end
                                                                                                              as 'receiverEn',
                               case
                                   when bank.Bank_ID is not null then
                                       case
                                           when bank.Term_OUTREF is not null then
                                               case
                                                   when t.MaskedNumber is not null
                                                       then (trm_bank.Term_KZ + ' • ' + right(t.MaskedNumber, 4))
                                                   else (trm_bank.Term_KZ + ' • ' + left(t.Receiver_Account, 2) +
                                                         right(t.Receiver_Account, 4)) end
                                           else case
                                                    when t.MaskedNumber is not null
                                                        then (bank.Bank_Title + ' • ' + right(t.MaskedNumber, 4))
                                                    else (bank.Bank_Title + ' • ' + left(t.Receiver_Account, 2) +
                                                          right(t.Receiver_Account, 4)) end
                                           end
                                   else case
                                            when t.MaskedNumber is not null then (' • ' + right(t.MaskedNumber, 4))
                                            else (' • ' + left(t.Receiver_Account, 2) + right(t.Receiver_Account, 4)) end
                                   end
                                                                                                              as 'receiverKk',
                               case
                                   when bank.Bank_ID is not null then
                                       case
                                           when bank.Term_OUTREF is not null then
                                               case
                                                   when t.MaskedNumber is not null
                                                       then (trm_bank.Term_RU + ' • ' + right(t.MaskedNumber, 4))
                                                   else (trm_bank.Term_RU + ' • ' + left(t.Receiver_Account, 2) +
                                                         right(t.Receiver_Account, 4)) end
                                           else case
                                                    when t.MaskedNumber is not null
                                                        then (bank.Bank_Title + ' • ' + right(t.MaskedNumber, 4))
                                                    else (bank.Bank_Title + ' • ' + left(t.Receiver_Account, 2) +
                                                          right(t.Receiver_Account, 4)) end
                                           end
                                   else case
                                            when t.MaskedNumber is not null then (' • ' + right(t.MaskedNumber, 4))
                                            else (' • ' + left(t.Receiver_Account, 2) + right(t.Receiver_Account, 4)) end
                                   end
                                                                                                              as 'receiverRu',
                               Receiver_BIC                                                                   as imageDefinition
                        from FinDoc fd
                                 join FinDocState fds on fd.FinDoc_ID = fds.FinDoc_IDREF
                                 join DocTechStatus dts on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF and
                                                           dts.FinDocStatus_IDREF in ('DONE', 'PROC', 'EROR', 'RJCT', 'RTRN')
                                 join FinDocType fdt on fdt.FinDocType_ID = fd.FinDocType_IDREF
                                 left join Term trm_fdt on trm_fdt.Term_ID = fdt.Term_OUTREF
                                 left join Account a on a.Account_ID = fd.Account_IDREF
                                 left join AccountType at on a.AccountType_IDREF = at.AccountType_ID
                                 left join Term trm_at on at.Term_OUTREF = trm_at.Term_ID
                                 join Transfer t on fd.FinDoc_ID = t.FinDoc_IDREF
                                 left join map_User_Account on map_User_Account.User_IDREF = fd.User_IDREF and
                                                               map_User_Account.Account_IDREF = fd.Account_IDREF
                                 left join bank on t.Receiver_BIC = bank.BIC
                                 left join term trm_bank on bank.Term_OUTREF = trm_bank.Term_ID
                        where FinDocType_ID in ('TLOC', 'TOUT', 'TINT')
                          and fd.DateCreated >= :dateFrom
                          and fd.DateCreated <= :dateTill
                          and fd.User_IDREF = :userId
                        union
                        select fd.FinDoc_ID                                as finDocId,
                               fdt.FinDocType_ID                           as finDocType,
                               fd.DateCreated                              as createdDate,
                               fd.Amount                                   as amount,
                               fd.Currency                                 as currency,
                               dts.FinDocStatus_IDREF                      as status,
                               trm_fdt.Term_RU                             as transferTypeRu,
                               trm_fdt.Term_EN                             as transferTypeEn,
                               trm_fdt.Term_kz                             as transferTypeKk,
                               case
                                   when map_user_account.Pseudonym is not null then (map_user_account.Pseudonym + ' • ' +
                                                                                     left(a.Number, 2) + right(a.Number, 4))
                                   else (trm_at.Term_EN + ' • ' + left(a.Number, 2) +
                                         right(a.Number, 4)) end           as 'senderEn',
                               case
                                   when map_user_account.Pseudonym is not null then (map_user_account.Pseudonym + ' • ' +
                                                                                     left(a.Number, 2) + right(a.Number, 4))
                                   else (trm_at.Term_KZ + ' • ' + left(a.Number, 2) +
                                         right(a.Number, 4)) end           as 'senderKk',
                               case
                                   when map_user_account.Pseudonym is not null then (map_user_account.Pseudonym + ' • ' +
                                                                                     left(a.Number, 2) + right(a.Number, 4))
                                   else (trm_at.Term_RU + ' • ' + left(a.Number, 2) +
                                         right(a.Number, 4)) end           as 'senderRu',
                               case
                                   when map_user_account.Pseudonym is not null then (map_user_account.Pseudonym + ' • ' +
                                                                                     left(t.Receiver_Account, 2) +
                                                                                     right(t.Receiver_Account, 4))
                                   else (trm_rec.Term_EN + ' • ' + left(t.Receiver_Account, 2) +
                                         right(t.Receiver_Account, 4)) end as 'receiverEn',
                               case
                                   when map_user_account.Pseudonym is not null then (map_user_account.Pseudonym + ' • ' +
                                                                                     left(t.Receiver_Account, 2) +
                                                                                     right(t.Receiver_Account, 4))
                                   else (trm_rec.Term_KZ + ' • ' + left(t.Receiver_Account, 2) +
                                         right(t.Receiver_Account, 4)) end as 'receiverKk',
                               case
                                   when map_user_account.Pseudonym is not null then (map_user_account.Pseudonym + ' • ' +
                                                                                     left(t.Receiver_Account, 2) +
                                                                                     right(t.Receiver_Account, 4))
                                   else (trm_rec.Term_RU + ' • ' + left(t.Receiver_Account, 2) +
                                         right(t.Receiver_Account, 4)) end as 'receiverRu',
                               fdt.FinDocType_ID                           as imageDefinition
                        from FinDoc fd
                                 join FinDocState fds on fd.FinDoc_ID = fds.FinDoc_IDREF
                                 join DocTechStatus dts on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF and
                                                           dts.FinDocStatus_IDREF in ('DONE', 'PROC', 'EROR', 'RJCT')
                                 join FinDocType fdt on fdt.FinDocType_ID = fd.FinDocType_IDREF
                                 left join Term trm_fdt on trm_fdt.Term_ID = fdt.Term_OUTREF
                                 left join Account a on a.Account_ID = fd.Account_IDREF
                                 left join AccountType at on a.AccountType_IDREF = at.AccountType_ID
                                 left join Term trm_at on at.Term_OUTREF = trm_at.Term_ID
                                 left join Transfer t on fd.FinDoc_ID = t.FinDoc_IDREF
                                 left join map_User_Account on map_User_Account.User_IDREF = fd.User_IDREF and
                                                               map_User_Account.Account_IDREF = fd.Account_IDREF
                                 left join Account acc_rec on acc_rec.Number=t.Receiver_Account
                                 left join AccountType at_rec on acc_rec.AccountType_IDREF=at_rec.AccountType_ID
                                 left join term trm_rec on trm_rec.Term_ID=at_rec.Term_OUTREF
                        where fdt.FinDocType_ID in ('TSLF')
                          and fd.DateCreated >= :dateFrom
                          and fd.DateCreated <= :dateTill
                          and fd.User_IDREF = :userId
                        union
                        select fd.FinDoc_ID           as finDocId,
                               fdt.FinDocType_ID      as finDocType,
                               fd.DateCreated         as createdDate,
                               fd.Amount              as amount,
                               fd.Currency            as currency,
                               dts.FinDocStatus_IDREF as status,
                               trm_fdt.Term_RU        as transferTypeRu,
                               trm_fdt.Term_EN        as transferTypeEn,
                               trm_fdt.Term_kz        as transferTypeKk,
                               case
                                   when ct.DebitMaskedCardNumber is not null then
                                       case
                                           when ct.DebitCard_IDREF is not null
                                               then (ct1.CardType_Title + ' • ' + right(ct.DebitMaskedCardNumber, 4))
                                           else (' • ' + right(ct.DebitMaskedCardNumber, 4)) end
                                   else case
                                            when ct.DebitCard_IDREF is not null then (ct1.CardType_Title + ' • ' + right(c1.MaskedNumber, 4))
                                            else (' • ' + right(c1.MaskedNumber, 4)) end
                                   end                as 'senderEn',
                               case
                                   when ct.DebitMaskedCardNumber is not null then
                                       case
                                           when ct.DebitCard_IDREF is not null
                                               then (ct1.CardType_Title + ' • ' + right(ct.DebitMaskedCardNumber, 4))
                                           else (' • ' + right(ct.DebitMaskedCardNumber, 4)) end
                                   else case
                                            when ct.DebitCard_IDREF is not null then (ct1.CardType_Title + ' • ' + right(c1.MaskedNumber, 4))
                                            else (' • ' + right(c1.MaskedNumber, 4)) end
                                   end                as 'senderKk',
                               case
                                   when ct.DebitMaskedCardNumber is not null then
                                       case
                                           when ct.DebitCard_IDREF is not null
                                               then (ct1.CardType_Title + ' • ' + right(ct.DebitMaskedCardNumber, 4))
                                           else (' • ' + right(ct.DebitMaskedCardNumber, 4)) end
                                   else case
                                            when ct.DebitCard_IDREF is not null then (ct1.CardType_Title + ' • ' + right(c1.MaskedNumber, 4))
                                            else (' • ' + right(c1.MaskedNumber, 4)) end
                                   end                as 'senderRu',
                               case
                                   when bc.Bin is not null then
                                       case
                                           when bank.term_OUTREF is not null then
                                               case
                                                   when c2.MaskedNumber is not null then
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (trm_bank.term_EN + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else (trm_bank.term_EN + ' • ' + right(c2.MaskedNumber, 4)) end
                                                   else /*cc2.MaskedNumber is null*/
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (trm_bank.term_EN + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else (trm_bank.term_EN + ' • ') end
                                                   end
                                           else /*b.term_OUTREF is null*/
                                               case
                                                   when c2.MaskedNumber is not null then
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (bank.bank_title + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else (bank.bank_title + ' • ' + right(c2.MaskedNumber, 4)) end
                                                   else /*cc2.MaskedNumber is null*/
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (bank.bank_title + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else (bank.bank_title + ' • ') end
                                                   end
                                           end
                                   /*1*/
                                   else /*bc.Bin is null*/
                                       case
                                           when bank.term_OUTREF is not null then
                                               case
                                                   when c2.MaskedNumber is not null then
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else (' • ' + right(c2.MaskedNumber, 4)) end
                                                   else /*cc2.MaskedNumber is null*/
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else '' end
                                                   end
                                           else /*b.term_OUTREF is null*/
                                               case
                                                   when c2.MaskedNumber is not null then
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else (' • ' + right(c2.MaskedNumber, 4)) end
                                                   else /*cc2.MaskedNumber is null*/
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else '' end
                                                   end
                                           end
                                   end                as 'receiverEn',
                               case
                                   when bc.Bin is not null then
                                       case
                                           when bank.term_OUTREF is not null then
                                               case
                                                   when c2.MaskedNumber is not null then
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (trm_bank.Term_KZ + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else (trm_bank.Term_KZ + ' • ' + right(c2.MaskedNumber, 4)) end
                                                   else /*cc2.MaskedNumber is null*/
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (trm_bank.Term_KZ + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else (trm_bank.Term_KZ + ' • ') end
                                                   end
                                           else /*b.term_OUTREF is null*/
                                               case
                                                   when c2.MaskedNumber is not null then
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (bank.bank_title + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else (bank.bank_title + ' • ' + right(c2.MaskedNumber, 4)) end
                                                   else /*cc2.MaskedNumber is null*/
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (bank.bank_title + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else (bank.bank_title + ' • ') end
                                                   end
                                           end
                                   /*1*/
                                   else /*bc.Bin is null*/
                                       case
                                           when bank.term_OUTREF is not null then
                                               case
                                                   when c2.MaskedNumber is not null then
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else (' • ' + right(c2.MaskedNumber, 4)) end
                                                   else /*cc2.MaskedNumber is null*/
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else '' end
                                                   end
                                           else /*b.term_OUTREF is null*/
                                               case
                                                   when c2.MaskedNumber is not null then
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else (' • ' + right(c2.MaskedNumber, 4)) end
                                                   else /*cc2.MaskedNumber is null*/
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else '' end
                                                   end
                                           end
                                   end                as 'receiverKk',
                               case
                                   when bc.Bin is not null then
                                       case
                                           when bank.term_OUTREF is not null then
                                               case
                                                   when c2.MaskedNumber is not null then
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (trm_bank.Term_RU + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else (trm_bank.Term_RU + ' • ' + right(c2.MaskedNumber, 4)) end
                                                   else /*cc2.MaskedNumber is null*/
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (trm_bank.Term_RU + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else (trm_bank.Term_RU + ' • ') end
                                                   end
                                           else /*b.term_OUTREF is null*/
                                               case
                                                   when c2.MaskedNumber is not null then
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (bank.bank_title + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else (bank.bank_title + ' • ' + right(c2.MaskedNumber, 4)) end
                                                   else /*cc2.MaskedNumber is null*/
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (bank.bank_title + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else (bank.bank_title + ' • ') end
                                                   end
                                           end
                                   /*1*/
                                   else /*bc.Bin is null*/
                                       case
                                           when bank.term_OUTREF is not null then
                                               case
                                                   when c2.MaskedNumber is not null then
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else (' • ' + right(c2.MaskedNumber, 4)) end
                                                   else /*cc2.MaskedNumber is null*/
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else '' end
                                                   end
                                           else /*b.term_OUTREF is null*/
                                               case
                                                   when c2.MaskedNumber is not null then
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else (' • ' + right(c2.MaskedNumber, 4)) end
                                                   else /*cc2.MaskedNumber is null*/
                                                       case
                                                           when ct.CreditMaskedCardNumber is not null
                                                               then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                           /*ct.CreditMaskedCardNumber is null*/
                                                           else '' end
                                                   end
                                           end
                                   end                as 'receiverRu',
                               bank.BIC               as imageDefinition
                        from FinDoc fd
                                 join FinDocState fds on fd.FinDoc_ID = fds.FinDoc_IDREF
                                 join DocTechStatus dts on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF and
                                                           dts.FinDocStatus_IDREF in ('DONE', 'PROC', 'EROR', 'RJCT')
                                 join FinDocType fdt on fdt.FinDocType_ID = fd.FinDocType_IDREF
                                 left join Term trm_fdt on trm_fdt.Term_ID = fdt.Term_OUTREF
                                 join CardTransfer ct on ct.FinDoc_IDREF = fd.FinDoc_ID and ct.CardTransferType_IDREF != 'LPEC'
                                 left join CardTransferType ctt on ct.CardTransferType_IDREF = ctt.CardTransferType_ID
                                 left join card c1 on ct.DebitCard_IDREF = c1.Card_ID
                                 left join card c2 on ct.CreditCard_IDREF = c2.Card_ID
                                 left join CardType ct1 on c1.CardType_IDREF = ct1.CardType_ID
                                 left join CardType ct2 on c2.CardType_IDREF = ct2.CardType_ID
                                 left join BinCard bc on left(ct.CreditMaskedCardNumber, 6) = bc.Bin
                                 left join Bank bank on bc.Bank_IDREF = bank.Bank_ID
                                 left join Term trm_bank on bank.Term_OUTREF = trm_bank.Term_ID
                        where fdt.FinDocType_ID in ('CRCR')
                          and fd.DateCreated >= :dateFrom
                          and fd.DateCreated <= :dateTill
                          and fd.User_IDREF = :userId
                        order by createdDate desc;
                """,
            countQuery = """

                    select COUNT(*)
                FROM (select fd.FinDoc_ID as finDocId
                      from FinDoc fd
                               join FinDocState fds on fd.FinDoc_ID = fds.FinDoc_IDREF
                               join DocTechStatus dts on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF and
                                                         dts.FinDocStatus_IDREF in ('DONE', 'PROC', 'EROR', 'RJCT')
                               join FinDocType fdt on fdt.FinDocType_ID = fd.FinDocType_IDREF
                               left join Term trm_fdt on trm_fdt.Term_ID = fdt.Term_OUTREF
                               left join Account a on a.Account_ID = fd.Account_IDREF
                               left join AccountType at on a.AccountType_IDREF = at.AccountType_ID
                               left join Term trm_at on at.Term_OUTREF = trm_at.Term_ID
                               join IPSTransfer ipst on fd.FinDoc_ID = ipst.FinDoc_IDREF and ipst.TransferType != 'IPSP'
                               left join map_User_Account on map_User_Account.User_IDREF = fd.User_IDREF and
                                                             map_User_Account.Account_IDREF = fd.Account_IDREF
                      where FinDocType_ID in ('OIPS', 'IIPS')
                        and fd.DateCreated >= :dateFrom
                        and fd.DateCreated <= :dateTill
                        and fd.User_IDREF = :userId
                      union
                      select fd.FinDoc_ID as finDocId
                      from FinDoc fd
                               join FinDocState fds on fd.FinDoc_ID = fds.FinDoc_IDREF
                               join DocTechStatus dts on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF and
                                                         dts.FinDocStatus_IDREF in ('DONE', 'PROC', 'EROR', 'RJCT', 'RTRN')
                               join FinDocType fdt on fdt.FinDocType_ID = fd.FinDocType_IDREF
                               left join Term trm_fdt on trm_fdt.Term_ID = fdt.Term_OUTREF
                               left join Account a on a.Account_ID = fd.Account_IDREF
                               left join AccountType at on a.AccountType_IDREF = at.AccountType_ID
                               left join Term trm_at on at.Term_OUTREF = trm_at.Term_ID
                               join Transfer t on fd.FinDoc_ID = t.FinDoc_IDREF
                               left join map_User_Account on map_User_Account.User_IDREF = fd.User_IDREF and
                                                             map_User_Account.Account_IDREF = fd.Account_IDREF
                               left join bank on t.Receiver_BIC = bank.BIC
                               left join term trm_bank on bank.Term_OUTREF = trm_bank.Term_ID
                      where FinDocType_ID in ('TLOC', 'TOUT', 'TINT')
                        and fd.DateCreated >= :dateFrom
                        and fd.DateCreated <= :dateTill
                        and fd.User_IDREF = :userId
                      union
                      select fd.FinDoc_ID as finDocId
                      from FinDoc fd
                               join FinDocState fds on fd.FinDoc_ID = fds.FinDoc_IDREF
                               join DocTechStatus dts on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF and
                                                         dts.FinDocStatus_IDREF in ('DONE', 'PROC', 'EROR', 'RJCT')
                               join FinDocType fdt on fdt.FinDocType_ID = fd.FinDocType_IDREF
                               left join Term trm_fdt on trm_fdt.Term_ID = fdt.Term_OUTREF
                               left join Account a on a.Account_ID = fd.Account_IDREF
                               left join AccountType at on a.AccountType_IDREF = at.AccountType_ID
                               left join Term trm_at on at.Term_OUTREF = trm_at.Term_ID
                               left join Transfer t on fd.FinDoc_ID = t.FinDoc_IDREF
                               left join map_User_Account on map_User_Account.User_IDREF = fd.User_IDREF and
                                                             map_User_Account.Account_IDREF = fd.Account_IDREF
                               left join Account acc_rec on acc_rec.Number = t.Receiver_Account
                               left join AccountType at_rec on acc_rec.AccountType_IDREF = at_rec.AccountType_ID
                               left join term trm_rec on trm_rec.Term_ID = at_rec.Term_OUTREF
                      where fdt.FinDocType_ID in ('TSLF')
                        and fd.DateCreated >= :dateFrom
                        and fd.DateCreated <= :dateTill
                        and fd.User_IDREF = :userId
                      union
                      select fd.FinDoc_ID as finDocId
                      from FinDoc fd
                               join FinDocState fds on fd.FinDoc_ID = fds.FinDoc_IDREF
                               join DocTechStatus dts on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF and
                                                         dts.FinDocStatus_IDREF in ('DONE', 'PROC', 'EROR', 'RJCT')
                               join FinDocType fdt on fdt.FinDocType_ID = fd.FinDocType_IDREF
                               left join Term trm_fdt on trm_fdt.Term_ID = fdt.Term_OUTREF
                               join CardTransfer ct on ct.FinDoc_IDREF = fd.FinDoc_ID and ct.CardTransferType_IDREF != 'LPEC'
                               left join CardTransferType ctt on ct.CardTransferType_IDREF = ctt.CardTransferType_ID
                               left join card c1 on ct.DebitCard_IDREF = c1.Card_ID
                               left join card c2 on ct.CreditCard_IDREF = c2.Card_ID
                               left join CardType ct1 on c1.CardType_IDREF = ct1.CardType_ID
                               left join CardType ct2 on c2.CardType_IDREF = ct2.CardType_ID
                               left join BinCard bc on left(ct.CreditMaskedCardNumber, 6) = bc.Bin
                               left join Bank bank on bc.Bank_IDREF = bank.Bank_ID
                               left join Term trm_bank on bank.Term_OUTREF = trm_bank.Term_ID
                      where fdt.FinDocType_ID in ('CRCR')
                        and fd.DateCreated >= :dateFrom
                        and fd.DateCreated <= :dateTill
                        and fd.User_IDREF = :userId) as historyCount;
                """,
            nativeQuery = true)
    Page<TransferStory> findByDatePeriodAndUserId(@Param("dateFrom") LocalDate from,
                                                  @Param("dateTill") LocalDate to,
                                                  @Param("userId") Long userId,
                                                  Pageable pageable);
}
