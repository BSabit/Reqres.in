package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.in.infrastructure.IipsTransferIn;

import java.util.Optional;

public interface IipsTransferRepository {

    Optional<IipsTransferIn> findByFinDocId(Long finDocId);
}
