package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferResponse;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferTcWay4;

public interface TransferTcWay4UseCase {

    TransferTcWay4 invoke(TransferResponse transferResponse, String correlationId);
}
