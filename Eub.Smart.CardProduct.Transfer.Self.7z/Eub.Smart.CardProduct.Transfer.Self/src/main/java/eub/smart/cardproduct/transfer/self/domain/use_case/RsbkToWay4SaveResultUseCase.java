package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToWay4;

public interface RsbkToWay4SaveResultUseCase {

    void invoke(Long finDocId, RrnBrrn rrnBrrn, TransferRsbkToWay4 transferRsbkToWay4);
}
