package eub.smart.cardproduct.transfer.self.domain.model.grpc;

public class TryReverseDocRequest {

    private String collectorId;

    public TryReverseDocRequest() {
    }

    public TryReverseDocRequest(String collectorId) {
        this.collectorId = collectorId;
    }

    public void setCollectorId(String collectorId) {
        this.collectorId = collectorId;
    }

    public String getCollectorId() {
        return collectorId;
    }

    @Override
    public String toString() {
        return "TryReverseDocRequest{" +
                "collectorId=" + collectorId +
                '}';
    }
}
