package eub.smart.cardproduct.transfer.self.core.util;

public class AccountUtil {

    public static String maskAccountNumber(String accountNumber) {
        if (StringUtil.isEmpty(accountNumber)) return accountNumber;
        int length = accountNumber.length();
        if (length < 8) return accountNumber;
        String substring1 = accountNumber.substring(0, 2);
        String substring2 = accountNumber.substring(length - 4, length);
        return substring1 + "**" + substring2;
    }
}
