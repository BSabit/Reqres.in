package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.core.util.LangUtil;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.repository.MessageSourceRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.ValidateMultiConvertUseCase;

import java.util.Objects;

import static eub.smart.cardproduct.transfer.self.core.constant.BundleCode.ERROR_MESSAGE_MTNT;
import static eub.smart.cardproduct.transfer.self.core.constant.BundleCode.ERROR_MESSAGE_VLSS;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_LG_800_MTNT;
import static java.util.Objects.isNull;

public class ValidateMultiConvertUseCaseImpl implements ValidateMultiConvertUseCase {

    private final MessageSourceRepository messageSourceRepository;

    public ValidateMultiConvertUseCaseImpl(MessageSourceRepository messageSourceRepository) {
        this.messageSourceRepository = messageSourceRepository;
    }

    @Override
    public void invoke(AccountData sender, AccountData receiver, LangKey lang) {
        if (isInvalid(sender, receiver)) {
            var locale = LangUtil.get(lang);
            var message = messageSourceRepository.getMessage(ERROR_MESSAGE_MTNT, locale);
            throw new SelfException(
                    E_LG_800_MTNT,
                    ": illegal operation",
                    message);
        }
    }

    private boolean isInvalid(AccountData sender, AccountData receiver) {
        var senderCurrency = sender.getCurrency();
        var receiverCurrency = receiver.getCurrency();
        var senderFlagMulti = sender.getFlagMulti();
        var receiverFlagMulti = receiver.getFlagMulti();
        var senderAccountIdRef = sender.getAccountIdRef();
        var receiverAccountIdRef = receiver.getAccountIdRef();
        var senderAccountNumber = sender.getAccountNumber();
        var receiverAccountNumber = receiver.getAccountNumber();

        return isBothMulti(senderFlagMulti, receiverFlagMulti) &&
                isOneOldMulti(senderAccountIdRef, receiverAccountIdRef) &&
                isConvert(senderCurrency, receiverCurrency) &&
                isNotWithinOneAccount(senderAccountNumber, receiverAccountNumber);
    }

    private boolean isConvert(String senderCurrency, String receiverCurrency) {
        return !Objects.equals(senderCurrency, receiverCurrency);
    }

    private boolean isOneOldMulti(Long senderAccountIdRef, Long receiverAccountIdRef) {
        return isNull(senderAccountIdRef) || isNull(receiverAccountIdRef);
    }

    private boolean isBothMulti(Boolean senderFlagMulti, Boolean receiverFlagMulti) {
        return senderFlagMulti && receiverFlagMulti;
    }

    private boolean isNotWithinOneAccount(String senderAccountNumber, String receiverAccountNumber) {
        return !Objects.equals(senderAccountNumber, receiverAccountNumber);
    }
}
