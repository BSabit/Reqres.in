package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.domain.model.in.TransferReceiptIn;
import eub.smart.cardproduct.transfer.self.domain.model.out.TransferReceiptOut;

public interface TransferReceiptUseCase {

    TransferReceiptOut invoke(TransferReceiptIn in, LangKey lang);
}
