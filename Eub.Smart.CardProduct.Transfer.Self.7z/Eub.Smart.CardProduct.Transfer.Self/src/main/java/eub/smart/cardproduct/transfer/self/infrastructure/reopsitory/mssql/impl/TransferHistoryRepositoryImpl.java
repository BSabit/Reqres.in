package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.component.AuthToken;
import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.core.model.UserDetails;
import eub.smart.cardproduct.transfer.self.core.util.CollectionUtil;
import eub.smart.cardproduct.transfer.self.core.util.LangUtil;
import eub.smart.cardproduct.transfer.self.domain.model.in.StoryIn;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferHistoryRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.TransferHistoryMapper;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.FinDocHiberRepository;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.stream.Collectors;

import static eub.smart.cardproduct.transfer.self.core.constant.BundleCode.ERROR_MESSAGE_EMPTY_TRANSFER_HISTORY;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_605;

@Repository
public class TransferHistoryRepositoryImpl implements TransferHistoryRepository {

    private final FinDocHiberRepository finDocRepository;
    private final AuthToken authToken;
    private final MessageSource messageSource;

    public TransferHistoryRepositoryImpl(FinDocHiberRepository finDocRepository,
                                         AuthToken authToken,
                                         MessageSource messageSource) {
        this.finDocRepository = finDocRepository;
        this.authToken = authToken;
        this.messageSource = messageSource;
    }

    @Override
    public Page<StoryIn> findByDatePeriodAndUserId(LocalDate from, LocalDate to, Pageable pageable, LangKey lang) {
        var userId = extractUserIdFromToken();
        var historyInPage = finDocRepository.findByDatePeriodAndUserId(from, to.plusDays(1), userId, pageable);
        var errorMessage = formErrorMessage(lang);
        if (CollectionUtil.isEmpty(historyInPage.getContent()))
            throw new SelfException(E_DB_605, ": history page is empty", errorMessage);
        var historyIn = historyInPage.stream()
                .map(TransferHistoryMapper::toStoryIn)
                .collect(Collectors.toList());
        return new PageImpl<>(historyIn, pageable, historyInPage.getTotalElements());
    }

    private Long extractUserIdFromToken() {
        var decodedPayload = authToken.getDecodedPayload();
        var userDetails = UserDetails.build(decodedPayload);
        return userDetails.getUserId();
    }

    private String formErrorMessage(LangKey lang) {
        return messageSource.getMessage(ERROR_MESSAGE_EMPTY_TRANSFER_HISTORY, null, LangUtil.get(lang));
    }
}
