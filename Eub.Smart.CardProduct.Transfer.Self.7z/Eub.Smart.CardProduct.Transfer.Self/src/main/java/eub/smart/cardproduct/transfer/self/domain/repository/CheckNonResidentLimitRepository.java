package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.Usage;

import java.util.Optional;

public interface CheckNonResidentLimitRepository {

    Optional<Usage> findByFinDocId(Long finDocId);
}
