package eub.smart.cardproduct.transfer.self.core.util;

import java.time.LocalTime;

public class DateTimeUtil {

    public static final LocalTime DAY_START = LocalTime.of(9, 0);
    public static final LocalTime DAY_END = LocalTime.of(17, 0);
}
