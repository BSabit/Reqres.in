package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.domain.model.AccountInfo;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.scanner.MapResultScanner;

import java.util.Map;

public class AccountMapper {

    public static AccountInfo toNewAccountInfo(Map<String, Object> row) {
        MapResultScanner scanner = new MapResultScanner(row);

        AccountInfo model = new AccountInfo();
        model.setId(scanner.getLong("accountId"));
        model.setType(scanner.getString("accountType"));
        model.setNumber(scanner.getString("number"));
        model.setCurrency(scanner.getString("currency"));
        model.setFlagMultiCurrency(scanner.getBoolean("multiCurrencyFlag"));
        model.setIdRef(scanner.getLong("accountIdRef"));
        model.setClientIdRef(scanner.getLong("clientIdRef"));
        model.setResidentFlag(scanner.getBoolean("residentFlag"));
        return model;
    }

}
