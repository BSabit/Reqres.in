package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToWay4ReverseTransit;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.UfxResponse;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.UfxTransferRequest;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferSelfProtoRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.TransferRsbkToWay4ReverseTransitUseCase;

public class TransferRsbkToWay4ReverseTransitUseCaseImpl implements TransferRsbkToWay4ReverseTransitUseCase {

    private final TransferSelfProtoRepository transferSelfProtoRepository;

    public TransferRsbkToWay4ReverseTransitUseCaseImpl(TransferSelfProtoRepository transferSelfProtoRepository) {
        this.transferSelfProtoRepository = transferSelfProtoRepository;
    }

    @Override
    public TransferRsbkToWay4ReverseTransit invoke(UfxTransferRequest ufxTransferRequest) {
        var ufxResponse = transferSelfProtoRepository.transferRsbkToWay4ReverseTransit(ufxTransferRequest);
        return new TransferRsbkToWay4ReverseTransit(ufxTransferRequest, ufxResponse );
    }
}
