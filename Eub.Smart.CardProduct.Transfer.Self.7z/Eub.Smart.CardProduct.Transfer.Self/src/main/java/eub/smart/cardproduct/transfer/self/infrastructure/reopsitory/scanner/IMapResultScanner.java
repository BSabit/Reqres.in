package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.scanner;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Date;

public interface IMapResultScanner {
    String getString(String fieldName);
    Integer getInteger(String fieldName);
    Long getLong(String fieldName);
    Boolean getBoolean(String fieldName);
    Double getDouble(String fieldName);
    Date getDate(String fieldName);
    Object getObject(String fieldName);
    BigDecimal getBigDecimal(String fieldName);
}
