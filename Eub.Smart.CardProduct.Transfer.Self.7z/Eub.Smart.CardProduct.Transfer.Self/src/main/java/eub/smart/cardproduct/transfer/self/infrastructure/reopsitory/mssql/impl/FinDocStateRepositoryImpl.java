package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.repository.FinDocStateRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.entity.FinDocState;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.FinDocStateHiberRepository;
import org.springframework.stereotype.Repository;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;

@Repository
public class FinDocStateRepositoryImpl implements FinDocStateRepository {

    private final FinDocStateHiberRepository finDocStateHiberRepository;

    public FinDocStateRepositoryImpl(FinDocStateHiberRepository finDocStateHiberRepository) {
        this.finDocStateHiberRepository = finDocStateHiberRepository;
    }

    @Override
    public void saveFinDocStatus(String status, Long finDocId) {
        FinDocState finDocState = finDocStateHiberRepository.findByFinDocId(finDocId)
                .orElseThrow(() -> new SelfException(E_DB_600, ": FinDocStateRepositoryImpl findByFinDocId"));
        finDocState.setDocTechStatus(status);
        finDocStateHiberRepository.save(finDocState);
    }
}

