package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToWay4Request;

import java.util.Optional;

public interface TransferRsbkToWay4Repository {

    Optional<TransferRsbkToWay4Request> findByFinDocId(Long finDocId);

    TransferRsbkToWay4Request findByFinDocIdOrException(Long finDocId);
}
