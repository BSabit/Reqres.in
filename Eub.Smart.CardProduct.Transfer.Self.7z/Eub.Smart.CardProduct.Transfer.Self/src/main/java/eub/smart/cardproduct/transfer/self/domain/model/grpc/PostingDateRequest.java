package eub.smart.cardproduct.transfer.self.domain.model.grpc;

public class PostingDateRequest {

    private String rrn;

    public PostingDateRequest() {
    }

    public PostingDateRequest(String rrn) {
        this.rrn = rrn;
    }

    public void setRrn(String rrn) {
        this.rrn = rrn;
    }

    public String getRrn() {
        return rrn;
    }

    @Override
    public String toString() {
        return "PostingDateRequest{" +
                "rrn=" + rrn +
                '}';
    }
}
