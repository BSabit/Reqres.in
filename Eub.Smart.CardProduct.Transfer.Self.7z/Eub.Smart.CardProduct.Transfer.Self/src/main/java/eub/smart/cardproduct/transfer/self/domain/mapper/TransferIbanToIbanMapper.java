package eub.smart.cardproduct.transfer.self.domain.mapper;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferIbanToIbanRequest;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.scanner.MapResultScanner;

import java.util.Map;

import static eub.smart.cardproduct.transfer.self.core.util.StanUtil.generateStun;

public class TransferIbanToIbanMapper {

    public static TransferIbanToIbanRequest createRequest(AccountData senderData, AccountData receiverData, RrnBrrn rrnBrrn) {
        TransferIbanToIbanRequest model = new TransferIbanToIbanRequest();
        model.setSenderNumber(senderData.getAccountNumber());
        model.setReceiverNumber(receiverData.getAccountNumber());
        model.setRrn(rrnBrrn.getRrn());
        model.setStan(generateStun());
        model.setAmount(senderData.getAmount());
        model.setCurrency(senderData.getCurrency());
        return model;
    }
}
