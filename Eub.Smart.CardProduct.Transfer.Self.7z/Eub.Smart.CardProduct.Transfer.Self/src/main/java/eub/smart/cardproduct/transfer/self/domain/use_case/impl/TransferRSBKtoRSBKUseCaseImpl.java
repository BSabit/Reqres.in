package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToRsbk;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToRsbkRequest;
import eub.smart.cardproduct.transfer.self.domain.repository.RsbkTransactionalProtoRepository;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferRsbkToRsbkRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.TransferRSBKtoRSBKUseCase;

public class TransferRSBKtoRSBKUseCaseImpl implements TransferRSBKtoRSBKUseCase {

    private final RsbkTransactionalProtoRepository rsbkTransactionalProtoRepository;

    public TransferRSBKtoRSBKUseCaseImpl(RsbkTransactionalProtoRepository rsbkTransactionalProtoRepository) {
        this.rsbkTransactionalProtoRepository = rsbkTransactionalProtoRepository;
    }

    @Override
    public TransferRsbkToRsbk invoke(FinDocData finDocData, AccountData senderData, AccountData receiverData) {
        var request = new TransferRsbkToRsbkRequest(finDocData, senderData, receiverData);
        var response = rsbkTransactionalProtoRepository.transferRsbkToRsbk(request, finDocData.getCorrelationId());
        return new TransferRsbkToRsbk(request, response);
    }
}
