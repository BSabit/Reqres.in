package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4ToWay4Credit;

import java.util.Optional;

public interface TransferWay4ToWay4CreditRepository {

    Optional<TransferWay4ToWay4Credit> findByFinDocId(Long finDocId, RrnBrrn rrnBrrn, String stun);

    TransferWay4ToWay4Credit findByFinDocIdOrException(Long finDocId, RrnBrrn rrnBrrn, String stun);
}
