package eub.smart.cardproduct.transfer.self.domain.mapper;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.UfxTransferRequest;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.scanner.MapResultScanner;

import java.util.Map;

import static eub.smart.cardproduct.transfer.self.core.util.StanUtil.generateStun;


public class TransferWay4ToRsbkCreditTransitMapper {

    private static String createDetails(String fullname, String accountNumber) {
        return String.format("To RS; %s; %s", fullname, accountNumber);
    }

    public static UfxTransferRequest createRequest(FinDocData finDocData, AccountData senderData, AccountData receiverData, RrnBrrn rrnBrrn, String operationAccount) {
        UfxTransferRequest request = new UfxTransferRequest();
        request.setFindoc(String.valueOf(finDocData.getId()));
        request.setRrn(rrnBrrn.getBrrn());
        request.setBrrn(rrnBrrn.getRrn());
        request.setStan(generateStun());
        request.setOperationAccount(operationAccount);
        request.setOperationSum(senderData.getAmount());
        request.setOperationCurrency(senderData.getCurrency());
        request.setLinkedOperationAccount(receiverData.getAccountNumber());
        request.setDeposit(false);
        request.setDetails(createDetails(receiverData.getFullName(), receiverData.getAccountNumber()));
        return request;
    }

}
