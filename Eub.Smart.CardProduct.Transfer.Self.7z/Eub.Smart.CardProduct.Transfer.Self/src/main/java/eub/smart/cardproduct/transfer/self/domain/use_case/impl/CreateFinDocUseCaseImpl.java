package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.component.AuthToken;
import eub.smart.cardproduct.transfer.self.core.model.UserDetails;
import eub.smart.cardproduct.transfer.self.domain.model.FinDoc;
import eub.smart.cardproduct.transfer.self.domain.model.CreateTransferAccountInfo;
import eub.smart.cardproduct.transfer.self.domain.repository.FinDocRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.CreateFinDocUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.GetFeeUseCase;

import java.math.BigDecimal;
import java.util.Date;

public class CreateFinDocUseCaseImpl implements CreateFinDocUseCase {

    private final GetFeeUseCase getFeeUseCase;
    private final FinDocRepository finDocRepository;
    private final AuthToken authToken;

    public CreateFinDocUseCaseImpl(GetFeeUseCase getFeeUseCase,
                                   FinDocRepository finDocRepository,
                                   AuthToken authToken) {
        this.getFeeUseCase = getFeeUseCase;
        this.finDocRepository = finDocRepository;
        this.authToken = authToken;
    }

    @Override
    public FinDoc invoke(String type,
                         BigDecimal amount,
                         Long finDocIdRef,
                         CreateTransferAccountInfo senderAccount,
                         CreateTransferAccountInfo receiverAccount) {
        var senderAccountNumber = senderAccount.getNumber();
        var senderCurrency = senderAccount.getCurrency();
        var receiverCurrency = receiverAccount.getCurrency();
        var accountId = senderAccount.getId();
        var selfFee = getFeeUseCase.invoke(amount, senderAccountNumber, senderCurrency, receiverCurrency, type);
        var feeAmount = selfFee.getAmount();
        var feeCurrency = selfFee.getCurrency();
        var payload = authToken.getDecodedPayload();
        var userDetails = UserDetails.build(payload);
        var userId = userDetails.getUserId();
        var dateScheduled = new Date();
        var dateCreated = new Date();

        var finDoc = new FinDoc(
                type, userId, null, accountId, senderCurrency,
                amount, feeAmount, feeCurrency, dateCreated,
                dateScheduled, null, false, false,
                null, null, 0, finDocIdRef);
        return finDocRepository.save(finDoc);
    }
}
