package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4ToWay4;

public interface TransferWay4ToWay4DebitUseCase {

    TransferWay4ToWay4 invoke(FinDocData finDocData, AccountData senderData, AccountData receiverData, RrnBrrn rrnBrrn);
}
