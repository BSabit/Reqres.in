package eub.smart.cardproduct.transfer.self.domain.repository;

import java.util.Optional;

public interface FinDocTypeRepository {

    Optional<Long> findTargetIdById(String targetPk);

    Long findTargetIdByIdOrException(String targetPk);
}
