package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.domain.model.in.TransferHistoryIn;
import eub.smart.cardproduct.transfer.self.domain.model.out.StoryOut;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface TransferHistoryUseCase {

    Page<StoryOut> invoke(TransferHistoryIn in, Pageable pageable, LangKey lang);
}
