package eub.smart.cardproduct.transfer.self.domain.model.grpc;

import java.math.BigDecimal;

public class TransferIbanToIbanRequest {

    private String senderNumber;
    private String receiverNumber;
    private String rrn;
    private String stan;
    private BigDecimal amount;
    private String currency;

    public String getSenderNumber() {
        return senderNumber;
    }

    public void setSenderNumber(String senderNumber) {
        this.senderNumber = senderNumber;
    }

    public String getReceiverNumber() {
        return receiverNumber;
    }

    public void setReceiverNumber(String receiverNumber) {
        this.receiverNumber = receiverNumber;
    }

    public String getRrn() {
        return rrn;
    }

    public void setRrn(String rrn) {
        this.rrn = rrn;
    }

    public String getStan() {
        return stan;
    }

    public void setStan(String stan) {
        this.stan = stan;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @Override
    public String toString() {
        return "TransferIbanToIbanRequest{" +
                "senderNumber=" + senderNumber +
                ", receiverNumber=" + receiverNumber +
                ", rrn=" + rrn +
                ", stan=" + stan +
                ", amount=" + amount +
                ", currency=" + currency +
                '}';
    }
}
