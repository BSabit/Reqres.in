package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.repository.LimitClientDayRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.LimitClientDayUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.LimitFinDocUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.LimitUseCase;

import java.math.BigDecimal;
import java.time.LocalDate;

import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isEmpty;

public class LimitClientDayUseCaseImpl implements LimitClientDayUseCase {

    private final LimitClientDayRepository limitClientDayRepository;
    private final LimitFinDocUseCase finDocUseCase;
    private final LimitUseCase limitUseCase;

    public LimitClientDayUseCaseImpl(LimitClientDayRepository limitClientDayRepository,
                                     LimitFinDocUseCase finDocUseCase,
                                     LimitUseCase limitUseCase) {
        this.limitClientDayRepository = limitClientDayRepository;
        this.finDocUseCase = finDocUseCase;
        this.limitUseCase = limitUseCase;
    }

    @Override
    public void invoke(BigDecimal limitDay, Long clientId, Long userId, BigDecimal amount, String currency, String correlationId, Boolean convert) {
        LocalDate currentDate = LocalDate.now();
        var spentAmountGroupByCurrency = limitClientDayRepository.findByClientIdAndUserId(currentDate, clientId, userId);
        if (isEmpty(spentAmountGroupByCurrency)) finDocUseCase.invoke(limitDay, amount, currency, correlationId);
        limitUseCase.invoke(limitDay, correlationId, amount, currency, convert, spentAmountGroupByCurrency);
    }

}
