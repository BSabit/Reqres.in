package eub.smart.cardproduct.transfer.self.domain.model.grpc;

public class TransferIbanToIban {

    private TransferIbanToIbanRequest transferIbanToIbanRequest;
    private UfxResponse transferIbanToIbanResponse;

    public TransferIbanToIban() {
    }

    public TransferIbanToIban(TransferIbanToIbanRequest transferIbanToIbanRequest, UfxResponse transferIbanToIbanResponse) {
        this.transferIbanToIbanRequest = transferIbanToIbanRequest;
        this.transferIbanToIbanResponse = transferIbanToIbanResponse;
    }

    public TransferIbanToIbanRequest getTransferIbanToIbanRequest() {
        return transferIbanToIbanRequest;
    }

    public void setTransferIbanToIbanRequest(TransferIbanToIbanRequest transferIbanToIbanRequest) {
        this.transferIbanToIbanRequest = transferIbanToIbanRequest;
    }

    public UfxResponse getTransferIbanToIbanResponse() {
        return transferIbanToIbanResponse;
    }

    public void setTransferIbanToIbanResponse(UfxResponse transferIbanToIbanResponse) {
        this.transferIbanToIbanResponse = transferIbanToIbanResponse;
    }
}
