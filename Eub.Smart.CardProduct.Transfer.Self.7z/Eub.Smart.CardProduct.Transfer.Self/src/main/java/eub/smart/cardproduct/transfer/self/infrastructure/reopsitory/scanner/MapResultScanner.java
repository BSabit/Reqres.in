package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.scanner;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_603;

public class MapResultScanner implements IMapResultScanner {

    private final Map<String, Object> map;

    public MapResultScanner(Map<String, Object> map){
        this.map = map;
    }

    @Override
    public String getString(String fieldName) {
        Object obj = getObjectOrThrow(fieldName);
        return obj == null ? null : obj.toString();
    }

    public String getStringOrNull(String fieldName) {
        Object obj = getObjectOrNull(fieldName);
        return obj == null ? null : obj.toString();
    }

    @Override
    public Integer getInteger(String fieldName) {
        Object obj = getObjectOrThrow(fieldName);
        return obj == null ? null : ((Number)obj).intValue();
    }

    public Integer getIntegerOrNull(String fieldName) {
        Object obj = getObjectOrNull(fieldName);
        return obj == null ? null : ((Number)obj).intValue();
    }

    @Override
    public Long getLong(String fieldName) {
        Object obj = getObjectOrThrow(fieldName);
        return obj == null ? null : ((Number)obj).longValue();
    }

    public Long getLongOrNull(String fieldName) {
        Object obj = getObjectOrNull(fieldName);
        return obj == null ? null : ((Number)obj).longValue();
    }

    @Override
    public Boolean getBoolean(String fieldName) {
        return (Boolean) getObjectOrThrow(fieldName);
    }

    public Boolean getBooleanOrNull(String fieldName) {
        return (Boolean) getObjectOrNull(fieldName);
    }

    @Override
    public Double getDouble(String fieldName) {
        Object obj = getObjectOrThrow(fieldName);
        return obj == null ? null : ((Number)obj).doubleValue();
    }

    @Override
    public Date getDate(String fieldName) {
        return (Date) getObjectOrThrow(fieldName);
    }

    @Override
    public Object getObject(String fieldName) {
        return getObjectOrThrow(fieldName);
    }

    @Override
    public BigDecimal getBigDecimal(String fieldName) {
        return (BigDecimal) getObjectOrThrow(fieldName);
    }

    private Object getObjectOrThrow(String fieldName){
        if(!map.containsKey(fieldName)){
            throw new SelfException(E_DB_603, ": field name: " + fieldName + " is not match");
        }
        return map.get(fieldName);
    }

    private Object getObjectOrNull(String fieldName) {
        if(!map.containsKey(fieldName)){
            return null;
        }
        return map.get(fieldName);
    }
}
