package eub.smart.cardproduct.transfer.self.application.mapper;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.SenderDetails;
import org.mapstruct.Mapper;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING)
public interface ApplicationMapper {

    AccountData toDomain(eub.smart.cardproduct.transfer.self.application.model.AccountData accountData);

    FinDocData toDomain(eub.smart.cardproduct.transfer.self.application.model.FinDocData finDocData);

    SenderDetails toDomain(eub.smart.cardproduct.transfer.self.application.model.SenderDetails senderDetails);
    RrnBrrn toDomain(eub.smart.cardproduct.transfer.self.application.model.RrnBrrn rrnBrrn);
    eub.smart.cardproduct.transfer.self.application.model.RrnBrrn toApplication(RrnBrrn rrnBrrn);

}