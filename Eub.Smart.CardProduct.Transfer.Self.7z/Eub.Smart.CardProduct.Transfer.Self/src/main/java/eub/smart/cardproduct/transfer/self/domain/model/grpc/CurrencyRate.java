package eub.smart.cardproduct.transfer.self.domain.model.grpc;

import java.math.BigDecimal;

public class CurrencyRate {

    private BigDecimal buyRate;
    private BigDecimal sellRate;

    public CurrencyRate() {
    }

    public CurrencyRate(BigDecimal buyRate, BigDecimal sellRate) {
        this.buyRate = buyRate;
        this.sellRate = sellRate;
    }

    public BigDecimal getBuyRate() {
        return buyRate;
    }

    public void setBuyRate(BigDecimal buyRate) {
        this.buyRate = buyRate;
    }

    public BigDecimal getSellRate() {
        return sellRate;
    }

    public void setSellRate(BigDecimal sellRate) {
        this.sellRate = sellRate;
    }

    @Override
    public String toString() {
        return "CurrencyRate{" +
                "buyRate=" + buyRate +
                ", sellRate=" + sellRate +
                '}';
    }
}
