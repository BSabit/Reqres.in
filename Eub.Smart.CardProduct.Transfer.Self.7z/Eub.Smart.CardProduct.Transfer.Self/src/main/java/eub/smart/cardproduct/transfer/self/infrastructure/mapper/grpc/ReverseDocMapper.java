package eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.TryReverseDocReply;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TryReverseDocRequest;
import rsbktransactional.V1.EubAdapterRsbkTransactional;

public class ReverseDocMapper {

    public static EubAdapterRsbkTransactional.TryReverseDocRequest toGrpcModel(TryReverseDocRequest requestModel) {
        return EubAdapterRsbkTransactional.TryReverseDocRequest
                .newBuilder()
                .setCollectorId(requestModel.getCollectorId())
                .build();
    }

    public static TryReverseDocReply toDomainModel(EubAdapterRsbkTransactional.TryReverseDocReply response) {
        return new TryReverseDocReply(response.getIsSuccess(), response.getErrorDesc());
    }
}
