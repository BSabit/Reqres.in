package eub.smart.cardproduct.transfer.self.infrastructure.mapper;

import eub.smart.cardproduct.transfer.self.domain.model.create_transfer.FinDoc;
import eub.smart.cardproduct.transfer.self.domain.model.create_transfer.Transfer;
import org.mapstruct.Mapper;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING)
public interface DomainMapper {

    Transfer toCreateTransfer(eub.smart.cardproduct.transfer.self.domain.model.Transfer domainModel);
    FinDoc toCreateTransfer(eub.smart.cardproduct.transfer.self.domain.model.FinDoc domainModel);


}
