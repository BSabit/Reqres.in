package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferTypeRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.CommonMapper;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isOneResult;

@Primary
@Repository
public class TransferTypeRepositoryImpl implements TransferTypeRepository {

    private final NamedParameterJdbcTemplate template;

    public TransferTypeRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<Long> findOperationId(String accountNumber, String targetCurrency) {
        Map<String, Object> map = new HashMap<>();
        map.put("accountNumber", accountNumber);
        map.put("targetCurrency", targetCurrency);

        String sql = """ 
                select tt.Operation_IDREF   as id
                from dbo.TransferType tt
                         join Account a on a.Currency = tt.SrcCurrency
                where tt.FinDocType_IDREF = 'TSLF'
                    and a.Number = :accountNumber
                    and tt.TargetCurrency = :targetCurrency
                """;

        List<Map<String, Object>> queryResult = template.queryForList(sql, map);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .map(CommonMapper::getLong);
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": TransferTypeRepository findOperationId");
        }
    }

    @Override
    public Optional<Long> findOperationId(String finDocType, String sourceCurrency, String targetCurrency) {
        Map<String, Object> map = new HashMap<>();
        map.put("finDocType", finDocType);
        map.put("sourceCurrency", sourceCurrency);
        map.put("targetCurrency", targetCurrency);

        String sql = """ 
                select tt.Operation_IDREF   as id
                from dbo.TransferType tt
                where tt.FinDocType_IDREF = :finDocType
                    and tt.SrcCurrency = :sourceCurrency
                    and tt.TargetCurrency = :targetCurrency
                    and tt.IsCorporate = 0
                """;

        List<Map<String, Object>> queryResult = template.queryForList(sql, map);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .map(CommonMapper::getLong);
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": TransferTypeRepository findOperationId");
        }
    }

    @Override
    public Optional<String> findId(String finDocType, String srcCurrency, String targetCurrency, Boolean flagCorporate) {
        Map<String, Object> map = new HashMap<>();
        map.put("finDocType", finDocType);
        map.put("srcCurrency", srcCurrency);
        map.put("targetCurrency", targetCurrency);
        map.put("flagCorporate", flagCorporate);

        String sql = """
                select t.TransferType_ID    as type
                from TransferType t
                where t.FinDocType_IDREF = :finDocType
                    and t.SrcCurrency = :srcCurrency
                    and t.TargetCurrency = :targetCurrency
                    and t.IsCorporate = :flagCorporate
                """;

        List<Map<String, Object>> queryResult = template.queryForList(sql, map);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .map(CommonMapper::getString);
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": TransferTypeRepository findId");
        }
    }

    @Override
    public String findIdOrException(String finDocType, String srcCurrency, String targetCurrency, Boolean flagCorporate) {
        return findId(finDocType, srcCurrency, targetCurrency, flagCorporate)
                .orElseThrow(() -> new SelfException(E_DB_600, ": TransferTypeRepository findIdOrException"));
    }

    @Override
    public Long findOperationIdOrException(String finDocType, String sourceCurrency, String targetCurrency) {
        return findOperationId(finDocType, sourceCurrency, targetCurrency)
                .orElseThrow(() -> new SelfException(E_DB_600, ": TransferTypeRepository findOperationIdOrException"));
    }

    @Override
    public Long findOperationIdOrException(String accountNumber, String targetCurrency) {
        return findOperationId(accountNumber, targetCurrency)
                .orElseThrow(() -> new SelfException(E_DB_600, ": TransferTypeRepository findOperationIdOrException"));
    }
}
