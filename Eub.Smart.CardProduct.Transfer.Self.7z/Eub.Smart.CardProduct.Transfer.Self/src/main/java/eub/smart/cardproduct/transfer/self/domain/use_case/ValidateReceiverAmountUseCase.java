package eub.smart.cardproduct.transfer.self.domain.use_case;

import java.math.BigDecimal;

public interface ValidateReceiverAmountUseCase {

    void invoke(BigDecimal senderAmount, BigDecimal receiverAmount, String senderAccountCurrency, String receiverAccountCurrency);
}
