package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.Usage;

import java.util.Optional;

public interface UsageRepository {

    Optional<Usage> findByAccountNumber(String number);

    Usage findByAccountNumberOrException(String number);

    Optional<Usage> findByClintIdAndUserId(Long clientId, Long userId);

    Usage findByClintIdAndUserIdOrException(Long clientId, Long userId);
}