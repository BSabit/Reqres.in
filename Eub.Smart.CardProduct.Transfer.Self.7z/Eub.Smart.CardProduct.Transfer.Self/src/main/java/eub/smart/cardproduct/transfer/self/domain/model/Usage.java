package eub.smart.cardproduct.transfer.self.domain.model;

import java.math.BigDecimal;

public class Usage {

    private Long id;
    private BigDecimal limitFinDoc;
    private BigDecimal limitDay;
    private BigDecimal limitNight;
    private BigDecimal limitMonth;

    public Usage() {
    }

    public Usage(BigDecimal limitFinDoc, BigDecimal limitDay, BigDecimal limitNight) {
        this.limitFinDoc = limitFinDoc;
        this.limitDay = limitDay;
        this.limitNight = limitNight;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public BigDecimal getLimitFinDoc() {
        return limitFinDoc;
    }

    public void setLimitFinDoc(BigDecimal limitFinDoc) {
        this.limitFinDoc = limitFinDoc;
    }

    public BigDecimal getLimitDay() {
        return limitDay;
    }

    public void setLimitDay(BigDecimal limitDay) {
        this.limitDay = limitDay;
    }

    public BigDecimal getLimitNight() {
        return limitNight;
    }

    public void setLimitNight(BigDecimal limitNight) {
        this.limitNight = limitNight;
    }

    public BigDecimal getLimitMonth() {
        return limitMonth;
    }

    public void setLimitMonth(BigDecimal limitMonth) {
        this.limitMonth = limitMonth;
    }

    @Override
    public String toString() {
        return "Usage{" +
                "id=" + id +
                ", limitFinDoc=" + limitFinDoc +
                ", limitDay=" + limitDay +
                ", limitNight=" + limitNight +
                ", limitMonth=" + limitMonth +
                '}';
    }
}
