package eub.smart.cardproduct.transfer.self.domain.repository;

import java.math.BigDecimal;
import java.util.Optional;

public interface MapProductOperationRepository {

    Optional<Long> findFeeId(BigDecimal amount, Long operationId, Long productId);

    Long findFeeIdOrException(BigDecimal amount, Long operationId, Long productId);

    boolean existByAccountNumberAndTransferType(String accountNumber, String transferType);

    boolean absenceByAccountNumberAndTransferType(String accountNumber, String transferType);
}
