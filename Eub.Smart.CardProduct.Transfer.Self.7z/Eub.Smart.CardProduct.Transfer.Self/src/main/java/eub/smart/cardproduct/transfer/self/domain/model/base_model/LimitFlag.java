package eub.smart.cardproduct.transfer.self.domain.model.base_model;

public class LimitFlag {

    private Boolean clientMonthLimit;
    private Boolean clientNightLimit;
    private Boolean clientDayLimit;
    private Boolean clientFinDocLimit;
    private Boolean accountMonthLimit;
    private Boolean accountNightLimit;
    private Boolean accountDayLimit;
    private Boolean accountFinDocLimit;
    private Boolean day;

    public LimitFlag() {
    }

    public LimitFlag(Boolean day) {
        this.day = day;
    }

    public Boolean getClientMonthLimit() {
        return clientMonthLimit;
    }

    public void setClientMonthLimit(Boolean clientMonthLimit) {
        this.clientMonthLimit = clientMonthLimit;
    }

    public Boolean getClientNightLimit() {
        return clientNightLimit;
    }

    public void setClientNightLimit(Boolean clientNightLimit) {
        this.clientNightLimit = clientNightLimit;
    }

    public Boolean getClientDayLimit() {
        return clientDayLimit;
    }

    public void setClientDayLimit(Boolean clientDayLimit) {
        this.clientDayLimit = clientDayLimit;
    }

    public Boolean getClientFinDocLimit() {
        return clientFinDocLimit;
    }

    public void setClientFinDocLimit(Boolean clientFinDocLimit) {
        this.clientFinDocLimit = clientFinDocLimit;
    }

    public Boolean getAccountMonthLimit() {
        return accountMonthLimit;
    }

    public void setAccountMonthLimit(Boolean accountMonthLimit) {
        this.accountMonthLimit = accountMonthLimit;
    }

    public Boolean getAccountNightLimit() {
        return accountNightLimit;
    }

    public void setAccountNightLimit(Boolean accountNightLimit) {
        this.accountNightLimit = accountNightLimit;
    }

    public Boolean getAccountDayLimit() {
        return accountDayLimit;
    }

    public void setAccountDayLimit(Boolean accountDayLimit) {
        this.accountDayLimit = accountDayLimit;
    }

    public Boolean getAccountFinDocLimit() {
        return accountFinDocLimit;
    }

    public void setAccountFinDocLimit(Boolean accountFinDocLimit) {
        this.accountFinDocLimit = accountFinDocLimit;
    }

    public Boolean getDay() {
        return day;
    }

    public void setDay(Boolean day) {
        this.day = day;
    }

    @Override
    public String toString() {
        return "LimitFlag{" +
                "clientMonthLimit=" + clientMonthLimit +
                ", clientNightLimit=" + clientNightLimit +
                ", clientDayLimit=" + clientDayLimit +
                ", clintFinDocLimit=" + clientFinDocLimit +
                ", accountMonthLimit=" + accountMonthLimit +
                ", accountNightLimit=" + accountNightLimit +
                ", accountDayLimit=" + accountDayLimit +
                ", accountFinDocLimit=" + accountFinDocLimit +
                ", day=" + day +
                '}';
    }
}
