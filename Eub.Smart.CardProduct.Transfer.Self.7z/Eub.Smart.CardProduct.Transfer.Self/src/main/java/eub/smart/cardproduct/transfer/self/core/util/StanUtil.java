package eub.smart.cardproduct.transfer.self.core.util;

import java.util.Random;

public class StanUtil {

    public static String generateStun() {
        Random generator = new Random();
        int stan = 100000 + generator.nextInt(900000);
        return String.valueOf(stan);
    }
}
