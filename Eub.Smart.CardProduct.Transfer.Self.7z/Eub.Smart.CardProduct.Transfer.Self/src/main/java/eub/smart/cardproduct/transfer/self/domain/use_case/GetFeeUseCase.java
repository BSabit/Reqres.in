package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.FeeResponse;

import java.math.BigDecimal;

public interface GetFeeUseCase {

    FeeResponse invoke(BigDecimal amount, String accountNumber, String targetCurrency);

    FeeResponse invoke(BigDecimal amount, String accountNumber, String sourceCurrency, String targetCurrency, String finDocType);
}
