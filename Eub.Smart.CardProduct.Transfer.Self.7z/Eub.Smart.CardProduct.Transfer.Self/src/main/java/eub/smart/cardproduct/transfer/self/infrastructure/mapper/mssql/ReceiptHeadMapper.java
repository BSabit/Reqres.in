package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.domain.model.common.LocalizedText;
import eub.smart.cardproduct.transfer.self.domain.model.out.AccountNameDisplay;
import eub.smart.cardproduct.transfer.self.domain.model.out.AmountDisplay;
import eub.smart.cardproduct.transfer.self.domain.model.out.MetaDocumentOut;
import eub.smart.cardproduct.transfer.self.domain.model.out.infrastracture.HeadOut;

import java.sql.ResultSet;
import java.sql.SQLException;

import static java.util.Objects.nonNull;

public class ReceiptHeadMapper {

    public static HeadOut processHead(ResultSet resultSet, LangKey lang, String finDocType, String s3Url) throws SQLException {
        var amount = resultSet.getBigDecimal("amount");
        var currency = resultSet.getString("currency");
        var fee = resultSet.getBigDecimal("fee");
        var feeCurrency = resultSet.getString("feeCurrency");
        var status = resultSet.getString("status");
        var fileUid = resultSet.getString("fileUid");
        var titleRu = resultSet.getString("dataTitle_title_RU");
        var titleKz = resultSet.getString("dataTitle_title_KZ");
        var titleEn = resultSet.getString("dataTitle_title_EN");
        var descRu = resultSet.getString("dataTitle_desc_RU");
        var descKz = resultSet.getString("dataTitle_desc_KZ");
        var descEn = resultSet.getString("dataTitle_desc_EN");

        var title = new LocalizedText(titleRu, titleKz, titleEn).text(lang);
        var accountNameDisplay = new AccountNameDisplay(title, finDocType);
        var desc = new LocalizedText(descRu, descKz, descEn).text(lang);

        String imageUrl = null;
        if (nonNull(fileUid)) imageUrl = String.format("%s?fileUid=%s", s3Url, fileUid);

        return new HeadOut(
                new AmountDisplay(currency, amount),
                new AmountDisplay(feeCurrency, fee),
                status,
                imageUrl,
                accountNameDisplay,
                desc);
    }
}
