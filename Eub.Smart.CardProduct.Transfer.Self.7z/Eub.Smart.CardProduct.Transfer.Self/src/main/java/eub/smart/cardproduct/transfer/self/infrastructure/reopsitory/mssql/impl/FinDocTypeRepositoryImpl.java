package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.repository.FinDocTypeRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.CommonMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isOneResult;

@Repository
public class FinDocTypeRepositoryImpl implements FinDocTypeRepository {

    private final NamedParameterJdbcTemplate template;

    public FinDocTypeRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<Long> findTargetIdById(String id) {
        String sql = """ 
                select FDT.Target_ID as id
                from FinDocType FDT
                where FDT.FinDocType_ID = :id;
                """;

        List<Long> queryResult = template.query(
                sql,
                Map.of("id", id),
                (rs, row) -> CommonMapper.getLong(rs, row));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": FinDocTypeRepositoryImpl findTargetIdById");
        }
    }
    @Override
    public Long findTargetIdByIdOrException(String id) {
        return findTargetIdById(id)
                .orElseThrow(() -> new SelfException(E_DB_600, ": FinDocTypeRepositoryImpl findTargetIdByIdOrException"));
    }
}
