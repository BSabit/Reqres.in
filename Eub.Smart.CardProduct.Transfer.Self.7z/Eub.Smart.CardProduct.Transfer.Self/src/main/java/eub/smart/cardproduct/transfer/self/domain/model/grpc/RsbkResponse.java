package eub.smart.cardproduct.transfer.self.domain.model.grpc;

public class RsbkResponse {

    private String RequestId;
    private Integer ErrorCode;
    private String ErrorMessage;

    public String getRequestId() {
        return RequestId;
    }

    public void setRequestId(String requestId) {
        RequestId = requestId;
    }

    public Integer getErrorCode() {
        return ErrorCode;
    }

    public void setErrorCode(Integer errorCode) {
        ErrorCode = errorCode;
    }

    public String getErrorMessage() {
        return ErrorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        ErrorMessage = errorMessage;
    }

    @Override
    public String toString() {
        return "RsbkResponse{" +
                "RequestId=" + RequestId +
                ", ErrorCode=" + ErrorCode +
                ", ErrorMessage=" + ErrorMessage +
                '}';
    }
}
