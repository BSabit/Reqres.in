package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.ReverseDoc;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferResponse;

public interface ReverseRsbkDocumentUseCase {

    ReverseDoc invoke(TransferResponse transferResponse, String correlationId);
}
