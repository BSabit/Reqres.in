package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.FinDoc;
import eub.smart.cardproduct.transfer.self.domain.model.CreateTransferAccountInfo;

import java.math.BigDecimal;

public interface CreateFinDocUseCase {

    FinDoc invoke(String type, BigDecimal amount, Long aLong, CreateTransferAccountInfo senderAccount, CreateTransferAccountInfo receiverAccount);
}
