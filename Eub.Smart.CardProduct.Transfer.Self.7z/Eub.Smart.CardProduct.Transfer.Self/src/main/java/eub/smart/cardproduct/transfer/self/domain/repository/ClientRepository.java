package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.Client;

import java.util.Optional;

public interface ClientRepository {

    Optional<Client> findByAccountNumber(String accountNumber);

    Client findByAccountNumberOrException(String accountNumber);
}
