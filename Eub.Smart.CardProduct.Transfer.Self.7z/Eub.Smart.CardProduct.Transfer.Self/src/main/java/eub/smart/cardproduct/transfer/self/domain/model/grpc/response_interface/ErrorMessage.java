package eub.smart.cardproduct.transfer.self.domain.model.grpc.response_interface;

public interface ErrorMessage {

    String getErrorMessage();
}
