package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.repository.LimitAccountNightRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.LimitAccountNightUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.LimitFinDocUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.LimitUseCase;

import java.math.BigDecimal;
import java.time.LocalDate;

import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isEmpty;

public class LimitAccountNightUseCaseImpl implements LimitAccountNightUseCase {

    private final LimitAccountNightRepository limitAccountNightRepository;
    private final LimitFinDocUseCase finDocUseCase;
    private final LimitUseCase limitUseCase;

    public LimitAccountNightUseCaseImpl(LimitAccountNightRepository limitAccountNightRepository,
                                        LimitFinDocUseCase finDocUseCase,
                                        LimitUseCase limitUseCase) {
        this.limitAccountNightRepository = limitAccountNightRepository;
        this.finDocUseCase = finDocUseCase;
        this.limitUseCase = limitUseCase;
    }

    @Override
    public void invoke(BigDecimal limitNight, String accountNumber, String correlationId, BigDecimal amount, String currency) {
        var currentDate = LocalDate.now();
        var spentAmountGroupByCurrency = limitAccountNightRepository.findByAccountNumber(currentDate, accountNumber);
        if (isEmpty(spentAmountGroupByCurrency)) finDocUseCase.invoke(limitNight, amount, currency, correlationId);
        limitUseCase.invoke(limitNight, correlationId, amount, currency, false, spentAmountGroupByCurrency);
    }

}
