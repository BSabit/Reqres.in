package eub.smart.cardproduct.transfer.self.domain.model.grpc;

public class TransferWay4Convert {

    private TransferWay4ConvertRequest transferWay4ConvertRequest;
    private UfxResponse transferWay4ConvertResponse;

    public TransferWay4Convert() {
    }

    public TransferWay4Convert(TransferWay4ConvertRequest transferWay4ConvertRequest, UfxResponse transferWay4ConvertResponse) {
        this.transferWay4ConvertRequest = transferWay4ConvertRequest;
        this.transferWay4ConvertResponse = transferWay4ConvertResponse;
    }

    public TransferWay4ConvertRequest getTransferWay4ConvertRequest() {
        return transferWay4ConvertRequest;
    }

    public void setTransferWay4ConvertRequest(TransferWay4ConvertRequest transferWay4ConvertRequest) {
        this.transferWay4ConvertRequest = transferWay4ConvertRequest;
    }

    public UfxResponse getTransferWay4ConvertResponse() {
        return transferWay4ConvertResponse;
    }

    public void setTransferWay4ConvertResponse(UfxResponse transferWay4ConvertResponse) {
        this.transferWay4ConvertResponse = transferWay4ConvertResponse;
    }
}
