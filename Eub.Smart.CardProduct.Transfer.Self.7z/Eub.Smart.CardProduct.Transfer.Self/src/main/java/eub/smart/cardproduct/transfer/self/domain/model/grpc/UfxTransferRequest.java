package eub.smart.cardproduct.transfer.self.domain.model.grpc;

import java.math.BigDecimal;

public class UfxTransferRequest {

    private String findoc;
    private String rrn;
    private String brrn;
    private String stan;
    private String operationAccount;
    private BigDecimal operationSum;
    private String operationCurrency;
    private String linkedOperationAccount;
    private Boolean isDeposit;
    private String details;

    public String getFindoc() {
        return findoc;
    }

    public String getRrn() {
        return rrn;
    }

    public String getBrrn() {
        return brrn;
    }

    public String getStan() {
        return stan;
    }

    public String getOperationAccount() {
        return operationAccount;
    }

    public BigDecimal getOperationSum() {
        return operationSum;
    }

    public String getOperationCurrency() {
        return operationCurrency;
    }

    public String getLinkedOperationAccount() {
        return linkedOperationAccount;
    }

    public Boolean getDeposit() {
        return isDeposit;
    }

    public String getDetails() {
        return details;
    }

    public void setFindoc(String findoc) {
        this.findoc = findoc;
    }

    public void setRrn(String rrn) {
        this.rrn = rrn;
    }

    public void setBrrn(String brrn) {
        this.brrn = brrn;
    }

    public void setStan(String stan) {
        this.stan = stan;
    }

    public void setOperationAccount(String operationAccount) {
        this.operationAccount = operationAccount;
    }

    public void setOperationSum(BigDecimal operationSum) {
        this.operationSum = operationSum;
    }

    public void setOperationCurrency(String operationCurrency) {
        this.operationCurrency = operationCurrency;
    }

    public void setLinkedOperationAccount(String linkedOperationAccount) {
        this.linkedOperationAccount = linkedOperationAccount;
    }

    public void setDeposit(Boolean deposit) {
        isDeposit = deposit;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    @Override
    public String toString() {
        return "UfxTransferRequest{" +
                "findoc=" + findoc +
                ", rrn=" + rrn +
                ", brrn=" + brrn +
                ", stan=" + stan +
                ", operationAccount=" + operationAccount +
                ", operationSum=" + operationSum +
                ", operationCurrency=" + operationCurrency +
                ", linkedOperationAccount=" + linkedOperationAccount +
                ", isDeposit=" + isDeposit +
                ", details=" + details +
                '}';
    }
}
