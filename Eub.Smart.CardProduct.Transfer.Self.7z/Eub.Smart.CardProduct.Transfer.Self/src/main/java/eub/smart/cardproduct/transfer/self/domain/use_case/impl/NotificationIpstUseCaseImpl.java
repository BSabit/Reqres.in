package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.core.util.AccountUtil;
import eub.smart.cardproduct.transfer.self.core.util.LangUtil;
import eub.smart.cardproduct.transfer.self.domain.model.in.infrastructure.NotificationPOut;
import eub.smart.cardproduct.transfer.self.domain.model.out.presentation.NotificationIOut;
import eub.smart.cardproduct.transfer.self.domain.repository.MessageSourceRepository;
import eub.smart.cardproduct.transfer.self.domain.repository.NotificationRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.NotificationIpstUseCase;

import java.util.List;
import java.util.Objects;

import static eub.smart.cardproduct.transfer.self.core.constant.BundleCode.*;

public class NotificationIpstUseCaseImpl implements NotificationIpstUseCase {

    private final NotificationRepository notificationRepository;
    private final MessageSourceRepository messageSourceRepository;

    public NotificationIpstUseCaseImpl(NotificationRepository notificationRepository,
                                       MessageSourceRepository messageSourceRepository) {
        this.notificationRepository = notificationRepository;
        this.messageSourceRepository = messageSourceRepository;
    }

    public List<NotificationIOut> invoke(LangKey lang) {
        var ipstTransfers = notificationRepository.findAllIpstByAuthToken();
        return ipstTransfers.stream()
                .filter(Objects::nonNull)
                .map(notificationPOut -> toNotificationIOut(notificationPOut, lang))
                .toList();

    }

    private NotificationIOut toNotificationIOut(NotificationPOut notificationPOut, LangKey lang) {
        var finDocId = notificationPOut.finDocId();
        var createdDate = notificationPOut.createdDate().getTime();
        var amount = notificationPOut.amount();
        var currency = notificationPOut.transferCurrency();
        var accountNumber = notificationPOut.accountNumber();
        var accountNumberMasked = AccountUtil.maskAccountNumber(accountNumber);
        var firstName = notificationPOut.firstName();
        var lastName = notificationPOut.lastName();
        var lastNameInitial = String.valueOf(lastName.charAt(0));

        var transferInfoArgs = new Object[]{amount, currency, accountNumberMasked};
        var receiverInfoArgs = new Object[]{firstName, lastNameInitial};

        String title = messageSourceRepository.getMessage(NOTIFICATION_IPST_TITLE, LangUtil.get(lang));
        String transferInfo = messageSourceRepository.getMessage(NOTIFICATION_IPST_TRANSFER, transferInfoArgs, LangUtil.get(lang));
        String receiverInfo = messageSourceRepository.getMessage(NOTIFICATION_IPST_RECEIVER, receiverInfoArgs, LangUtil.get(lang));
        return new NotificationIOut(finDocId, title, transferInfo, receiverInfo, createdDate);
    }
}
