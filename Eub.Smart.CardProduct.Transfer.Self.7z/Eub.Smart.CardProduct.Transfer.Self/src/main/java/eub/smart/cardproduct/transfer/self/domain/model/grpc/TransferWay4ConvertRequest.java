package eub.smart.cardproduct.transfer.self.domain.model.grpc;

import java.math.BigDecimal;

public class TransferWay4ConvertRequest {

    private String rrn;
    private String stan;
    private String operationAccount;
    private BigDecimal operationSum;;
    private String operationCurrency;
    private String sourceAccountCurrency;
    private String targetAccountCurrency;

    public String getRrn() {
        return rrn;
    }

    public void setRrn(String rrn) {
        this.rrn = rrn;
    }

    public String getStan() {
        return stan;
    }

    public void setStan(String stan) {
        this.stan = stan;
    }

    public String getOperationAccount() {
        return operationAccount;
    }

    public void setOperationAccount(String operationAccount) {
        this.operationAccount = operationAccount;
    }

    public BigDecimal getOperationSum() {
        return operationSum;
    }

    public void setOperationSum(BigDecimal operationSum) {
        this.operationSum = operationSum;
    }

    public String getOperationCurrency() {
        return operationCurrency;
    }

    public void setOperationCurrency(String operationCurrency) {
        this.operationCurrency = operationCurrency;
    }

    public String getSourceAccountCurrency() {
        return sourceAccountCurrency;
    }

    public void setSourceAccountCurrency(String sourceAccountCurrency) {
        this.sourceAccountCurrency = sourceAccountCurrency;
    }

    public String getTargetAccountCurrency() {
        return targetAccountCurrency;
    }

    public void setTargetAccountCurrency(String targetAccountCurrency) {
        this.targetAccountCurrency = targetAccountCurrency;
    }

    @Override
    public String toString() {
        return "TransferWay4ConvertRequest{" +
                "rrn=" + rrn +
                ", stan=" + stan +
                ", operationAccount=" + operationAccount +
                ", operationSum=" + operationSum +
                ", operationCurrency=" + operationCurrency +
                ", sourceAccountCurrency=" + sourceAccountCurrency +
                ", targetAccountCurrency=" + targetAccountCurrency +
                '}';
    }
}
