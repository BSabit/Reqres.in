package eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc;

import custom_types.CustomTypes;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferResponse;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToRsbkRequest;
import rsbktransactional.V1.EubAdapterRsbkTransactional;

import static eub.smart.cardproduct.transfer.self.core.util.GrpcUtil.toTimestamp;
import static eub.smart.cardproduct.transfer.self.core.util.GrpcUtil.toDecimalValue;

public class TransferInternalRsbkToRsbkMapper {

    public static EubAdapterRsbkTransactional.TransferRsbkToRsbkRequest toGrpcModel(TransferRsbkToRsbkRequest requestModel) {
        return EubAdapterRsbkTransactional.TransferRsbkToRsbkRequest
                .newBuilder()
                .setPayerAccount(requestModel.getPayerAccount())
                .setReceiverAccount(requestModel.getReceiverAccount())
                .setOperSum(toDecimalValue(requestModel.getOperSum()))
                .setKnp(requestModel.getKpn())
                .setIsSelf(requestModel.isSelf())
                .setIin(requestModel.getIin())
                .setVicalcSumm(toDecimalValue(requestModel.getVicalcSumm()))
                .setComissTarif(CustomTypes.DecimalValue.getDefaultInstance())
                .setComissSummTg(toDecimalValue(requestModel.getComissSummTg()))
                .setDboId(requestModel.getDboId())
                .setDateSign(toTimestamp(requestModel.getDateSign()))
                .setIsSpecRate(0)
                .setRate(CustomTypes.DecimalValue.newBuilder().build())
                .setCoverRate(CustomTypes.DecimalValue.newBuilder().build())
                .setProcVersion(3)
                .build();
    }

    public static TransferResponse toDomainModel(EubAdapterRsbkTransactional.TransferResponse response) {
        TransferResponse domainModel = new TransferResponse();
        domainModel.setCollectorId(response.getCollectorId());
        domainModel.setErrorMessage(response.getErrorMessage());
        return domainModel;
    }
}
