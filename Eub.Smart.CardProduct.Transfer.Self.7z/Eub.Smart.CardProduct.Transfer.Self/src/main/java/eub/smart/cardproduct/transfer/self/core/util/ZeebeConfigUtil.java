package eub.smart.cardproduct.transfer.self.core.util;

public class ZeebeConfigUtil {

    public static final boolean WORKER_ENABLE = true;
}
