package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.scanner.MapResultScanner;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

public class CommonMapper {

    public static Long getLong(Map<String, Object> row) {
        MapResultScanner scanner = new MapResultScanner(row);
        return scanner.getLong("id");
    }

    public static String getString(Map<String, Object> row) {
        MapResultScanner scanner = new MapResultScanner(row);
        return scanner.getString("type");
    }

    public static Long getLong(ResultSet resultSet, int i) {
        try {
            return resultSet.getLong("id");
        } catch (SQLException e) {
            throw new SelfException(SelfErrorCode.E_DB_603, e);
        }
    }
}
