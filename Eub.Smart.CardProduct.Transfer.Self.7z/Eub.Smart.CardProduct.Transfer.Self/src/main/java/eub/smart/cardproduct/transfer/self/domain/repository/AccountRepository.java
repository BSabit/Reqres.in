package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.AccountInfo;

import java.util.Optional;

public interface AccountRepository {

    Optional<AccountInfo> findByPhoneNumber(String phoneNumber);

    Optional<AccountInfo> findByNumber(String number);

    AccountInfo findByNumberOrException(String number);

    AccountInfo findByPhoneNumberOrException(String phoneNumber);

    Optional<String> getAccountStatus(String finDocId);

    String getAccountStatusOrException(String finDocId);
}
