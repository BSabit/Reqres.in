package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4ToWay4Credit;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferWay4ToWay4CreditRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isOneResult;
import static eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.TransferWay4ToWay4CreditMapper.toDomainModel;

@Primary
@Repository
public class TransferWay4ToWay4CreditRepositoryImpl implements TransferWay4ToWay4CreditRepository {

    private final NamedParameterJdbcTemplate template;

    public TransferWay4ToWay4CreditRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<TransferWay4ToWay4Credit> findByFinDocId(Long finDocId, RrnBrrn rrnBrrn, String stun) {
        String sql = """ 
                select T.Receiver_Account   as receiverAccountNumber,
                       AccS.Number          as senderAccountNumber,
                       F.Amount             as senderAmount,
                       T.Receiver_Amount    as receiverAmount,
                       F.Currency           as senderCurrency,
                       T.Receiver_Currency  as receiverCurrency,
                       T.Receiver_Name      as receiverFullname,
                       AccR.IsMultiCurrency as receiverFlagMultiCurrency,
                       AccR.Account_IDREF   as receiverAccountIdRef,
                       AccS.IsMultiCurrency as senderFlagMultiCurrency
                from FinDoc F
                         join Transfer T on F.FinDoc_ID = T.FinDoc_IDREF
                         join Account AccR on AccR.Number = T.Receiver_Account
                         join Account AccS on F.Account_IDREF = AccS.Account_ID
                where F.FinDoc_ID = :finDocId
                """;

        List<Map<String, Object>> queryResult = template.queryForList(sql, Map.of("finDocId", finDocId));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .map(row -> toDomainModel(row, finDocId, stun, rrnBrrn));
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": TransferWay4ToWay4CreditRepository findByFinDocId");
        }
    }

    @Override
    public TransferWay4ToWay4Credit findByFinDocIdOrException(Long finDocId, RrnBrrn rrnBrrn, String stun) {
        return findByFinDocId(finDocId, rrnBrrn, stun)
                .orElseThrow(() -> new SelfException(E_DB_600, ": TransferWay4ToWay4CreditRepository findByFinDocIdOrException"));
    }
}
