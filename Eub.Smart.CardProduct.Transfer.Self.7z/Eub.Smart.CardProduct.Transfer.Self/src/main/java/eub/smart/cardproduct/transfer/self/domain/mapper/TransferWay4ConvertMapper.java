package eub.smart.cardproduct.transfer.self.domain.mapper;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4ConvertRequest;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.scanner.MapResultScanner;

import java.util.Map;

import static eub.smart.cardproduct.transfer.self.core.util.StanUtil.generateStun;

public class TransferWay4ConvertMapper {

    public static TransferWay4ConvertRequest createRequest(AccountData senderData,
                                                           AccountData receiverData,
                                                           RrnBrrn rrnBrrn) {
        TransferWay4ConvertRequest model = new TransferWay4ConvertRequest();
        model.setStan(generateStun());
        model.setRrn(rrnBrrn.getRrn());
        model.setOperationSum(senderData.getAmount());
        model.setOperationAccount(senderData.getAccountNumber());
        model.setOperationCurrency(senderData.getCurrency());
        model.setSourceAccountCurrency(senderData.getCurrency());
        model.setTargetAccountCurrency(receiverData.getCurrency());
        return model;
    }
}
