package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.TransferInternalBaseModel;
import eub.smart.cardproduct.transfer.self.domain.repository.FinDocStateRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.*;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import static java.util.concurrent.CompletableFuture.runAsync;

public class Way4ToWay4InitialValidationUseCaseImpl extends InitialValidationUseCaseImpl {

    private final ValidateMultiConvertUseCase validateMultiConvertUseCase;

    public Way4ToWay4InitialValidationUseCaseImpl(ValidateAccountAmountUseCase validateAccountAmountUseCase,
                                                  ValidateSenderAccountUseCase validateSenderAccountUseCase,
                                                  ValidateReceiverAccountUseCase validateReceiverAccountUseCase,
                                                  ValidateBSystemAvailabilityUseCase validateBSystemAvailabilityUseCase,
                                                  FinDocStateRepository finDocStateRepository,
                                                  ValidateMultiConvertUseCase validateMultiConvertUseCase) {
        super(validateAccountAmountUseCase,
                validateSenderAccountUseCase,
                validateReceiverAccountUseCase,
                validateBSystemAvailabilityUseCase,
                finDocStateRepository);
        this.validateMultiConvertUseCase = validateMultiConvertUseCase;
    }

    @Override
    public void invoke(TransferInternalBaseModel baseModel, LangKey lang) {
        var sender = baseModel.getSender();
        var receiver = baseModel.getReceiver();

        var validateMultiConvertFuture = runAsync(() -> validateMultiConvertUseCase.invoke(sender, receiver, lang));
        List<CompletableFuture<Void>> validateFutures = futures(baseModel, lang);
        validateFutures.add(validateMultiConvertFuture);
        executeFuture(baseModel, validateFutures);
    }
}
