package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.*;
import eub.smart.cardproduct.transfer.self.domain.repository.RsbkTransactionalProtoRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.SetWay4TransactionDateUseCase;

public class SetWay4TransactionDateUseCaseImpl implements SetWay4TransactionDateUseCase {

    private final RsbkTransactionalProtoRepository rsbkTransactionalProtoRepository;

    public SetWay4TransactionDateUseCaseImpl(RsbkTransactionalProtoRepository rsbkTransactionalProtoRepository) {
        this.rsbkTransactionalProtoRepository = rsbkTransactionalProtoRepository;
    }

    @Override
    public Way4TransactionDate invoke(PostingDateResponse postingDateResponse,
                                      TransferResponse transferResponse,
                                      String correlationId) {
        var request = new SetWay4TransactionDateRequest(transferResponse.getCollectorId(), postingDateResponse.getPostingDate());
        var response = rsbkTransactionalProtoRepository.setWay4TransactionDate(request, correlationId);
        return new Way4TransactionDate(request, response);
    }
}
