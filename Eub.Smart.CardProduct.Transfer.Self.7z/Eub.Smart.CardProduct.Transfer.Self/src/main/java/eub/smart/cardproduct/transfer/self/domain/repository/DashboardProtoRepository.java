package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.out.infrastructure.ValidateAccountAmountOut;

import java.math.BigDecimal;

public interface DashboardProtoRepository {

    BigDecimal availableBalance(ValidateAccountAmountOut accountData, String correlationId);
}
