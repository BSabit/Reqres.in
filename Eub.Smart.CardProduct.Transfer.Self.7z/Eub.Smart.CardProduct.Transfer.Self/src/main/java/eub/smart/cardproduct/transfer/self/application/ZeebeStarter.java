package eub.smart.cardproduct.transfer.self.application;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.core.util.JsonUtil;
import io.camunda.zeebe.client.api.response.ProcessInstanceResult;
import io.camunda.zeebe.client.impl.response.CreateProcessInstanceResponseImpl;
import io.camunda.zeebe.spring.client.lifecycle.ZeebeClientLifecycle;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_EX_701;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_SM_500;

@Component
public class ZeebeStarter {

    private final Logger log = LogManager.getLogger(getClass());

    private final ZeebeClientLifecycle client;

    @Autowired
    public ZeebeStarter(ZeebeClientLifecycle client) {
        this.client = client;
    }

    @Async
    public void run(String jsonBaseModel, String processId) {
        if (clientIsNotRunning()) throw new SelfException(E_EX_701, ": Zeebe");

        client.newCreateInstanceCommand()
                .bpmnProcessId(processId)
                .latestVersion()
                .variables(jsonBaseModel)
                .send()
                .join();
    }

    @Async
    public <T> T call(String correlationId, String jsonBaseModel, String processId, Class<T> clazz) {
        if (clientIsNotRunning()) throw new SelfException(E_EX_701, ": Zeebe");

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        log.info("Start correlationId: {}, time: {}", correlationId, dateFormat.format(new Date()));

        ProcessInstanceResult result = client.newCreateInstanceCommand()
                .bpmnProcessId(processId)
                .latestVersion()
                .variables(jsonBaseModel)
                .withResult()
                .requestTimeout(Duration.ofSeconds(10L))
                .send()
                .join();

        log.info("End correlationId: {}, time: {}", correlationId, dateFormat.format(new Date()));

        return JsonUtil.toObject(result.getVariables(), clazz)
                .orElseThrow(() -> new SelfException(E_SM_500, ": " + clazz.getSimpleName()));
    }

    private boolean clientIsNotRunning() {
        return !client.isRunning();
    }
}
