package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToRsbkRequest;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.scanner.MapResultScanner;

import java.util.Map;

import static eub.smart.cardproduct.transfer.self.core.constant.FinDocType.SELF;

public class TransferRsbkToRsbkMapper {

    public static TransferRsbkToRsbkRequest toDomainModel(Map<String, Object> row, Long finDocId, String iin) {
        MapResultScanner scanner = new MapResultScanner(row);

        TransferRsbkToRsbkRequest model = new TransferRsbkToRsbkRequest();
        model.setPayerAccount(scanner.getString("senderAccountNumber"));
        model.setReceiverAccount(scanner.getString("receiverAccountNumber"));
        model.setKpn(scanner.getString("knpCode"));
        model.setOperSum(scanner.getBigDecimal("senderAmount"));
        model.setVicalcSumm(scanner.getBigDecimal("receiverAmount"));
        model.setComissSummTg(scanner.getBigDecimal("feeAmount"));
        model.setDboId(String.valueOf(finDocId));
        model.setDateSign(scanner.getDate("signDate"));
        model.setSelf(SELF.equals(scanner.getString("finDocType")));
        model.setIin(iin);
        return model;
    }
}
