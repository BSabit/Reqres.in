package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.domain.model.Transfer;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.InfrastructureMapper;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.TransferHiberRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Primary
@Repository
public class TransferRepositoryImpl implements TransferRepository {

    private final TransferHiberRepository transferHiberRepository;
    private final InfrastructureMapper mapper;

    public TransferRepositoryImpl(TransferHiberRepository transferHiberRepository,
                                  InfrastructureMapper mapper) {
        this.transferHiberRepository = transferHiberRepository;
        this.mapper = mapper;
    }

    @Override
    @Transactional
    public Transfer save(Transfer transferModel) {
        var transfer = mapper.toEntity(transferModel);
        var saved = transferHiberRepository.save(transfer);
        return mapper.toDomain(saved);
    }
}
