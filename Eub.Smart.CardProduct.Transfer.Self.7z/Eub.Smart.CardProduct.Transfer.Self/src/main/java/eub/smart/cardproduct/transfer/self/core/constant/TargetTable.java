package eub.smart.cardproduct.transfer.self.core.constant;

public interface TargetTable {

    String FIN_DOC_TYPE = "FinDocType";
    String BANK = "Bank";
    String IPS_ORG = "IPSOrg";
}
