package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.core.util.LangUtil;
import eub.smart.cardproduct.transfer.self.core.util.StringUtil;
import eub.smart.cardproduct.transfer.self.domain.model.create_transfer.CreateTransfer;
import eub.smart.cardproduct.transfer.self.domain.model.in.infrastructure.IipsTransferIn;
import eub.smart.cardproduct.transfer.self.domain.model.in.presentation.CreateTransferDataPIn;
import eub.smart.cardproduct.transfer.self.domain.model.out.infrastructure.ValidateAccountAmountOut;
import eub.smart.cardproduct.transfer.self.domain.repository.*;
import eub.smart.cardproduct.transfer.self.domain.use_case.CreateTransferDataUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.GetAccountInfoBuyNumberUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.RefundIipsTransferUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.ValidateAccountAmountUseCase;
import org.slf4j.MDC;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;

import static eub.smart.cardproduct.transfer.self.core.constant.BundleCode.*;
import static eub.smart.cardproduct.transfer.self.core.constant.CurrencyCode.NUL;
import static eub.smart.cardproduct.transfer.self.core.constant.DocTechStatus.RTRN;
import static eub.smart.cardproduct.transfer.self.core.constant.FinDocStatus.PROC;
import static eub.smart.cardproduct.transfer.self.core.constant.FinDocType.LOCAL;
import static eub.smart.cardproduct.transfer.self.core.constant.HeaderName.CORRELATION_ID;
import static eub.smart.cardproduct.transfer.self.core.constant.HeaderName.LANG_KEY;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_LG_800;

public class RefundIipsTransferUseCaseImpl implements RefundIipsTransferUseCase {

    private final CreateTransferDataUseCase createTransferUseCase;
    private final IipsTransferRepository iipsTransferRepository;
    private final ValidateAccountAmountUseCase validateAccountAmountUseCase;
    private final FinDocRepository finDocRepository;
    private final MapProductOperationRepository mapProductOperationRepository;
    private final MessageSourceRepository messageSourceRepository;
    private final GetAccountInfoBuyNumberUseCase getAccountInfoUseCase;
    private static final int EXPIRY_DAY_COUNT = 30;

    public RefundIipsTransferUseCaseImpl(CreateTransferDataUseCase createTransferUseCase,
                                         IipsTransferRepository iipsTransferRepository,
                                         ValidateAccountAmountUseCase validateAccountAmountUseCase,
                                         FinDocRepository finDocRepository,
                                         MapProductOperationRepository mapProductOperationRepository,
                                         MessageSourceRepository messageSourceRepository,
                                         GetAccountInfoBuyNumberUseCase getAccountInfoUseCase) {
        this.createTransferUseCase = createTransferUseCase;
        this.iipsTransferRepository = iipsTransferRepository;
        this.validateAccountAmountUseCase = validateAccountAmountUseCase;
        this.finDocRepository = finDocRepository;
        this.mapProductOperationRepository = mapProductOperationRepository;
        this.messageSourceRepository = messageSourceRepository;
        this.getAccountInfoUseCase = getAccountInfoUseCase;
    }

    @Override
    public Long invoke(Long finDocId, LangKey lang) {
        var iipsTransfer = findTransfer(finDocId);
        validate(iipsTransfer);
        var irfrTransfer = createIrfrTransfer(iipsTransfer);
        return irfrTransfer.getTransfer().getFinDoc().getId();
    }

    private IipsTransferIn findTransfer(Long finDocId) {
        var optIipsTransferIn = iipsTransferRepository.findByFinDocId(finDocId);
        if (optIipsTransferIn.isPresent()) {
            return optIipsTransferIn.get();
        } else {
            var lang = MDC.get(LANG_KEY);
            var locale = LangUtil.get(lang);
            var message = messageSourceRepository.getMessage(ERROR_MESSAGE_FIN_DOC_NOT_FOUND, locale);
            throw new SelfException(
                    E_LG_800,
                    ": findoc not found with id: " + finDocId,
                    message);
        }
    }

    private void validate(IipsTransferIn iipsTransfer) { //TODO separate validation
        var lang = MDC.get(LANG_KEY);
        var langKey = LangKey.valueOf(lang);
        var locale = LangUtil.get(langKey);
        var optExistProcFinDocId = finDocRepository.finDocIdByStatusAndParentFinDoc(PROC, iipsTransfer.finDocId());
        if (optExistProcFinDocId.isPresent()) {
            var message = messageSourceRepository.getMessage(ERROR_MESSAGE_REFUND_IN_PROCESS, locale);
            throw new SelfException(
                    E_LG_800,
                    ": findoc in process exist with id: " + optExistProcFinDocId.get(),
                    message);
        }
        if (StringUtil.isEmpty(iipsTransfer.senderAccountNumber())) {
            var message = messageSourceRepository.getMessage(ERROR_MESSAGE_SENDER_ACCOUNT_NOT_EXIST, locale);
            throw new SelfException(
                    E_LG_800,
                    ": account sender not exist with number: " + iipsTransfer.senderAccountNumber(),
                    message);
        }
        if (StringUtil.isEmpty(iipsTransfer.receiverAccountNumber())) {
            var message = messageSourceRepository.getMessage(ERROR_MESSAGE_RECEIVER_ACCOUNT_NOT_EXIST, locale);
            throw new SelfException(
                    E_LG_800,
                    ": account receiver not exist with number: " + iipsTransfer.receiverAccountNumber(),
                    message);
        }
        if (RTRN.equals(iipsTransfer.docTechStatus())) {
            var message = messageSourceRepository.getMessage(ERROR_MESSAGE_REFUND_HAS_ALREADY_DONE, locale);
            throw new SelfException(
                    E_LG_800,
                    ": findoc has already refund with id: " + iipsTransfer.finDocId(),
                    message);
        }
        var denyDebitFlag = mapProductOperationRepository.absenceByAccountNumberAndTransferType(iipsTransfer.senderAccountNumber(), LOCAL);
        if (denyDebitFlag) {
            var message = messageSourceRepository.getMessage(ERROR_MESSAGE_ACCOUNT_HAVE_CONSTRAINT, locale);
            throw new SelfException(
                    E_LG_800,
                    ": account have constraint for debit :" + iipsTransfer.senderAccountNumber(),
                    message);
        }
        if (isRefundDateExpired(iipsTransfer)) {
            var message = messageSourceRepository.getMessage(ERROR_MESSAGE_REFUND_DATE_EXPIRED, locale);
            throw new SelfException(
                    E_LG_800,
                    ": refund date expired",
                    message);
        }
        var validateAccountAmountOut = new ValidateAccountAmountOut(iipsTransfer);
        validateAccountAmountUseCase.invoke(validateAccountAmountOut, MDC.get(CORRELATION_ID), langKey);
    }

    private boolean isRefundDateExpired(IipsTransferIn iipsTransfer) {
        var expiryLocalDate = LocalDate.now()
                .minusDays(EXPIRY_DAY_COUNT);
        var signDate = iipsTransfer.signDate();
        var signLocalDate = Instant.ofEpochMilli(signDate.getTime())
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
        return signLocalDate.isBefore(expiryLocalDate);
    }

    private CreateTransfer createIrfrTransfer(IipsTransferIn iipsTransfer) {
        var createTransferDataIn = new CreateTransferDataPIn(iipsTransfer, NUL, LOCAL);
        var senderAccount = getAccountInfoUseCase.invoke(iipsTransfer.receiverAccountNumber(), iipsTransfer.currency());
        var receiverAccount = getAccountInfoUseCase.invoke(iipsTransfer.senderAccountNumber(), iipsTransfer.currency());

        return createTransferUseCase.invoke(createTransferDataIn, senderAccount, receiverAccount);
    }

}
