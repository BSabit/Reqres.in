package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql;

import eub.smart.cardproduct.transfer.self.infrastructure.entity.ZeebeEventFinDocEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ZeebeEventFinDocHiberRepository extends JpaRepository<ZeebeEventFinDocEntity, Long> {

    Optional<ZeebeEventFinDocEntity> findByFinDocId(Long aLong);
}
