package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.PostingDateResponse;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.Way4TransactionDate;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferResponse;

public interface SetWay4TransactionDateUseCase {

    Way4TransactionDate invoke(PostingDateResponse postingDateResponse, TransferResponse transferResponse, String correlationId);
}
