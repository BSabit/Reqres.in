package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.DepositAccount;
import eub.smart.cardproduct.transfer.self.domain.repository.DepositAccountRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.GetAccountDepositTypeUseCase;

import static eub.smart.cardproduct.transfer.self.core.constant.AccountType.SAVL;
import static eub.smart.cardproduct.transfer.self.core.constant.AccountType.SAVS;

public class GetAccountDepositTypeUseCaseImpl implements GetAccountDepositTypeUseCase {

    private static final String MONTH = "M";
    private static final int MIN_PERIOD = 0;
    private static final int MAX_PERIOD = 12;
    private final DepositAccountRepository depositAccountRepository;

    public GetAccountDepositTypeUseCaseImpl(DepositAccountRepository depositAccountRepository) {
        this.depositAccountRepository = depositAccountRepository;
    }

    @Override
    public String invoke(Long accountId) {
        var account = depositAccountRepository.findByAccountIdOrException(accountId);
        if (isShortTermPeriod(account)) return SAVS;
        else return SAVL;
    }

    private boolean isShortTermPeriod(DepositAccount account) {
        return MONTH.equals(account.getTermPeriodType())
                && account.getTermPeriodCount() > MIN_PERIOD
                && account.getTermPeriodCount() < MAX_PERIOD;
    }
}
