package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.in.infrastructure.NotificationPOut;

import java.sql.ResultSet;
import java.sql.SQLException;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_603;

public class NotificationMapper {


    public static NotificationPOut toDomainModel(ResultSet resultSet, int i) {
        try {
            return new NotificationPOut(
                    resultSet.getLong("finDocId"),
                    resultSet.getBigDecimal("amount"),
                    resultSet.getString("transferCurrency"),
                    resultSet.getString("accountCurrency"),
                    resultSet.getString("accountNumber"),
                    resultSet.getString("firstName"),
                    resultSet.getString("lastName"),
                    resultSet.getTimestamp("createdDate")
            );
        } catch (SQLException e) {
            throw new SelfException(E_DB_603, e);
        }
    }
}
