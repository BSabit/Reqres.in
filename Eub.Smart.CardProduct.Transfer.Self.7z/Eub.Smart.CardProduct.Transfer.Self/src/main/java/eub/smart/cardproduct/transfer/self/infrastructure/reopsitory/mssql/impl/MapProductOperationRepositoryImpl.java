package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.repository.MapProductOperationRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.CommonMapper;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isOneResult;

@Primary
@Repository
public class MapProductOperationRepositoryImpl implements MapProductOperationRepository {

    private final NamedParameterJdbcTemplate template;

    public MapProductOperationRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<Long> findFeeId(BigDecimal amount, Long operationId, Long productId) {
        Map<String, Object> map = new HashMap<>();
        map.put("amount", amount);
        map.put("operationId", operationId);
        map.put("productId", productId);

        String sql = """ 
                select mpo.Fee_IDREF    as id
                from dbo.map_Product_Operation mpo
                where Product_IDREF = :productId
                    and Operation_IDREF = :operationId
                    and :amount
                        between isnull(mpo.Sum_Min, :amount)
                        and isnull(mpo.Sum_Max, :amount)
                """;

        List<Map<String, Object>> queryResult = template.queryForList(sql, map);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .map(CommonMapper::getLong);
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": MapProductOperationRepository findFeeId");
        }
    }

    @Override
    public Long findFeeIdOrException(BigDecimal amount, Long operationId, Long productId) {
        return findFeeId(amount, operationId, productId)
                .orElseThrow(() -> new SelfException(E_DB_600, ": MapProductOperationRepository findFeeIdOrException"));
    }

    @Override
    public boolean existByAccountNumberAndTransferType(String accountNumber, String transferType) {
        String sql = """ 
                select COUNT(1) as id
                from map_Product_Operation mpo
                    join Account a on mpo.Product_IDREF = a.Product_IDREF
                    join Operation o on mpo.Operation_IDREF = o.Operation_ID
                where a.Number = :accountNumber
                    and o.Action_IDREF = :transferType;
                """;
        var optCount = Optional.ofNullable(template.queryForObject(sql, Map.of("accountNumber", accountNumber, "transferType", transferType), CommonMapper::getLong));
        if (optCount.isPresent()) {
            var count = optCount.get();
            return count != 0;
        } else {
            return false;
        }
    }

    @Override
    public boolean absenceByAccountNumberAndTransferType(String accountNumber, String transferType) {
        return !existByAccountNumberAndTransferType(accountNumber, transferType);
    }
}
