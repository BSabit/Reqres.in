package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4ToRsbkCreditRsbk;
import eub.smart.cardproduct.transfer.self.domain.repository.ZeebeEventFinDocRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.Way4ToRsbkSaveResultUseCase;

import static java.util.Objects.isNull;

public class Way4ToRsbkSaveResultUseCaseImpl extends ZeebeEventFinDocSaveResult implements Way4ToRsbkSaveResultUseCase {

    public Way4ToRsbkSaveResultUseCaseImpl(ZeebeEventFinDocRepository zeebeEventFinDocRepository) {
        super(zeebeEventFinDocRepository);
    }

    @Override
    public void invoke(Long finDocId, RrnBrrn rrnBrrn, TransferWay4ToRsbkCreditRsbk transferWay4ToRsbkCreditRsbk) {
        if (isNull(rrnBrrn)) {
            saveResult(finDocId);
        } else if (isNull(transferWay4ToRsbkCreditRsbk)) {
            saveResult(finDocId, rrnBrrn);
        } else {
            var collectorId = getCollectorId(transferWay4ToRsbkCreditRsbk);
            saveResult(finDocId, rrnBrrn, collectorId);
        }
    }

    private String getCollectorId(TransferWay4ToRsbkCreditRsbk transferWay4ToRsbkCreditRsbk) {
        return transferWay4ToRsbkCreditRsbk.getResponse().getCollectorId();
    }
}
