package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.out.MetaDocumentOut;

import java.sql.ResultSet;
import java.sql.SQLException;

public class MetaDocumentMapper {

    public static MetaDocumentOut toDomain(ResultSet resultSet, String s3Url) {
        try {
            return new MetaDocumentOut(
                    resultSet.getString("uid"),
                    s3Url,
                    resultSet.getString("format")
            );
        } catch (SQLException e) {
            throw new SelfException(SelfErrorCode.E_DB_603, e);
        }
    }
}
