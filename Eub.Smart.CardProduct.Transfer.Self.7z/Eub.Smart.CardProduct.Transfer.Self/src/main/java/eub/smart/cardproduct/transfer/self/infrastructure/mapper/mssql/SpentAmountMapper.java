package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.domain.model.limit.SpentAmount;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.scanner.MapResultScanner;

import java.util.Map;

public class SpentAmountMapper {

    public static SpentAmount toDomainModel(Map<String, Object> row) {
        if (row == null) return null;
        MapResultScanner scanner = new MapResultScanner(row);

        SpentAmount model = new SpentAmount();
        model.setSenderCurrency(scanner.getString("senderCurrency"));
        model.setReceiverCurrency(scanner.getString("receiverCurrency"));
        model.setSpentSum(scanner.getBigDecimal("amountSum"));
        return model;
    }
}
