package eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4PostRequest;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4PostResponse;
import way4transactional.EubAdapterWay4Transactional;

public class TransferWay4PostMapper {

    public static EubAdapterWay4Transactional.TransferWay4PostRequest toGrpcModel(TransferWay4PostRequest requestModel) {
        return EubAdapterWay4Transactional.TransferWay4PostRequest
                .newBuilder()
                .setRrn(requestModel.getRrn())
                .build();
    }

    public static TransferWay4PostResponse toDomainModel(EubAdapterWay4Transactional.TransferWay4PostResponse response) {
        return new TransferWay4PostResponse(response.getErrorMessage());
    }
}
