package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;

public interface RefundIipsTransferUseCase {

    Long invoke(Long finDocId, LangKey lang);
}
