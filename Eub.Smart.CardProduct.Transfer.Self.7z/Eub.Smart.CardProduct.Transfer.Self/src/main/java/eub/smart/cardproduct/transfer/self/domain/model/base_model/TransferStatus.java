package eub.smart.cardproduct.transfer.self.domain.model.base_model;

public class TransferStatus {

    private String docTechStatus;
    private String title;
    private String finDocStatus;

    public TransferStatus() {
    }

    public TransferStatus(String docTechStatus, String title, String finDocStatus) {
        this.docTechStatus = docTechStatus;
        this.title = title;
        this.finDocStatus = finDocStatus;
    }

    public String getDocTechStatus() {
        return docTechStatus;
    }

    public void setDocTechStatus(String docTechStatus) {
        this.docTechStatus = docTechStatus;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFinDocStatus() {
        return finDocStatus;
    }

    public void setFinDocStatus(String finDocStatus) {
        this.finDocStatus = finDocStatus;
    }

    @Override
    public String toString() {
        return "TransferStatus{" +
                "docTechStatus=" + docTechStatus +
                ", title=" + title +
                ", finDocStatus=" + finDocStatus +
                '}';
    }
}
