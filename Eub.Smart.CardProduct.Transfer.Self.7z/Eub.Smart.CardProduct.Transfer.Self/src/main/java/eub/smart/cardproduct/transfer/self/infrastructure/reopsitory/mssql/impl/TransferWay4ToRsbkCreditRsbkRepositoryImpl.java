package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4ToRsbkRequest;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferWay4ToRsbkCreditRsbkRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isOneResult;
import static eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.TransferWay4ToRsbkRequestMapper.toDomainModel;

@Primary
@Repository
public class TransferWay4ToRsbkCreditRsbkRepositoryImpl implements TransferWay4ToRsbkCreditRsbkRepository {

    private final NamedParameterJdbcTemplate template;

    public TransferWay4ToRsbkCreditRsbkRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<TransferWay4ToRsbkRequest> findByFinDocId(Long finDocId, String dboIdPrefix) {
        String sql = """
                select A.Number                as senderAccountNumber,
                       T.Receiver_Account      as receiverAccountNumber,
                       F.Amount                as senderAmount,
                       T.Receiver_Amount       as receiverAmount,
                       T.KNP_IDREF             as knpCode,
                       F.Currency              as senderCurrency,
                       T.Receiver_Currency     as receiverCurrency,
                       F.FinDocType_IDREF      as finDocType,
                       BSC.BSystemClient_Title as senderFullname,
                       P.IIN                   as senderIin,
                       P.IsResident            as senderIsResident,
                       T.Receiver_Name         as receiverFullname,
                       F.DateSigned            as finDocSignDate
                from FinDoc F
                         join [User] U on F.User_IDREF = U.User_ID
                         join Person P on U.Person_IDREF = P.Person_ID
                         join Transfer T on F.FinDoc_ID = T.FinDoc_IDREF
                         join Account A on F.Account_IDREF = A.Account_ID
                         join BSystemClient BSC on A.BSystemClient_IDREF = BSC.BSystemClient_ID
                where F.FinDoc_ID = :finDocId
                """;

        List<Map<String, Object>> queryResult = template.queryForList(sql, Map.of("finDocId", finDocId));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .map(row -> toDomainModel(row, finDocId, dboIdPrefix));
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": TransferWay4ToRsbkCreditRsbkRepository findByFinDocId");
        }
    }

    @Override
    public TransferWay4ToRsbkRequest findByFinDocIdOrException(Long finDocId, String dboIdPrefix) {
        return findByFinDocId(finDocId, dboIdPrefix)
                .orElseThrow(() -> new SelfException(E_DB_600, ": TransferWay4ToRsbkCreditRsbkRepository findByFinDocIdOrException"));
    }
}
