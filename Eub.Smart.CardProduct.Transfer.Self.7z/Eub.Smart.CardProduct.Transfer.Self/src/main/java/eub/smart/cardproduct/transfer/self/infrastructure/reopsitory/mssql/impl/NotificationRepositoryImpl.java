package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.component.AuthToken;
import eub.smart.cardproduct.transfer.self.core.model.UserDetails;
import eub.smart.cardproduct.transfer.self.domain.model.in.infrastructure.NotificationPOut;
import eub.smart.cardproduct.transfer.self.domain.repository.NotificationRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.NotificationMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class NotificationRepositoryImpl implements NotificationRepository {

    private final NamedParameterJdbcTemplate template;
    private final AuthToken authToken;

    public NotificationRepositoryImpl(NamedParameterJdbcTemplate template, AuthToken authToken) {
        this.template = template;
        this.authToken = authToken;
    }

    @Override
    public List<NotificationPOut> findAllIpstByAuthToken() {
        var decodedPayload = authToken.getDecodedPayload();
        var userDetails = UserDetails.build(decodedPayload);
        var iin = userDetails.getIin();

        String query = ("""
                SELECT FinDoc.FinDoc_ID    as finDocId,
                       FinDoc.Amount       as amount,
                       FinDoc.Currency     as transferCurrency,
                       Account.Currency    as accountCurrency,
                       Account.Number      as accountNumber,
                       PersonSen.FirstName as firstName,
                       PersonSen.LastName  as lastName,
                       FinDoc.DateCreated  as createdDate
                FROM IPSTransfer
                         JOIN Account ON IPSTransfer.Receiver_IBAN = Account.Number
                         JOIN BSystemClient ON Account.BSystemClient_IDREF = BSystemClient.BSystemClient_ID
                         JOIN Client ON Client.Client_ID = BSystemClient.Client_IDREF
                         JOIN Person AS PersonRes ON PersonRes.Person_ID = Client.Person_IDREF
                         JOIN FinDoc ON FinDoc.FinDoc_ID = IPSTransfer.FinDoc_IDREF
                         JOIN FinDocState ON FinDocState.FinDoc_IDREF = FinDoc.FinDoc_ID
                         JOIN [User] ON [User].User_ID = FinDoc.User_IDREF
                         JOIN Person AS PersonSen ON PersonSen.Person_ID = [User].Person_IDREF
                where FinDoc.DateCreated >= DATEADD(MONTH, -1, GETDATE())
                  and IPSTransfer.TransferType = 'IPST'
                  and FinDocState.DocTechStatus_IDREF = 'DONE'
                  and PersonRes.IIN = :iin
                order by FinDoc.DateCreated desc;
                """);
        return template.query(query, Map.of("iin", iin), NotificationMapper::toDomainModel);
    }
}
