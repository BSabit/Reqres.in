package eub.smart.cardproduct.transfer.self.domain.model.grpc;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.response_interface.ErrorMessage;

public class TransferResponse implements ErrorMessage {
    private String errorMessage;
    private String collectorId;

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getCollectorId() {
        return collectorId;
    }

    public void setCollectorId(String collectorId) {
        this.collectorId = collectorId;
    }

    @Override
    public String toString() {
        return "TransferResponse{" +
                "errorMessage=" + errorMessage +
                ", collectorId=" + collectorId +
                '}';
    }
}
