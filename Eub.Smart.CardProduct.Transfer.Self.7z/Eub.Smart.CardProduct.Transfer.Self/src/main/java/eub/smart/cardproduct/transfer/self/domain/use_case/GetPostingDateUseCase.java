package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.PostingDate;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;

public interface GetPostingDateUseCase {

    PostingDate invoke(RrnBrrn rrnBrrn, String correlationId);
}
