package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.application.model.MessageNotification;

import java.math.BigDecimal;

public interface FormSmsMessageUseCase {
    MessageNotification invoke(Long finDocId, String docStatus, BigDecimal amount, String currency);
}
