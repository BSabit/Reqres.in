package eub.smart.cardproduct.transfer.self.domain.model.in;

import eub.smart.cardproduct.transfer.self.domain.model.common.LocalizedText;

import java.math.BigDecimal;
import java.util.Date;

public record StoryIn(
        Long finDocId,
        String finDocType,
        Date createdDate,
        BigDecimal amount,
        String currency,
        String status,
        LocalizedText transferType,
        LocalizedText sender,
        LocalizedText receiver,
        String imageDefinition
) {
}
