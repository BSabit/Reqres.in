package eub.smart.cardproduct.transfer.self.domain.use_case;

import java.math.BigDecimal;

public interface LimitAccountNightUseCase {

    void invoke(BigDecimal limitNight, String accountNumber, String correlationId, BigDecimal amount, String currency);
}
