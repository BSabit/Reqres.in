package eub.smart.cardproduct.transfer.self.infrastructure.model;

import java.math.BigDecimal;
import java.util.Date;

public interface TransferStory {

    Long getFinDocId();
    String getFinDocType();
    Date getCreatedDate();
    BigDecimal getAmount();
    String getCurrency();
    String getStatus();
    String getTransferTypeRu();
    String getTransferTypeKk();
    String getTransferTypeEn();
    String getSenderRu();
    String getSenderKk();
    String getSenderEn();
    String getReceiverRu();
    String getReceiverKk();
    String getReceiverEn();
    String getImageDefinition();
}
