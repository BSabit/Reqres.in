package eub.smart.cardproduct.transfer.self.core.constant;

public interface FinDocStatus {
    String DONE = "DONE";
    String DRFT = "DRFT";
    String EROR = "EROR";
    String NEWW = "NEWW";
    String PROC = "PROC";
    String PWRS = "PWRS";
    String RJCT = "RJCT";
    String STCL = "STCL";
    String STND = "STND";
    String TPLT = "TPLT";

}
