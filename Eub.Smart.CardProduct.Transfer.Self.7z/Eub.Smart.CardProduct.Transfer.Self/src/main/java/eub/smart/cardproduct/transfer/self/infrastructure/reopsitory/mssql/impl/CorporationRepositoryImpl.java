package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.NewTransferClient;
import eub.smart.cardproduct.transfer.self.domain.repository.CorporationRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.CorporationMapper;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isOneResult;

@Primary
@Repository
public class CorporationRepositoryImpl implements CorporationRepository {

    private final NamedParameterJdbcTemplate template;

    public CorporationRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<NewTransferClient> findNewTransferClient(Long id) {
        String sql = """ 
                select C.Corporation_Title  as name, 
                       C.IsResident         as flagResident,
                       C.BIN                as bin
                from Corporation C
                where C.Corporation_ID = :id
                """;

        List<Map<String, Object>> queryResult = template.queryForList(sql, Map.of("id", id));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .map(CorporationMapper::toDomainModel);
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": CorporationRepository findNewTransferClient");
        }
    }

    @Override
    public NewTransferClient findNewTransferClientOrException(Long id) {
        return findNewTransferClient(id)
                .orElseThrow(() -> new SelfException(E_DB_600, ": CorporationRepository findNewTransferClientOrException"));
    }
}
