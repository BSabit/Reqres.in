package eub.smart.cardproduct.transfer.self.domain.model.grpc;

public class Way4TransactionDate {

    private SetWay4TransactionDateRequest request;
    private TransferResponse response;

    public Way4TransactionDate() {
    }

    public Way4TransactionDate(SetWay4TransactionDateRequest request, TransferResponse response) {
        this.request = request;
        this.response = response;
    }

    public void setRequest(SetWay4TransactionDateRequest request) {
        this.request = request;
    }

    public void setResponse(TransferResponse response) {
        this.response = response;
    }

    public SetWay4TransactionDateRequest getRequest() {
        return request;
    }

    public TransferResponse getResponse() {
        return response;
    }
}
