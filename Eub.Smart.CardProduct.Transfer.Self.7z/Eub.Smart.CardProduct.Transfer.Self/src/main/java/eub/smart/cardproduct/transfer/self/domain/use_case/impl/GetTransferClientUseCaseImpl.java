package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.Client;
import eub.smart.cardproduct.transfer.self.domain.model.NewTransferClient;
import eub.smart.cardproduct.transfer.self.domain.repository.ClientRepository;
import eub.smart.cardproduct.transfer.self.domain.repository.CorporationRepository;
import eub.smart.cardproduct.transfer.self.domain.repository.PersonRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.GetTransferClientUseCase;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Objects;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_LG_801;

public class GetTransferClientUseCaseImpl implements GetTransferClientUseCase {

    private final Logger log = LogManager.getLogger(getClass());
    private final PersonRepository personRepository;
    private final CorporationRepository corporationRepository;
    private final ClientRepository clientRepository;

    public GetTransferClientUseCaseImpl(PersonRepository personRepository,
                                        CorporationRepository corporationRepository,
                                        ClientRepository clientRepository) {
        this.personRepository = personRepository;
        this.corporationRepository = corporationRepository;
        this.clientRepository = clientRepository;
    }

    @Override
    public NewTransferClient invoke(String accountNumber) {
        var client = clientRepository.findByAccountNumberOrException(accountNumber);
        if (isCorp(client)) {
            return corporationRepository.findNewTransferClientOrException(client.getCorporationId());
        } else if (isPerson(client)) {
            return personRepository.findNewTransferClientOrException(client.getPersonId());
        } else {
            log.warn("Client is not Corporation or Person");
            throw new SelfException(E_LG_801, ": Client is not corporation or person");
        }
    }

    private boolean isCorp(Client client) {
        return Objects.nonNull(client.getCorporationId());
    }

    private boolean isPerson(Client client) {
        return Objects.nonNull(client.getPersonId());
    }
}
