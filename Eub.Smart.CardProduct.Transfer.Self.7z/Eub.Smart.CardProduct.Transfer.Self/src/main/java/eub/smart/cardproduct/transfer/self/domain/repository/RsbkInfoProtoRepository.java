package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.CurrencyRate;

public interface RsbkInfoProtoRepository {

    CurrencyRate getCurrencyRate(String currency, String correlationId);
}
