package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.domain.model.in.StoryIn;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;

public interface TransferHistoryRepository {
    Page<StoryIn> findByDatePeriodAndUserId(LocalDate from, LocalDate to, Pageable pageable, LangKey lang);
}
