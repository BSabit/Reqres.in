package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql;

import eub.smart.cardproduct.transfer.self.infrastructure.entity.TransferEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TransferHiberRepository extends JpaRepository<TransferEntity, Long> {
}
