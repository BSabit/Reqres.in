package eub.smart.cardproduct.transfer.self.core.exception;

import java.util.List;

public class SelfException extends RuntimeException {

    public SelfException(SelfErrorCode errorCode, List<ErrorDto> errorDtos) {
        super(errorDtos.toString());
        this.errorCode = errorCode;
    }


    public SelfException(SelfErrorCode errorCode) {
        super(errorCode.message());
        this.errorCode = errorCode;
    }


    public SelfException(SelfErrorCode errorCode, String additionalMessage) {
        super(errorCode.message() + additionalMessage);
        this.errorCode = errorCode;
    }

    public SelfException(SelfErrorCode errorCode, String additionalMessage, String errorMessage) {
        super(errorCode.message() + additionalMessage);
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }


    public SelfException(SelfErrorCode errorCode, Throwable throwable) {
        super(throwable);
        if (throwable.getCause() instanceof SelfException se) {
            this.errorCode = se.getCode();
            this.errorMessage = se.getErrorMessage();
        } else {
            this.errorCode = errorCode;
        }
    }

    private final SelfErrorCode errorCode;
    private String errorMessage;

    public SelfErrorCode getCode() {
        return errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }
}
