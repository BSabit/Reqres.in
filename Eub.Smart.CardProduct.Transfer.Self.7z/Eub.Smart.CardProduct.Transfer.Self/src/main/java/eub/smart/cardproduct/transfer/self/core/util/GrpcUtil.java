package eub.smart.cardproduct.transfer.self.core.util;

import TransferSelf.EubAggregatorCardProductTransferSelf;
import com.google.protobuf.Timestamp;
import custom_types.CustomTypes;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import rsbkinfo.V1.EubAdapterRsbkInfo;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.Date;

import static java.util.Objects.isNull;

public class GrpcUtil {

    private static final Logger log = LogManager.getLogger(GrpcUtil.class);
    private static final int NANO_MULTIPLAYER = 10_000_000;

    public static CustomTypes.DecimalValue toDecimalValue(BigDecimal value) {
        try {
            String[] valueArray = value
                    .setScale(2, RoundingMode.FLOOR)
                    .toString()
                    .split("\\.");
            int units = Integer.parseInt(valueArray[0]);
            int nanos = Integer.parseInt(valueArray[1]);
            return CustomTypes.DecimalValue
                    .newBuilder()
                    .setUnits(units)
                    .setNanos(nanos * NANO_MULTIPLAYER)
                    .build();
        } catch (Exception e) {
            log.error("GrpcUtil toValue");
            return CustomTypes.DecimalValue.getDefaultInstance();
        }
    }

    public static BigDecimal toBigDecimal(CustomTypes.DecimalValue decimalValue) {
        BigDecimal whole = new BigDecimal(decimalValue.getUnits());
        BigDecimal nanos = new BigDecimal(decimalValue.getNanos());
        BigDecimal tenPowMinusNine = new BigDecimal("0.000000001");
        BigDecimal fractional = nanos.multiply(tenPowMinusNine);
        return whole.add(fractional).setScale(2, RoundingMode.FLOOR);
    }

    public static Timestamp toTimestamp(Date date) {
        if (isNull(date)) return Timestamp.getDefaultInstance();
        Instant time = date.toInstant();
        return toTimestamp(time);
    }

    public static Timestamp toTimestamp(Instant time) {
        if (isNull(time)) return Timestamp.getDefaultInstance();
        return Timestamp.newBuilder().setSeconds(time.getEpochSecond()).setNanos(time.getNano()).build();
    }

    public static EubAggregatorCardProductTransferSelf.CurrencyCode toAggregatorCurrencyCode(String operationCurrency) {
        try {
            return EubAggregatorCardProductTransferSelf.CurrencyCode.valueOf(operationCurrency);
        } catch (Exception e) {
            log.error("GrpcUtil toCurrencyCode: {}", operationCurrency);
            return EubAggregatorCardProductTransferSelf.CurrencyCode.UNKNOWN;
        }
    }

    public static EubAdapterRsbkInfo.CurrencyCode toAdapterCurrencyCode(String operationCurrency) {
        try {
            return EubAdapterRsbkInfo.CurrencyCode.valueOf(operationCurrency);
        } catch (Exception e) {
            log.error("GrpcUtil toCurrencyCode: {}", operationCurrency);
            return EubAdapterRsbkInfo.CurrencyCode.ZERO;
        }
    }

    public static Instant toInstant(Timestamp timestamp) {
        if (isInvalidTimestamp(timestamp)) return null;
        return Instant.ofEpochSecond(timestamp.getSeconds(), timestamp.getNanos());
    }

    public static Date toDate(Timestamp timestamp) {
        Instant instant = toInstant(timestamp);
        if (isNull(instant)) return null;
        return Date.from(instant);
    }

    private static boolean isInvalidTimestamp(Timestamp timestamp) {
        return isNull(timestamp) || (timestamp.getSeconds() == 0 && timestamp.getNanos() == 0);
    }
}
