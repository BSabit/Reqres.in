package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.grpc;

import TransferSelf.TransferSelfGrpc;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.*;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferSelfProtoRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.handler.GrpcReturnValueHandler;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc.TransferIbanToIbanMapper;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc.TransferSelfMapper;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc.TransferTcRsbkMapper;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc.TransferWay4ConvertMapper;
import io.grpc.StatusRuntimeException;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.springframework.stereotype.Component;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_EX_700;
import static eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc.TransferSelfMapper.toProtoModel;
import static eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc.TransferTcRsbkMapper.toGrpcModel;

@Component
public class TransferSelfProtoRepositoryImpl implements TransferSelfProtoRepository {

    @GrpcClient("aggregator-card-product-transfer-self")
    private TransferSelfGrpc.TransferSelfBlockingStub stub;

    @Override
    @GrpcReturnValueHandler(methodName = "transferTcRsbk")
    public TransferTcResponse transferTcRsbk(TransferTcRequest requestModel, String correlationId) {
        try {
            var grpcRequest = toGrpcModel(requestModel);
            var grpcResponse = stub.transferTcRsbk(grpcRequest);
            return TransferTcRsbkMapper.toDomainModel(grpcResponse);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": transferTcRsbk " + e.getStatus().getCode().name());
        }
    }

    @Override
    @GrpcReturnValueHandler(methodName = "transferTcWay4")
    public TransferTcResponse transferTcWay4(TransferTcRequest requestModel, String correlationId) {
        try {
            var grpcRequest = toGrpcModel(requestModel);
            var grpcResponse = stub.transferTcWay4(grpcRequest);
            return TransferTcRsbkMapper.toDomainModel(grpcResponse);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": transferTcWay4 " + e.getStatus().getCode().name());
        }
    }

    @Override
    @GrpcReturnValueHandler(methodName = "transferRsbkToWay4DebitTransit")
    public UfxResponse transferRsbkToWay4DebitTransit(UfxTransferRequest requestModel) {
        try {
            var grpcRequest = toProtoModel(requestModel);
            var grpcResponse = stub.transferRsbkToWay4DebitTransit(grpcRequest);
            return TransferSelfMapper.toDomainModel(grpcResponse);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": transferRsbkToWay4DebitTransit " + e.getStatus().getCode().name());
        }
    }

    @Override
    @GrpcReturnValueHandler(methodName = "transferRsbkToWay4Credit")
    public UfxResponse transferRsbkToWay4Credit(UfxTransferRequest requestModel) {
        try {
            var grpcRequest = toProtoModel(requestModel);
            var grpcResponse = stub.transferRsbkToWay4Credit(grpcRequest);
            return TransferSelfMapper.toDomainModel(grpcResponse);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": transferRsbkToWay4Credit " + e.getStatus().getCode().name());
        }
    }

    @Override
    @GrpcReturnValueHandler(methodName = "transferRsbkToWay4ReverseTransit")
    public UfxResponse transferRsbkToWay4ReverseTransit(UfxTransferRequest requestModel) {
        try {
            var grpcRequest = toProtoModel(requestModel);
            var grpcResponse = stub.transferRsbkToWay4ReverseTransit(grpcRequest);
            return TransferSelfMapper.toDomainModel(grpcResponse);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": transferRsbkToWay4ReverseTransit " + e.getStatus().getCode().name());
        }
    }

    @Override
    @GrpcReturnValueHandler(methodName = "transferWay4ToRsbkCreditTransit")
    public UfxResponse transferWay4ToRsbkCreditTransit(UfxTransferRequest requestModel) {
        try {
            var grpcRequest = toProtoModel(requestModel);
            var grpcResponse = stub.transferWay4ToRsbkCreditTransit(grpcRequest);
            return TransferSelfMapper.toDomainModel(grpcResponse);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": transferWay4ToRsbkCreditTransit " + e.getStatus().getCode().name());
        }
    }

    @Override
    @GrpcReturnValueHandler(methodName = "transferWay4ToRsbkDebit")
    public UfxResponse transferWay4ToRsbkDebit(UfxTransferRequest requestModel) {
        try {
            var grpcRequest = toProtoModel(requestModel);
            var grpcResponse = stub.transferWay4ToRsbkDebit(grpcRequest);
            return TransferSelfMapper.toDomainModel(grpcResponse);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": transferWay4ToRsbkDebit " + e.getStatus().getCode().name());
        }
    }

    @Override
    @GrpcReturnValueHandler(methodName = "transferWay4ToRsbkReverseDebit")
    public UfxResponse transferWay4ToRsbkReverseDebit(UfxTransferRequest requestModel) {
        try {
            var grpcRequest = toProtoModel(requestModel);
            var grpcResponse = stub.transferWay4ToRsbkReverseDebit(grpcRequest);
            return TransferSelfMapper.toDomainModel(grpcResponse);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": transferWay4ToRsbkReverseDebit " + e.getStatus().getCode().name());
        }
    }

    @Override
    @GrpcReturnValueHandler(methodName = "transferWay4ToRsbkReverseTransit")
    public UfxResponse transferWay4ToRsbkReverseTransit(UfxTransferRequest requestModel) {
        try {
            var grpcRequest = toProtoModel(requestModel);
            var grpcResponse = stub.transferWay4ToRsbkReverseTransit(grpcRequest);
            return TransferSelfMapper.toDomainModel(grpcResponse);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": transferWay4ToRsbkReverseTransit " + e.getStatus().getCode().name());
        }
    }

    @Override
    @GrpcReturnValueHandler(methodName = "transferWay4ToWay4Debit")
    public UfxResponse transferWay4ToWay4Debit(UfxTransferRequest requestModel) {
        try {
            var grpcRequest = toProtoModel(requestModel);
            var grpcResponse = stub.transferWay4ToWay4Debit(grpcRequest);
            return TransferSelfMapper.toDomainModel(grpcResponse);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": transferWay4ToWay4Debit " + e.getStatus().getCode().name());
        }
    }

    @Override
    @GrpcReturnValueHandler(methodName = "transferWay4ToWay4Credit")
    public UfxResponse transferWay4ToWay4Credit(UfxTransferRequest requestModel) {
        try {
            var grpcRequest = toProtoModel(requestModel);
            var grpcResponse = stub.transferWay4ToWay4Credit(grpcRequest);
            return TransferSelfMapper.toDomainModel(grpcResponse);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": transferWay4ToWay4Credit " + e.getStatus().getCode().name());
        }
    }

    @Override
    @GrpcReturnValueHandler(methodName = "transferWay4ToWay4ReverseDebit")
    public UfxResponse transferWay4ToWay4ReverseDebit(UfxTransferRequest requestModel) {
        try {
            var grpcRequest = toProtoModel(requestModel);
            var grpcResponse = stub.transferWay4ToWay4ReverseDebit(grpcRequest);
            return TransferSelfMapper.toDomainModel(grpcResponse);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": transferWay4ToWay4ReverseDebit " + e.getStatus().getCode().name());
        }
    }

    @Override
    @GrpcReturnValueHandler(methodName = "transferWay4Convert")
    public UfxResponse transferWay4Convert(TransferWay4ConvertRequest requestModel) {
        try {
            var grpcRequest = TransferWay4ConvertMapper.toProtoModel(requestModel);
            var grpcResponse = stub.transferWay4Convert(grpcRequest);
            return TransferSelfMapper.toDomainModel(grpcResponse);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": transferWay4Convert " + e.getStatus().getCode().name());
        }
    }

    @Override
    @GrpcReturnValueHandler(methodName = "transferIbanToIban")
    public UfxResponse transferIbanToIban(TransferIbanToIbanRequest requestModel) {
        try {
            var grpcRequest = TransferIbanToIbanMapper.toProtoModel(requestModel);
            var grpcResponse = stub.transferIbanToIban(grpcRequest);
            return TransferSelfMapper.toDomainModel(grpcResponse);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": transferIbanToIban " + e.getStatus().getCode().name());
        }
    }
}
