package eub.smart.cardproduct.transfer.self.domain.model.grpc;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

public class PostingDateResponse {

    private String docStatus;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private Date postingDate;

    public PostingDateResponse() {
    }

    public PostingDateResponse(String docStatus, Date postingDate) {
        this.docStatus = docStatus;
        this.postingDate = postingDate;
    }

    public void setDocStatus(String docStatus) {
        this.docStatus = docStatus;
    }

    public void setPostingDate(Date postingDate) {
        this.postingDate = postingDate;
    }

    public String getDocStatus() {
        return docStatus;
    }

    public Date getPostingDate() {
        return postingDate;
    }

    @Override
    public String toString() {
        return "PostingDateResponse{" +
                "docStatus=" + docStatus +
                ", postingDate=" + postingDate +
                '}';
    }
}
