package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.limit.SpentAmount;

import java.time.LocalDate;
import java.util.List;

public interface LimitClientNightRepository {

    List<SpentAmount> findByClientIdAndUserId(LocalDate signDate, Long clientId, Long userId);
}
