package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.AccountInfo;
import eub.smart.cardproduct.transfer.self.domain.model.CreateTransferAccountInfo;
import eub.smart.cardproduct.transfer.self.domain.repository.AccountRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.GetAccountInfoBuyNumberUseCase;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_LG_800;
import static java.util.Objects.isNull;

public class GetAccountInfoBuyNumberUseCaseImpl implements GetAccountInfoBuyNumberUseCase {

    private final AccountRepository accountRepository;

    public GetAccountInfoBuyNumberUseCaseImpl(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Override
    public CreateTransferAccountInfo invoke(String number, String currency) {
        var accountInfo = accountRepository.findByNumberOrException(number);
        if (isOldMultiCurrency(accountInfo)) {
            accountInfo.setCurrency(currency);
        } else if (!accountInfo.getCurrency().equals(currency)){
            throw new SelfException(E_LG_800, ": invalid currency by account number: " + number);
        }
        return new CreateTransferAccountInfo(accountInfo);
    }

    /**
     * It can be simple account or new multi currency
     * @param accountInfo short account info
     * @return flag is olf multi currency
     */
    private boolean isOldMultiCurrency(AccountInfo accountInfo) {
        return accountInfo.getFlagMultiCurrency() && isNull(accountInfo.getIdRef());
    }
}
