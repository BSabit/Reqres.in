package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4ToRsbk;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.UfxTransferRequest;

public interface TransferWay4ToRsbkReverseTransitUseCase {

    TransferWay4ToRsbk invoke(UfxTransferRequest finDocId);
}
