package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.component.AuthToken;
import eub.smart.cardproduct.transfer.self.core.model.UserDetails;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.*;
import eub.smart.cardproduct.transfer.self.domain.repository.FinDocRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.CreateBaseModeUseCase;

import java.time.LocalTime;

import static eub.smart.cardproduct.transfer.self.core.util.DateTimeUtil.DAY_END;
import static eub.smart.cardproduct.transfer.self.core.util.DateTimeUtil.DAY_START;

public class CreateBaseModeUseCaseImpl implements CreateBaseModeUseCase {

    private final FinDocRepository finDocRepository;
    private final AuthToken authToken;

    public CreateBaseModeUseCaseImpl(FinDocRepository finDocRepository,
                                     AuthToken authToken) {
        this.finDocRepository = finDocRepository;
        this.authToken = authToken;
    }

    public TransferInternalBaseModel invoke(Long finDocId, String correlationId) {
        var payload = authToken.getDecodedPayload();
        var userDetails = UserDetails.build(payload);
        var senderIin = userDetails.getIin();
        var finDocInfo = finDocRepository.findFinDocAccOrException(finDocId, senderIin, correlationId);

        var finDocData = new FinDocData(finDocInfo);
        var senderData = AccountData.buildSenderData(finDocInfo);
        var receiverData = AccountData.buildReceiverData(finDocInfo);
        var senderDetails = new SenderDetails(userDetails);
        var limitFlag = new LimitFlag(isDay());
        return new TransferInternalBaseModel(finDocData, senderData, receiverData, limitFlag, senderDetails);
    }

    private boolean isDay() {
        LocalTime now = LocalTime.now();
        return now.isAfter(DAY_START) && now.isBefore(DAY_END);
    }
}
