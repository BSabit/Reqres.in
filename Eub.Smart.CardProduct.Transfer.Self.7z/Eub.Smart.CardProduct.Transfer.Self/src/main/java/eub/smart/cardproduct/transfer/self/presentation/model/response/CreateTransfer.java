package eub.smart.cardproduct.transfer.self.presentation.model.response;

import eub.smart.cardproduct.transfer.self.application.model.TransferStatus;
import io.swagger.v3.oas.annotations.media.Schema;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import static java.util.Objects.isNull;

public class CreateTransfer {

    @Schema(description = "FinDoc Id")
    private Long id;
    private String account;
    private BigDecimal amount;
    private List<Object> warnings;
    private String clientName;
    private String currency;
    private Date dateCreated;
    private Date dateScheduled;
    private String docType;
    private String feeCurrency;
    private String number;
    private String receiverAccount;
    private String receiverName;
    private Boolean template;
    private Boolean urgent;
    private BigDecimal feeAmount;
    private String transferType;
    private String senderSubAccountCurrency;
    private String subAccountCurrency;
    private Object fee;
    @Schema(description = "Статус FinDoc")
    private CreateTransferStatus status;
    private BigDecimal exchangeRate;
    private String sourceAccountCurrency;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public List<Object> getWarnings() {
        return warnings;
    }

    public void setWarnings(List<Object> warnings) {
        this.warnings = warnings;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateScheduled() {
        return dateScheduled;
    }

    public void setDateScheduled(Date dateScheduled) {
        this.dateScheduled = dateScheduled;
    }

    public String getDocType() {
        return docType;
    }

    public void setDocType(String docType) {
        this.docType = docType;
    }

    public String getFeeCurrency() {
        return feeCurrency;
    }

    public void setFeeCurrency(String feeCurrency) {
        this.feeCurrency = feeCurrency;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getReceiverAccount() {
        return receiverAccount;
    }

    public void setReceiverAccount(String receiverAccount) {
        this.receiverAccount = receiverAccount;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public Boolean getTemplate() {
        return template;
    }

    public void setTemplate(Boolean template) {
        this.template = template;
    }

    public Boolean getUrgent() {
        return urgent;
    }

    public void setUrgent(Boolean urgent) {
        this.urgent = urgent;
    }

    public BigDecimal getFeeAmount() {
        return feeAmount;
    }

    public void setFeeAmount(BigDecimal feeAmount) {
        this.feeAmount = feeAmount;
    }

    public String getTransferType() {
        return transferType;
    }

    public void setTransferType(String transferType) {
        this.transferType = transferType;
    }

    public String getSenderSubAccountCurrency() {
        return senderSubAccountCurrency;
    }

    public void setSenderSubAccountCurrency(String senderSubAccountCurrency) {
        this.senderSubAccountCurrency = senderSubAccountCurrency;
    }

    public String getSubAccountCurrency() {
        return subAccountCurrency;
    }

    public void setSubAccountCurrency(String subAccountCurrency) {
        this.subAccountCurrency = subAccountCurrency;
    }

    public Object getFee() {
        return fee;
    }

    public void setFee(Object fee) {
        this.fee = fee;
    }

    public CreateTransferStatus getStatus() {
        return status;
    }

    public void setStatus(CreateTransferStatus status) {
        this.status = status;
    }

    public BigDecimal getExchangeRate() {
        return exchangeRate;
    }

    public void setExchangeRate(BigDecimal exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    public String getSourceAccountCurrency() {
        return sourceAccountCurrency;
    }

    public void setSourceAccountCurrency(String sourceAccountCurrency) {
        this.sourceAccountCurrency = sourceAccountCurrency;
    }

    public void setStatus(TransferStatus status) {
        if (isNull(status)) return;
        this.status = new CreateTransferStatus(status.getDocTechStatus(), status.getTitle(), status.getFinDocStatus());
    }
}
