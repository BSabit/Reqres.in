package eub.smart.cardproduct.transfer.self.core.constant;

public interface FinDocType {

    String SELF = "TSLF";
    String LOCAL = "TLOC";
    String OIPS = "OIPS";
    String IIPS = "IIPS";
    String TOUT = "TOUT";
    String TINT = "TINT";
    String CRCR = "CRCR";
}
