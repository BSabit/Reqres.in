package eub.smart.cardproduct.transfer.self.domain.model.in.infrastructure;

import java.math.BigDecimal;
import java.util.Date;

public record IipsTransferIn(
        Long finDocId,
        String docTechStatus,
        Date signDate,
        Long accountOutRef,
        String bSystem,
        String senderAccountNumber,
        String receiverAccountNumber,
        BigDecimal amount,
        String currency,
        String knpCode
) {
}
