package eub.smart.cardproduct.transfer.self.domain.model.grpc;

import java.util.UUID;

public class TransferTcRequest {

    private String collectorID;
    private String requestId;

    public TransferTcRequest() {
    }

    public TransferTcRequest(TransferResponse transferResponse) {
        this.collectorID = transferResponse.getCollectorId();
        this.requestId = UUID.randomUUID().toString();
    }

    public String getCollectorID() {
        return collectorID;
    }

    public void setCollectorID(String collectorID) {
        this.collectorID = collectorID;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    @Override
    public String toString() {
        return "TransferTcRequest{" +
                "collectorID=" + collectorID +
                ", requestId=" + requestId +
                '}';
    }
}
