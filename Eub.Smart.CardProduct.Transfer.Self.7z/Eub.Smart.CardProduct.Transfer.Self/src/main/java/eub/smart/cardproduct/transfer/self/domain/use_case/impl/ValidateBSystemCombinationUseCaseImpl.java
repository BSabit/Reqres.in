package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.use_case.ValidateBSystemCombinationUseCase;

import java.util.Set;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_LG_802;
import static eub.smart.cardproduct.transfer.self.core.constant.BSystemType.RSBK;
import static eub.smart.cardproduct.transfer.self.core.constant.BSystemType.WAY4;

public class ValidateBSystemCombinationUseCaseImpl implements ValidateBSystemCombinationUseCase {

    private final Set<String> validBSystems = Set.of(WAY4, RSBK);

    private boolean isValidSystems(String senderSystem, String receiverSystem) {
        return !validBSystems.contains(senderSystem) || !validBSystems.contains(receiverSystem);
    }

    @Override
    public void invoke(String senderBSystem, String receiverBSystem) {
        if (isValidSystems(senderBSystem, receiverBSystem)) {
            throw new SelfException(E_LG_802, String.format(": Combination %s and %s is not supported", senderBSystem, receiverBSystem));
        }
    }
}
