package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferResponse;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferTcRsbk;

public interface TransferTcRsbkUseCase {

    TransferTcRsbk invoke(TransferResponse transferResponse, String correlationId);
}
