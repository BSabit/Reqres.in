package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.CreateTransferAccountInfo;
import eub.smart.cardproduct.transfer.self.domain.model.in.presentation.CreateTransferDataPIn;
import eub.smart.cardproduct.transfer.self.domain.model.in.presentation.CreateTransferTslfPIn;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferKnpRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.*;

import static eub.smart.cardproduct.transfer.self.core.constant.AccountType.isDeposit;
import static eub.smart.cardproduct.transfer.self.core.constant.FinDocType.SELF;
import static eub.smart.cardproduct.transfer.self.core.constant.TransferKNPConvertType.NONE;

public class CreateTslfTransferUseCaseImpl implements CreateTslfTransferUseCase {

    private final CreateTransferDataUseCase createTransferDataUseCase;
    private final TransferKnpRepository transferKnpRepository;
    private final GetAccountDepositTypeUseCase getAccountDepositTypeUseCase;
    private final GetAccountInfoBuyNumberUseCase getAccountInfoUseCase;
    private final ValidateReceiverAmountUseCase validateReceiverAmountUseCase;

    public CreateTslfTransferUseCaseImpl(CreateTransferDataUseCase createTransferDataUseCase,
                                         TransferKnpRepository transferKnpRepository,
                                         GetAccountDepositTypeUseCase getAccountDepositTypeUseCase,
                                         GetAccountInfoBuyNumberUseCase getAccountInfoUseCase,
                                         ValidateReceiverAmountUseCase validateReceiverAmountUseCase) {
        this.createTransferDataUseCase = createTransferDataUseCase;
        this.transferKnpRepository = transferKnpRepository;
        this.getAccountDepositTypeUseCase = getAccountDepositTypeUseCase;
        this.getAccountInfoUseCase = getAccountInfoUseCase;
        this.validateReceiverAmountUseCase = validateReceiverAmountUseCase;
    }

    @Override
    public Long invoke(CreateTransferTslfPIn in) {
        var senderAccount = getAccountInfoUseCase.invoke(in.senderAccountNumber(), in.senderCurrency());
        var receiverAccount = getAccountInfoUseCase.invoke(in.receiverAccountNumber(), in.receiverCurrency());
        var knpCode = getKnpCode(senderAccount, receiverAccount);
        validateReceiverAmountUseCase.invoke(in.senderAmount(), in.receiverAmount(), in.senderCurrency(), in.receiverCurrency());

        var createTransferDataIn = new CreateTransferDataPIn(in, SELF, knpCode);
        var transfer = createTransferDataUseCase.invoke(createTransferDataIn, senderAccount, receiverAccount);
        return transfer.getTransfer().getFinDoc().getId();
    }

    private String getKnpCode(CreateTransferAccountInfo senderAccount,
                              CreateTransferAccountInfo receiverAccount) {
        var senderAccountType = isDeposit(senderAccount.getType())
                ? getAccountDepositTypeUseCase.invoke(senderAccount.getId())
                : senderAccount.getType();
        var receiverAccountType = isDeposit(receiverAccount.getType())
                ? getAccountDepositTypeUseCase.invoke(receiverAccount.getId())
                : receiverAccount.getType();
        return transferKnpRepository.findKNPCodeOrException(senderAccountType, receiverAccountType, NONE, true);
    }
}
