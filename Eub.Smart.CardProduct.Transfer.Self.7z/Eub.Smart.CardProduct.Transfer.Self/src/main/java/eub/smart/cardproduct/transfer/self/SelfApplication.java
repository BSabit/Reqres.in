package eub.smart.cardproduct.transfer.self;

import io.camunda.zeebe.spring.client.EnableZeebeClient;
import io.camunda.zeebe.spring.client.annotation.Deployment;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableZeebeClient
@Deployment(resources = {
		"bpmn/TransferInternal.bpmn",
		"bpmn/TransferInternalLimit.bpmn",
		"bpmn/TransferInternalValidation.bpmn",
		"bpmn/TransferInternalRsbkToRsbk.bpmn",
		"bpmn/TransferInternalRsbkToRsbkValidation.bpmn",
		"bpmn/TransferInternalRsbkToWay4.bpmn",
		"bpmn/TransferInternalRsbkToWay4Validation.bpmn",
		"bpmn/TransferInternalWay4ToRsbk.bpmn",
		"bpmn/TransferInternalWay4ToRsbkValidation.bpmn",
		"bpmn/TransferInternalWay4ToWay4.bpmn",
		"bpmn/TransferInternalWay4ToWay4Validation.bpmn"})
public class SelfApplication {

	public static void main(String[] args) {
		SpringApplication.run(SelfApplication.class, args);
	}

}
