package eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.SetWay4TransactionDateRequest;
import rsbktransactional.V1.EubAdapterRsbkTransactional;

import static eub.smart.cardproduct.transfer.self.core.util.GrpcUtil.toTimestamp;

public class Way4TransactionDateMapper {

    public static EubAdapterRsbkTransactional.SetWay4TransactionDateRequest toGrpcModel(SetWay4TransactionDateRequest requestModel) {
        return EubAdapterRsbkTransactional.SetWay4TransactionDateRequest
                .newBuilder()
                .setCollectorId(requestModel.getCollectorId())
                .setWay4PostingDate(toTimestamp(requestModel.getWay4PostingDate()))
                .build();
    }
}
