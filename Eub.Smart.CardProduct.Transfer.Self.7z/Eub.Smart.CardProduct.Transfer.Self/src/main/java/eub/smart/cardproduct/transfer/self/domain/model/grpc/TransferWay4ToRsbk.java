package eub.smart.cardproduct.transfer.self.domain.model.grpc;

public class TransferWay4ToRsbk {

    private UfxTransferRequest ufxTransferRequest;
    private UfxResponse ufxResponse;

    public TransferWay4ToRsbk() {
    }

    public TransferWay4ToRsbk(UfxTransferRequest ufxTransferRequest,
                              UfxResponse ufxResponse) {
        this.ufxTransferRequest = ufxTransferRequest;
        this.ufxResponse = ufxResponse;
    }

    public void setUfxTransferRequest(UfxTransferRequest ufxTransferRequest) {
        this.ufxTransferRequest = ufxTransferRequest;
    }

    public void setUfxResponse(UfxResponse ufxResponse) {
        this.ufxResponse = ufxResponse;
    }

    public UfxTransferRequest getUfxTransferRequest() {
        return ufxTransferRequest;
    }

    public UfxResponse getUfxResponse() {
        return ufxResponse;
    }
}
