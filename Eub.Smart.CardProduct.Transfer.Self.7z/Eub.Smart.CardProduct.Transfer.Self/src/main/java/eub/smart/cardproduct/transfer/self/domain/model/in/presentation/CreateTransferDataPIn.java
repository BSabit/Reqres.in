package eub.smart.cardproduct.transfer.self.domain.model.in.presentation;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.core.util.JsonUtil;
import eub.smart.cardproduct.transfer.self.domain.model.in.infrastructure.IipsTransferIn;

import java.math.BigDecimal;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_SM_501;

public record CreateTransferDataPIn(
        String senderAccountNumber,
        String receiverAccountNumber,
        BigDecimal senderAmount,
        BigDecimal receiverAmount,
        String senderCurrency,
        String receiverCurrency,
        String currencyRates,
        String finDocType,
        String knpCode,
        Long finDocIdRef
) {
    public CreateTransferDataPIn(CreateTransferTslfPIn in, String finDocType, String knpCode) {
        this(in.senderAccountNumber(),
                in.receiverAccountNumber(),
                in.senderAmount(),
                in.receiverAmount(),
                in.senderCurrency(),
                in.receiverCurrency(),
                toCurrencyRatesJson(in),
                finDocType,
                knpCode,
                null);
    }

    private static String toCurrencyRatesJson(CreateTransferTslfPIn in) {
        return JsonUtil.toJson(in.currencyRates())
                .orElseThrow(() -> new SelfException(E_SM_501, ": CurrencyRate"));
    }

    public CreateTransferDataPIn(IipsTransferIn in, String receiverCurrency, String finDocType) {
        this(in.receiverAccountNumber(),
                in.senderAccountNumber(),
                in.amount(),
                in.amount(),
                in.currency(),
                receiverCurrency,
                null,
                finDocType,
                in.knpCode(),
                in.finDocId());
    }
}
