package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.Usage;

public interface GetClientUsageUseCase {

    Usage invoke(Long clientId, Long userId);
}
