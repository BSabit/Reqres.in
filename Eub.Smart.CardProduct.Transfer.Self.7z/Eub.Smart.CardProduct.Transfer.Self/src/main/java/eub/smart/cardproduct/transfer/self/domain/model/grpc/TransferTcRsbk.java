package eub.smart.cardproduct.transfer.self.domain.model.grpc;

public class TransferTcRsbk {

    private TransferTcRequest transferTcRsbkRequest;
    private TransferTcResponse transferTcRsbkResponse;

    public TransferTcRsbk() {
    }

    public TransferTcRsbk(TransferTcRequest transferTcRsbkRequest,
                          TransferTcResponse transferTcRsbkResponse) {
        this.transferTcRsbkRequest = transferTcRsbkRequest;
        this.transferTcRsbkResponse = transferTcRsbkResponse;
    }

    public TransferTcRequest getTransferTcRsbkRequest() {
        return transferTcRsbkRequest;
    }

    public TransferTcResponse getTransferTcRsbkResponse() {
        return transferTcRsbkResponse;
    }

    public void setTransferTcRsbkRequest(TransferTcRequest transferTcRsbkRequest) {
        this.transferTcRsbkRequest = transferTcRsbkRequest;
    }

    public void setTransferTcRsbkResponse(TransferTcResponse transferTcRsbkResponse) {
        this.transferTcRsbkResponse = transferTcRsbkResponse;
    }
}
