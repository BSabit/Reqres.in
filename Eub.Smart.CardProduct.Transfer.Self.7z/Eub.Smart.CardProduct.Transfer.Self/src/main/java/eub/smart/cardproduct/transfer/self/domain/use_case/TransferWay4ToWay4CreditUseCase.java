package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4ToWay4;

public interface TransferWay4ToWay4CreditUseCase {

    TransferWay4ToWay4 invoke(Long finDocId, RrnBrrn rrnBrrn, String correlationId);
}
