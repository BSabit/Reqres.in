package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.Fee;

import java.util.Optional;

public interface FeeRepository {

    Optional<Fee> findById(Long id);

    Fee findByIdOrException(Long id);
}
