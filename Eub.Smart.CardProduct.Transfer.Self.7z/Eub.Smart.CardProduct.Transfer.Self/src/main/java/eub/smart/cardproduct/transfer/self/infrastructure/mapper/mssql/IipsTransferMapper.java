package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.domain.model.in.infrastructure.IipsTransferIn;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

public class IipsTransferMapper {

    public static IipsTransferIn toDomainModel(ResultSet resultSet, int row) throws SQLException {
        Long finDocId = resultSet.getLong("finDocId");
        String docTechStatus = resultSet.getString("docTechStatus");
        Date signDate = resultSet.getTimestamp("signDate");
        Long accountOutRef = resultSet.getLong("accountOutRef");
        String bSystem = resultSet.getString("bSystem");
        String senderAccountNumber = resultSet.getString("senderAccountNumber");
        String receiverAccountNumber = resultSet.getString("receiverAccountNumber");
        BigDecimal amount = resultSet.getBigDecimal("amount");
        String currency = resultSet.getString("currency");
        String knpCode = resultSet.getString("knpCode");
        return new IipsTransferIn(
                finDocId,
                docTechStatus,
                signDate,
                accountOutRef,
                bSystem,
                senderAccountNumber,
                receiverAccountNumber,
                amount,
                currency,
                knpCode);
    }
}
