package eub.smart.cardproduct.transfer.self.domain.model.grpc;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class TransferWay4PostRequest {

    private final String rrn;

    @JsonCreator(mode = JsonCreator.Mode.PROPERTIES)
    public TransferWay4PostRequest(@JsonProperty("rrn") String rrn) {
        this.rrn = rrn;
    }

    public String getRrn() {
        return rrn;
    }

    @Override
    public String toString() {
        return "TransferWay4PostRequest{" +
                "rrn='" + rrn + '\'' +
                '}';
    }
}
