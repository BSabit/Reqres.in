package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.in.infrastructure.IipsTransferIn;
import eub.smart.cardproduct.transfer.self.domain.repository.IipsTransferRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.IipsTransferMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isOneResult;

@Repository
public class IipsTransferRepositoryImpl implements IipsTransferRepository {

    private final NamedParameterJdbcTemplate template;

    public IipsTransferRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<IipsTransferIn> findByFinDocId(Long finDocId) {
        String sql = """ 
                select FD.FinDoc_ID         as finDocId,
                       DTS.DocTechStatus_ID as docTechStatus,
                       FD.DateSigned        as signDate,
                       A.Account_OUTREF     as accountOutRef,
                       BSC.BSystem_IDREF    as bSystem,
                       A.Number             as senderAccountNumber,
                       IIPS.Receiver_IBAN   as receiverAccountNumber,
                       FD.Amount            as amount,
                       FD.Currency          as currency,
                       IIPS.Knp_IDREF       as knpCode
                from DocTechStatus DTS
                         join FinDocState FDS on DTS.DocTechStatus_ID = FDS.DocTechStatus_IDREF
                         join FinDoc FD on FDS.FinDoc_IDREF = FD.FinDoc_ID
                         join Account A on FD.Account_IDREF = A.Account_ID
                         join BSystemClient BSC on A.BSystemClient_IDREF = BSC.BSystemClient_ID
                         join IPSTransfer IIPS on FD.FinDoc_ID = IIPS.FinDoc_IDREF
                where FD.FinDoc_ID = :finDocId;
                """;
        List<IipsTransferIn> queryResult = template.query(sql, Map.of("finDocId", finDocId), IipsTransferMapper::toDomainModel);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": IipsTransferRepositoryImpl findByFinDocId");
        }
    }
}
