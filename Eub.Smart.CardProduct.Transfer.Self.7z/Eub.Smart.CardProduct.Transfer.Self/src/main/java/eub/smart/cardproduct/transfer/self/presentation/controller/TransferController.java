package eub.smart.cardproduct.transfer.self.presentation.controller;

import eub.smart.cardproduct.transfer.self.application.model.TransferStatus;
import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.domain.model.in.presentation.CreateTransferTslfPIn;
import eub.smart.cardproduct.transfer.self.domain.repository.FinDocStateRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.*;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.TransferInternalBaseModel;
import eub.smart.cardproduct.transfer.self.domain.repository.FinDocStateRepository;
import eub.smart.cardproduct.transfer.self.presentation.mapper.PresentationMapper;
import eub.smart.cardproduct.transfer.self.presentation.model.request.CreateTransferRequest;
import eub.smart.cardproduct.transfer.self.presentation.model.request.TransferHistoryRequest;
import eub.smart.cardproduct.transfer.self.presentation.model.request.TransferReceiptRequest;
import eub.smart.cardproduct.transfer.self.presentation.model.response.CreateTransfer;
import eub.smart.cardproduct.transfer.self.presentation.response_advise.ResponseBinding;
import eub.smart.cardproduct.transfer.self.application.ZeebeStarter;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.core.util.JsonUtil;
import eub.smart.cardproduct.transfer.self.presentation.swagger.response.CreateTransferResponse;
import eub.smart.cardproduct.transfer.self.presentation.swagger.response.ExecuteTransferResponse;
import eub.smart.cardproduct.transfer.self.presentation.swagger.response.TransferHistoryResponse;
import eub.smart.cardproduct.transfer.self.presentation.swagger.response.TransferReceiptResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import static eub.smart.cardproduct.transfer.self.core.constant.BSystemType.WAY4;
import static eub.smart.cardproduct.transfer.self.core.constant.DocTechStatus.NEWW;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_SM_501;

import java.time.LocalDate;

import static eub.smart.cardproduct.transfer.self.core.constant.HeaderName.LANG_KEY;
import static eub.smart.cardproduct.transfer.self.core.constant.HeaderName.CORRELATION_ID;
import static java.util.Objects.isNull;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.OK;

@ResponseBinding
@RestController
@RequestMapping("/api/transfer")
@Tag(name = "TransferController", description = "API длѝ переводов")
public class TransferController {

    private final ZeebeStarter zeebeStarter;
    private final String transferInternal;
    private final CreateBaseModeUseCase createBaseModeUseCase;
    private final PresentationMapper mapper;
    private final SaveZeebeEventFinDocUseCase saveZeebeEventFinDocUseCase;
    private final InitialValidationUseCase initialValidationUseCase;
    private final InitialValidationUseCase way4ToWay4InitialValidationUseCase;
    private final TransferHistoryUseCase transferHistoryUseCase;
    private final TransferReceiptUseCase transferReceiptUseCase;
    private final RefundIipsTransferUseCase refundIipsTransferUseCase;
    private final FinDocStateRepository finDocStateRepository;
    private final NotificationIpstUseCase notificationIpstUseCase;
    private final CreateTslfTransferUseCase createTslfTransferUseCase;

    public TransferController(ZeebeStarter zeebeStarter,
                              @Value("${app.zeebe.process-id.transfer-internal}") String transferInternal,
                              CreateBaseModeUseCase createBaseModeUseCase,
                              PresentationMapper mapper,
                              SaveZeebeEventFinDocUseCase saveZeebeEventFinDocUseCase,
                              @Qualifier("initialValidationUseCaseImpl") InitialValidationUseCase initialValidationUseCase,
                              @Qualifier("way4ToWay4InitialValidationUseCaseImpl") InitialValidationUseCase way4ToWay4InitialValidationUseCase,
                              TransferHistoryUseCase transferHistoryUseCase,
                              TransferReceiptUseCase transferReceiptUseCase,
                              RefundIipsTransferUseCase refundIipsTransferUseCase,
                              FinDocStateRepository finDocStateRepository,
                              NotificationIpstUseCase notificationIpstUseCase,
                              CreateTslfTransferUseCase createTslfTransferUseCase) {
        this.zeebeStarter = zeebeStarter;
        this.transferInternal = transferInternal;
        this.createBaseModeUseCase = createBaseModeUseCase;
        this.mapper = mapper;
        this.saveZeebeEventFinDocUseCase = saveZeebeEventFinDocUseCase;
        this.initialValidationUseCase = initialValidationUseCase;
        this.way4ToWay4InitialValidationUseCase = way4ToWay4InitialValidationUseCase;
        this.transferHistoryUseCase = transferHistoryUseCase;
        this.transferReceiptUseCase = transferReceiptUseCase;
        this.refundIipsTransferUseCase = refundIipsTransferUseCase;
        this.finDocStateRepository = finDocStateRepository;
        this.notificationIpstUseCase = notificationIpstUseCase;
        this.createTslfTransferUseCase = createTslfTransferUseCase;
    }

    @SecurityRequirement(name = "Bearer Authentication")
    @Operation(description = "Создание перевода TSLF", responses = {
            @ApiResponse(content = {
                    @Content(schema = @Schema(implementation = CreateTransferResponse.class))})})
    @PostMapping
    public ResponseEntity<?> createSelfTransfer(@RequestHeader(CORRELATION_ID) String correlationId,
                                                @RequestHeader(value = LANG_KEY, defaultValue = "RU") LangKey lang,
                                                @Valid @RequestBody CreateTransferRequest request) {
        CreateTransferTslfPIn in = mapper.toDomain(request);
        var finDocId = createTslfTransferUseCase.invoke(in);
        var response = new CreateTransfer();
        response.setId(finDocId);
        var baseModel = createBaseModeUseCase.invoke(finDocId, correlationId);
        if (way4ToWay4(baseModel)) {
            way4ToWay4InitialValidationUseCase.invoke(baseModel, lang);
        } else {
            initialValidationUseCase.invoke(baseModel, lang);
        }
        var finDocStatus = new TransferStatus("VLOK", "Провалидирован", "PROC");
        response.setStatus(finDocStatus);
        return new ResponseEntity<>(response, CREATED);
    }

    @SecurityRequirement(name = "Bearer Authentication")
    @Operation(description = "Создание инѝтанѝа процеѝѝа transfer internal", responses = {
            @ApiResponse(content = {
                    @Content(schema = @Schema(implementation = ExecuteTransferResponse.class))})})
    @PostMapping("/execute/{finDocId}")
    public ResponseEntity<?> execute(@RequestHeader(CORRELATION_ID) String correlationId,
                                     @Parameter(description = "FinDoc id")
                                     @PathVariable("finDocId") Long finDocId) {
        saveZeebeEventFinDocUseCase.invoke(finDocId);
        var baseModel = createBaseModeUseCase.invoke(finDocId, correlationId);
        var jsonBaseModel = JsonUtil.toJson(baseModel)
                .orElseThrow(() -> new SelfException(E_SM_501, ": TransferInternalBaseModel"));
        zeebeStarter.run(jsonBaseModel, transferInternal);
        return new ResponseEntity<>(true, CREATED);
    }

    private boolean way4ToWay4(TransferInternalBaseModel baseModel) {
        return WAY4.equals(baseModel.getSender().getbSystem()) && WAY4.equals(baseModel.getReceiver().getbSystem());
    }

    @SecurityRequirement(name = "Bearer Authentication")
    @Operation(description = "Иѝториѝ переводов", responses = {
            @ApiResponse(content = {
                    @Content(schema = @Schema(implementation = TransferHistoryResponse.class))})})
    @PostMapping("/history")
    public ResponseEntity<?> history(@RequestHeader(CORRELATION_ID) String correlationId,
                                     @RequestHeader(value = LANG_KEY, defaultValue = "RU") LangKey lang,
                                     @Valid @RequestBody(required = false) TransferHistoryRequest request,
                                     @PageableDefault(page = 0, size = 20) Pageable pageable) {
        if (isNull(request)) {
            var from = LocalDate.now().minusDays(7);
            var to = LocalDate.now();
            request = new TransferHistoryRequest(from, to);
        }
        var in = mapper.toDomain(request);
        var historyResponses = transferHistoryUseCase.invoke(in, pageable, lang);
        return new ResponseEntity<>(historyResponses, OK);
    }

    @SecurityRequirement(name = "Bearer Authentication")
    @Operation(description = "Квитанци по переводу", responses = {
            @ApiResponse(content = {
                    @Content(schema = @Schema(implementation = TransferReceiptResponse.class))})})
    @PostMapping("/receipt")
    public ResponseEntity<?> receipt(@RequestHeader(CORRELATION_ID) String correlationId,
                                     @RequestHeader(value = LANG_KEY, defaultValue = "RU") LangKey lang,
                                     @Valid @RequestBody TransferReceiptRequest request) {
        var in = mapper.toDomain(request);
        var receiptResponses = transferReceiptUseCase.invoke(in, lang);
        return new ResponseEntity<>(receiptResponses, OK);
    }

    @SecurityRequirement(name = "Bearer Authentication")
    @Operation(description = "Создание возврата", responses = {
            @ApiResponse(content = {
                    @Content(schema = @Schema(implementation = CreateTransferResponse.class))})})
    @PostMapping("/refund/{finDocId}")
    public ResponseEntity<?> createRefund(@RequestHeader(CORRELATION_ID) String correlationId,
                                          @RequestHeader(value = LANG_KEY, defaultValue = "RU") LangKey lang,
                                          @PathVariable("finDocId") Long finDocId) {
        var refundFinDocId = refundIipsTransferUseCase.invoke(finDocId, lang);
        var response = new CreateTransfer();
        response.setId(refundFinDocId);
        var finDocStatus = new TransferStatus("DRFT", "Черновик", "DRFT");
        response.setStatus(finDocStatus);
        return new ResponseEntity<>(response, CREATED);
    }

    @SecurityRequirement(name = "Bearer Authentication")
    @Operation(description = "Обновить статус на neww")
    @PostMapping("/status/neww/{finDocId}")
    public ResponseEntity<?> updateStatusToNeww(@RequestHeader(CORRELATION_ID) String correlationId,
                                                @PathVariable("finDocId") Long finDocId) {
        finDocStateRepository.saveFinDocStatus(NEWW, finDocId);
        return new ResponseEntity<>(true, OK);
    }

    @SecurityRequirement(name = "Bearer Authentication")
    @Operation(description = "Уведомления по возврату средств", responses = {
            @ApiResponse(content = {
                    @Content(schema = @Schema(implementation = TransferHistoryResponse.class))})})
    @GetMapping("/notification/ipst")
    public ResponseEntity<?> notificationIpst(@RequestHeader(CORRELATION_ID) String correlationId,
                                              @RequestHeader(value = LANG_KEY, defaultValue = "EN") LangKey lang) {
        var notificationOuts = notificationIpstUseCase.invoke(lang);
        return new ResponseEntity<>(notificationOuts, OK);
    }
}
