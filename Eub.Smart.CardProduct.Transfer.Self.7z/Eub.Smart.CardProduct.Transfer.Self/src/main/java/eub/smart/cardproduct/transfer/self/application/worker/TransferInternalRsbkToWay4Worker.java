package eub.smart.cardproduct.transfer.self.application.worker;

import eub.smart.cardproduct.transfer.self.application.handler.JobWorkerException;
import eub.smart.cardproduct.transfer.self.application.handler.JobWorkerFailFast;
import eub.smart.cardproduct.transfer.self.application.mapper.ApplicationMapper;
import eub.smart.cardproduct.transfer.self.application.model.TransferInternalRsbkToWay4BaseModel;
import eub.smart.cardproduct.transfer.self.domain.use_case.*;
import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.client.annotation.VariablesAsType;
import org.springframework.stereotype.Component;

import static eub.smart.cardproduct.transfer.self.core.util.ZeebeConfigUtil.WORKER_ENABLE;

@Component
public class TransferInternalRsbkToWay4Worker {

    private final TransferRsbkToWay4UseCase transferRsbkToWay4UseCase;
    private final TransferRsbkToWay4DebitTransitUseCase transferRsbkToWay4DebitTransitUseCase;
    private final TransferRsbkToWay4CreditUseCase transferRsbkToWay4CreditUseCase;
    private final TransferRsbkToWay4ReverseTransitUseCase transferRsbkToWay4ReverseTransitUseCase;
    private final ReverseRsbkDocumentUseCase reverseRsbkDocumentUseCase;
    private final TransferTcWay4UseCase transferTcWay4UseCase;
    private final GenerateRrnBrrnUseCase generateRrnBrrnUseCase;
    private final GetPostingDateUseCase getPostingDateUseCase;
    private final SetWay4TransactionDateUseCase setWay4TransactionDateUseCase;
    private final ApplicationMapper applicationMapper;
    private final RsbkToWay4SaveResultUseCase rsbkToWay4SaveResultUseCase;

    public TransferInternalRsbkToWay4Worker(TransferRsbkToWay4UseCase transferRsbkToWay4UseCase,
                                            TransferRsbkToWay4DebitTransitUseCase transferRsbkToWay4DebitTransitUseCase,
                                            TransferRsbkToWay4CreditUseCase transferRsbkToWay4CreditUseCase,
                                            TransferRsbkToWay4ReverseTransitUseCase transferRsbkToWay4ReverseTransitUseCase,
                                            ReverseRsbkDocumentUseCase reverseRsbkDocumentUseCase,
                                            TransferTcWay4UseCase transferTcWay4UseCase,
                                            GenerateRrnBrrnUseCase generateRrnBrrnUseCase,
                                            GetPostingDateUseCase getPostingDateUseCase,
                                            SetWay4TransactionDateUseCase setWay4TransactionDateUseCase,
                                            ApplicationMapper applicationMapper,
                                            RsbkToWay4SaveResultUseCase rsbkToWay4SaveResultUseCase) {
        this.transferRsbkToWay4UseCase = transferRsbkToWay4UseCase;
        this.transferRsbkToWay4DebitTransitUseCase = transferRsbkToWay4DebitTransitUseCase;
        this.transferRsbkToWay4CreditUseCase = transferRsbkToWay4CreditUseCase;
        this.transferRsbkToWay4ReverseTransitUseCase = transferRsbkToWay4ReverseTransitUseCase;
        this.reverseRsbkDocumentUseCase = reverseRsbkDocumentUseCase;
        this.transferTcWay4UseCase = transferTcWay4UseCase;
        this.generateRrnBrrnUseCase = generateRrnBrrnUseCase;
        this.getPostingDateUseCase = getPostingDateUseCase;
        this.setWay4TransactionDateUseCase = setWay4TransactionDateUseCase;
        this.applicationMapper = applicationMapper;
        this.rsbkToWay4SaveResultUseCase = rsbkToWay4SaveResultUseCase;
    }

    @JobWorkerException(errorCode = "Reject")
    @JobWorkerFailFast("${app.fail.rsbk-to-way4.transfer-rsbk-to-way4}")
    @JobWorker(type = "transfer_self_rsbk_to_way4", enabled = WORKER_ENABLE)
    public TransferInternalRsbkToWay4BaseModel transferRsbkToWay4(@VariablesAsType TransferInternalRsbkToWay4BaseModel baseModel,
                                                                  JobClient client,
                                                                  ActivatedJob job) {
        var finDocData = applicationMapper.toDomain(baseModel.getFinDoc());
        var senderData = applicationMapper.toDomain(baseModel.getSender());
        var receiverData = applicationMapper.toDomain(baseModel.getReceiver());

        var response = transferRsbkToWay4UseCase.invoke(finDocData, senderData, receiverData);
        baseModel.setTransferRsbkToWay4(response);
        return baseModel;
    }

    @JobWorkerException(errorCode = "ReverseRsbkDoc")
    @JobWorkerFailFast("${app.fail.rsbk-to-way4.transfer-rsbk-to-way4-debit-transit}")
    @JobWorker(type = "transfer_self_rsbk_to_way4_debit_transit", enabled = WORKER_ENABLE)
    public TransferInternalRsbkToWay4BaseModel transferRsbkToWay4DebitTransit(@VariablesAsType TransferInternalRsbkToWay4BaseModel baseModel,
                                                                              JobClient client,
                                                                              ActivatedJob job) {
        var finDocData = applicationMapper.toDomain(baseModel.getFinDoc());
        var receiverData = applicationMapper.toDomain(baseModel.getReceiver());
        var rrnBrrn = applicationMapper.toDomain(baseModel.getRrnBrrn());

        var response = transferRsbkToWay4DebitTransitUseCase.invoke(finDocData, receiverData, rrnBrrn);
        baseModel.setDebitTransit(response);
        return baseModel;
    }

    @JobWorkerException(errorCode = "ReverseWay4DebitTransit")
    @JobWorkerFailFast("${app.fail.rsbk-to-way4.transfer-rsbk-to-way4-credit}")
    @JobWorker(type = "transfer_self_rsbk_to_way4_credit", enabled = WORKER_ENABLE)
    public TransferInternalRsbkToWay4BaseModel transferRsbkToWay4Credit(@VariablesAsType TransferInternalRsbkToWay4BaseModel baseModel,
                                                                        JobClient client,
                                                                        ActivatedJob job) {
        var finDocData = applicationMapper.toDomain(baseModel.getFinDoc());
        var senderData = applicationMapper.toDomain(baseModel.getSender());
        var receiverData = applicationMapper.toDomain(baseModel.getReceiver());
        var rrnBrrn = applicationMapper.toDomain(baseModel.getRrnBrrn());

        var response = transferRsbkToWay4CreditUseCase.invoke(finDocData, senderData, receiverData, rrnBrrn);
        baseModel.setCredit(response);
        return baseModel;
    }

    @JobWorker(type = "transfer_self_rsbk_to_way4_reverse_transit", enabled = WORKER_ENABLE)
    public TransferInternalRsbkToWay4BaseModel transferRsbkToWay4ReverseTransit(@VariablesAsType TransferInternalRsbkToWay4BaseModel baseModel) {
        var ufxTransferRequest = baseModel.getDebitTransit().getUfxTransferRequest();

        var response = transferRsbkToWay4ReverseTransitUseCase.invoke(ufxTransferRequest);
        baseModel.setReverseTransit(response);
        return baseModel;
    }

    @JobWorker(type = "transfer_self_rsbk_to_way4_reverse_tc", enabled = WORKER_ENABLE)
    public TransferInternalRsbkToWay4BaseModel tryReverseDoc(@VariablesAsType TransferInternalRsbkToWay4BaseModel baseModel) {
        var transferResponse = baseModel.getTransferRsbkToWay4().getTransferRsbkToWay4Response();
        var correlationId = baseModel.getFinDoc().getCorrelationId();

        var response = reverseRsbkDocumentUseCase.invoke(transferResponse, correlationId);
        baseModel.setReverseDoc(response);
        return baseModel;
    }

    @JobWorkerException(errorCode = "ReverseRsbkDoc", retries = 6)
    @JobWorkerFailFast("${app.fail.rsbk-to-way4.rsbk-to-way4-transfer-tc-way4}")
    @JobWorker(type = "transfer_self_rsbk_to_way4_tc", enabled = WORKER_ENABLE)
    public TransferInternalRsbkToWay4BaseModel transferTcWay4(@VariablesAsType TransferInternalRsbkToWay4BaseModel baseModel,
                                                              JobClient jobClient,
                                                              ActivatedJob job) {
        var transferResponse = baseModel.getTransferRsbkToWay4().getTransferRsbkToWay4Response();
        var correlationId = baseModel.getFinDoc().getCorrelationId();

        var response = transferTcWay4UseCase.invoke(transferResponse, correlationId);
        baseModel.setTransferTcWay4(response);
        return baseModel;
    }

    @JobWorker(type = "transfer_self_rsbk_to_way4_generate_rrn", enabled = WORKER_ENABLE)
    public TransferInternalRsbkToWay4BaseModel generateRrn(@VariablesAsType TransferInternalRsbkToWay4BaseModel baseModel) {
        var response = generateRrnBrrnUseCase.invoke();
        var rrnBrrn = applicationMapper.toApplication(response);
        baseModel.setRrnBrrn(rrnBrrn);
        return baseModel;
    }

    @JobWorkerException(retries = 20)
    @JobWorker(type = "transfer_self_rsbk_to_way4_get_posting_date", enabled = WORKER_ENABLE)
    public TransferInternalRsbkToWay4BaseModel getPostingDateOldGen(@VariablesAsType TransferInternalRsbkToWay4BaseModel baseModel,
                                                                    JobClient jobClient,
                                                                    ActivatedJob job) {
        var rrnBrrn = applicationMapper.toDomain(baseModel.getRrnBrrn());
        var response = getPostingDateUseCase.invoke(
                rrnBrrn,
                baseModel.getFinDoc().getCorrelationId());
        baseModel.setPostingDate(response);
        return baseModel;
    }

    @JobWorkerException(retries = 20)
    @JobWorker(type = "transfer_self_rsbk_to_way4_get_transaction_date", enabled = WORKER_ENABLE)
    public TransferInternalRsbkToWay4BaseModel getPostingDateNewGen(@VariablesAsType TransferInternalRsbkToWay4BaseModel baseModel,
                                                                    JobClient jobClient,
                                                                    ActivatedJob job) {
        var rrnBrrn = applicationMapper.toDomain(baseModel.getRrnBrrn());
        var response = getPostingDateUseCase.invoke(
                rrnBrrn,
                baseModel.getFinDoc().getCorrelationId());
        baseModel.setPostingDate(response);
        return baseModel;
    }

    @JobWorker(type = "transfer_self_rsbk_to_way4_set_transaction_date", enabled = WORKER_ENABLE)
    public TransferInternalRsbkToWay4BaseModel setWay4TransactionDate(@VariablesAsType TransferInternalRsbkToWay4BaseModel baseModel) {
        var postingDateResponse = baseModel.getPostingDate().getResponse();
        var transferResponse = baseModel.getTransferRsbkToWay4().getTransferRsbkToWay4Response();
        var correlationId = baseModel.getFinDoc().getCorrelationId();

        var response = setWay4TransactionDateUseCase.invoke(
                postingDateResponse,
                transferResponse,
                correlationId);
        baseModel.setWay4TransactionDate(response);
        return baseModel;
    }

    @JobWorker(type = "transfer_self_rsbk_to_way4_save_zeebe_findoc", enabled = WORKER_ENABLE)
    public TransferInternalRsbkToWay4BaseModel saveZeebeFindoc(@VariablesAsType TransferInternalRsbkToWay4BaseModel baseModel) {
        var finDocId = baseModel.getFinDocId();
        var transferRsbkToWay4 = baseModel.getTransferRsbkToWay4();
        var rrnBrrn = applicationMapper.toDomain(baseModel.getRrnBrrn());
        rsbkToWay4SaveResultUseCase.invoke(finDocId, rrnBrrn, transferRsbkToWay4);
        return baseModel;
    }
}
