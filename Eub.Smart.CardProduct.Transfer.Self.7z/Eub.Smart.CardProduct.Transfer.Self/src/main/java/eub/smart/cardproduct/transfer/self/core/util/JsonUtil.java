package eub.smart.cardproduct.transfer.self.core.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Optional;

public class JsonUtil {

    private static final Logger log = LogManager.getLogger(JsonUtil.class);
    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static <T> Optional<T> toObject(String json, Class<T> clazz) {
        try {
            T result = objectMapper.readValue(json, clazz);
            return Optional.of(result);
        } catch (Exception e) {
            log.error("Json read value error: {}", e.getMessage());
            return Optional.empty();
        }
    }

    public static Optional<String> toJson(Object object) {
        try {
            String result = objectMapper.writeValueAsString(object);
            return Optional.of(result);
        } catch (Exception e) {
            log.error("Json write value error: {}", e.getMessage());
            return Optional.empty();
        }
    }
}