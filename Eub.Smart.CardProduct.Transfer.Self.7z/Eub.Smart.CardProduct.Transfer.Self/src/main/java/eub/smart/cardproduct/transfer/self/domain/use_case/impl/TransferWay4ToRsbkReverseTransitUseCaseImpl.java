package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4ToRsbk;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.UfxResponse;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.UfxTransferRequest;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferSelfProtoRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.TransferWay4ToRsbkReverseTransitUseCase;

public class TransferWay4ToRsbkReverseTransitUseCaseImpl implements TransferWay4ToRsbkReverseTransitUseCase {

    private final TransferSelfProtoRepository transferSelfProtoRepository;

    public TransferWay4ToRsbkReverseTransitUseCaseImpl(TransferSelfProtoRepository transferSelfProtoRepository) {
        this.transferSelfProtoRepository = transferSelfProtoRepository;
    }

    @Override
    public TransferWay4ToRsbk invoke(UfxTransferRequest request) {
        request.setBrrn("");
        var response = transferSelfProtoRepository.transferWay4ToRsbkReverseTransit(request);
        return new TransferWay4ToRsbk(request, response);
    }
}
