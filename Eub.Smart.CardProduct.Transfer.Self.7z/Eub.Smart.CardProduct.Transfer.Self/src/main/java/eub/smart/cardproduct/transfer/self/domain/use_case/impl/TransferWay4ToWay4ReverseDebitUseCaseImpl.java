package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4ToWay4;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.UfxResponse;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.UfxTransferRequest;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferSelfProtoRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.TransferWay4ToWay4ReverseDebitUseCase;

public class TransferWay4ToWay4ReverseDebitUseCaseImpl implements TransferWay4ToWay4ReverseDebitUseCase {

    private final TransferSelfProtoRepository transferSelfProtoRepository;

    public TransferWay4ToWay4ReverseDebitUseCaseImpl(TransferSelfProtoRepository transferSelfProtoRepository) {
        this.transferSelfProtoRepository = transferSelfProtoRepository;
    }

    @Override
    public TransferWay4ToWay4 invoke(UfxTransferRequest request) {
        request.setBrrn("");
        var response = transferSelfProtoRepository.transferWay4ToWay4ReverseDebit(request);
        return new TransferWay4ToWay4(request, response);
    }
}
