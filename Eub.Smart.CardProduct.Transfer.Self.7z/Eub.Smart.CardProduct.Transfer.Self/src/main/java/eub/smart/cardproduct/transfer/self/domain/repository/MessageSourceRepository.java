package eub.smart.cardproduct.transfer.self.domain.repository;

import java.util.Locale;

public interface MessageSourceRepository {

    String getMessage(String bundleCode, Object[] args, Locale locale);

    String getMessage(String bundleCode, Locale locale);
}
