package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.domain.model.out.infrastructure.ValidateAccountAmountOut;

public interface ValidateAccountAmountUseCase {

    void invoke(ValidateAccountAmountOut accountData, String correlationId, LangKey lang);
}
