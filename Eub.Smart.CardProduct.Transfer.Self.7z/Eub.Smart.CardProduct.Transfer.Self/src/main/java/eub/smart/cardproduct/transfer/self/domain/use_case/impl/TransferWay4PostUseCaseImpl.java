package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.*;
import eub.smart.cardproduct.transfer.self.domain.repository.Way4TransactionalProtoRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.TransferWay4PostUseCase;

public class TransferWay4PostUseCaseImpl implements TransferWay4PostUseCase {

    private final Way4TransactionalProtoRepository way4TransactionalProtoRepository;

    public TransferWay4PostUseCaseImpl(Way4TransactionalProtoRepository way4TransactionalProtoRepository) {
        this.way4TransactionalProtoRepository = way4TransactionalProtoRepository;
    }

    @Override
    public TransferWay4Post invoke(RrnBrrn rrnBrrn, String correlationId) {
        var request = new TransferWay4PostRequest(rrnBrrn.getRrn());
        var response = way4TransactionalProtoRepository.transferWay4Post(request, correlationId);
        return new TransferWay4Post(request, response);
    }
}
