package eub.smart.cardproduct.transfer.self.presentation.model.request;

import io.swagger.v3.oas.annotations.media.Schema;

import javax.validation.constraints.*;
import java.math.BigDecimal;

public class FeeRequest {

    @NotNull
    @DecimalMin(value = "0.0", inclusive = false)
    @Schema(description = "Сумма")
    private BigDecimal amount;
    @NotBlank
    @Schema(description = "Номер аккаунта")
    private String accountNumber;
    @NotBlank
    @Schema(description = "Валюта отправителя")
    private String sourceCurrency;
    @NotBlank
    @Schema(description = "Валюта получателя")
    private String targetCurrency;

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getSourceCurrency() {
        return sourceCurrency;
    }

    public void setSourceCurrency(String sourceCurrency) {
        this.sourceCurrency = sourceCurrency;
    }

    public String getTargetCurrency() {
        return targetCurrency;
    }

    public void setTargetCurrency(String targetCurrency) {
        this.targetCurrency = targetCurrency;
    }

    @Override
    public String toString() {
        return "FeeRequest{" +
                "amount=" + amount +
                ", accountNumber=" + accountNumber +
                ", sourceCurrency=" + sourceCurrency +
                ", targetCurrency=" + targetCurrency +
                '}';
    }
}
