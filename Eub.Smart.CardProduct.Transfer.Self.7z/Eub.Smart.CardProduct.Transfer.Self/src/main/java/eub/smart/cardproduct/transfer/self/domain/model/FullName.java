package eub.smart.cardproduct.transfer.self.domain.model;

import static java.util.Objects.isNull;

public class FullName {

    private String lastname;
    private String firstname;
    private String middlename;

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getMiddlename() {
        if (isNull(middlename)) middlename = "";
        return middlename;
    }

    public void setMiddlename(String middlename) {
        this.middlename = middlename;
    }

    @Override
    public String toString() {
        return "FullName{" +
                "lastname=" + lastname +
                ", firstname=" + firstname +
                ", middlename=" + middlename +
                '}';
    }
}
