package eub.smart.cardproduct.transfer.self.core.constant;

public interface HeaderName {

    String CORRELATION_ID = "X-Correlation-Id";
    String LANG_KEY = "Lang-Key";
    String FRONT_END_ID = "Front-End-Id";
}
