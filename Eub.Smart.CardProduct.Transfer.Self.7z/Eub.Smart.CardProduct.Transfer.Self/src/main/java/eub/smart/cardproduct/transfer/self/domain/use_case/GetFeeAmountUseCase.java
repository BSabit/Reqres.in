package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.Fee;

import java.math.BigDecimal;

public interface GetFeeAmountUseCase {

    BigDecimal invoke(BigDecimal amount, Fee fee);
}
