package eub.smart.cardproduct.transfer.self.presentation.model.response;

import io.swagger.v3.oas.annotations.media.Schema;

public record MetaDocumentResponse(
        @Schema(description = "UID документа")
        String UID,
        @Schema(description = "Расширение документа")
        String contentType
) {
}
