package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.repository.ZeebeEventFinDocRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.Way4ToWay4SaveResultUseCase;

import static java.util.Objects.isNull;

public class Way4ToWay4SaveResultUseCaseImpl extends ZeebeEventFinDocSaveResult implements Way4ToWay4SaveResultUseCase {

    public Way4ToWay4SaveResultUseCaseImpl(ZeebeEventFinDocRepository zeebeEventFinDocRepository) {
        super(zeebeEventFinDocRepository);
    }

    @Override
    public void invoke(Long finDocId, RrnBrrn rrnBrrn) {
        if (isNull(rrnBrrn)) {
            saveResult(finDocId);
        } else {
            saveResult(finDocId, rrnBrrn);
        }
    }
}
