package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.domain.model.out.presentation.NotificationIOut;

import java.util.List;

public interface NotificationIpstUseCase {
    List<NotificationIOut> invoke(LangKey lang);
}
