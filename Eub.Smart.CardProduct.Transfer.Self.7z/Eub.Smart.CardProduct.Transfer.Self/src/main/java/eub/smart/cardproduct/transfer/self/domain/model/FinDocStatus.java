package eub.smart.cardproduct.transfer.self.domain.model;


public class FinDocStatus {

    private String code;
    private String title;
    private Long termId;
    private boolean flagFinal;

    public FinDocStatus() {
    }

    public FinDocStatus(String code, String title, Long termId, boolean flagFinal) {
        this.code = code;
        this.title = title;
        this.termId = termId;
        this.flagFinal = flagFinal;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Long getTermId() {
        return termId;
    }

    public void setTermId(Long termId) {
        this.termId = termId;
    }

    public boolean getFlagFinal() {
        return flagFinal;
    }

    public void setFlagFinal(boolean aFlagFinal) {
        flagFinal = aFlagFinal;
    }

    @Override
    public String toString() {
        return "FinDocStatus{" +
                "code=" + code +
                ", title=" + title +
                ", termId=" + termId +
                ", flagFinal=" + flagFinal +
                '}';
    }
}
