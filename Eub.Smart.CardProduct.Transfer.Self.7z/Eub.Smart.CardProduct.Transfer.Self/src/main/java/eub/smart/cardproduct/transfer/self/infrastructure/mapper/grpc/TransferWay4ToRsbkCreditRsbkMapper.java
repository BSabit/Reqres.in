package eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc;

import custom_types.CustomTypes;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4ToRsbkRequest;
import rsbktransactional.V1.EubAdapterRsbkTransactional;

import static eub.smart.cardproduct.transfer.self.core.util.GrpcUtil.toTimestamp;
import static eub.smart.cardproduct.transfer.self.core.util.GrpcUtil.toDecimalValue;

public class TransferWay4ToRsbkCreditRsbkMapper {

    public static EubAdapterRsbkTransactional.TransferWay4ToRsbkRequest toGrpcModel(TransferWay4ToRsbkRequest requestModel) {
        return EubAdapterRsbkTransactional.TransferWay4ToRsbkRequest
                .newBuilder()
                .setPayerAccount(requestModel.getPayerAccount())
                .setReceiverAccount(requestModel.getReceiverAccount())
                .setOperSum(toDecimalValue(requestModel.getOperSum()))
                .setKnp(requestModel.getKnp())
                .setViCardIso(requestModel.getViCardIso())
                .setIsSelf(requestModel.getIsSelf())
                .setViCardHolderName(requestModel.getViCardHolderName())
                .setViCardHolderName1(requestModel.getViCardHolderName1())
                .setViCardHolderName2(requestModel.getViCardHolderName2())
                .setViCardHolderName3(requestModel.getViCardHolderName3())
                .setViIin(requestModel.getViIin())
                .setViNotRez(requestModel.getViNotRez())
                .setViCalcSumm(toDecimalValue(requestModel.getViCalcSumm()))
                .setGround(requestModel.getGround())
                .setDboId(requestModel.getDboId())
                .setDateSign(toTimestamp(requestModel.getDateSign()))
                .setIsSpecRate(requestModel.getIsSpecRate())
                .setRate(CustomTypes.DecimalValue.newBuilder().setUnits(0).setNanos(0).build())
                .setCoverRate(CustomTypes.DecimalValue.newBuilder().setUnits(0).setNanos(0).build())
                .setDboIdPrefix(requestModel.getDboIdPrefix())
                .setProcVersion(requestModel.getProcVersion())
                .build();
    }
}
