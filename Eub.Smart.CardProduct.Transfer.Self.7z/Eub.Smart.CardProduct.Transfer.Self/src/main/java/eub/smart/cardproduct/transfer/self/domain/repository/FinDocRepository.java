package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.FinDoc;
import eub.smart.cardproduct.transfer.self.domain.model.FinDocInfo;

import java.util.Optional;

public interface FinDocRepository {

    FinDoc save(FinDoc finDoc);

    Optional<FinDocInfo> findFinDocAcc(Long finDocId, String senderIin, String correlationId);

    FinDocInfo findFinDocAccOrException(Long finDocId, String senderIin, String correlationId);

    Optional<FinDoc> findById(Long finDocId);

    FinDoc findByIdOrException(Long finDocId);

    Optional<Long> finDocIdByStatusAndParentFinDoc(String status, Long finDocId);
}
