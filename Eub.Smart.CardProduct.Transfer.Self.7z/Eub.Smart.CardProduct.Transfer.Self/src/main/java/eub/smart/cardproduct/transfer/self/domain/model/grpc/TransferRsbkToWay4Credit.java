package eub.smart.cardproduct.transfer.self.domain.model.grpc;

public class TransferRsbkToWay4Credit {

    private UfxTransferRequest ufxTransferRequest;
    private UfxResponse ufxResponse;

    public TransferRsbkToWay4Credit() {
    }

    public TransferRsbkToWay4Credit(UfxTransferRequest ufxTransferRequest,
                                    UfxResponse ufxResponse) {
        this.ufxTransferRequest = ufxTransferRequest;
        this.ufxResponse = ufxResponse;
    }

    public UfxTransferRequest getUfxTransferRequest() {
        return ufxTransferRequest;
    }

    public UfxResponse getUfxResponse() {
        return ufxResponse;
    }

    public void setUfxTransferRequest(UfxTransferRequest ufxTransferRequest) {
        this.ufxTransferRequest = ufxTransferRequest;
    }

    public void setUfxResponse(UfxResponse ufxResponse) {
        this.ufxResponse = ufxResponse;
    }
}
