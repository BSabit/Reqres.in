package eub.smart.cardproduct.transfer.self.application.model;

import java.math.BigDecimal;

public class AccountData {

    private String iin;
    private String bSystem;
    private String accountNumber;
    private BigDecimal amount;
    private String currency;
    private Boolean flagResident;
    private String fullName;
    private String accountType;
    private Boolean flagMulti;
    private String accountStatus;
    private Long accountIdRef;
    private Long accountOutRef;

    public AccountData() {
    }

    public String getIin() {
        return iin;
    }

    public void setIin(String iin) {
        this.iin = iin;
    }

    public String getbSystem() {
        return bSystem;
    }

    public void setbSystem(String bSystem) {
        this.bSystem = bSystem;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public Boolean getFlagMulti() {
        return flagMulti;
    }

    public void setFlagMulti(Boolean flagMulti) {
        this.flagMulti = flagMulti;
    }

    public Boolean getFlagResident() {
        return flagResident;
    }

    public void setFlagResident(Boolean flagResident) {
        this.flagResident = flagResident;
    }

    public String getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }

    public Long getAccountIdRef() {
        return accountIdRef;
    }

    public void setAccountIdRef(Long accountIdRef) {
        this.accountIdRef = accountIdRef;
    }

    public Long getAccountOutRef() {
        return accountOutRef;
    }

    public void setAccountOutRef(Long accountOutRef) {
        this.accountOutRef = accountOutRef;
    }

    @Override
    public String toString() {
        return "AccountData{" +
                "iin=" + iin +
                ", bSystem=" + bSystem +
                ", accountNumber=" + accountNumber +
                ", amount=" + amount +
                ", currency=" + currency +
                ", flagResident=" + flagResident +
                ", fullName=" + fullName +
                ", accountType=" + accountType +
                ", flagMulti=" + flagMulti +
                ", accountStatus=" + accountStatus +
                ", accountIdRef=" + accountIdRef +
                ", accountOutRef=" + accountOutRef +
                '}';
    }
}
