package eub.smart.cardproduct.transfer.self.core.constant;

public interface SelfMultiType {

    String NON_SELF = "NON_SELF";
    String OLD_MULTI = "OLD_MULTI";
    String NEW_MULTI = "NEW_MULTI";
}
