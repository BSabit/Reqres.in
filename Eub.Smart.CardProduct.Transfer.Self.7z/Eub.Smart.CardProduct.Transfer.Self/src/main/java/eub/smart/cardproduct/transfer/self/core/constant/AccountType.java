package eub.smart.cardproduct.transfer.self.core.constant;

public interface AccountType {

    String SAVE = "SAVE";
    String SAVS = "SAVS";
    String SAVL = "SAVL";

    static boolean isDeposit(String accountType) {
        return SAVE.equals(accountType);
    }
}
