package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.repository.LimitAccountDayRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.LimitAccountDayUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.LimitFinDocUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.LimitUseCase;

import java.math.BigDecimal;
import java.time.LocalDate;

import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isEmpty;

public class LimitAccountDayUseCaseImpl implements LimitAccountDayUseCase {

    private final LimitAccountDayRepository limitAccountNightRepository;
    private final LimitFinDocUseCase finDocUseCase;
    private final LimitUseCase limitUseCase;

    public LimitAccountDayUseCaseImpl(LimitAccountDayRepository limitAccountNightRepository,
                                      LimitFinDocUseCase finDocUseCase,
                                      LimitUseCase limitUseCase) {
        this.limitAccountNightRepository = limitAccountNightRepository;
        this.finDocUseCase = finDocUseCase;
        this.limitUseCase = limitUseCase;
    }

    @Override
    public void invoke(BigDecimal limitDay, String accountNumber, String correlationId, BigDecimal amount, String currency) {
        var currentDate = LocalDate.now();
        var spentAmountGroupByCurrency = limitAccountNightRepository.findByAccountNumber(currentDate, accountNumber);
        if (isEmpty(spentAmountGroupByCurrency)) finDocUseCase.invoke(limitDay, amount, currency, correlationId);
        limitUseCase.invoke(limitDay, correlationId, amount, currency, false, spentAmountGroupByCurrency);
    }
}
