package eub.smart.cardproduct.transfer.self.presentation.model.request;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.CurrencyRate;
import io.swagger.v3.oas.annotations.media.Schema;

import javax.validation.constraints.*;
import java.math.BigDecimal;
import java.util.List;

public class CreateTransferRequest {

    @NotBlank
    @Schema(description = "Номер аккаунта отправителя")
    private String senderAccountNumber;
    @NotBlank
    @Schema(description = "Номер аккаунта получателя")
    private String receiverAccountNumber;
    @NotNull
    @DecimalMin(value = "0.0", inclusive = false)
    @Schema(description = "Сумма отправителя")
    private BigDecimal senderAmount;
    @NotNull
    @DecimalMin(value = "0.0", inclusive = false)
    @Schema(description = "Сумма получателя")
    private BigDecimal receiverAmount;
    @NotBlank
    @Schema(description = "Валюта отправителя")
    private String senderCurrency;
    @NotBlank
    @Schema(description = "Валюта получателя")
    private String receiverCurrency;
    @Schema(description = "Курсы валют")
    private List<CurrencyRate> currencyRates;

    public String getSenderAccountNumber() {
        return senderAccountNumber;
    }

    public void setSenderAccountNumber(String senderAccountNumber) {
        this.senderAccountNumber = senderAccountNumber;
    }

    public String getReceiverAccountNumber() {
        return receiverAccountNumber;
    }

    public void setReceiverAccountNumber(String receiverAccountNumber) {
        this.receiverAccountNumber = receiverAccountNumber;
    }

    public BigDecimal getSenderAmount() {
        return senderAmount;
    }

    public void setSenderAmount(BigDecimal senderAmount) {
        this.senderAmount = senderAmount;
    }

    public BigDecimal getReceiverAmount() {
        return receiverAmount;
    }

    public void setReceiverAmount(BigDecimal receiverAmount) {
        this.receiverAmount = receiverAmount;
    }

    public List<CurrencyRate> getCurrencyRates() {
        return currencyRates;
    }

    public void setCurrencyRates(List<CurrencyRate> currencyRates) {
        this.currencyRates = currencyRates;
    }

    public String getSenderCurrency() {
        return senderCurrency;
    }

    public void setSenderCurrency(String senderCurrency) {
        this.senderCurrency = senderCurrency;
    }

    public String getReceiverCurrency() {
        return receiverCurrency;
    }

    public void setReceiverCurrency(String receiverCurrency) {
        this.receiverCurrency = receiverCurrency;
    }

    @Override
    public String toString() {
        return "CreateTransferRequest{" +
                "senderAccountNumber=" + senderAccountNumber +
                ", receiverAccountNumber=" + receiverAccountNumber +
                ", senderAmount=" + senderAmount +
                ", receiverAmount=" + receiverAmount +
                ", senderCurrency=" + senderCurrency +
                ", receiverCurrency=" + receiverCurrency +
                ", currencyRates=" + currencyRates +
                '}';
    }
}

