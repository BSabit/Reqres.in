package eub.smart.cardproduct.transfer.self.presentation.model.response;

import io.swagger.v3.oas.annotations.media.Schema;

import java.math.BigDecimal;

public class FeeResponse {

    @Schema(description = "Сумма комиссии")
    private BigDecimal amount;
    @Schema(description = "Тип валюты")
    private String currency;

    public FeeResponse() {
    }

    public FeeResponse(BigDecimal amount, String currency) {
        this.amount = amount;
        this.currency = currency;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @Override
    public String toString() {
        return "FeeResponse{" +
                "amount=" + amount +
                ", currency=" + currency +
                "}";
    }
}
