package eub.smart.cardproduct.transfer.self.infrastructure.handler;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.*;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.response_interface.ErrorMessage;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_EX_700;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_LG_802;
import static eub.smart.cardproduct.transfer.self.core.util.StringUtil.isNotEmpty;
import static java.util.Objects.isNull;

@Aspect
@Component
public class GrpcAspectHandler {

    @AfterReturning(value = "@annotation(eub.smart.cardproduct.transfer.self.infrastructure.handler.GrpcReturnValueHandler)", returning = "returnValue")
    public void returnValueValidation(JoinPoint joinPoint, Object returnValue) {

        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        GrpcReturnValueHandler handler = method.getAnnotation(GrpcReturnValueHandler.class);
        String methodName = handler.methodName();

        if (returnValue instanceof TransferTcResponse response) {
            validateTransferTcResponse(response, methodName);
        } else if (returnValue instanceof ErrorMessage response) {
            validateResponseErrorMessage(response, methodName);
        } else if (returnValue instanceof TryReverseDocReply response) {
            validateTryReverseDocReply(response, methodName);
        } else if (returnValue instanceof PostingDateResponse response) {
            validatePostingDateResponse(response, methodName);
        } else if (returnValue instanceof RsbkResponse response) {
            validateRsbkResponse(response, methodName);
        } else if (returnValue instanceof UfxResponse response) {
            validateUfxResponse(response, methodName);
        } else {
            throw new SelfException(E_LG_802, " returnValueValidation");
        }
    }

    private void validateUfxResponse(UfxResponse response, String methodName) {
        if (!response.getStatus()) {
            throw new SelfException(E_EX_700, ": " + methodName + " " + response.getErrorMessage());
        }
    }

    private void validateRsbkResponse(RsbkResponse response, String methodName) {
        if (isNull(response.getErrorCode()) || response.getErrorCode() != 0)
            throw new SelfException(E_EX_700, ": " + methodName + " " + response.getErrorCode());
    }

    private void validatePostingDateResponse(PostingDateResponse response, String methodName) {
        if (isNull(response.getPostingDate())) {
            throw new SelfException(E_EX_700, ": " + methodName);
        }
    }

    private void validateTryReverseDocReply(TryReverseDocReply response, String methodName) {
        if (!response.getSuccess())
            throw new SelfException(E_EX_700, ": " + methodName + " " + response.getErrorDesc());
    }

    private void validateResponseErrorMessage(ErrorMessage response, String methodName) {
        if (isNotEmpty(response.getErrorMessage()))
            throw new SelfException(E_EX_700, ": " + methodName + " " + response.getErrorMessage());
    }

    private void validateTransferTcResponse(TransferTcResponse response, String methodName) {
        if (isInvalidResponse(response))
            throw new SelfException(E_EX_700, ": " + methodName + " " + response.getMessage());
    }

    private boolean isInvalidResponse(TransferTcResponse response) {
        return isNull(response.getStatus()) || response.getStatus() != 1;
    }

}
