package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.repository.BankRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.CommonMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isOneResult;

@Repository
public class BankRepositoryImpl implements BankRepository {

    private final NamedParameterJdbcTemplate template;

    public BankRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<Long> findTargetIdByBic(String bic) {
        String sql = """ 
                select B.Bank_ID as id
                from Bank B
                where B.BIC = :bic;
                """;

        List<Long> queryResult = template.query(
                sql,
                Map.of("bic", bic),
                (rs, row) -> CommonMapper.getLong(rs, row));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": BankRepositoryImpl findTargetIdByBic");
        }
    }

    @Override
    public Long findTargetIdByBicOrException(String bic) {
        return findTargetIdByBic(bic)
                .orElseThrow(() -> new SelfException(E_DB_600, ": BankRepositoryImpl findTargetIdByBicOrException"));
    }
}
