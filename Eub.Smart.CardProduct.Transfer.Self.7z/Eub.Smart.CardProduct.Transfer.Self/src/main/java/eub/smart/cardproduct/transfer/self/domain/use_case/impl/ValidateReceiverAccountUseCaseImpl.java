package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.core.util.LangUtil;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.repository.MessageSourceRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.ValidateReceiverAccountUseCase;

import java.util.Locale;

import static eub.smart.cardproduct.transfer.self.core.constant.BundleCode.ERROR_MESSAGE_VLSS;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_LG_800_VLSS;

public class ValidateReceiverAccountUseCaseImpl extends AbstractValidateAccountUseCase implements ValidateReceiverAccountUseCase {

    private final MessageSourceRepository messageSourceRepository;

    public ValidateReceiverAccountUseCaseImpl(MessageSourceRepository messageSourceRepository) {
        this.messageSourceRepository = messageSourceRepository;
    }

    @Override
    public void invoke(AccountData accountData, LangKey lang) {
        var bSystemType = accountData.getbSystem();
        var accountStatus = accountData.getAccountStatus();
        invoke(accountStatus, bSystemType, lang);
    }

    @Override
    public void validateWay4Acc(String accountStatus, LangKey lang) {
        if (!WAY4_RECEIVER_ACC_VALID_STATUS.contains(accountStatus)) {
            var locale = LangUtil.get(lang);
            var message = messageSourceRepository.getMessage(ERROR_MESSAGE_VLSS, locale);
            throw new SelfException(
                    E_LG_800_VLSS,
                    ": Way4 receiver acc status " + accountStatus,
                    message);
        }
    }

    @Override
    public void validateRsbkAcc(String accountStatus, LangKey lang) {
        if (!RSBK_ACC_VALID_STATUS.contains(accountStatus)) {
            var locale = LangUtil.get(lang);
            var message = messageSourceRepository.getMessage(ERROR_MESSAGE_VLSS, locale);
            throw new SelfException(
                    E_LG_800_VLSS,
                    ": RSBK receiver acc status " + accountStatus,
                    message);
        }
    }
}
