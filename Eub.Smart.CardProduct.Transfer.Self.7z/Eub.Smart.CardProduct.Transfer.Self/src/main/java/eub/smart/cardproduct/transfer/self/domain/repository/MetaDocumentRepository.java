package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.out.MetaDocumentOut;

import java.util.Optional;

public interface MetaDocumentRepository {
    Optional<MetaDocumentOut> find(Long targetId, String targetTable, String docType);
    MetaDocumentOut findOrException(Long targetId, String targetTable, String docType);

}
