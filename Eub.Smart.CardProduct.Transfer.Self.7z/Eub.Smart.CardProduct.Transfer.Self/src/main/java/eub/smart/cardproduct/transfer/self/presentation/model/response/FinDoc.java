package eub.smart.cardproduct.transfer.self.presentation.model.response;

import io.swagger.v3.oas.annotations.media.Schema;

import java.math.BigDecimal;
import java.util.Date;

public class FinDoc {

    @Schema(description = "id")
    private Long id;
    @Schema(description = "Тип Платежного поручения")
    private String docType;
    @Schema(description = "Пользователь id")
    private Long userId;
    @Schema(description = "Тип валюты")
    private String currency;
    @Schema(description = "Сумма")
    private BigDecimal amount;
    @Schema(description = "Сумма комиссии")
    private BigDecimal feeAmount;
    @Schema(description = "Тип валюты комиссии")
    private String feeCurrency;
    @Schema(description = "Дата создания")
    private Date dateCreated;
    @Schema(description = "Дата исполнения")
    private Date dateScheduled;
    @Schema(description = "Признак срочности")
    private Boolean flagUrgent;
    @Schema(description = "Признак шаблона")
    private Boolean flagTemplate;
    @Schema(description = "Front End id")
    private String frontEnd;

    public Long getId() {
        return id;
    }

    public String getDocType() {
        return docType;
    }

    public Long getUserId() {
        return userId;
    }

    public String getCurrency() {
        return currency;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public BigDecimal getFeeAmount() {
        return feeAmount;
    }

    public String getFeeCurrency() {
        return feeCurrency;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public Date getDateScheduled() {
        return dateScheduled;
    }

    public Boolean getFlagUrgent() {
        return flagUrgent;
    }

    public Boolean getFlagTemplate() {
        return flagTemplate;
    }

    public String getFrontEnd() {
        return frontEnd;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setDocType(String docType) {
        this.docType = docType;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public void setFeeAmount(BigDecimal feeAmount) {
        this.feeAmount = feeAmount;
    }

    public void setFeeCurrency(String feeCurrency) {
        this.feeCurrency = feeCurrency;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public void setDateScheduled(Date dateScheduled) {
        this.dateScheduled = dateScheduled;
    }

    public void setFlagUrgent(Boolean flagUrgent) {
        this.flagUrgent = flagUrgent;
    }

    public void setFlagTemplate(Boolean flagTemplate) {
        this.flagTemplate = flagTemplate;
    }

    public void setFrontEnd(String frontEnd) {
        this.frontEnd = frontEnd;
    }
}
