package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.repository.RnnRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.GenerateRrnBrrnUseCase;

public class GenerateRrnBrrnUseCaseImpl implements GenerateRrnBrrnUseCase {

    private final RnnRepository rnnRepository;

    public GenerateRrnBrrnUseCaseImpl(RnnRepository rnnRepository) {
        this.rnnRepository = rnnRepository;
    }

    @Override
    public RrnBrrn invoke() {
        var rrn = rnnRepository.generateRnnOrException();
        var brrn = rnnRepository.generateRnnOrException();
        var rrnBrrn = new RrnBrrn();
        rrnBrrn.setRrn(rrn);
        rrnBrrn.setBrrn(brrn);
        return rrnBrrn;
    }
}
