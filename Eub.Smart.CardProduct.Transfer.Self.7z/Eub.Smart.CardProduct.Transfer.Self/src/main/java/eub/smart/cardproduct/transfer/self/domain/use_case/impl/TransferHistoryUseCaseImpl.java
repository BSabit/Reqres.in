package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.domain.model.common.Target;
import eub.smart.cardproduct.transfer.self.domain.model.in.StoryIn;
import eub.smart.cardproduct.transfer.self.domain.model.in.TransferHistoryIn;
import eub.smart.cardproduct.transfer.self.domain.model.out.StoryOut;
import eub.smart.cardproduct.transfer.self.domain.repository.*;
import eub.smart.cardproduct.transfer.self.domain.use_case.TransferHistoryUseCase;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import java.util.Optional;
import java.util.stream.Collectors;

import static eub.smart.cardproduct.transfer.self.core.constant.DocType.I92A;
import static eub.smart.cardproduct.transfer.self.core.constant.FinDocType.SELF;
import static eub.smart.cardproduct.transfer.self.core.constant.TargetTable.*;

public class TransferHistoryUseCaseImpl implements TransferHistoryUseCase {

    private final Logger log = LogManager.getLogger(getClass());

    private final TransferHistoryRepository transferHistoryRepository;
    private final MetaDocumentRepository metaDocumentRepository;
    private final FinDocTypeRepository finDocTypeRepository;
    private final BankRepository bankRepository;
    private final IpsOrgRepository ipsOrgRepository;

    public TransferHistoryUseCaseImpl(TransferHistoryRepository transferHistoryRepository,
                                      MetaDocumentRepository metaDocumentRepository,
                                      FinDocTypeRepository finDocTypeRepository,
                                      BankRepository bankRepository,
                                      IpsOrgRepository ipsOrgRepository) {
        this.transferHistoryRepository = transferHistoryRepository;
        this.metaDocumentRepository = metaDocumentRepository;
        this.finDocTypeRepository = finDocTypeRepository;
        this.bankRepository = bankRepository;
        this.ipsOrgRepository = ipsOrgRepository;
    }

    @Override
    public Page<StoryOut> invoke(TransferHistoryIn in, Pageable pageable, LangKey lang) {
        var historyInPage = transferHistoryRepository.findByDatePeriodAndUserId(in.from(), in.to(), pageable, lang);
        var historyOut = historyInPage.stream()
                .map(storyIn -> toStoryOut(lang, storyIn))
                .collect(Collectors.toList());
        return new PageImpl<>(historyOut, pageable, historyInPage.getTotalElements());
    }

    private StoryOut toStoryOut(LangKey lang, StoryIn storyIn) {
        return defineTarget(storyIn)
                .map(target -> metaDocumentRepository.find(target.id(), target.table(), I92A)
                        .map(metaDocumentOut -> new StoryOut(storyIn, metaDocumentOut.imageUrl(), lang))
                        .orElseGet(() -> new StoryOut(storyIn, lang)))
                .orElseGet(() -> new StoryOut(storyIn, lang));
    }

    private Optional<Target> defineTarget(StoryIn storyIn) {
        var targetKey = storyIn.imageDefinition();
        var finDocType = storyIn.finDocType();

        if (SELF.equals(finDocType)) {
            return defineFinDocTypeTarget(targetKey);
        } else {
            return defineTargetByBic(targetKey);
        }
    }
    
    private Optional<Target> defineFinDocTypeTarget(String targetKey) {
        var optSelfTargetId = finDocTypeRepository.findTargetIdById(targetKey);
        if (optSelfTargetId.isPresent()) {
            Long targetId = optSelfTargetId.get();
            return Optional.of(new Target(targetId, FIN_DOC_TYPE));
        }
        log.error("Target id not found by this fin doc type: {}", targetKey);
        return Optional.empty();
    }

    private Optional<Target> defineTargetByBic(String targetKey) {
        var optBankTargetId = bankRepository.findTargetIdByBic(targetKey);
        if (optBankTargetId.isPresent()) {
            Long targetId = optBankTargetId.get();
            return Optional.of(new Target(targetId, BANK));
        }
        var optIpsOrgTargetId = ipsOrgRepository.findTargetIdByBic(targetKey);
        if (optIpsOrgTargetId.isPresent()) {
            Long targetId = optIpsOrgTargetId.get();
            return Optional.of(new Target(targetId, IPS_ORG));
        }
        log.error("Target id not found by this bic: {}", targetKey);
        return Optional.empty();
    }

}
