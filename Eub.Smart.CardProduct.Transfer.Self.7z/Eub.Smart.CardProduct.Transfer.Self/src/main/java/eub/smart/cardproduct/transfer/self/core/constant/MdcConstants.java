package eub.smart.cardproduct.transfer.self.core.constant;

public interface MdcConstants {

    String X_FORWARDED_FOR = "X-Forwarded-For";
}
