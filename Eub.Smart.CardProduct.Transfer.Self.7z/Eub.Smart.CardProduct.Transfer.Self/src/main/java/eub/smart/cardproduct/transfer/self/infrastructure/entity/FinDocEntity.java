package eub.smart.cardproduct.transfer.self.infrastructure.entity;

import javax.persistence.*;

import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "FinDoc")
public class FinDocEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "FinDoc_ID")
    private Long id;

    @Column(name = "FinDocType_IDREF", nullable = false)
    private String docType;

    @Column(name = "User_IDREF", nullable = false)
    private Long userId;

    @Column(name = "BLOB")
    private byte[] blob;

    @Column(name = "Account_IDREF")
    private Long accountId;

    @Column(name = "Currency", nullable = false)
    private String currency;

    @Column(name = "Amount", nullable = false)
    private BigDecimal amount;

    @Column(name = "Fee", nullable = false)
    private BigDecimal feeAmount;

    @Column(name = "Details")
    private String details;

    @Column(name = "DateCreated", nullable = false)
    private Date dateCreated;

    @Column(name = "DateSigned")
    private Date dateSigned;

    @Column(name = "DateScheduled", nullable = false)
    private Date dateScheduled;

    @Column(name = "IsUrgent", nullable = false)
    private Boolean flagUrgent;

    @Column(name = "FeeCurrency", nullable = false)
    private String feeCurrency;

    @Column(name = "IsTemplate", nullable = false)
    private Boolean flagTemplate = false;

    @Column(name = "LockVersion", nullable = false)
    private int lockVersion = 0;

    @Column(name = "FinDoc_IDREF")
    private Long finDocId;

    @Column(name = "FrontEnd_IDREF")
    private String frontEnd;

    public Long getId() {
        return id;
    }

    public String getDocType() {
        return docType;
    }

    public Long getUserId() {
        return userId;
    }

    public byte[] getBlob() {
        return blob;
    }

    public Long getAccountId() {
        return accountId;
    }

    public String getCurrency() {
        return currency;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public BigDecimal getFeeAmount() {
        return feeAmount;
    }

    public String getDetails() {
        return details;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public Date getDateSigned() {
        return dateSigned;
    }

    public Date getDateScheduled() {
        return dateScheduled;
    }

    public Boolean getFlagUrgent() {
        return flagUrgent;
    }

    public String getFeeCurrency() {
        return feeCurrency;
    }

    public Boolean getFlagTemplate() {
        return flagTemplate;
    }

    public int getLockVersion() {
        return lockVersion;
    }

    public Long getFinDocId() {
        return finDocId;
    }

    public String getFrontEnd() {
        return frontEnd;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setDocType(String docType) {
        this.docType = docType;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setBlob(byte[] blob) {
        this.blob = blob;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public void setFeeAmount(BigDecimal feeAmount) {
        this.feeAmount = feeAmount;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public void setDateSigned(Date dateSigned) {
        this.dateSigned = dateSigned;
    }

    public void setDateScheduled(Date dateScheduled) {
        this.dateScheduled = dateScheduled;
    }

    public void setFlagUrgent(Boolean flagUrgent) {
        this.flagUrgent = flagUrgent;
    }

    public void setFeeCurrency(String feeCurrency) {
        this.feeCurrency = feeCurrency;
    }

    public void setFlagTemplate(Boolean flagTemplate) {
        this.flagTemplate = flagTemplate;
    }

    public void setLockVersion(int lockVersion) {
        this.lockVersion = lockVersion;
    }

    public void setFinDocId(Long finDocId) {
        this.finDocId = finDocId;
    }

    public void setFrontEnd(String frontEnd) {
        this.frontEnd = frontEnd;
    }
}
