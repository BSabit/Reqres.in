package eub.smart.cardproduct.transfer.self.domain.model.grpc;

public class TransferTcResponse {

    private Integer status;
    private String message;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "TransferTcResponse{" +
                "status=" + status +
                ", message=" + message +
                '}';
    }
}
