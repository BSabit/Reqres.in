package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.Usage;
import eub.smart.cardproduct.transfer.self.domain.repository.UsageRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.GetClientUsageUseCase;

public class GetClientUsageUseCaseImpl implements GetClientUsageUseCase {

    private final UsageRepository usageRepository;

    public GetClientUsageUseCaseImpl(UsageRepository usageRepository) {
        this.usageRepository = usageRepository;
    }

    @Override
    public Usage invoke(Long clientId, Long userId) {
        return usageRepository.findByClintIdAndUserIdOrException(clientId, userId);
    }
}
