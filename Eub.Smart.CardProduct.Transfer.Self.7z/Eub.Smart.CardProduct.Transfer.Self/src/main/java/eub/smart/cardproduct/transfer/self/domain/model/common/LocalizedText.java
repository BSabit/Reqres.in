package eub.smart.cardproduct.transfer.self.domain.model.common;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.core.util.LangUtil;

import java.util.Locale;

public record LocalizedText(
        String textRu,
        String textKk,
        String textEn
) {

    public String text(LangKey langKey) {
        return switch (langKey) {
            case RU -> textRu;
            case KK -> textKk;
            case EN -> textEn;
        };
    }

    public String text(Locale locale) {
        return LangUtil.RU.equals(locale) ? textRu :
               LangUtil.KK.equals(locale) ? textKk :
               LangUtil.EN.equals(locale) ? textEn :
               textRu;
    }
}
