package eub.smart.cardproduct.transfer.self.infrastructure.entity;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "FinDocState")
public class FinDocState {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "FinDocState_ID")
    private Long id;

    @Column(name = "FinDoc_IDREF")
    private Long finDocId;

    @Column(name = "Attempts")
    private int attempts;

    @Column(name = "StatusDate")
    private Date statusDate;

    @Column(name = "TechScheduled")
    private Date techScheduled;

    @Column(name = "DocTechStatus_IDREF")
    private String docTechStatus;

    @Column(name = "DocTechStatusComment")
    private String docTechStatusComment;

    @Column(name = "Process_ID")
    private String processId;

    @Column(name = "isHidden")
    private boolean hidden;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getFinDocId() {
        return finDocId;
    }

    public void setFinDocId(Long finDoc) {
        this.finDocId = finDoc;
    }

    public int getAttempts() {
        return attempts;
    }

    public void setAttempts(int attempts) {
        this.attempts = attempts;
    }

    public Date getStatusDate() {
        return statusDate;
    }

    public void setStatusDate(Date statusDate) {
        this.statusDate = statusDate;
    }

    public Date getTechScheduled() {
        return techScheduled;
    }

    public void setTechScheduled(Date techScheduled) {
        this.techScheduled = techScheduled;
    }

    public String getDocTechStatus() {
        return docTechStatus;
    }

    public void setDocTechStatus(String docTechStatus) {
        this.docTechStatus = docTechStatus;
    }

    public String getDocTechStatusComment() {
        return docTechStatusComment;
    }

    public void setDocTechStatusComment(String docTechStatusComment) {
        this.docTechStatusComment = docTechStatusComment;
    }

    public String getProcessId() {
        return processId;
    }

    public void setProcessId(String processId) {
        this.processId = processId;
    }

    public boolean isHidden() {
        return hidden;
    }

    public void setHidden(boolean hidden) {
        this.hidden = hidden;
    }
}
