package eub.smart.cardproduct.transfer.self.domain.model.common;

public record Target(Long id, String table) {
}
