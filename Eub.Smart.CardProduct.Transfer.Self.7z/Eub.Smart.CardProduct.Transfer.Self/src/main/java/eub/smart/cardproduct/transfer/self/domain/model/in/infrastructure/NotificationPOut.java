package eub.smart.cardproduct.transfer.self.domain.model.in.infrastructure;

import java.math.BigDecimal;
import java.util.Date;

public record NotificationPOut(
        Long finDocId,
        BigDecimal amount,
        String transferCurrency,
        String accountCurrency,
        String accountNumber,
        String firstName,
        String lastName,
        Date createdDate) {
}
