package eub.smart.cardproduct.transfer.self.domain.model.base_model;

import eub.smart.cardproduct.transfer.self.core.model.UserDetails;

public class SenderDetails {

    private Long userId;
    private Long clientId;
    private Long personId;
    private String phoneNumber;

    public SenderDetails() {
    }
    public SenderDetails(UserDetails userDetails) {
        this.userId = userDetails.getUserId();
        this.clientId = userDetails.getClientId();
        this.personId = userDetails.getPersonId();
        this.phoneNumber = userDetails.getPreferredUsername();
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getClientId() {
        return clientId;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public Long getPersonId() {
        return personId;
    }

    public void setPersonId(Long personId) {
        this.personId = personId;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Override
    public String toString() {
        return "SenderDetails{" +
                "userId=" + userId +
                ", clientId=" + clientId +
                ", personId=" + personId +
                ", phoneNumber=" + phoneNumber +
                '}';
    }
}
