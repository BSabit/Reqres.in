package eub.smart.cardproduct.transfer.self.presentation.model.response;

import io.swagger.v3.oas.annotations.media.Schema;

public class Transfer {

    @Schema(description = "Данные по финдоку")
    private FinDoc finDoc;
    @Schema(description = "Тип")
    private String type;
    @Schema(description = "БИК получателя")
    private String receiverBic;
    @Schema(description = "Номер аккаунта получателя")
    private String receiverAccountNumber;
    @Schema(description = "Имя получателя")
    private String receiverName;
    @Schema(description = "Признак резидентства получателя")
    private boolean flagReceiverResident;
    @Schema(description = "Сектор экономики")
    private String secoId;
    @Schema(description = "КНП-Код назначения платежа")
    private String knpId;
    @Schema(description = "Тип валюты саб аккоунта получателя")
    private String receiverSubAccountCurrency;
    @Schema(description = "Тип валюты саб аккоунта отправителя")
    private String senderSubAccountCurrency;

    public FinDoc getFinDoc() {
        return finDoc;
    }

    public void setFinDoc(FinDoc finDoc) {
        this.finDoc = finDoc;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getReceiverBic() {
        return receiverBic;
    }

    public void setReceiverBic(String receiverBic) {
        this.receiverBic = receiverBic;
    }

    public String getReceiverAccountNumber() {
        return receiverAccountNumber;
    }

    public void setReceiverAccountNumber(String receiverAccountNumber) {
        this.receiverAccountNumber = receiverAccountNumber;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public boolean isFlagReceiverResident() {
        return flagReceiverResident;
    }

    public void setFlagReceiverResident(boolean flagReceiverResident) {
        this.flagReceiverResident = flagReceiverResident;
    }

    public String getSecoId() {
        return secoId;
    }

    public void setSecoId(String secoId) {
        this.secoId = secoId;
    }

    public String getKnpId() {
        return knpId;
    }

    public void setKnpId(String knpId) {
        this.knpId = knpId;
    }

    public String getReceiverSubAccountCurrency() {
        return receiverSubAccountCurrency;
    }

    public void setReceiverSubAccountCurrency(String receiverSubAccountCurrency) {
        this.receiverSubAccountCurrency = receiverSubAccountCurrency;
    }

    public String getSenderSubAccountCurrency() {
        return senderSubAccountCurrency;
    }

    public void setSenderSubAccountCurrency(String senderSubAccountCurrency) {
        this.senderSubAccountCurrency = senderSubAccountCurrency;
    }
}
