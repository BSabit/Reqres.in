package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.BSystem;
import eub.smart.cardproduct.transfer.self.domain.repository.BSystemRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.BSystemMapper;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.*;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isOneResult;

@Primary
@Repository
public class BSystemRepositoryImpl implements BSystemRepository {

    private final NamedParameterJdbcTemplate template;

    public BSystemRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<BSystem> findByFinDocId(Long finDocId) {
        String sql = """ 
                select BSCS.BSystem_IDREF   as senderBSystem, 
                       BSCR.BSystem_IDREF   as receiverBSystem
                from FinDoc F
                         join Account AccS on F.Account_IDREF = AccS.Account_ID
                         join BSystemClient BSCS on AccS.BSystemClient_IDREF = BSCS.BSystemClient_ID
                         join Transfer T on F.FinDoc_ID = T.FinDoc_IDREF
                         join Account AccR on T.Receiver_Account = AccR.Number
                         join BSystemClient BSCR on AccR.BSystemClient_IDREF = BSCR.BSystemClient_ID
                where F.FinDoc_ID = :finDocId
                """;

        List<Map<String, Object>> queryResult = template.queryForList(sql, Map.of("finDocId", finDocId));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .map(BSystemMapper::toTransferModel);
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": BSystemRepositoryImpl findByFinDocId");
        }
    }

    @Override
    public BSystem findByFinDocIdOrException(Long finDocId) {
        return findByFinDocId(finDocId)
                .orElseThrow(() -> new SelfException(E_DB_600, ": BSystemRepositoryImpl findByFinDocIdOrException"));
    }

    @Override
    public Optional<Integer> findInactiveBSystemCount(String bSystem) {
        String query = ("""
                SELECT count(1) as activeSystemsCount
                            FROM [dbo].[AccessibilityAccSystems]
                            WHERE AnnouncementStatus_IdRef = 'ACTV'
                              and BSystem_IdRef = :bSystem
                              and GetDate() BETWEEN StartDate AND EndDate
                """);
        List<Integer> queryResult = template.query(query, Map.of("bSystem", bSystem), BSystemMapper::toActiveBSystemModel);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": BSystemRepositoryImpl findInactiveBSystemCount");
        }
    }

    @Override
    public Integer findInactiveBSystemCountOrException(String bSystem) {
        return findInactiveBSystemCount(bSystem)
                .orElseThrow(() -> new SelfException(E_DB_600, ": BSystemRepositoryImpl findInactiveBSystemCountOrException"));
    }
}
