package eub.smart.cardproduct.transfer.self.core.enums;

public enum LangKey {
    RU,
    KK,
    EN
}
