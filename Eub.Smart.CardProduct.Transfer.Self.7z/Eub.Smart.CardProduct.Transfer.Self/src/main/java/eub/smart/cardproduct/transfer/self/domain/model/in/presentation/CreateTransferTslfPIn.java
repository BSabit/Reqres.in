package eub.smart.cardproduct.transfer.self.domain.model.in.presentation;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.CurrencyRate;

import java.math.BigDecimal;
import java.util.List;

public record CreateTransferTslfPIn(
        String senderAccountNumber,
        String receiverAccountNumber,
        BigDecimal senderAmount,
        BigDecimal receiverAmount,
        String senderCurrency,
        String receiverCurrency,
        List<CurrencyRate> currencyRates
) {
}
