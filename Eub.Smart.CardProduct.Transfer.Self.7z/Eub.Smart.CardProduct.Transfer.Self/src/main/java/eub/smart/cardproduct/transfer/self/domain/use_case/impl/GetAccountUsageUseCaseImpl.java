package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.Usage;
import eub.smart.cardproduct.transfer.self.domain.repository.UsageRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.GetAccountUsageUseCase;

public class GetAccountUsageUseCaseImpl implements GetAccountUsageUseCase {

    private final UsageRepository usageRepository;

    public GetAccountUsageUseCaseImpl(UsageRepository usageRepository) {
        this.usageRepository = usageRepository;
    }

    @Override
    public Usage invoke(String senderAccountNumber) {
        return usageRepository.findByAccountNumberOrException(senderAccountNumber);
    }
}
