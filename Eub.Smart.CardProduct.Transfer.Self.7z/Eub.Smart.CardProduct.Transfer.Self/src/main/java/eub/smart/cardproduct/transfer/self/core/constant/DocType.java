package eub.smart.cardproduct.transfer.self.core.constant;

public interface DocType {

    String I92A = "I92A";
}
