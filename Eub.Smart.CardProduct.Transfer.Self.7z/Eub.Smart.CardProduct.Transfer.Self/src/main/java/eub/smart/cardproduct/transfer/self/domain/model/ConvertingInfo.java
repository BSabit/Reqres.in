package eub.smart.cardproduct.transfer.self.domain.model;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.CurrencyRate;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;


public class ConvertingInfo {

    private BigDecimal correctAmount;

    private BigDecimal receiverAmount;

    private List<CurrencyRate> currencyRates;

    public ConvertingInfo() {
        this.currencyRates = new ArrayList<>();
    }

    public ConvertingInfo(BigDecimal correctAmount, BigDecimal receiverAmount, List<CurrencyRate> currencyRates) {
        this.correctAmount = correctAmount;
        this.receiverAmount = receiverAmount;
        this.currencyRates = currencyRates;
    }

    public ConvertingInfo(BigDecimal correctAmount, BigDecimal receiverAmount, CurrencyRate... currencyRates) {
        this.correctAmount = correctAmount;
        this.receiverAmount = receiverAmount;
        this.currencyRates = new ArrayList<>();
        this.currencyRates.addAll(List.of(currencyRates));
    }

    public BigDecimal getCorrectAmount() {
        return correctAmount;
    }

    public void setCorrectAmount(BigDecimal correctAmount) {
        this.correctAmount = correctAmount;
    }

    public BigDecimal getReceiverAmount() {
        return receiverAmount;
    }

    public void setReceiverAmount(BigDecimal receiverAmount) {
        this.receiverAmount = receiverAmount;
    }

    public List<CurrencyRate> getCurrencyRates() {
        return currencyRates;
    }

    public void setCurrencyRates(List<CurrencyRate> currencyRates) {
        this.currencyRates = currencyRates;
    }

    @Override
    public String toString() {
        return "ConvertingInfo{" +
                "correctAmount=" + correctAmount +
                ", receiverAmount=" + receiverAmount +
                ", currencyRates=" + currencyRates +
                '}';
    }
}
