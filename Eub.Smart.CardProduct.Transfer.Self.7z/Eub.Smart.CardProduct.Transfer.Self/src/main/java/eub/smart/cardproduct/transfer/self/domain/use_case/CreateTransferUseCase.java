package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.FinDoc;
import eub.smart.cardproduct.transfer.self.domain.model.CreateTransferAccountInfo;
import eub.smart.cardproduct.transfer.self.domain.model.Transfer;

import java.math.BigDecimal;

public interface CreateTransferUseCase {

    Transfer invoke(FinDoc finDoc, CreateTransferAccountInfo senderAccount, CreateTransferAccountInfo receiverAccount, String knpCode, BigDecimal receiverAmount, String currencyRates, String receiverCurrency);
}
