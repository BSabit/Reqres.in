package eub.smart.cardproduct.transfer.self.domain.model.in;

import java.time.LocalDate;

public record TransferHistoryIn(
        LocalDate from,
        LocalDate to
) {
}
