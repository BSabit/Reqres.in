package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.CreateTransferAccountInfo;
import eub.smart.cardproduct.transfer.self.domain.model.create_transfer.CreateTransfer;
import eub.smart.cardproduct.transfer.self.domain.model.in.presentation.CreateTransferDataPIn;

public interface CreateTransferDataUseCase {

    CreateTransfer invoke(CreateTransferDataPIn createTransferDataPIn, CreateTransferAccountInfo senderAccount, CreateTransferAccountInfo receiverAccount);
}
