# Введение 
TODO: кратко опишите проект. В этом разделе объясняются цели и задачи этого проекта. 

# Начало работы
TODO: объясните пользователям, как запустить и настроить ваш код в их системе. В этом разделе можно предоставить следующие сведения.
1.	Процесс установки
2.	Зависимости программного обеспечения
3.	Последние выпуски
4.	Ссылки на API

# Сборка и тестирование
TODO: опишите и покажите, как выполнить сборку кода и тесты. 

# Участие
TODO: объясните, как другие пользователи и разработчики могут внести свои улучшения в ваш код. 

Если вам нужны дополнительные сведения о создании файлов сведений, ознакомьтесь со следующими [руководствами](https://docs.microsoft.com/en-us/azure/devops/repos/git/create-a-readme?view=azure-devops). Кроме того, вам, возможно, будут полезны следующие примеры файлов сведений:
- [ASP.NET Core](https://github.com/aspnet/Home)
- [Visual Studio Code](https://github.com/Microsoft/vscode)
- [Chakra Core](https://github.com/Microsoft/ChakraCore)

#Deploy
- project_name: **smart-cardproduct-transfer-self**
- namespace: **smart-cardproduct**
- image: **nexus-dev.eub.kz:8085/repository/smart-cardproduct/smart-cardproduct-transfer-self: "IMAGE"**
- dns: **smart-cardproduct-transfer-self.devk8s.eub.kz**
- port: **8080**
- limit: **500m, 500Mi**
- request: **500m, 500Mi**