package kz.zenwei.authorization.infrastructure.entity;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
public class UserEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String username;
    private String password;
    private String email;
    private String role;
}
