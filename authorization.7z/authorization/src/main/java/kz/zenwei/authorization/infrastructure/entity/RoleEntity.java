package kz.zenwei.authorization.infrastructure.entity;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
public class RoleEntity {

    @Id
    private long id;
    private String name;
}
