package kz.zenwei.authorization.domain.model;

public class Role {
}
